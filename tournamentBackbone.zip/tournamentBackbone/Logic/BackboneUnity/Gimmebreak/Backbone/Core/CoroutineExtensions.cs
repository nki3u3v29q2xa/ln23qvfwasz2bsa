﻿using System;
using System.Collections;
using UnityEngine;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000061 RID: 97
	public static class CoroutineExtensions
	{
		// Token: 0x06000485 RID: 1157 RVA: 0x000161C4 File Offset: 0x000143C4
		public static Coroutine StartCoroutine<T>(this MonoBehaviour target, IEnumerator routine, out AsyncOperation<T> asyncOperation)
		{
			asyncOperation = new AsyncOperation<T>(routine, false);
			((IAsyncOperation)asyncOperation).AutoThrowExecutionException = true;
			return target.StartCoroutine(asyncOperation);
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x000161F0 File Offset: 0x000143F0
		public static Coroutine Run<T>(this AsyncOperation<T> asyncOperation, MonoBehaviour target)
		{
			((IAsyncOperation)asyncOperation).AutoThrowExecutionException = true;
			return target.StartCoroutine(asyncOperation);
		}

		// Token: 0x06000487 RID: 1159 RVA: 0x00016214 File Offset: 0x00014414
		public static AsyncOperation<T> ResultCallback<T>(this AsyncOperation<T> asyncOperation, Action<T> result)
		{
			return new AsyncOperation<T>(asyncOperation.InjectResultCallback(result), false)
			{
				AutoThrowExecutionException = true
			};
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x000053F3 File Offset: 0x000035F3
		private static IEnumerator InjectResultCallback<T>(this AsyncOperation<T> asyncOperation, Action<T> result)
		{
			yield return asyncOperation;
			bool flag = result != null;
			if (flag)
			{
				result(asyncOperation.ReturnValue);
			}
			yield return new AsyncOperation<T>.Result(asyncOperation.ReturnValue);
			yield break;
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x00016240 File Offset: 0x00014440
		public static AsyncOperation<T> FinishCallback<T>(this AsyncOperation<T> asyncOperation, Action callback)
		{
			return new AsyncOperation<T>(asyncOperation.InjectFinishCallback(callback), false)
			{
				AutoThrowExecutionException = true
			};
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x00005409 File Offset: 0x00003609
		private static IEnumerator InjectFinishCallback<T>(this AsyncOperation<T> asyncOperation, Action callback)
		{
			yield return asyncOperation;
			bool flag = callback != null;
			if (flag)
			{
				callback();
			}
			yield return new AsyncOperation<T>.Result(asyncOperation.ReturnValue);
			yield break;
		}
	}
}
