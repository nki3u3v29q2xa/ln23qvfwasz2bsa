﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000062 RID: 98
	internal interface IAsyncOperation
	{
		// Token: 0x1700014F RID: 335
		// (get) Token: 0x0600048B RID: 1163
		// (set) Token: 0x0600048C RID: 1164
		bool AutoThrowExecutionException { get; set; }

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x0600048D RID: 1165
		// (set) Token: 0x0600048E RID: 1166
		bool IsNestedOperation { get; set; }

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x0600048F RID: 1167
		Exception ExecutionException { get; }
	}
}
