﻿using System;
using System.Collections.Generic;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000068 RID: 104
	[Serializable]
	public class GameData
	{
		// Token: 0x1700015E RID: 350
		// (get) Token: 0x060004DB RID: 1243 RVA: 0x0000556F File Offset: 0x0000376F
		// (set) Token: 0x060004DC RID: 1244 RVA: 0x00005577 File Offset: 0x00003777
		public string GameId { get; set; }

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x060004DD RID: 1245 RVA: 0x00005580 File Offset: 0x00003780
		// (set) Token: 0x060004DE RID: 1246 RVA: 0x00005588 File Offset: 0x00003788
		public SerializableDictionary<string, string> CustomProperties { get; set; }

		// Token: 0x060004DF RID: 1247 RVA: 0x00005591 File Offset: 0x00003791
		public GameData()
		{
			this.CustomProperties = new SerializableDictionary<string, string>();
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x00017224 File Offset: 0x00015424
		internal void LoadJsonGameData(JSONObject data)
		{
			bool flag = data != null && !data.IsNull && data.HasField(GameData.FIELD_PROPERTIES) && !data[GameData.FIELD_PROPERTIES].IsNull;
			if (flag)
			{
				this.CustomProperties.Clear();
				List<JSONObject> list = data[GameData.FIELD_PROPERTIES].list;
				for (int i = 0; i < list.Count; i++)
				{
					JSONObject jsonobject = list[i];
					bool flag2 = jsonobject.HasField(GameData.FIELD_NAME) && jsonobject.HasField(GameData.FIELD_VALUE);
					if (flag2)
					{
						string str = jsonobject[GameData.FIELD_NAME].str;
						string str2 = jsonobject[GameData.FIELD_VALUE].str;
						bool flag3 = !this.CustomProperties.ContainsKey(str);
						if (flag3)
						{
							this.CustomProperties.Add(str, str2);
						}
					}
				}
			}
		}

		// Token: 0x04000398 RID: 920
		private static readonly string FIELD_PROPERTIES = "properties";

		// Token: 0x04000399 RID: 921
		private static readonly string FIELD_NAME = "@name";

		// Token: 0x0400039A RID: 922
		private static readonly string FIELD_VALUE = "@value";
	}
}
