﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200006E RID: 110
	public class ServerTime
	{
		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000534 RID: 1332 RVA: 0x00017B3C File Offset: 0x00015D3C
		public static DateTime UtcNow
		{
			get
			{
				return DateTime.UtcNow - ServerTime.compensationTimeStamp;
			}
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x0000582E File Offset: 0x00003A2E
		public static void UpdateCompensationTimeStamp(DateTime serverTime)
		{
			ServerTime.compensationTimeStamp = DateTime.UtcNow - serverTime;
		}

		// Token: 0x040003B5 RID: 949
		private static TimeSpan compensationTimeStamp;
	}
}
