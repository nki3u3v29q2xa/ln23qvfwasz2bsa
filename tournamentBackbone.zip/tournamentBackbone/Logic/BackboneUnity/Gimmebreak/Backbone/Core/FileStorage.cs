﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Unity.IO.Compression;
using UnityEngine;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000064 RID: 100
	public class FileStorage
	{
		// Token: 0x17000158 RID: 344
		// (get) Token: 0x0600049E RID: 1182 RVA: 0x0000546E File Offset: 0x0000366E
		// (set) Token: 0x0600049F RID: 1183 RVA: 0x00005475 File Offset: 0x00003675
		public static string RootFolder { get; set; }

		// Token: 0x060004A0 RID: 1184 RVA: 0x0001657C File Offset: 0x0001477C
		public static void Initialize()
		{
			bool flag = FileStorage.fileStorageProvider == null;
			if (flag)
			{
				FileStorage.fileStorageProvider = new FileStorage.DefaultStorageProvider();
			}
			FileStorage.GetLocalAbsolutePath(string.Empty);
			FileStorage.GetExternalAbsolutePath(string.Empty);
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x0000547D File Offset: 0x0000367D
		public static void Initialize(IFileStorageProvider customProvider)
		{
			FileStorage.fileStorageProvider = customProvider;
			FileStorage.Initialize();
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x000165B8 File Offset: 0x000147B8
		public static bool Exists(string path)
		{
			return FileStorage.ExistsAbsolutePath(FileStorage.GetLocalAbsolutePath(path));
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x000165D8 File Offset: 0x000147D8
		public static bool ExistsAbsolutePath(string path)
		{
			return FileStorage.fileStorageProvider.FileExists(FileStorage.FormatPath(path));
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x0000548C File Offset: 0x0000368C
		public static void SaveFile(string path, byte[] data, bool useCryptography)
		{
			FileStorage.SaveFileAbsolutePath(FileStorage.GetLocalAbsolutePath(path), data, useCryptography);
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x000165FC File Offset: 0x000147FC
		public static void SaveFileAbsolutePath(string path, byte[] data, bool useCryptography)
		{
			if (useCryptography)
			{
				byte[] cryptoKey = FileStorage.GetCryptoKey(path);
				ICryptoTransform cryptoTransform = new RijndaelManaged
				{
					Key = cryptoKey,
					Mode = CipherMode.ECB,
					Padding = PaddingMode.PKCS7
				}.CreateEncryptor();
				data = cryptoTransform.TransformFinalBlock(data, 0, data.Length);
			}
			object obj = FileStorage.readWriteLock;
			lock (obj)
			{
				FileStorage.fileStorageProvider.FileSave(FileStorage.FormatPath(path), data);
			}
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x00016688 File Offset: 0x00014888
		public static byte[] LoadFile(string path, bool useCryptography)
		{
			return FileStorage.LoadFileAbsolutePath(FileStorage.GetLocalAbsolutePath(path), useCryptography);
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x000166A8 File Offset: 0x000148A8
		public static byte[] LoadFileAbsolutePath(string path, bool useCryptography)
		{
			object obj = FileStorage.readWriteLock;
			byte[] array;
			lock (obj)
			{
				array = FileStorage.fileStorageProvider.FileLoad(FileStorage.FormatPath(path));
			}
			if (useCryptography)
			{
				byte[] cryptoKey = FileStorage.GetCryptoKey(path);
				ICryptoTransform cryptoTransform = new RijndaelManaged
				{
					Key = cryptoKey,
					Mode = CipherMode.ECB,
					Padding = PaddingMode.PKCS7
				}.CreateDecryptor();
				array = cryptoTransform.TransformFinalBlock(array, 0, array.Length);
			}
			return array;
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x00016740 File Offset: 0x00014940
		private static byte[] GetCryptoKey(string path)
		{
			bool flag = path == FileStorage.GetLocalAbsolutePath(FileStorage.DEVICE_INFO_FILE);
			byte[] bytes;
			if (flag)
			{
				string text = SystemInfo.deviceModel;
				while (text.Length < 32)
				{
					text += "_vardeviceid";
				}
				text = text.Substring(0, 32);
				bytes = Encoding.UTF8.GetBytes(text);
			}
			else
			{
				string text2 = SystemInfoExtensions.GetBackboneDeviceUniqueId();
				while (text2.Length < 32)
				{
					text2 = text2 + "_" + SystemInfoExtensions.GetBackboneDeviceUniqueId();
				}
				text2 = text2.Substring(0, 32);
				bytes = Encoding.UTF8.GetBytes(text2);
			}
			return bytes;
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x0000549D File Offset: 0x0000369D
		public static void Delete(string path)
		{
			FileStorage.DeleteAbsolutePath(FileStorage.GetLocalAbsolutePath(path));
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x000054AC File Offset: 0x000036AC
		public static void DeleteAbsolutePath(string path)
		{
			FileStorage.fileStorageProvider.FileDelete(FileStorage.FormatPath(path));
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x000054C0 File Offset: 0x000036C0
		public static void DeleteDirectory(string path)
		{
			FileStorage.DeleteDirectoryAbsolutePath(FileStorage.GetLocalAbsolutePath(path));
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x000054CF File Offset: 0x000036CF
		public static void DeleteDirectoryAbsolutePath(string path)
		{
			FileStorage.fileStorageProvider.DirectoryDelete(path);
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x000167EC File Offset: 0x000149EC
		public static bool CheckDirectory(string path)
		{
			return FileStorage.CheckDirectoryAbsolutePath(FileStorage.GetLocalAbsolutePath(path));
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x0001680C File Offset: 0x00014A0C
		public static bool CheckDirectoryAbsolutePath(string path)
		{
			return FileStorage.fileStorageProvider.DirectoryExists(path);
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x000054DE File Offset: 0x000036DE
		public static void CreateDirectory(string path)
		{
			FileStorage.CreateDirectoryAbsolutePath(FileStorage.GetLocalAbsolutePath(path));
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x000054ED File Offset: 0x000036ED
		public static void CreateDirectoryAbsolutePath(string path)
		{
			FileStorage.fileStorageProvider.DirectoryCreate(path);
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x0001682C File Offset: 0x00014A2C
		public static byte[] ConvertObjectToBytes<T>(T o) where T : class
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				XmlTextWriter xmlWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
				xmlSerializer.Serialize(xmlWriter, o);
				result = memoryStream.ToArray();
			}
			return result;
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x00016890 File Offset: 0x00014A90
		public static T ConvertObjectFromBytes<T>(byte[] data) where T : class
		{
			bool flag = data == null;
			T result;
			if (flag)
			{
				result = default(T);
			}
			else
			{
				try
				{
					using (MemoryStream memoryStream = new MemoryStream(data))
					{
						XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
						XmlReader xmlReader = XmlReader.Create(memoryStream);
						T t = (T)((object)xmlSerializer.Deserialize(xmlReader));
						result = t;
					}
				}
				catch (Exception ex)
				{
					Debug.LogError(ex);
					result = default(T);
				}
			}
			return result;
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x0001692C File Offset: 0x00014B2C
		public static long SaveObjectToFile<T>(string path, T o, bool useCryptography)
		{
			long result = 0L;
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
			using (MemoryStream memoryStream = new MemoryStream())
			{
				XmlTextWriter xmlWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
				xmlSerializer.Serialize(xmlWriter, o);
				result = memoryStream.Length;
				FileStorage.SaveFile(path, memoryStream.ToArray(), useCryptography);
			}
			return result;
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x000169A8 File Offset: 0x00014BA8
		public static T LoadObjectFromFile<T>(string path, Version expectedVersion, Func<UpdateInfo, T, T> resolveOldVersion, bool useCryptography) where T : class
		{
			bool flag = FileStorage.Exists(path);
			if (flag)
			{
				try
				{
					byte[] data = FileStorage.LoadFile(path, useCryptography);
					T t = FileStorage.ConvertObjectFromBytes<T>(data);
					bool flag2 = t is ISerializeVersion;
					if (flag2)
					{
						UpdateInfo updateInfo = ((ISerializeVersion)((object)t)).Version.CompareWithNewVersion(expectedVersion);
						bool flag3 = updateInfo > UpdateInfo.NoUpdate;
						if (flag3)
						{
							bool flag4 = resolveOldVersion != null;
							if (flag4)
							{
								return resolveOldVersion(updateInfo, t);
							}
							return default(T);
						}
					}
					return t;
				}
				catch (Exception ex)
				{
					Debug.LogError(ex);
					return default(T);
				}
			}
			return default(T);
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x00016A78 File Offset: 0x00014C78
		public static T LoadObjectFromFile<T>(string path, Version expectedVersion, bool useCryptography) where T : class
		{
			return FileStorage.LoadObjectFromFile<T>(path, expectedVersion, null, useCryptography);
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x00016A94 File Offset: 0x00014C94
		public static T LoadObjectFromFile<T>(string path, bool useCryptography) where T : class
		{
			return FileStorage.LoadObjectFromFile<T>(path, new Version("0.0.0"), useCryptography);
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x00016AB8 File Offset: 0x00014CB8
		public static string FormatPath(string path)
		{
			RuntimePlatform platform = Application.platform;
			if (platform <= 25)
			{
				switch (platform)
				{
				case 0:
				case 1:
				case 8:
				case 11:
				case 13:
				case 16:
				case 17:
					break;
				case 2:
				case 7:
				case 18:
				case 19:
				case 20:
					goto IL_92;
				case 3:
				case 4:
				case 5:
				case 6:
				case 9:
				case 10:
				case 12:
				case 14:
				case 15:
					goto IL_A5;
				default:
					if (platform != 25)
					{
						goto IL_A5;
					}
					break;
				}
			}
			else
			{
				if (platform == 27)
				{
					goto IL_92;
				}
				if (platform - 31 > 1)
				{
					goto IL_A5;
				}
			}
			return path.Replace("\\", "/");
			IL_92:
			return path.Replace("/", "\\");
			IL_A5:
			return path.Replace("\\", "/");
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x00016B80 File Offset: 0x00014D80
		public static string GetLocalAbsolutePath(string path)
		{
			bool flag = !string.IsNullOrEmpty(FileStorage.internalDataPath);
			string result;
			if (flag)
			{
				result = FileStorage.FormatPath(FileStorage.internalDataPath + "\\" + path);
			}
			else
			{
				bool flag2 = !string.IsNullOrEmpty(FileStorage.RootFolder);
				if (flag2)
				{
					FileStorage.internalDataPath = FileStorage.fileStorageProvider.PersistantDataPath + "\\" + FileStorage.RootFolder;
				}
				else
				{
					FileStorage.internalDataPath = FileStorage.fileStorageProvider.PersistantDataPath;
				}
				result = FileStorage.FormatPath(FileStorage.internalDataPath + "\\" + path);
			}
			return result;
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x00016C18 File Offset: 0x00014E18
		public static string GetExternalAbsolutePath(string path)
		{
			bool flag = string.IsNullOrEmpty(FileStorage.externalPersistantDataPath);
			if (flag)
			{
				FileStorage.externalPersistantDataPath = FileStorage.fileStorageProvider.PersistantDataPath;
			}
			bool flag2 = !string.IsNullOrEmpty(FileStorage.RootFolder);
			string result;
			if (flag2)
			{
				result = FileStorage.FormatPath(string.Concat(new string[]
				{
					FileStorage.externalPersistantDataPath,
					"\\",
					FileStorage.RootFolder,
					"\\",
					path
				}));
			}
			else
			{
				result = FileStorage.FormatPath(FileStorage.externalPersistantDataPath + "\\" + path);
			}
			return result;
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x00016CA8 File Offset: 0x00014EA8
		public static void CreateExternalDirectory()
		{
			bool flag = !FileStorage.fileStorageProvider.DirectoryExists(FileStorage.GetExternalAbsolutePath(string.Empty));
			if (flag)
			{
				FileStorage.fileStorageProvider.DirectoryCreate(FileStorage.GetExternalAbsolutePath(string.Empty));
			}
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x00016CE8 File Offset: 0x00014EE8
		public static string DeflateString(string input)
		{
			string result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (DeflateStream deflateStream = new DeflateStream(memoryStream, CompressionMode.Compress))
				{
					byte[] bytes = Encoding.UTF8.GetBytes(input);
					deflateStream.Write(bytes, 0, bytes.Length);
				}
				result = Convert.ToBase64String(memoryStream.ToArray());
			}
			return result;
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x00016D64 File Offset: 0x00014F64
		public static string InflateString(string input)
		{
			string result;
			using (MemoryStream memoryStream = new MemoryStream(Convert.FromBase64String(input)))
			{
				using (DeflateStream deflateStream = new DeflateStream(memoryStream, CompressionMode.Decompress))
				{
					using (StreamReader streamReader = new StreamReader(deflateStream, Encoding.UTF8))
					{
						result = streamReader.ReadToEnd();
					}
				}
			}
			return result;
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x00016DE8 File Offset: 0x00014FE8
		public static byte[] GzipCompress(byte[] input)
		{
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream(input.Length))
			{
				using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Compress))
				{
					gzipStream.Write(input, 0, input.Length);
					gzipStream.Close();
					memoryStream.Close();
					result = memoryStream.ToArray();
				}
			}
			return result;
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x00016E60 File Offset: 0x00015060
		public static byte[] GzipDecompress(byte[] input)
		{
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream(input))
			{
				using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Decompress, true))
				{
					using (MemoryStream memoryStream2 = new MemoryStream(input.Length))
					{
						FileStorage.CopyStream(gzipStream, memoryStream2);
						gzipStream.Close();
						memoryStream2.Close();
						result = memoryStream2.ToArray();
					}
				}
			}
			return result;
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x00016EF4 File Offset: 0x000150F4
		public static void CopyStream(Stream input, Stream output)
		{
			byte[] array = new byte[32768];
			int count;
			while ((count = input.Read(array, 0, array.Length)) > 0)
			{
				output.Write(array, 0, count);
			}
		}

		// Token: 0x0400038B RID: 907
		internal static readonly string SESSION_FILE = "ls.data";

		// Token: 0x0400038C RID: 908
		internal static readonly string DEVICE_INFO_FILE = "dvc.data";

		// Token: 0x0400038D RID: 909
		internal static readonly string CLIENT_DATA_FILE = "clnt.data";

		// Token: 0x0400038E RID: 910
		private static string externalPersistantDataPath;

		// Token: 0x0400038F RID: 911
		private static string internalDataPath;

		// Token: 0x04000390 RID: 912
		private static IFileStorageProvider fileStorageProvider;

		// Token: 0x04000391 RID: 913
		private static object readWriteLock = new object();

		// Token: 0x020000F7 RID: 247
		public class DefaultStorageProvider : IFileStorageProvider
		{
			// Token: 0x17000262 RID: 610
			// (get) Token: 0x06000879 RID: 2169 RVA: 0x00024AC4 File Offset: 0x00022CC4
			public string PersistantDataPath
			{
				get
				{
					return Application.persistentDataPath;
				}
			}

			// Token: 0x0600087A RID: 2170 RVA: 0x0000709E File Offset: 0x0000529E
			public virtual void FileDelete(string path)
			{
				File.Delete(path);
			}

			// Token: 0x0600087B RID: 2171 RVA: 0x00024ADC File Offset: 0x00022CDC
			public virtual bool FileExists(string path)
			{
				return File.Exists(path);
			}

			// Token: 0x0600087C RID: 2172 RVA: 0x00024AF4 File Offset: 0x00022CF4
			public virtual byte[] FileLoad(string path)
			{
				FileStream fileStream = File.Open(path, FileMode.Open);
				byte[] array = new byte[fileStream.Length];
				fileStream.Read(array, 0, array.Length);
				fileStream.Close();
				return array;
			}

			// Token: 0x0600087D RID: 2173 RVA: 0x00024B30 File Offset: 0x00022D30
			public virtual void FileSave(string path, byte[] data)
			{
				FileStream fileStream = File.Create(path);
				fileStream.Write(data, 0, data.Length);
				fileStream.Close();
			}

			// Token: 0x0600087E RID: 2174 RVA: 0x000070A8 File Offset: 0x000052A8
			public void DirectoryCreate(string path)
			{
				Directory.CreateDirectory(path);
			}

			// Token: 0x0600087F RID: 2175 RVA: 0x000070B2 File Offset: 0x000052B2
			public void DirectoryDelete(string path)
			{
				Directory.Delete(path, true);
			}

			// Token: 0x06000880 RID: 2176 RVA: 0x00024B58 File Offset: 0x00022D58
			public bool DirectoryExists(string path)
			{
				return Directory.Exists(path);
			}
		}
	}
}
