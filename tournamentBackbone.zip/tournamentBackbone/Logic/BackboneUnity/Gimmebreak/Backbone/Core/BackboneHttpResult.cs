﻿using System;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200005A RID: 90
	public class BackboneHttpResult
	{
		// Token: 0x17000137 RID: 311
		// (get) Token: 0x06000404 RID: 1028 RVA: 0x000152F4 File Offset: 0x000134F4
		public bool ConnectionUnavailable
		{
			get
			{
				return this.IsNetworkError && this.ErrorMessage != null && this.ErrorMessage.Contains("Could not resolve host");
			}
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x06000405 RID: 1029 RVA: 0x0001532C File Offset: 0x0001352C
		public bool HasError
		{
			get
			{
				return this.IsHttpError || this.IsNetworkError;
			}
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x06000406 RID: 1030 RVA: 0x00015350 File Offset: 0x00013550
		public string ErrorMessage
		{
			get
			{
				return this.errorMessage;
			}
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x06000407 RID: 1031 RVA: 0x00015368 File Offset: 0x00013568
		public string ErrorReference
		{
			get
			{
				return this.errorReference;
			}
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000408 RID: 1032 RVA: 0x00015380 File Offset: 0x00013580
		public int ErrorCode
		{
			get
			{
				return this.errorCode;
			}
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000409 RID: 1033 RVA: 0x00015398 File Offset: 0x00013598
		public bool IsHttpError
		{
			get
			{
				return this.ResponseCode >= 400;
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x0600040A RID: 1034 RVA: 0x000153BC File Offset: 0x000135BC
		public bool IsNetworkError
		{
			get
			{
				return this.ResponseCode == -1;
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x0600040B RID: 1035 RVA: 0x000153D8 File Offset: 0x000135D8
		public int ResponseCode
		{
			get
			{
				return this.reponseCode;
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x0600040C RID: 1036 RVA: 0x000153F0 File Offset: 0x000135F0
		public JSONObject JsonResult
		{
			get
			{
				return this.jsonResult;
			}
		}

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x0600040D RID: 1037 RVA: 0x00015408 File Offset: 0x00013608
		public byte[] RawData
		{
			get
			{
				return this.rawData;
			}
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x00004E0B File Offset: 0x0000300B
		internal BackboneHttpResult(int responseCode, JSONObject jsonResult, byte[] rawData, int errorCode = -1, string errorMessage = null, string errorReference = null)
		{
			this.reponseCode = responseCode;
			this.jsonResult = jsonResult;
			this.rawData = rawData;
			this.errorCode = errorCode;
			this.errorMessage = errorMessage;
			this.errorReference = errorReference;
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x00004E42 File Offset: 0x00003042
		internal BackboneHttpResult(int responseCode, JSONObject jsonResult, int errorCode = -1, string errorMessage = null, string errorReference = null) : this(responseCode, jsonResult, null, errorCode, errorMessage, errorReference)
		{
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x00015420 File Offset: 0x00013620
		internal static BackboneHttpResult Error(string message, int errorCode = -1, string errorReference = null)
		{
			return new BackboneHttpResult(-1, null, errorCode, message, errorReference);
		}

		// Token: 0x04000365 RID: 869
		private readonly int reponseCode;

		// Token: 0x04000366 RID: 870
		private readonly string errorMessage;

		// Token: 0x04000367 RID: 871
		private readonly string errorReference;

		// Token: 0x04000368 RID: 872
		private readonly int errorCode;

		// Token: 0x04000369 RID: 873
		private readonly JSONObject jsonResult;

		// Token: 0x0400036A RID: 874
		private readonly byte[] rawData;
	}
}
