﻿using System;
using UnityEngine;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000058 RID: 88
	[CreateAssetMenu(fileName = "BackboneClientSetting", menuName = "ScriptableObjects/BackboneClientSetting", order = 1)]
	public class BackboneClientSetting : ScriptableObject
	{
		// Token: 0x04000363 RID: 867
		internal static readonly Uri serverUri = new Uri("https://backbone-client-api.azurewebsites.net");

		// Token: 0x04000364 RID: 868
		public string gameId;
	}
}
