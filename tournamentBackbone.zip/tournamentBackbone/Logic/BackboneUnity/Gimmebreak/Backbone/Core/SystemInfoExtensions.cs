﻿using System;
using UnityEngine;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200006F RID: 111
	public static class SystemInfoExtensions
	{
		// Token: 0x06000537 RID: 1335 RVA: 0x00017B60 File Offset: 0x00015D60
		public static string GetBackboneDeviceUniqueId()
		{
			bool flag = !SystemInfoExtensions.DeviceInfo.IsDeviceIdInitialized;
			if (flag)
			{
				new SystemInfoExtensions.DeviceInfo().Id = SystemInfo.deviceUniqueIdentifier;
			}
			return SystemInfoExtensions.DeviceInfo.GetId();
		}

		// Token: 0x06000538 RID: 1336 RVA: 0x0000584A File Offset: 0x00003A4A
		public static int GetPlatformId()
		{
			throw new NotImplementedException();
		}

		// Token: 0x02000108 RID: 264
		[Serializable]
		public class DeviceInfo
		{
			// Token: 0x1700027B RID: 635
			// (get) Token: 0x060008D4 RID: 2260 RVA: 0x00025CF8 File Offset: 0x00023EF8
			public static bool IsDeviceIdInitialized
			{
				get
				{
					return !string.IsNullOrEmpty(SystemInfoExtensions.DeviceInfo.deviceId);
				}
			}

			// Token: 0x1700027C RID: 636
			// (get) Token: 0x060008D5 RID: 2261 RVA: 0x00025D18 File Offset: 0x00023F18
			// (set) Token: 0x060008D6 RID: 2262 RVA: 0x0000734E File Offset: 0x0000554E
			public string Id
			{
				get
				{
					return SystemInfoExtensions.DeviceInfo.deviceId;
				}
				set
				{
					SystemInfoExtensions.DeviceInfo.deviceId = value;
				}
			}

			// Token: 0x060008D7 RID: 2263 RVA: 0x00025D30 File Offset: 0x00023F30
			public static string GetId()
			{
				return SystemInfoExtensions.DeviceInfo.deviceId;
			}

			// Token: 0x04000727 RID: 1831
			private static string deviceId;
		}
	}
}
