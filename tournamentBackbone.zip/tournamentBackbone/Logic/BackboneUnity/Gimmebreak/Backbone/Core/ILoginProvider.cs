﻿using System;
using System.Collections.Generic;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200005C RID: 92
	internal interface ILoginProvider
	{
		// Token: 0x17000144 RID: 324
		// (get) Token: 0x0600041C RID: 1052
		bool CreateNewUser { get; }

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x0600041D RID: 1053
		string DeviceId { get; }

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x0600041E RID: 1054
		string DeviceName { get; }

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x0600041F RID: 1055
		int DevicePlatform { get; }

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x06000420 RID: 1056
		string ProviderName { get; }

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x06000421 RID: 1057
		KeyValuePair<string, object>[] Parameters { get; }
	}
}
