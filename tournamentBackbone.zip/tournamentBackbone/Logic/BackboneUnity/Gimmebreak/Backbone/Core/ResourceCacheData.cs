﻿using System;
using System.Collections.Generic;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200006C RID: 108
	[Serializable]
	public class ResourceCacheData : ISerializeVersion
	{
		// Token: 0x17000165 RID: 357
		// (get) Token: 0x06000508 RID: 1288 RVA: 0x0000570A File Offset: 0x0000390A
		// (set) Token: 0x06000509 RID: 1289 RVA: 0x00005712 File Offset: 0x00003912
		public Version Version { get; set; }

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x0600050A RID: 1290 RVA: 0x0000571B File Offset: 0x0000391B
		// (set) Token: 0x0600050B RID: 1291 RVA: 0x00005723 File Offset: 0x00003923
		public List<ResourceCacheObject> CachedObjects { get; set; }

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x0600050C RID: 1292 RVA: 0x000175F0 File Offset: 0x000157F0
		public int CachedObjectsCount
		{
			get
			{
				return this.cachedObjectsByUri.Count;
			}
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x0000572C File Offset: 0x0000392C
		public ResourceCacheData()
		{
			this.Version = ResourceCacheData.CURRENTVERSION;
			this.CachedObjects = new List<ResourceCacheObject>(100);
			this.cachedObjectsByUri = new Dictionary<string, ResourceCacheObject>();
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x00017610 File Offset: 0x00015810
		public bool AddCachedObject(ResourceCacheObject cachedObject)
		{
			bool flag = !this.cachedObjectsByUri.ContainsKey(cachedObject.Uri);
			bool result;
			if (flag)
			{
				this.cachedObjectsByUri.Add(cachedObject.Uri, cachedObject);
				result = true;
			}
			else
			{
				bool flag2 = this.cachedObjectsByUri[cachedObject.Uri].Version < cachedObject.Version;
				if (flag2)
				{
					this.RemoveCachedObject(cachedObject.Uri);
					this.cachedObjectsByUri.Add(cachedObject.Uri, cachedObject);
					result = true;
				}
				else
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x0001769C File Offset: 0x0001589C
		public void RemoveCachedObject(string uri)
		{
			ResourceCacheObject resourceCacheObject = this.cachedObjectsByUri[uri];
			FileStorage.Delete(resourceCacheObject.FileDataPath);
			resourceCacheObject.Dispose();
			this.cachedObjectsByUri.Remove(uri);
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x000176D8 File Offset: 0x000158D8
		public ResourceCacheObject GetChachedObject(string uri)
		{
			bool flag = this.cachedObjectsByUri.ContainsKey(uri);
			ResourceCacheObject result;
			if (flag)
			{
				result = this.cachedObjectsByUri[uri];
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000511 RID: 1297 RVA: 0x0001770C File Offset: 0x0001590C
		public void OnBeforeSerialize()
		{
			this.CachedObjects.Clear();
			Dictionary<string, ResourceCacheObject>.Enumerator enumerator = this.cachedObjectsByUri.GetEnumerator();
			List<string> list = null;
			while (enumerator.MoveNext())
			{
				KeyValuePair<string, ResourceCacheObject> keyValuePair = enumerator.Current;
				bool flag;
				if (keyValuePair.Value.CanExpire)
				{
					keyValuePair = enumerator.Current;
					flag = (keyValuePair.Value.ExpiryDate.AddHours(12.0) < DateTime.UtcNow);
				}
				else
				{
					flag = false;
				}
				bool flag2 = flag;
				if (flag2)
				{
					bool flag3 = list == null;
					if (flag3)
					{
						list = new List<string>();
					}
					List<string> list2 = list;
					keyValuePair = enumerator.Current;
					list2.Add(keyValuePair.Key);
				}
				else
				{
					List<ResourceCacheObject> cachedObjects = this.CachedObjects;
					keyValuePair = enumerator.Current;
					cachedObjects.Add(keyValuePair.Value);
				}
			}
			bool flag4 = list != null;
			if (flag4)
			{
				for (int i = 0; i < list.Count; i++)
				{
					this.RemoveCachedObject(list[i]);
				}
			}
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x0001781C File Offset: 0x00015A1C
		public void OnAfterDeserialize()
		{
			for (int i = 0; i < this.CachedObjects.Count; i++)
			{
				this.cachedObjectsByUri.Add(this.CachedObjects[i].Uri, this.CachedObjects[i]);
			}
		}

		// Token: 0x040003A5 RID: 933
		public static Version CURRENTVERSION = new Version("2.0.0");

		// Token: 0x040003A6 RID: 934
		private Dictionary<string, ResourceCacheObject> cachedObjectsByUri;
	}
}
