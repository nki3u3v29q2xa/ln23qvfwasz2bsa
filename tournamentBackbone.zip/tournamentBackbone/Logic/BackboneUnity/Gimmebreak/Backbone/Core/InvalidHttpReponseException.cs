﻿using System;
using System.Runtime.Serialization;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000059 RID: 89
	public class InvalidHttpReponseException : Exception
	{
		// Token: 0x06000400 RID: 1024 RVA: 0x00004DDE File Offset: 0x00002FDE
		public InvalidHttpReponseException()
		{
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x00004DE8 File Offset: 0x00002FE8
		public InvalidHttpReponseException(string message) : base(message)
		{
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x00004DF3 File Offset: 0x00002FF3
		public InvalidHttpReponseException(string message, Exception innerException) : base(message, innerException)
		{
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x00004DFF File Offset: 0x00002FFF
		protected InvalidHttpReponseException(SerializationInfo info, StreamingContext context) : base(info, context)
		{
		}
	}
}
