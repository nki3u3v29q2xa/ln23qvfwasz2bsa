﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000067 RID: 103
	[Serializable]
	public class SerializableDictionary<TKey, TValue> : Dictionary<TKey, TValue>, IXmlSerializable
	{
		// Token: 0x060004CC RID: 1228 RVA: 0x0000552F File Offset: 0x0000372F
		public SerializableDictionary()
		{
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x00005539 File Offset: 0x00003739
		protected SerializableDictionary(SerializationInfo info, StreamingContext context) : base(info, context)
		{
		}

		// Token: 0x1700015B RID: 347
		// (get) Token: 0x060004CE RID: 1230 RVA: 0x00016F30 File Offset: 0x00015130
		protected virtual string ItemTagName
		{
			get
			{
				return "item";
			}
		}

		// Token: 0x1700015C RID: 348
		// (get) Token: 0x060004CF RID: 1231 RVA: 0x00016F48 File Offset: 0x00015148
		protected virtual string KeyTagName
		{
			get
			{
				return "key";
			}
		}

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x060004D0 RID: 1232 RVA: 0x00016F60 File Offset: 0x00015160
		protected virtual string ValueTagName
		{
			get
			{
				return "value";
			}
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x00016F78 File Offset: 0x00015178
		public XmlSchema GetSchema()
		{
			return null;
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x00016F8C File Offset: 0x0001518C
		public void ReadXml(XmlReader reader)
		{
			bool isEmptyElement = reader.IsEmptyElement;
			reader.Read();
			bool flag = isEmptyElement;
			if (!flag)
			{
				try
				{
					while (reader.NodeType != XmlNodeType.EndElement)
					{
						this.ReadItem(reader);
						reader.MoveToContent();
					}
				}
				finally
				{
					reader.ReadEndElement();
				}
			}
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x00016FF4 File Offset: 0x000151F4
		public void WriteXml(XmlWriter writer)
		{
			foreach (KeyValuePair<TKey, TValue> keyValuePair in this)
			{
				this.WriteItem(writer, keyValuePair);
			}
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x0001704C File Offset: 0x0001524C
		private void ReadItem(XmlReader reader)
		{
			reader.ReadStartElement(this.ItemTagName);
			try
			{
				base.Add(this.ReadKey(reader), this.ReadValue(reader));
			}
			finally
			{
				reader.ReadEndElement();
			}
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x0001709C File Offset: 0x0001529C
		private TKey ReadKey(XmlReader reader)
		{
			reader.ReadStartElement(this.KeyTagName);
			TKey result;
			try
			{
				result = (TKey)((object)SerializableDictionary<TKey, TValue>.keySerializer.Deserialize(reader));
			}
			finally
			{
				reader.ReadEndElement();
			}
			return result;
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x000170E8 File Offset: 0x000152E8
		private TValue ReadValue(XmlReader reader)
		{
			reader.ReadStartElement(this.ValueTagName);
			TValue result;
			try
			{
				result = (TValue)((object)SerializableDictionary<TKey, TValue>.valueSerializer.Deserialize(reader));
			}
			finally
			{
				reader.ReadEndElement();
			}
			return result;
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x00017134 File Offset: 0x00015334
		private void WriteItem(XmlWriter writer, KeyValuePair<TKey, TValue> keyValuePair)
		{
			writer.WriteStartElement(this.ItemTagName);
			try
			{
				this.WriteKey(writer, keyValuePair.Key);
				this.WriteValue(writer, keyValuePair.Value);
			}
			finally
			{
				writer.WriteEndElement();
			}
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x0001718C File Offset: 0x0001538C
		private void WriteKey(XmlWriter writer, TKey key)
		{
			writer.WriteStartElement(this.KeyTagName);
			try
			{
				SerializableDictionary<TKey, TValue>.keySerializer.Serialize(writer, key);
			}
			finally
			{
				writer.WriteEndElement();
			}
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x000171D8 File Offset: 0x000153D8
		private void WriteValue(XmlWriter writer, TValue value)
		{
			writer.WriteStartElement(this.ValueTagName);
			try
			{
				SerializableDictionary<TKey, TValue>.valueSerializer.Serialize(writer, value);
			}
			finally
			{
				writer.WriteEndElement();
			}
		}

		// Token: 0x04000393 RID: 915
		private const string DefaultItemTag = "item";

		// Token: 0x04000394 RID: 916
		private const string DefaultKeyTag = "key";

		// Token: 0x04000395 RID: 917
		private const string DefaultValueTag = "value";

		// Token: 0x04000396 RID: 918
		private static readonly XmlSerializer keySerializer = new XmlSerializer(typeof(TKey));

		// Token: 0x04000397 RID: 919
		private static readonly XmlSerializer valueSerializer = new XmlSerializer(typeof(TValue));
	}
}
