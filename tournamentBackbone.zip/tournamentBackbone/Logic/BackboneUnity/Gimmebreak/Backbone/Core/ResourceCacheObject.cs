﻿using System;
using System.Collections;
using UnityEngine;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200006D RID: 109
	[Serializable]
	public class ResourceCacheObject : IDisposable
	{
		// Token: 0x17000168 RID: 360
		// (get) Token: 0x06000514 RID: 1300 RVA: 0x0000576C File Offset: 0x0000396C
		// (set) Token: 0x06000515 RID: 1301 RVA: 0x00005774 File Offset: 0x00003974
		public string Uri { get; set; }

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x06000516 RID: 1302 RVA: 0x0000577D File Offset: 0x0000397D
		// (set) Token: 0x06000517 RID: 1303 RVA: 0x00005785 File Offset: 0x00003985
		public int Version { get; set; }

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x06000518 RID: 1304 RVA: 0x0000578E File Offset: 0x0000398E
		// (set) Token: 0x06000519 RID: 1305 RVA: 0x00005796 File Offset: 0x00003996
		public DateTime CreatedDate { get; set; }

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x0600051A RID: 1306 RVA: 0x0000579F File Offset: 0x0000399F
		// (set) Token: 0x0600051B RID: 1307 RVA: 0x000057A7 File Offset: 0x000039A7
		public bool CanExpire { get; set; }

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x0600051C RID: 1308 RVA: 0x000057B0 File Offset: 0x000039B0
		// (set) Token: 0x0600051D RID: 1309 RVA: 0x000057B8 File Offset: 0x000039B8
		public bool CanExtendExpiryDate { get; set; }

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x0600051E RID: 1310 RVA: 0x000057C1 File Offset: 0x000039C1
		// (set) Token: 0x0600051F RID: 1311 RVA: 0x000057C9 File Offset: 0x000039C9
		public DateTime ExpiryDate { get; set; }

		// Token: 0x1700016E RID: 366
		// (get) Token: 0x06000520 RID: 1312 RVA: 0x000057D2 File Offset: 0x000039D2
		// (set) Token: 0x06000521 RID: 1313 RVA: 0x000057DA File Offset: 0x000039DA
		public int Lifespan { get; set; }

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x06000522 RID: 1314 RVA: 0x000057E3 File Offset: 0x000039E3
		// (set) Token: 0x06000523 RID: 1315 RVA: 0x000057EB File Offset: 0x000039EB
		public string FileDataPath { get; set; }

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x06000524 RID: 1316 RVA: 0x000057F4 File Offset: 0x000039F4
		// (set) Token: 0x06000525 RID: 1317 RVA: 0x000057FC File Offset: 0x000039FC
		public int Size { get; set; }

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x06000526 RID: 1318 RVA: 0x00005805 File Offset: 0x00003A05
		// (set) Token: 0x06000527 RID: 1319 RVA: 0x0000580D File Offset: 0x00003A0D
		public bool IsFileDataCompressed { get; set; }

		// Token: 0x06000528 RID: 1320 RVA: 0x00017870 File Offset: 0x00015A70
		private byte[] LoadData()
		{
			bool isFileDataCompressed = this.IsFileDataCompressed;
			byte[] result;
			if (isFileDataCompressed)
			{
				result = FileStorage.GzipDecompress(FileStorage.LoadFile(this.FileDataPath, false));
			}
			else
			{
				result = FileStorage.LoadFile(this.FileDataPath, false);
			}
			return result;
		}

		// Token: 0x06000529 RID: 1321 RVA: 0x000178B0 File Offset: 0x00015AB0
		private T LoadData<T>() where T : class
		{
			return FileStorage.ConvertObjectFromBytes<T>(this.LoadData());
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x000178D0 File Offset: 0x00015AD0
		public AsyncOperation<byte[]> GetData(bool keepLoaded)
		{
			return new AsyncOperation<byte[]>(delegate()
			{
				bool keepLoaded2 = keepLoaded;
				byte[] result;
				if (keepLoaded2)
				{
					bool flag = this.fileData == null;
					if (flag)
					{
						this.fileData = this.LoadData();
					}
					result = (byte[])this.fileData;
				}
				else
				{
					result = this.LoadData();
				}
				return result;
			});
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x00017908 File Offset: 0x00015B08
		public AsyncOperation<T> GetData<T>(bool keepLoaded) where T : class
		{
			return new AsyncOperation<T>(delegate()
			{
				bool keepLoaded2 = keepLoaded;
				T result;
				if (keepLoaded2)
				{
					bool flag = this.fileData == null;
					if (flag)
					{
						this.fileData = this.LoadData<T>();
					}
					result = (T)((object)this.fileData);
				}
				else
				{
					result = this.LoadData<T>();
				}
				return result;
			});
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x00017940 File Offset: 0x00015B40
		public AsyncOperation<bool> SetData(byte[] data, bool keepLoaded, bool compress = true)
		{
			this.IsFileDataCompressed = compress;
			return new AsyncOperation<bool>(delegate()
			{
				bool compress2 = compress;
				if (compress2)
				{
					data = FileStorage.GzipCompress(data);
				}
				bool keepLoaded2 = keepLoaded;
				if (keepLoaded2)
				{
					this.fileData = data;
				}
				else
				{
					this.fileData = null;
				}
				this.Size = data.Length;
				FileStorage.SaveFile(this.FileDataPath, data, false);
				return true;
			});
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x00017994 File Offset: 0x00015B94
		public AsyncOperation<bool> SetData<T>(T data, bool keepLoaded, bool compress = true) where T : class
		{
			this.IsFileDataCompressed = compress;
			return new AsyncOperation<bool>(delegate()
			{
				bool keepLoaded2 = keepLoaded;
				if (keepLoaded2)
				{
					this.fileData = data;
				}
				else
				{
					this.fileData = null;
				}
				bool compress2 = compress;
				if (compress2)
				{
					byte[] array = FileStorage.GzipCompress(FileStorage.ConvertObjectToBytes<T>(data));
					this.Size = array.Length;
					FileStorage.SaveFile(this.FileDataPath, array, false);
				}
				else
				{
					this.Size = (int)FileStorage.SaveObjectToFile<T>(this.FileDataPath, data, false);
				}
				return true;
			});
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x000179E8 File Offset: 0x00015BE8
		public AsyncOperation<Texture2D> GetDataAsTexture2d()
		{
			return new AsyncOperation<Texture2D>(this.GetDataAsTexture2dRoutine(), false);
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x00005816 File Offset: 0x00003A16
		private IEnumerator GetDataAsTexture2dRoutine()
		{
			bool flag = this.texture == null;
			if (flag)
			{
				AsyncOperation<ResourceCacheObject.SerializableTexture> getDataOperation = this.GetData<ResourceCacheObject.SerializableTexture>(false);
				yield return getDataOperation;
				bool flag2 = getDataOperation.ReturnValue != null;
				if (flag2)
				{
					this.texture = new Texture2D(2, 2);
					getDataOperation.ReturnValue.LoadDataToTexture(this.texture);
					this.texture.name = this.Uri;
				}
				getDataOperation = null;
			}
			yield return new AsyncOperation<Texture2D>.Result(this.texture);
			yield break;
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x00017A08 File Offset: 0x00015C08
		public AsyncOperation<bool> SetDataAsTexture2d(Texture2D data)
		{
			ResourceCacheObject.SerializableTexture serializableTexture = null;
			bool flag = this.fileData != null;
			if (flag)
			{
				serializableTexture = (this.fileData as ResourceCacheObject.SerializableTexture);
			}
			bool flag2 = serializableTexture == null;
			if (flag2)
			{
				serializableTexture = new ResourceCacheObject.SerializableTexture();
			}
			serializableTexture.LoadDataFromTexture(data);
			bool flag3 = this.texture != null;
			if (flag3)
			{
				bool flag4 = this.texture.width == data.width && this.texture.height == data.height;
				if (flag4)
				{
					this.texture.SetPixels32(data.GetPixels32());
					this.texture.Apply();
					Object.Destroy(data);
				}
				else
				{
					Object.Destroy(this.texture);
					this.texture = data;
				}
			}
			return this.SetData<ResourceCacheObject.SerializableTexture>(serializableTexture, false, true);
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x00017ADC File Offset: 0x00015CDC
		public void ExtendExpiration()
		{
			this.ExpiryDate = DateTime.UtcNow.AddSeconds((double)this.Lifespan);
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x00017B08 File Offset: 0x00015D08
		public void Dispose()
		{
			bool flag = this.texture != null;
			if (flag)
			{
				Object.Destroy(this.texture);
				this.texture = null;
			}
		}

		// Token: 0x040003A9 RID: 937
		private object fileData;

		// Token: 0x040003AA RID: 938
		private Texture2D texture;

		// Token: 0x02000102 RID: 258
		[Serializable]
		public class SerializableTexture
		{
			// Token: 0x17000275 RID: 629
			// (get) Token: 0x060008BB RID: 2235 RVA: 0x0000724C File Offset: 0x0000544C
			// (set) Token: 0x060008BC RID: 2236 RVA: 0x00007254 File Offset: 0x00005454
			public int Width { get; set; }

			// Token: 0x17000276 RID: 630
			// (get) Token: 0x060008BD RID: 2237 RVA: 0x0000725D File Offset: 0x0000545D
			// (set) Token: 0x060008BE RID: 2238 RVA: 0x00007265 File Offset: 0x00005465
			public int Height { get; set; }

			// Token: 0x17000277 RID: 631
			// (get) Token: 0x060008BF RID: 2239 RVA: 0x0000726E File Offset: 0x0000546E
			// (set) Token: 0x060008C0 RID: 2240 RVA: 0x00007276 File Offset: 0x00005476
			public TextureFormat Format { get; set; }

			// Token: 0x17000278 RID: 632
			// (get) Token: 0x060008C1 RID: 2241 RVA: 0x0000727F File Offset: 0x0000547F
			// (set) Token: 0x060008C2 RID: 2242 RVA: 0x00007287 File Offset: 0x00005487
			public byte[] Data { get; set; }

			// Token: 0x060008C3 RID: 2243 RVA: 0x00007290 File Offset: 0x00005490
			public void LoadDataFromTexture(Texture2D texture)
			{
				this.Width = texture.width;
				this.Height = texture.height;
				this.Format = texture.format;
				this.Data = texture.GetRawTextureData();
			}

			// Token: 0x060008C4 RID: 2244 RVA: 0x000072C7 File Offset: 0x000054C7
			public void LoadDataToTexture(Texture2D texture)
			{
				texture.Resize(this.Width, this.Height, this.Format, false);
				texture.LoadRawTextureData(this.Data);
				texture.Apply();
			}
		}
	}
}
