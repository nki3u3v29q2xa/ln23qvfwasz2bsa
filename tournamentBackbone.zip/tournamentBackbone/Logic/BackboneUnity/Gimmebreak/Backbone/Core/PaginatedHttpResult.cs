﻿using System;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200005B RID: 91
	public class PaginatedHttpResult : BackboneHttpResult
	{
		// Token: 0x17000141 RID: 321
		// (get) Token: 0x06000411 RID: 1041 RVA: 0x00004E54 File Offset: 0x00003054
		// (set) Token: 0x06000412 RID: 1042 RVA: 0x00004E5C File Offset: 0x0000305C
		public int TotalResultCount { get; private set; }

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x06000413 RID: 1043 RVA: 0x00004E65 File Offset: 0x00003065
		// (set) Token: 0x06000414 RID: 1044 RVA: 0x00004E6D File Offset: 0x0000306D
		public int MaxResultsPerPage { get; private set; }

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x06000415 RID: 1045 RVA: 0x00004E76 File Offset: 0x00003076
		// (set) Token: 0x06000416 RID: 1046 RVA: 0x00004E7E File Offset: 0x0000307E
		public int CurrentPage { get; private set; }

		// Token: 0x06000417 RID: 1047 RVA: 0x0001543C File Offset: 0x0001363C
		internal PaginatedHttpResult(BackboneHttpResult httpResponse) : base(httpResponse.ResponseCode, httpResponse.JsonResult, httpResponse.ErrorCode, httpResponse.ErrorMessage, httpResponse.ErrorReference)
		{
			bool flag = !httpResponse.HasError && httpResponse.JsonResult != null && httpResponse.JsonResult.HasFields(PaginatedHttpResult.REQUIRED_FIELDS) && httpResponse.JsonResult["pagination"].HasFields(PaginatedHttpResult.REQUIRED_FIELDS_DATA);
			if (flag)
			{
				JSONObject jsonobject = httpResponse.JsonResult["pagination"];
				bool isNumber = jsonobject["totalResultCount"].IsNumber;
				if (isNumber)
				{
					this.TotalResultCount = (int)jsonobject["totalResultCount"].i;
				}
				bool isNumber2 = jsonobject["maxResults"].IsNumber;
				if (isNumber2)
				{
					this.MaxResultsPerPage = (int)jsonobject["maxResults"].i;
				}
				bool isNumber3 = jsonobject["currentPage"].IsNumber;
				if (isNumber3)
				{
					this.CurrentPage = (int)jsonobject["currentPage"].i;
				}
			}
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x00015554 File Offset: 0x00013754
		internal static int GetMaxResultsPerPage(BackboneHttpResult httpResponse)
		{
			bool flag = !httpResponse.HasError && httpResponse.JsonResult != null && httpResponse.JsonResult.HasFields(PaginatedHttpResult.REQUIRED_FIELDS) && httpResponse.JsonResult["pagination"].HasFields(PaginatedHttpResult.REQUIRED_FIELDS_DATA);
			if (flag)
			{
				JSONObject jsonobject = httpResponse.JsonResult["pagination"];
				bool isNumber = jsonobject["maxResults"].IsNumber;
				if (isNumber)
				{
					return (int)jsonobject["maxResults"].i;
				}
			}
			return 0;
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x000155E8 File Offset: 0x000137E8
		internal static int GetTotalResultCount(BackboneHttpResult httpResponse)
		{
			bool flag = !httpResponse.HasError && httpResponse.JsonResult != null && httpResponse.JsonResult.HasFields(PaginatedHttpResult.REQUIRED_FIELDS) && httpResponse.JsonResult["pagination"].HasFields(PaginatedHttpResult.REQUIRED_FIELDS_DATA);
			if (flag)
			{
				JSONObject jsonobject = httpResponse.JsonResult["pagination"];
				bool isNumber = jsonobject["totalResultCount"].IsNumber;
				if (isNumber)
				{
					return (int)jsonobject["totalResultCount"].i;
				}
			}
			return 0;
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x0001567C File Offset: 0x0001387C
		internal static int GetCurrentPage(BackboneHttpResult httpResponse)
		{
			bool flag = !httpResponse.HasError && httpResponse.JsonResult != null && httpResponse.JsonResult.HasFields(PaginatedHttpResult.REQUIRED_FIELDS) && httpResponse.JsonResult["pagination"].HasFields(PaginatedHttpResult.REQUIRED_FIELDS_DATA);
			if (flag)
			{
				JSONObject jsonobject = httpResponse.JsonResult["pagination"];
				bool isNumber = jsonobject["currentPage"].IsNumber;
				if (isNumber)
				{
					return (int)jsonobject["currentPage"].i;
				}
			}
			return 0;
		}

		// Token: 0x0400036B RID: 875
		private static readonly string[] REQUIRED_FIELDS = new string[]
		{
			"pagination"
		};

		// Token: 0x0400036C RID: 876
		private static readonly string[] REQUIRED_FIELDS_DATA = new string[]
		{
			"totalResultCount",
			"maxResults",
			"currentPage"
		};
	}
}
