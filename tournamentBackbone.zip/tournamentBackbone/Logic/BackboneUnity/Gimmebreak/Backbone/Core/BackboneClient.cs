﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Gimmebreak.Backbone.Core.JSON;
using Gimmebreak.Backbone.GameSessions;
using Gimmebreak.Backbone.Notifications;
using Gimmebreak.Backbone.Season;
using Gimmebreak.Backbone.Tournaments;
using Gimmebreak.Backbone.User;
using UnityEngine;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000056 RID: 86
	public sealed class BackboneClient
	{
		// Token: 0x17000129 RID: 297
		// (get) Token: 0x06000395 RID: 917 RVA: 0x000149A0 File Offset: 0x00012BA0
		private BackboneHttpClient HttpClient
		{
			get
			{
				bool flag = this.backboneHttpClient == null || !this.isInitialized;
				if (flag)
				{
					throw new InvalidOperationException("BackboneClient must be initialized first before it can be used.");
				}
				return this.backboneHttpClient;
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x06000396 RID: 918 RVA: 0x000149DC File Offset: 0x00012BDC
		private BackboneClientData ClientData
		{
			get
			{
				bool flag = this.clientData == null || !this.isInitialized;
				if (flag)
				{
					throw new InvalidOperationException("BackboneClient must be initialized first before it can be used.");
				}
				return this.clientData;
			}
		}

		// Token: 0x06000397 RID: 919 RVA: 0x0000498D File Offset: 0x00002B8D
		private BackboneClient()
		{
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x06000398 RID: 920 RVA: 0x00014A18 File Offset: 0x00012C18
		public bool IsInitialized
		{
			get
			{
				return this.isInitialized;
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x06000399 RID: 921 RVA: 0x00014A30 File Offset: 0x00012C30
		public bool IsUserLoggedIn
		{
			get
			{
				return this.loginSession != null && this.loginSession.IsValid;
			}
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x0600039A RID: 922 RVA: 0x00014A58 File Offset: 0x00012C58
		public UserData User
		{
			get
			{
				return this.ClientData.UserData;
			}
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x0600039B RID: 923 RVA: 0x00014A78 File Offset: 0x00012C78
		public SeasonData Season
		{
			get
			{
				return this.ClientData.SeasonData;
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x0600039C RID: 924 RVA: 0x00014A98 File Offset: 0x00012C98
		public NotificationData Notifications
		{
			get
			{
				return this.ClientData.NotificationData;
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x0600039D RID: 925 RVA: 0x00014AB8 File Offset: 0x00012CB8
		public TournamentData Tournaments
		{
			get
			{
				return this.ClientData.TournamentData;
			}
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x0600039E RID: 926 RVA: 0x00014AD8 File Offset: 0x00012CD8
		public GameData Game
		{
			get
			{
				return this.ClientData.GameData;
			}
		}

		// Token: 0x0600039F RID: 927 RVA: 0x00014AF8 File Offset: 0x00012CF8
		private AsyncOperation<bool> LogoutInvalidSession()
		{
			return new AsyncOperation<bool>(this.LogoutInvalidSessionRoutine(), false);
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x00004997 File Offset: 0x00002B97
		private IEnumerator LogoutInvalidSessionRoutine()
		{
			bool flag = this.loginSession != null && !this.loginSession.IsValid;
			if (flag)
			{
				yield return this.ClientData.Delete();
				this.clientData = new BackboneClientData();
				yield return this.loginSession.Delete();
				this.loginSession = null;
				bool flag2 = this.callbackHandler != null;
				if (flag2)
				{
					this.callbackHandler.OnLogout();
				}
				yield return new AsyncOperation<bool>.Result(true);
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x00014B18 File Offset: 0x00012D18
		public static AsyncOperation<BackboneClient> Initialize(IBackboneClientCallbackHandler callbackHandler = null)
		{
			BackboneClientSetting backboneClientSetting = Resources.Load<BackboneClientSetting>("BackboneClientSetting");
			bool flag = backboneClientSetting == null;
			if (flag)
			{
				throw new InvalidOperationException("Could not find BackboneClientSetting.asset in resource folder.");
			}
			return BackboneClient.Initialize(backboneClientSetting, callbackHandler);
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x00014B54 File Offset: 0x00012D54
		public static AsyncOperation<BackboneClient> Initialize(BackboneClientSetting settings, IBackboneClientCallbackHandler callbackHandler = null)
		{
			bool flag = settings == null;
			if (flag)
			{
				throw new InvalidOperationException("BackboneClientSetting.asset cannot be null.");
			}
			return BackboneClient.Initialize(BackboneClientSetting.serverUri, settings.gameId, callbackHandler);
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x00014B90 File Offset: 0x00012D90
		public static AsyncOperation<BackboneClient> Initialize(Uri server, string gameId, IBackboneClientCallbackHandler callbackHandler = null)
		{
			return new AsyncOperation<BackboneClient>(BackboneClient.InitializeRoutine(server, gameId, callbackHandler), false);
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x000049A6 File Offset: 0x00002BA6
		private static IEnumerator InitializeRoutine(Uri server, string gameId, IBackboneClientCallbackHandler callbackHandler = null)
		{
			bool flag = string.IsNullOrEmpty(gameId);
			if (flag)
			{
				throw new ArgumentNullException("gameId", "Game id cannot be null or empty string.");
			}
			FileStorage.Initialize();
			SystemInfoExtensions.GetBackboneDeviceUniqueId();
			BackboneClient backboneClient = new BackboneClient();
			backboneClient.callbackHandler = callbackHandler;
			GameObject gameObject = new GameObject("BackboneClient-TournamentHub");
			gameObject.hideFlags = 61;
			Object.DontDestroyOnLoad(gameObject);
			backboneClient.tournamentHub = gameObject.AddComponent<TournamentHub>();
			yield return BackboneHttpClient.Initialize(server, gameId).ResultCallback(delegate(BackboneHttpClient initializedHttpClient)
			{
				backboneClient.backboneHttpClient = initializedHttpClient;
			});
			yield return backboneClient.backboneHttpClient.Ping().ResultCallback(delegate(BackboneHttpResult pingHttpResult)
			{
				bool hasError = pingHttpResult.HasError;
				if (hasError)
				{
					bool flag5 = pingHttpResult.IsHttpError && pingHttpResult.ErrorCode == 100;
					if (flag5)
					{
						throw new Exception(pingHttpResult.ErrorMessage);
					}
					Debug.LogWarning("Faild to contact Backbone server. " + pingHttpResult.ErrorMessage);
				}
			});
			yield return LoginSession.Load().ResultCallback(delegate(LoginSession loginSession)
			{
				backboneClient.loginSession = loginSession;
			});
			bool flag2 = backboneClient.loginSession != null;
			if (flag2)
			{
				yield return backboneClient.backboneHttpClient.RefreshAccessToken(backboneClient.loginSession);
				yield return backboneClient.LogoutInvalidSession();
			}
			bool isUserLoggedIn = backboneClient.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				yield return BackboneClientData.Load().ResultCallback(delegate(BackboneClientData clientData)
				{
					backboneClient.clientData = (clientData ?? new BackboneClientData());
				});
				bool flag3 = !string.IsNullOrEmpty(backboneClient.clientData.GameData.GameId) && !backboneClient.clientData.GameData.GameId.Equals(gameId, StringComparison.InvariantCultureIgnoreCase);
				if (flag3)
				{
					backboneClient.isInitialized = true;
					backboneClient.clientData.GameData.GameId = gameId;
					yield return backboneClient.loginSession.InvalidateAuthContext();
					yield return backboneClient.LogoutInvalidSession();
				}
				else
				{
					backboneClient.isInitialized = true;
					backboneClient.clientData.GameData.GameId = gameId;
					yield return backboneClient.SynchUser(true);
				}
			}
			else
			{
				backboneClient.clientData = new BackboneClientData();
				backboneClient.isInitialized = true;
				backboneClient.clientData.GameData.GameId = gameId;
			}
			bool flag4 = backboneClient.callbackHandler != null;
			if (flag4)
			{
				backboneClient.callbackHandler.OnInitialize(backboneClient);
				bool isUserLoggedIn2 = backboneClient.IsUserLoggedIn;
				if (isUserLoggedIn2)
				{
					backboneClient.callbackHandler.OnLogin(false);
				}
			}
			yield return new AsyncOperation<BackboneClient>.Result(backboneClient);
			yield break;
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x00014BB0 File Offset: 0x00012DB0
		public AsyncOperation<LoginResult> Login(LoginProvider loginProvider)
		{
			return new AsyncOperation<LoginResult>(this.LoginRoutine(loginProvider), false);
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x000049C3 File Offset: 0x00002BC3
		private IEnumerator LoginRoutine(LoginProvider loginProvider)
		{
			bool flag = this.loginSession != null;
			if (flag)
			{
				Debug.LogWarning("User is already logged in. If you want to log in different user call Logout method first.");
				yield return new AsyncOperation<LoginResult>.Result(null);
			}
			AsyncOperation<BackboneHttpResult> loginOperation = this.HttpClient.Login(loginProvider);
			yield return loginOperation;
			LoginResult loginResult = new LoginResult(loginOperation.ReturnValue);
			bool hasError = loginResult.HasError;
			if (hasError)
			{
				bool flag2 = this.callbackHandler != null;
				if (flag2)
				{
					this.callbackHandler.OnHttpError(loginResult);
				}
			}
			else
			{
				this.loginSession = new LoginSession(loginResult);
				AsyncOperation<bool> saveOperation = this.loginSession.Save();
				yield return saveOperation;
				bool flag3 = !saveOperation.ReturnValue;
				if (flag3)
				{
					Debug.LogWarning("Backbone client login session falied to save. Offline mode will not be available.");
				}
				yield return this.SynchUser(true);
				bool flag4 = this.callbackHandler != null;
				if (flag4)
				{
					this.callbackHandler.OnLogin(true);
				}
				saveOperation = null;
			}
			yield return new AsyncOperation<LoginResult>.Result(loginResult);
			yield break;
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x00014BD0 File Offset: 0x00012DD0
		public AsyncOperation<bool> SynchUser(bool fullSynch = false)
		{
			return new AsyncOperation<bool>(this.SynchUserRoutine(fullSynch), false);
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x000049D9 File Offset: 0x00002BD9
		private IEnumerator SynchUserRoutine(bool fullSynch)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				if (fullSynch)
				{
					this.ClientData.UserData.LastUpdate = DateTime.MinValue;
				}
				AsyncOperation<BackboneHttpResult> userGetOperation = this.HttpClient.UserGet(this.loginSession, this.ClientData.UserData.LastUpdate, this.ClientData.UserData.LastSync, this.ClientData.UserData.IsSyncDirty ? this.ClientData.UserData.GetSyncXML() : null, false, false, false, false);
				yield return userGetOperation;
				bool hasError = userGetOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag = this.callbackHandler != null;
					if (flag)
					{
						this.callbackHandler.OnHttpError(userGetOperation.ReturnValue);
					}
				}
				else
				{
					this.ClientData.UserData.IsSyncDirty = false;
					this.ClientData.UserData.LoadJsonUser(userGetOperation.ReturnValue.JsonResult, !this.HttpClient.HasPendingTransactions(this.ClientData.UserData.UserId));
					this.ClientData.SeasonData.LoadJsonSeason(userGetOperation.ReturnValue.JsonResult);
					this.ClientData.GameData.LoadJsonGameData(userGetOperation.ReturnValue.JsonResult);
					bool flag2 = !userGetOperation.ReturnValue.JsonResult["ntfupdatedat"].IsNull;
					if (flag2)
					{
						yield return this.LoadNotifications(userGetOperation.ReturnValue.JsonResult["ntfupdatedat"].ToUniversalTime());
					}
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<bool>.Result(true);
				userGetOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x00014BF0 File Offset: 0x00012DF0
		public AsyncOperation<bool> ChangeNickname(string nickName)
		{
			return this.ChangeNickname(nickName, 0);
		}

		// Token: 0x060003AA RID: 938 RVA: 0x00014C0C File Offset: 0x00012E0C
		public AsyncOperation<bool> ChangeNickname(string nickName, int preferredNickHash)
		{
			return new AsyncOperation<bool>(this.ChangeNicknameRoutine(nickName, preferredNickHash), false);
		}

		// Token: 0x060003AB RID: 939 RVA: 0x000049EF File Offset: 0x00002BEF
		private IEnumerator ChangeNicknameRoutine(string nickName, int preferredNickHash)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				bool flag = this.ClientData.UserData.UserNick == nickName && (preferredNickHash == 0 || "#" + preferredNickHash.ToString() == this.ClientData.UserData.UserNickHash);
				if (flag)
				{
					yield return new AsyncOperation<bool>.Result(true);
				}
				AsyncOperation<BackboneHttpResult> userChangeNickOperation = this.HttpClient.UserChangeNick(this.loginSession, nickName, preferredNickHash);
				yield return userChangeNickOperation;
				bool hasError = userChangeNickOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag2 = this.callbackHandler != null;
					if (flag2)
					{
						this.callbackHandler.OnHttpError(userChangeNickOperation.ReturnValue);
					}
				}
				else
				{
					bool flag3 = userChangeNickOperation.ReturnValue.JsonResult.HasField("nickName");
					if (flag3)
					{
						this.ClientData.UserData.UserNick = userChangeNickOperation.ReturnValue.JsonResult["nickName"].str;
					}
					bool flag4 = userChangeNickOperation.ReturnValue.JsonResult.HasField("nickNameHash");
					if (flag4)
					{
						this.ClientData.UserData.UserNickHash = "#" + userChangeNickOperation.ReturnValue.JsonResult["nickNameHash"].n.ToString();
					}
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<bool>.Result(true);
				userChangeNickOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003AC RID: 940 RVA: 0x00014C2C File Offset: 0x00012E2C
		public AsyncOperation<bool> ReportUser(long userId, ReportReason reportReason, long gameSessionId = 0L, long tournamentMatchId = 0L, long tournamentId = 0L)
		{
			return new AsyncOperation<bool>(this.ReportUserRoutine(userId, reportReason, gameSessionId, tournamentMatchId, tournamentId), false);
		}

		// Token: 0x060003AD RID: 941 RVA: 0x00004A0C File Offset: 0x00002C0C
		private IEnumerator ReportUserRoutine(long userId, ReportReason reportReason, long gameSessionId = 0L, long tournamentMatchId = 0L, long tournamentId = 0L)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				bool flag = (this.User.RemainingReports > 0 && !this.User.LastReportedUsers.Contains(userId)) || this.User.UserId == userId;
				if (flag)
				{
					AsyncOperation<BackboneHttpResult> userReportOperation = this.HttpClient.UserReport(this.loginSession, userId, reportReason, gameSessionId, tournamentMatchId, tournamentId);
					this.User.LastReportedUsers.Add(userId);
					yield return userReportOperation;
					bool hasError = userReportOperation.ReturnValue.HasError;
					if (hasError)
					{
						this.User.LastReportedUsers.Remove(userId);
						bool flag2 = this.callbackHandler != null;
						if (flag2)
						{
							this.callbackHandler.OnHttpError(userReportOperation.ReturnValue);
						}
					}
					else
					{
						bool flag3 = userReportOperation.ReturnValue.JsonResult.HasField("remainingReports");
						if (flag3)
						{
							this.User.RemainingReports = (int)userReportOperation.ReturnValue.JsonResult["remainingReports"].i;
						}
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<bool>.Result(true);
					userReportOperation = null;
				}
				else
				{
					yield return new AsyncOperation<bool>.Result(false);
				}
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003AE RID: 942 RVA: 0x00014C54 File Offset: 0x00012E54
		public AsyncOperation<bool> LoadNotifications()
		{
			return new AsyncOperation<bool>(this.LoadNotificationsRoutine(DateTime.MinValue, true), false);
		}

		// Token: 0x060003AF RID: 943 RVA: 0x00014C78 File Offset: 0x00012E78
		internal AsyncOperation<bool> LoadNotifications(DateTime lastNotificationUpdate)
		{
			return new AsyncOperation<bool>(this.LoadNotificationsRoutine(lastNotificationUpdate, false), false);
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x00004A40 File Offset: 0x00002C40
		private IEnumerator LoadNotificationsRoutine(DateTime lastNotificationUpdate, bool forceUpdate)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				bool flag = this.ClientData.NotificationData.LastNotificationUpdate < lastNotificationUpdate || forceUpdate;
				if (flag)
				{
					AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.NotificationGetActive(this.loginSession);
					yield return asyncOperation;
					bool hasError = asyncOperation.ReturnValue.HasError;
					if (hasError)
					{
						bool flag2 = this.callbackHandler != null;
						if (flag2)
						{
							this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
						}
					}
					else
					{
						this.ClientData.NotificationData.LoadJsonNotifications(asyncOperation.ReturnValue.JsonResult);
						bool flag3 = !forceUpdate;
						if (flag3)
						{
							this.ClientData.NotificationData.LastNotificationUpdate = lastNotificationUpdate;
						}
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<bool>.Result(true);
					asyncOperation = null;
				}
				yield return new AsyncOperation<bool>.Result(false);
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x00014C98 File Offset: 0x00012E98
		public AsyncOperation<bool> DismissNotification(Notification notification)
		{
			return new AsyncOperation<bool>(this.DismissNotificationRoutine(notification), false);
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x00004A5D File Offset: 0x00002C5D
		private IEnumerator DismissNotificationRoutine(Notification notification)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				bool flag = notification != null;
				if (flag)
				{
					notification.Processing = true;
					AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.NotificationDismiss(this.loginSession, notification.Id);
					yield return asyncOperation;
					bool hasError = asyncOperation.ReturnValue.HasError;
					if (hasError)
					{
						bool flag2 = this.callbackHandler != null;
						if (flag2)
						{
							this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
						}
					}
					else
					{
						notification.DismissNotification();
					}
					notification.Processing = false;
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<bool>.Result(true);
					asyncOperation = null;
				}
				yield return new AsyncOperation<bool>.Result(false);
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x00014CB8 File Offset: 0x00012EB8
		public AsyncOperation<bool> LoadTournamentList()
		{
			return new AsyncOperation<bool>(this.LoadTournamentListRoutine(false), false);
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x00014CD8 File Offset: 0x00012ED8
		internal AsyncOperation<bool> LoadTournamentList(bool forceUpdate)
		{
			return new AsyncOperation<bool>(this.LoadTournamentListRoutine(forceUpdate), false);
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x00004A73 File Offset: 0x00002C73
		private IEnumerator LoadTournamentListRoutine(bool forceUpdate)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				bool flag = this.ClientData.TournamentData.LastTournamentListUpdate.AddMinutes((double)TournamentData.tournamentListUpdateLimit) <= ServerTime.UtcNow || forceUpdate;
				if (flag)
				{
					AsyncOperation<List<Tournament>> asyncOperation = this.LoadTournamentsAll(ServerTime.UtcNow.Add(TournamentData.tournamentListSinceOffset), ServerTime.UtcNow.Add(TournamentData.tournamentListUntilOffset));
					yield return asyncOperation;
					bool flag2 = asyncOperation.ReturnValue == null;
					if (flag2)
					{
						yield return new AsyncOperation<bool>.Result(false);
					}
					else
					{
						bool flag3 = !forceUpdate;
						if (flag3)
						{
							this.ClientData.TournamentData.LastTournamentListUpdate = ServerTime.UtcNow;
						}
						this.ClientData.TournamentData.LoadTournamentList(asyncOperation.ReturnValue);
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<bool>.Result(true);
					asyncOperation = null;
				}
				else
				{
					yield return new AsyncOperation<bool>.Result(false);
				}
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x00014CF8 File Offset: 0x00012EF8
		public AsyncOperation<TournamentsPaginatedResult> LoadTournaments(DateTime sinceDate, DateTime untilDate, int maxResults = 25, int page = 1)
		{
			return new AsyncOperation<TournamentsPaginatedResult>(this.LoadTournamentsRoutine(sinceDate, untilDate, maxResults, page), false);
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x00004A89 File Offset: 0x00002C89
		private IEnumerator LoadTournamentsRoutine(DateTime sinceDate, DateTime untilDate, int maxResults, int page)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				List<Tournament> tournaments = null;
				AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentGetList(this.loginSession, sinceDate, untilDate, maxResults, page);
				yield return asyncOperation;
				bool hasError = asyncOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag = this.callbackHandler != null;
					if (flag)
					{
						this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
					}
				}
				else
				{
					bool flag2 = asyncOperation.ReturnValue.JsonResult.HasField("tournaments");
					if (flag2)
					{
						tournaments = new List<Tournament>(PaginatedHttpResult.GetMaxResultsPerPage(asyncOperation.ReturnValue));
						this.ClientData.TournamentData.LoadJsonTournamentList(asyncOperation.ReturnValue.JsonResult["tournaments"], tournaments);
					}
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<TournamentsPaginatedResult>.Result(new TournamentsPaginatedResult(tournaments, asyncOperation.ReturnValue));
				tournaments = null;
				asyncOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<TournamentsPaginatedResult>.Result(null);
			yield break;
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x00014D1C File Offset: 0x00012F1C
		public AsyncOperation<List<Tournament>> LoadTournamentsAll(DateTime sinceDate, DateTime untilDate)
		{
			return new AsyncOperation<List<Tournament>>(this.LoadTournamentsAllRoutine(sinceDate, untilDate), false);
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x00004AB5 File Offset: 0x00002CB5
		private IEnumerator LoadTournamentsAllRoutine(DateTime sinceDate, DateTime untilDate)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				List<Tournament> tournaments = null;
				AsyncOperation<TournamentsPaginatedResult> asyncOperation = null;
				int page = 0;
				do
				{
					int num = page;
					page = num + 1;
					asyncOperation = this.LoadTournaments(sinceDate, untilDate, 25, page);
					yield return asyncOperation;
					bool hasError = asyncOperation.ReturnValue.HasError;
					if (hasError)
					{
						yield return this.LogoutInvalidSession();
						yield return new AsyncOperation<List<Tournament>>.Result(null);
					}
					else
					{
						bool flag = tournaments == null;
						if (flag)
						{
							tournaments = new List<Tournament>(asyncOperation.ReturnValue.TotalResultCount);
						}
						tournaments.AddRange(asyncOperation.ReturnValue.Tournaments);
					}
				}
				while (!asyncOperation.ReturnValue.HasError && (asyncOperation.ReturnValue.CurrentPage - 1) * asyncOperation.ReturnValue.MaxResultsPerPage + asyncOperation.ReturnValue.Tournaments.Count < asyncOperation.ReturnValue.TotalResultCount);
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<List<Tournament>>.Result(tournaments);
				tournaments = null;
				asyncOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<List<Tournament>>.Result(null);
			yield break;
		}

		// Token: 0x060003BA RID: 954 RVA: 0x00014D3C File Offset: 0x00012F3C
		public AsyncOperation<bool> LoadTournament(Tournament tournament)
		{
			return this.LoadTournament(tournament.Id);
		}

		// Token: 0x060003BB RID: 955 RVA: 0x00014D5C File Offset: 0x00012F5C
		public AsyncOperation<bool> LoadTournament(long tournamentId)
		{
			return new AsyncOperation<bool>(this.LoadTournamentRoutine(tournamentId, true, false, TimeSpan.Zero), false);
		}

		// Token: 0x060003BC RID: 956 RVA: 0x00014D84 File Offset: 0x00012F84
		internal AsyncOperation<bool> LoadTournament(long tournamentId, bool getAllData, bool isReadyForNextMatch, TimeSpan refresLimit)
		{
			return new AsyncOperation<bool>(this.LoadTournamentRoutine(tournamentId, getAllData, isReadyForNextMatch, refresLimit), false);
		}

		// Token: 0x060003BD RID: 957 RVA: 0x00004AD2 File Offset: 0x00002CD2
		private IEnumerator LoadTournamentRoutine(long tournamentId, bool getAllData, bool isReadyForNextMatch, TimeSpan refresLimit)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				Tournament tournament = this.ClientData.TournamentData.GetTournamentById(tournamentId);
				bool flag = tournament != null && tournament.LastUpdate.Add(refresLimit) < ServerTime.UtcNow;
				if (flag)
				{
					AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentGetData(this.loginSession, tournamentId, getAllData, isReadyForNextMatch);
					yield return asyncOperation;
					bool hasError = asyncOperation.ReturnValue.HasError;
					if (hasError)
					{
						bool flag2 = this.callbackHandler != null;
						if (flag2)
						{
							this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
						}
					}
					else
					{
						bool flag3 = asyncOperation.ReturnValue.JsonResult == null;
						if (flag3)
						{
							yield return new AsyncOperation<bool>.Result(false);
						}
						else
						{
							tournament.LastUpdate = ServerTime.UtcNow;
							tournament.LoadJsonTournamentFull(asyncOperation.ReturnValue.JsonResult, getAllData);
							bool flag4 = this.tournamentHub.IsInitialized && this.tournamentHub.Tournament.Id == tournament.Id;
							if (flag4)
							{
								this.tournamentHub.OnTournamentUpdate();
							}
						}
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<bool>.Result(true);
					asyncOperation = null;
				}
				else
				{
					bool flag5 = tournament == null;
					if (flag5)
					{
						Debug.LogWarningFormat("Requested tournament ({0}) could not be found in loaded tournament list. Populate tournament list first by calling LoadTournamentList() or LoadTournaments().", new object[]
						{
							tournamentId
						});
					}
				}
				yield return new AsyncOperation<bool>.Result(false);
				tournament = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003BE RID: 958 RVA: 0x00014DA8 File Offset: 0x00012FA8
		public AsyncOperation<ScoresPaginatedResult> LoadTournamentScores(long tournamentId, int phaseId, int maxResults, int page, int groupId = 0)
		{
			return new AsyncOperation<ScoresPaginatedResult>(this.LoadTournamentScoresRoutine(tournamentId, phaseId, maxResults, page, groupId), false);
		}

		// Token: 0x060003BF RID: 959 RVA: 0x00004AFE File Offset: 0x00002CFE
		private IEnumerator LoadTournamentScoresRoutine(long tournamentId, int phaseId, int maxResults, int page, int groupId = 0)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				Tournament tournament = this.ClientData.TournamentData.GetTournamentById(tournamentId);
				bool flag = tournament != null;
				if (flag)
				{
					TournamentPhase phase = tournament.GetTournamentPhaseById(phaseId);
					bool flag2 = phase != null;
					if (flag2)
					{
						List<TournamentScore> scores = null;
						AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentGetScore(this.loginSession, tournamentId, (byte)phaseId, maxResults, page, groupId);
						yield return asyncOperation;
						bool hasError = asyncOperation.ReturnValue.HasError;
						if (hasError)
						{
							bool flag3 = this.callbackHandler != null;
							if (flag3)
							{
								this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
							}
						}
						else
						{
							bool flag4 = asyncOperation.ReturnValue.JsonResult.HasField("scores");
							if (flag4)
							{
								scores = phase.LoadJsonScores(asyncOperation.ReturnValue.JsonResult["scores"]);
							}
						}
						yield return this.LogoutInvalidSession();
						yield return new AsyncOperation<ScoresPaginatedResult>.Result(new ScoresPaginatedResult(scores, asyncOperation.ReturnValue));
						scores = null;
						asyncOperation = null;
					}
					phase = null;
				}
				yield return new AsyncOperation<ScoresPaginatedResult>.Result(null);
				tournament = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<ScoresPaginatedResult>.Result(null);
			yield break;
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x00014DD0 File Offset: 0x00012FD0
		public AsyncOperation<List<TournamentScore>> LoadTournamentScoresAll(long tournamentId, int phaseId, int groupId = 0)
		{
			return new AsyncOperation<List<TournamentScore>>(this.LoadTournamentScoresAllRoutine(tournamentId, phaseId, groupId), false);
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x00004B32 File Offset: 0x00002D32
		private IEnumerator LoadTournamentScoresAllRoutine(long tournamentId, int phaseId, int groupId)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				Tournament tournament = this.ClientData.TournamentData.GetTournamentById(tournamentId);
				bool flag = tournament != null;
				if (flag)
				{
					TournamentPhase phase = tournament.GetTournamentPhaseById(phaseId);
					bool flag2 = phase != null;
					if (flag2)
					{
						List<TournamentScore> scores = null;
						AsyncOperation<ScoresPaginatedResult> asyncOperation = null;
						int page = 0;
						do
						{
							int num = page;
							page = num + 1;
							asyncOperation = this.LoadTournamentScores(tournamentId, phaseId, 256, page, groupId);
							yield return asyncOperation;
							bool hasError = asyncOperation.ReturnValue.HasError;
							if (hasError)
							{
								yield return this.LogoutInvalidSession();
								yield return new AsyncOperation<List<TournamentScore>>.Result(null);
							}
							else
							{
								bool flag3 = scores == null;
								if (flag3)
								{
									scores = new List<TournamentScore>(asyncOperation.ReturnValue.TotalResultCount);
								}
								scores.AddRange(asyncOperation.ReturnValue.Scores);
							}
						}
						while (!asyncOperation.ReturnValue.HasError && (asyncOperation.ReturnValue.CurrentPage - 1) * asyncOperation.ReturnValue.MaxResultsPerPage + asyncOperation.ReturnValue.Scores.Count < asyncOperation.ReturnValue.TotalResultCount);
						yield return this.LogoutInvalidSession();
						yield return new AsyncOperation<List<TournamentScore>>.Result(scores);
						scores = null;
						asyncOperation = null;
					}
					phase = null;
				}
				yield return new AsyncOperation<List<TournamentScore>>.Result(null);
				tournament = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<List<TournamentScore>>.Result(null);
			yield break;
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x00014DF4 File Offset: 0x00012FF4
		public AsyncOperation<List<TournamentMatch>> LoadTournamentMatches(long tournamentId, IEnumerable<long> matchIds)
		{
			return new AsyncOperation<List<TournamentMatch>>(this.LoadTournamentMatchesRoutine(tournamentId, matchIds), false);
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x00004B56 File Offset: 0x00002D56
		private IEnumerator LoadTournamentMatchesRoutine(long tournamentId, IEnumerable<long> matchIds)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				Tournament tournament = this.ClientData.TournamentData.GetTournamentById(tournamentId);
				bool flag = tournament != null;
				if (flag)
				{
					List<TournamentMatch> matches = null;
					AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentGetMatches(this.loginSession, tournamentId, matchIds.Take(25));
					yield return asyncOperation;
					bool hasError = asyncOperation.ReturnValue.HasError;
					if (hasError)
					{
						bool flag2 = this.callbackHandler != null;
						if (flag2)
						{
							this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
						}
					}
					else
					{
						bool flag3 = asyncOperation.ReturnValue.JsonResult.HasField("matches");
						if (flag3)
						{
							matches = tournament.LoadJsonAllMatches(asyncOperation.ReturnValue.JsonResult["matches"]);
						}
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<List<TournamentMatch>>.Result(matches);
					matches = null;
					asyncOperation = null;
				}
				yield return new AsyncOperation<List<TournamentMatch>>.Result(null);
				tournament = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<List<TournamentMatch>>.Result(null);
			yield break;
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x00014E14 File Offset: 0x00013014
		public AsyncOperation<MatchesPaginatedResult> LoadTournamentMatches(long tournamentId, int phaseId, int fromRoundId, int toRoundId, int maxResults, int page, bool onlyInProgress, int groupId = 0)
		{
			return new AsyncOperation<MatchesPaginatedResult>(this.LoadTournamentMatchesRoutine(tournamentId, phaseId, fromRoundId, toRoundId, maxResults, page, onlyInProgress, groupId), false);
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x00014E40 File Offset: 0x00013040
		private IEnumerator LoadTournamentMatchesRoutine(long tournamentId, int phaseId, int fromRoundId, int toRoundId, int maxResults, int page, bool onlyInProgress, int groupId = 0)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				Tournament tournament = this.ClientData.TournamentData.GetTournamentById(tournamentId);
				bool flag = tournament != null;
				if (flag)
				{
					List<TournamentMatch> matches = null;
					AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentGetMatches(this.loginSession, tournamentId, (byte)phaseId, (byte)fromRoundId, (byte)toRoundId, maxResults, page, onlyInProgress, groupId);
					yield return asyncOperation;
					bool hasError = asyncOperation.ReturnValue.HasError;
					if (hasError)
					{
						bool flag2 = this.callbackHandler != null;
						if (flag2)
						{
							this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
						}
					}
					else
					{
						bool flag3 = asyncOperation.ReturnValue.JsonResult.HasField("matches");
						if (flag3)
						{
							matches = tournament.LoadJsonAllMatches(asyncOperation.ReturnValue.JsonResult["matches"]);
						}
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<MatchesPaginatedResult>.Result(new MatchesPaginatedResult(matches, asyncOperation.ReturnValue));
					matches = null;
					asyncOperation = null;
				}
				yield return new AsyncOperation<MatchesPaginatedResult>.Result(null);
				tournament = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<MatchesPaginatedResult>.Result(null);
			yield break;
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x00014E98 File Offset: 0x00013098
		public AsyncOperation<List<TournamentMatch>> LoadTournamentMatchesAll(long tournamentId, int phaseId, int groupId = 0)
		{
			return new AsyncOperation<List<TournamentMatch>>(this.LoadTournamentMatchesAllRoutine(tournamentId, phaseId, groupId), false);
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x00004B73 File Offset: 0x00002D73
		private IEnumerator LoadTournamentMatchesAllRoutine(long tournamentId, int phaseId, int groupId)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				Tournament tournament = this.ClientData.TournamentData.GetTournamentById(tournamentId);
				bool flag = tournament != null;
				if (flag)
				{
					List<TournamentMatch> matches = null;
					AsyncOperation<MatchesPaginatedResult> asyncOperation = null;
					int page = 0;
					do
					{
						int num = page;
						page = num + 1;
						asyncOperation = this.LoadTournamentMatches(tournamentId, phaseId, 1, tournament.GetTournamentPhaseById(phaseId).Rounds.Count, 256, page, false, groupId);
						yield return asyncOperation;
						bool hasError = asyncOperation.ReturnValue.HasError;
						if (hasError)
						{
							yield return this.LogoutInvalidSession();
							yield return new AsyncOperation<List<TournamentMatch>>.Result(null);
						}
						else
						{
							bool flag2 = matches == null;
							if (flag2)
							{
								matches = new List<TournamentMatch>(asyncOperation.ReturnValue.TotalResultCount);
							}
							matches.AddRange(asyncOperation.ReturnValue.Matches);
						}
					}
					while (!asyncOperation.ReturnValue.HasError && (asyncOperation.ReturnValue.CurrentPage - 1) * asyncOperation.ReturnValue.MaxResultsPerPage + asyncOperation.ReturnValue.Matches.Count < asyncOperation.ReturnValue.TotalResultCount);
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<List<TournamentMatch>>.Result(matches);
					matches = null;
					asyncOperation = null;
				}
				yield return new AsyncOperation<List<TournamentMatch>>.Result(null);
				tournament = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<List<TournamentMatch>>.Result(null);
			yield break;
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x00014EBC File Offset: 0x000130BC
		public AsyncOperation<bool> LoadTournamentMatchGameSessions(TournamentMatch tournamentMatch)
		{
			return new AsyncOperation<bool>(this.LoadTournamentMatchGameSessionsRoutine(tournamentMatch), false);
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x00004B97 File Offset: 0x00002D97
		private IEnumerator LoadTournamentMatchGameSessionsRoutine(TournamentMatch tournamentMatch)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				bool flag = tournamentMatch != null && (tournamentMatch.Status != TournamentMatchStatus.Created || tournamentMatch.Status != TournamentMatchStatus.WaitingForOpponent || tournamentMatch.Status != TournamentMatchStatus.Unkown);
				if (flag)
				{
					AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentMatchGetGameSessions(this.loginSession, tournamentMatch.Id);
					yield return asyncOperation;
					bool hasError = asyncOperation.ReturnValue.HasError;
					if (hasError)
					{
						bool flag2 = this.callbackHandler != null;
						if (flag2)
						{
							this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
						}
					}
					else
					{
						tournamentMatch.LoadJSONGameSessions(asyncOperation.ReturnValue.JsonResult);
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<bool>.Result(true);
					asyncOperation = null;
				}
				yield return new AsyncOperation<bool>.Result(false);
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003CA RID: 970 RVA: 0x00014EDC File Offset: 0x000130DC
		public AsyncOperation<InviteResult> SignupForTournament(long tournamentId)
		{
			return new AsyncOperation<InviteResult>(this.SignupForTournamentRoutine(tournamentId), false);
		}

		// Token: 0x060003CB RID: 971 RVA: 0x00004BAD File Offset: 0x00002DAD
		private IEnumerator SignupForTournamentRoutine(long tournamentId)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				Tournament tournament = this.ClientData.TournamentData.GetTournamentById(tournamentId);
				bool flag = tournament != null;
				if (flag)
				{
					bool flag2 = tournament.Invite != null;
					AsyncOperation<BackboneHttpResult> asyncOperation;
					if (flag2)
					{
						asyncOperation = this.HttpClient.TournamentProcessInvite(this.loginSession, tournament.Invite.Id, 1);
					}
					else
					{
						asyncOperation = this.HttpClient.TournamentSignup(this.loginSession, tournament.Id);
					}
					yield return asyncOperation;
					bool hasError = asyncOperation.ReturnValue.HasError;
					if (hasError)
					{
						bool flag3 = this.callbackHandler != null;
						if (flag3)
						{
							this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
						}
					}
					else
					{
						yield return this.LoadTournament(tournamentId, true, false, TimeSpan.Zero);
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<InviteResult>.Result(new InviteResult(asyncOperation.ReturnValue));
					asyncOperation = null;
				}
				yield return new AsyncOperation<InviteResult>.Result(null);
				tournament = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<InviteResult>.Result(null);
			yield break;
		}

		// Token: 0x060003CC RID: 972 RVA: 0x00014EFC File Offset: 0x000130FC
		public AsyncOperation<InviteResult> SignoutFromTournament(long tournamentId)
		{
			return new AsyncOperation<InviteResult>(this.SignoutFromTournamentRoutine(tournamentId), false);
		}

		// Token: 0x060003CD RID: 973 RVA: 0x00004BC3 File Offset: 0x00002DC3
		private IEnumerator SignoutFromTournamentRoutine(long tournamentId)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				Tournament tournament = this.ClientData.TournamentData.GetTournamentById(tournamentId);
				bool flag = tournament != null && tournament.Invite != null;
				if (flag)
				{
					AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentProcessInvite(this.loginSession, tournament.Invite.Id, 2);
					yield return asyncOperation;
					bool hasError = asyncOperation.ReturnValue.HasError;
					if (hasError)
					{
						bool flag2 = this.callbackHandler != null;
						if (flag2)
						{
							this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
						}
					}
					else
					{
						yield return this.LoadTournament(tournamentId, true, false, TimeSpan.Zero);
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<InviteResult>.Result(new InviteResult(asyncOperation.ReturnValue));
					asyncOperation = null;
				}
				yield return new AsyncOperation<InviteResult>.Result(null);
				tournament = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<InviteResult>.Result(null);
			yield break;
		}

		// Token: 0x060003CE RID: 974 RVA: 0x00014F1C File Offset: 0x0001311C
		public AsyncOperation<PartyInviteResult> CreatePartyInviteForTournament(long tournamentId, long inviteUserId)
		{
			return new AsyncOperation<PartyInviteResult>(this.CreatePartyInviteForTournamentRoutine(tournamentId, inviteUserId, 0, null, null, 0), false);
		}

		// Token: 0x060003CF RID: 975 RVA: 0x00014F40 File Offset: 0x00013140
		public AsyncOperation<PartyInviteResult> CreatePartyInviteForTournament(long tournamentId, LoginProvider.Platform inviteUserPlatformType, string inviteUserPlatformId)
		{
			return new AsyncOperation<PartyInviteResult>(this.CreatePartyInviteForTournamentRoutine(tournamentId, 0L, (byte)inviteUserPlatformType, inviteUserPlatformId, null, 0), false);
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x00014F68 File Offset: 0x00013168
		public AsyncOperation<PartyInviteResult> CreatePartyInviteForTournament(long tournamentId, string inviteUserNick, int inviteUserHash)
		{
			return new AsyncOperation<PartyInviteResult>(this.CreatePartyInviteForTournamentRoutine(tournamentId, 0L, 0, null, inviteUserNick, inviteUserHash), false);
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x00004BD9 File Offset: 0x00002DD9
		private IEnumerator CreatePartyInviteForTournamentRoutine(long tournamentId, long inviteUserId, byte inviteUserPlatformType, string inviteUserPlatformId, string inviteUserNick, int inviteUserHash)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				AsyncOperation<BackboneHttpResult> serverOperation = this.HttpClient.TournamentPartyCreateInvite(this.loginSession, tournamentId, inviteUserId, inviteUserPlatformType, inviteUserPlatformId, inviteUserNick, inviteUserHash);
				yield return serverOperation;
				bool hasError = serverOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag = this.callbackHandler != null;
					if (flag)
					{
						this.callbackHandler.OnHttpError(serverOperation.ReturnValue);
					}
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<PartyInviteResult>.Result(new PartyInviteResult(serverOperation.ReturnValue));
				serverOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<PartyInviteResult>.Result(null);
			yield break;
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x00014F90 File Offset: 0x00013190
		public AsyncOperation<TournamentAcceptPartyStatus> AcceptPartyInvite(long tournamentId, long partyInviteId)
		{
			return new AsyncOperation<TournamentAcceptPartyStatus>(this.AcceptPartyInviteRoutine(tournamentId, partyInviteId), false);
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x00004C15 File Offset: 0x00002E15
		private IEnumerator AcceptPartyInviteRoutine(long tournamentId, long partyInviteId)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				TournamentAcceptPartyStatus result = TournamentAcceptPartyStatus.Unknown;
				Notification partyInviteNotification = this.Notifications.GetNotificationByType(NotificationType.TournamentPartyInvite).FirstOrDefault((Notification notification) => notification.Id == partyInviteId);
				bool flag = partyInviteNotification != null;
				if (flag)
				{
					partyInviteNotification.Processing = true;
				}
				AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentPartyAcceptInvite(this.loginSession, partyInviteId);
				yield return asyncOperation;
				bool hasError = asyncOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag2 = this.callbackHandler != null;
					if (flag2)
					{
						this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
					}
				}
				else
				{
					bool flag3 = asyncOperation.ReturnValue.JsonResult.HasField("status");
					if (flag3)
					{
						result = asyncOperation.ReturnValue.JsonResult["status"].ToEnum(TournamentAcceptPartyStatus.Unknown);
					}
					bool flag4 = result == TournamentAcceptPartyStatus.Ok;
					if (flag4)
					{
						bool flag5 = partyInviteNotification != null;
						if (flag5)
						{
							partyInviteNotification.DismissNotification();
						}
						yield return this.LoadTournament(tournamentId, true, false, TimeSpan.Zero);
					}
				}
				bool flag6 = partyInviteNotification != null;
				if (flag6)
				{
					partyInviteNotification.Processing = false;
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<TournamentAcceptPartyStatus>.Result(result);
				partyInviteNotification = null;
				asyncOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<TournamentAcceptPartyStatus>.Result(TournamentAcceptPartyStatus.NotAttempted);
			yield break;
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x00014FB0 File Offset: 0x000131B0
		public AsyncOperation<TournamentAcceptPartyStatus> AcceptPartyInvite(long tournamentId, string partyCode)
		{
			return new AsyncOperation<TournamentAcceptPartyStatus>(this.AcceptPartyInviteRoutine(tournamentId, partyCode), false);
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x00004C32 File Offset: 0x00002E32
		private IEnumerator AcceptPartyInviteRoutine(long tournamentId, string partyCode)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				TournamentAcceptPartyStatus result = TournamentAcceptPartyStatus.Unknown;
				AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentPartyJoinByCode(this.loginSession, tournamentId, partyCode);
				yield return asyncOperation;
				bool hasError = asyncOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag = this.callbackHandler != null;
					if (flag)
					{
						this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
					}
				}
				else
				{
					bool flag2 = asyncOperation.ReturnValue.JsonResult.HasField("status");
					if (flag2)
					{
						result = asyncOperation.ReturnValue.JsonResult["status"].ToEnum(TournamentAcceptPartyStatus.Unknown);
					}
					bool flag3 = result == TournamentAcceptPartyStatus.Ok;
					if (flag3)
					{
						yield return this.LoadTournament(tournamentId, true, false, TimeSpan.Zero);
					}
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<TournamentAcceptPartyStatus>.Result(result);
				asyncOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<TournamentAcceptPartyStatus>.Result(TournamentAcceptPartyStatus.NotAttempted);
			yield break;
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x00014FD0 File Offset: 0x000131D0
		public AsyncOperation<PartyCodeResult> CreatePartyCodeForTournament(long tournamentId, bool recreate = false)
		{
			return new AsyncOperation<PartyCodeResult>(this.CreatePartyCodeForTournamentRoutine(tournamentId, recreate), false);
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x00004C4F File Offset: 0x00002E4F
		private IEnumerator CreatePartyCodeForTournamentRoutine(long tournamentId, bool recreate)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				PartyCodeResult result = null;
				AsyncOperation<BackboneHttpResult> serverOperation = this.HttpClient.TournamentPartyCreateCode(this.loginSession, tournamentId, recreate);
				yield return serverOperation;
				bool hasError = serverOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag = this.callbackHandler != null;
					if (flag)
					{
						this.callbackHandler.OnHttpError(serverOperation.ReturnValue);
					}
				}
				else
				{
					result = new PartyCodeResult(serverOperation.ReturnValue);
					Tournament tournament = this.ClientData.TournamentData.GetTournamentById(tournamentId);
					bool flag2 = tournament != null && tournament.Party != null;
					if (flag2)
					{
						tournament.Party.PartyCode = result.PartyCode;
					}
					tournament = null;
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<PartyCodeResult>.Result(result);
				result = null;
				serverOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<PartyCodeResult>.Result(null);
			yield break;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x00014FF0 File Offset: 0x000131F0
		public AsyncOperation<bool> DeclinePartyInvite(long partyInviteId)
		{
			return new AsyncOperation<bool>(this.DeclinePartyInviteRoutine(partyInviteId), false);
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x00004C6C File Offset: 0x00002E6C
		private IEnumerator DeclinePartyInviteRoutine(long partyInviteId)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				bool result = false;
				Notification partyInviteNotification = this.Notifications.GetNotificationByType(NotificationType.TournamentPartyInvite).FirstOrDefault((Notification notification) => notification.Id == partyInviteId);
				bool flag = partyInviteNotification != null;
				if (flag)
				{
					partyInviteNotification.Processing = true;
				}
				AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.NotificationDismiss(this.loginSession, partyInviteId);
				yield return asyncOperation;
				bool hasError = asyncOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag2 = this.callbackHandler != null;
					if (flag2)
					{
						this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
					}
				}
				else
				{
					bool flag3 = partyInviteNotification != null;
					if (flag3)
					{
						partyInviteNotification.DismissNotification();
					}
					result = true;
				}
				bool flag4 = partyInviteNotification != null;
				if (flag4)
				{
					partyInviteNotification.Processing = false;
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<bool>.Result(result);
				partyInviteNotification = null;
				asyncOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003DA RID: 986 RVA: 0x00015010 File Offset: 0x00013210
		public AsyncOperation<TournamentRemoveUserStatus> RemovePartyUser(long tournamentId, long userId)
		{
			return new AsyncOperation<TournamentRemoveUserStatus>(this.RemovePartyUserRoutine(tournamentId, userId), false);
		}

		// Token: 0x060003DB RID: 987 RVA: 0x00004C82 File Offset: 0x00002E82
		private IEnumerator RemovePartyUserRoutine(long tournamentId, long userId)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				TournamentRemoveUserStatus result = TournamentRemoveUserStatus.Unknown;
				AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.TournamentPartyRemoveUser(this.loginSession, tournamentId, userId);
				yield return asyncOperation;
				bool hasError = asyncOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag = this.callbackHandler != null;
					if (flag)
					{
						this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
					}
				}
				else
				{
					bool flag2 = asyncOperation.ReturnValue.JsonResult.HasField("status");
					if (flag2)
					{
						result = asyncOperation.ReturnValue.JsonResult["status"].ToEnum(TournamentRemoveUserStatus.Unknown);
					}
					bool flag3 = result == TournamentRemoveUserStatus.Ok;
					if (flag3)
					{
						yield return this.LoadTournament(tournamentId, true, false, TimeSpan.Zero);
					}
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<TournamentRemoveUserStatus>.Result(result);
				asyncOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<TournamentRemoveUserStatus>.Result(TournamentRemoveUserStatus.NotAttempted);
			yield break;
		}

		// Token: 0x060003DC RID: 988 RVA: 0x00015030 File Offset: 0x00013230
		public AsyncOperation<GameSession> CreateGameSession(IEnumerable<TournamentMatch.User> users, long tournamentMatchId, byte gameSessionType = 0)
		{
			return new AsyncOperation<GameSession>(this.CreateGameSessionRoutine(from user in users
			select new GameSession.User(user.UserId, user.TeamId), tournamentMatchId, gameSessionType), false);
		}

		// Token: 0x060003DD RID: 989 RVA: 0x00015078 File Offset: 0x00013278
		public AsyncOperation<GameSession> CreateGameSession(IEnumerable<GameSession.User> users, long tournamentMatchId, byte gameSessionType = 0)
		{
			return new AsyncOperation<GameSession>(this.CreateGameSessionRoutine(users, tournamentMatchId, gameSessionType), false);
		}

		// Token: 0x060003DE RID: 990 RVA: 0x00004C9F File Offset: 0x00002E9F
		private IEnumerator CreateGameSessionRoutine(IEnumerable<GameSession.User> users, long tournamentMatchId, byte gameSessionType)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				GameSession gameSession = new GameSession(0L, gameSessionType, new List<GameSession.User>(users), tournamentMatchId);
				AsyncOperation<BackboneHttpResult> serverOperation = this.HttpClient.GameSessionCreate(this.loginSession, gameSession.GetCreateXmlData());
				yield return serverOperation;
				bool hasError = serverOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag = this.callbackHandler != null;
					if (flag)
					{
						this.callbackHandler.OnHttpError(serverOperation.ReturnValue);
					}
				}
				else
				{
					bool flag2 = serverOperation.ReturnValue.JsonResult.HasField("id");
					if (flag2)
					{
						long gameSessionId;
						bool flag3 = long.TryParse(serverOperation.ReturnValue.JsonResult["id"].str, out gameSessionId);
						if (flag3)
						{
							gameSession.Id = gameSessionId;
							yield return new AsyncOperation<GameSession>.Result(gameSession);
						}
						else
						{
							yield return new AsyncOperation<GameSession>.Result(null);
						}
					}
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<GameSession>.Result(null);
				gameSession = null;
				serverOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<GameSession>.Result(null);
			yield break;
		}

		// Token: 0x060003DF RID: 991 RVA: 0x0001509C File Offset: 0x0001329C
		public AsyncOperation<bool> SubmitGameSession(GameSession gameSession, byte[] replayData = null)
		{
			return new AsyncOperation<bool>(this.SubmitGameSessionRoutine(gameSession, replayData), false);
		}

		// Token: 0x060003E0 RID: 992 RVA: 0x00004CC3 File Offset: 0x00002EC3
		private IEnumerator SubmitGameSessionRoutine(GameSession gameSession, byte[] replayData)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				bool flag = gameSession == null;
				if (flag)
				{
					throw new ArgumentNullException("gameSession", "Game session cannot be null.");
				}
				bool flag2 = gameSession.Id <= 0L;
				if (flag2)
				{
					throw new ArgumentException("gameSession", "Game session has invalid session id.");
				}
				AsyncOperation<BackboneHttpResult> serverOperation = this.HttpClient.GameSessionSetResult(this.loginSession, gameSession.Id, gameSession.GetResultXmlData());
				yield return serverOperation;
				bool hasError = serverOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag3 = this.callbackHandler != null;
					if (flag3)
					{
						this.callbackHandler.OnHttpError(serverOperation.ReturnValue);
					}
				}
				else
				{
					bool flag4 = this.Season.UserSeasonProfile != null;
					if (flag4)
					{
						this.Season.UserSeasonProfile.LastUpdate = DateTime.MinValue;
					}
					bool flag5 = this.tournamentHub.IsInitialized && this.tournamentHub.Tournament.UserActiveMatch != null && this.tournamentHub.Tournament.UserActiveMatch.Id == gameSession.GetTournamentMatchId();
					if (flag5)
					{
						this.tournamentHub.RefreshActiveMatch();
					}
					bool flag6 = replayData != null;
					if (flag6)
					{
						AsyncOperation<bool> uploadOperation = this.SubmitGameSessionReplay(gameSession.Id, replayData);
						yield return uploadOperation;
						yield return new AsyncOperation<bool>.Result(uploadOperation.ReturnValue);
						uploadOperation = null;
					}
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<bool>.Result(true);
				serverOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x000150BC File Offset: 0x000132BC
		public AsyncOperation<bool> SubmitGameSessionReplay(long gameSessionId, byte[] replayData = null)
		{
			return new AsyncOperation<bool>(this.SubmitGameSessionReplayRoutine(gameSessionId, replayData), false);
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x00004CE0 File Offset: 0x00002EE0
		private IEnumerator SubmitGameSessionReplayRoutine(long gameSessionId, byte[] replayData)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				bool flag = gameSessionId > 0L;
				if (flag)
				{
					AsyncOperation<byte[]> compressOperation = this.CompressReplayData(replayData);
					yield return compressOperation;
					AsyncOperation<BackboneHttpResult> serverOperation = this.HttpClient.GameSessionReplayUserSubmit(this.loginSession, gameSessionId, compressOperation.ReturnValue);
					yield return serverOperation;
					bool hasError = serverOperation.ReturnValue.HasError;
					if (hasError)
					{
						bool flag2 = this.callbackHandler != null;
						if (flag2)
						{
							this.callbackHandler.OnHttpError(serverOperation.ReturnValue);
						}
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<bool>.Result(true);
					compressOperation = null;
					serverOperation = null;
				}
				else
				{
					yield return new AsyncOperation<bool>.Result(false);
				}
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x000150DC File Offset: 0x000132DC
		public AsyncOperation<bool> DownloadGameSessionReplay(GameSession gameSession)
		{
			return new AsyncOperation<bool>(this.DownloadGameSessionReplayRoutine(gameSession), false);
		}

		// Token: 0x060003E4 RID: 996 RVA: 0x00004CFD File Offset: 0x00002EFD
		private IEnumerator DownloadGameSessionReplayRoutine(GameSession gameSession)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				JSONObject metadata = null;
				bool flag = gameSession == null;
				if (flag)
				{
					throw new ArgumentNullException("gameSession", "Game session cannot be null.");
				}
				bool flag2 = gameSession.Id <= 0L;
				if (flag2)
				{
					throw new ArgumentException("gameSession", "Game session has invalid session id.");
				}
				AsyncOperation<BackboneHttpResult> serverOperation = this.HttpClient.GameSessionReplayGetMetadata(this.loginSession, gameSession.Id);
				yield return serverOperation;
				bool hasError = serverOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag3 = this.callbackHandler != null;
					if (flag3)
					{
						this.callbackHandler.OnHttpError(serverOperation.ReturnValue);
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<bool>.Result(false);
				}
				metadata = serverOperation.ReturnValue.JsonResult;
				bool flag4 = !metadata.HasField(Replay.FIELD_ISREPLAYAVAILABLE) || !metadata[Replay.FIELD_ISREPLAYAVAILABLE].b;
				if (flag4)
				{
					yield return new AsyncOperation<bool>.Result(false);
				}
				serverOperation = this.HttpClient.GameSessionReplayGetData(this.loginSession, gameSession.Id);
				yield return serverOperation;
				bool hasError2 = serverOperation.ReturnValue.HasError;
				if (hasError2)
				{
					bool flag5 = this.callbackHandler != null;
					if (flag5)
					{
						this.callbackHandler.OnHttpError(serverOperation.ReturnValue);
					}
					yield return this.LogoutInvalidSession();
					yield return new AsyncOperation<bool>.Result(false);
				}
				AsyncOperation<Submission[]> parseAndDecompressOperation = this.ParseAndDecompressReplayData(metadata, serverOperation.ReturnValue.RawData);
				yield return parseAndDecompressOperation;
				gameSession.Replay.LoadSubmissions(parseAndDecompressOperation.ReturnValue);
				yield return new AsyncOperation<bool>.Result(true);
				metadata = null;
				serverOperation = null;
				parseAndDecompressOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x000150FC File Offset: 0x000132FC
		private AsyncOperation<byte[]> CompressReplayData(byte[] replayData)
		{
			return new AsyncOperation<byte[]>(() => FileStorage.GzipCompress(replayData));
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x0001512C File Offset: 0x0001332C
		private AsyncOperation<Submission[]> ParseAndDecompressReplayData(JSONObject metadata, byte[] replayData)
		{
			return new AsyncOperation<Submission[]>(delegate()
			{
				Submission[] array = Replay.ParseReplayData(metadata, replayData);
				for (int i = 0; i < array.Length; i++)
				{
					array[i].Data = FileStorage.GzipDecompress(array[i].Data);
				}
				return array;
			});
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x00015164 File Offset: 0x00013364
		public AsyncOperation<UserSeasonProfile> LoadUserSeasonProfile(long userId, int season)
		{
			return new AsyncOperation<UserSeasonProfile>(this.LoadUserSeasonProfileRoutine(userId, 0, null, season), false);
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x00015188 File Offset: 0x00013388
		public AsyncOperation<UserSeasonProfile> LoadUserSeasonProfile(LoginProvider.Platform userPlatformType, string userPlatformId, int season)
		{
			return new AsyncOperation<UserSeasonProfile>(this.LoadUserSeasonProfileRoutine(0L, (byte)userPlatformType, userPlatformId, season), false);
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x00004D13 File Offset: 0x00002F13
		private IEnumerator LoadUserSeasonProfileRoutine(long userId, byte userPlatformType, string userPlatformId, int season)
		{
			bool isUserLoggedIn = this.IsUserLoggedIn;
			if (isUserLoggedIn)
			{
				UserSeasonProfile result = null;
				bool flag = this.Season.UserSeasonProfile != null && this.Season.UserSeasonProfile.UserId == userId && this.Season.UserSeasonProfile.Season == season;
				if (flag)
				{
					result = this.Season.UserSeasonProfile;
				}
				else
				{
					this.Season.UserSeasonProfiles.TryGetValue(userId, out result);
				}
				bool flag2 = result != null && result.LastUpdate.AddMinutes(15.0) > ServerTime.UtcNow;
				if (flag2)
				{
					yield return new AsyncOperation<UserSeasonProfile>.Result(result);
				}
				AsyncOperation<BackboneHttpResult> asyncOperation = this.HttpClient.StatsGetUserSeasonProfile(this.loginSession, userId, userPlatformType, userPlatformId, season);
				yield return asyncOperation;
				bool hasError = asyncOperation.ReturnValue.HasError;
				if (hasError)
				{
					bool flag3 = this.callbackHandler != null;
					if (flag3)
					{
						this.callbackHandler.OnHttpError(asyncOperation.ReturnValue);
					}
				}
				else
				{
					bool flag4 = asyncOperation.ReturnValue.JsonResult.HasField(UserSeasonProfile.FIELD_STATS) && !asyncOperation.ReturnValue.JsonResult[UserSeasonProfile.FIELD_STATS].IsNull;
					if (flag4)
					{
						bool flag5 = result == null;
						if (flag5)
						{
							result = new UserSeasonProfile();
							bool flag6 = !this.Season.UserSeasonProfiles.ContainsKey(userId);
							if (flag6)
							{
								this.Season.UserSeasonProfiles.Add(userId, result);
							}
							bool flag7 = this.Season.Season == season && this.User.UserId == userId;
							if (flag7)
							{
								this.Season.UserSeasonProfile = result;
							}
						}
						result.UserId = userId;
						result.Season = season;
						result.LoadJSONUserSeasonProfile(asyncOperation.ReturnValue.JsonResult);
					}
				}
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<UserSeasonProfile>.Result(result);
				result = null;
				asyncOperation = null;
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<UserSeasonProfile>.Result(null);
			yield break;
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x00004D3F File Offset: 0x00002F3F
		public void ConnectTournamentHub(ITournamentHubCallbackHandler tournamentHub, Tournament tournament)
		{
			this.tournamentHub.Initialize(tournamentHub, this, tournament);
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x00004D51 File Offset: 0x00002F51
		public void DisconnectTournamentHub()
		{
			this.tournamentHub.DeInitialize();
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x000151AC File Offset: 0x000133AC
		public AsyncOperation<bool> Logout()
		{
			return new AsyncOperation<bool>(this.LogoutRoutine(), false);
		}

		// Token: 0x060003ED RID: 1005 RVA: 0x00004D60 File Offset: 0x00002F60
		private IEnumerator LogoutRoutine()
		{
			bool flag = this.loginSession != null;
			if (flag)
			{
				yield return this.loginSession.InvalidateAuthContext();
				yield return this.LogoutInvalidSession();
				yield return new AsyncOperation<bool>.Result(true);
			}
			else
			{
				Debug.LogWarning("No user is currently logged in.");
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060003EE RID: 1006 RVA: 0x000151CC File Offset: 0x000133CC
		public AsyncOperation<bool> SaveSession()
		{
			return this.ClientData.Save();
		}

		// Token: 0x04000358 RID: 856
		private BackboneHttpClient backboneHttpClient;

		// Token: 0x04000359 RID: 857
		private bool isInitialized;

		// Token: 0x0400035A RID: 858
		private LoginSession loginSession;

		// Token: 0x0400035B RID: 859
		private BackboneClientData clientData;

		// Token: 0x0400035C RID: 860
		private IBackboneClientCallbackHandler callbackHandler;

		// Token: 0x0400035D RID: 861
		private TournamentHub tournamentHub;
	}
}
