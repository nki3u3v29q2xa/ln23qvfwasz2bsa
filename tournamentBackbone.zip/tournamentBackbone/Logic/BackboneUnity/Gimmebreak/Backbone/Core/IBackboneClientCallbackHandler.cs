﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200006A RID: 106
	public interface IBackboneClientCallbackHandler
	{
		// Token: 0x060004E8 RID: 1256
		void OnInitialize(BackboneClient client);

		// Token: 0x060004E9 RID: 1257
		void OnHttpError(BackboneHttpResult httpResult);

		// Token: 0x060004EA RID: 1258
		void OnLogin(bool freshLogin);

		// Token: 0x060004EB RID: 1259
		void OnLogout();
	}
}
