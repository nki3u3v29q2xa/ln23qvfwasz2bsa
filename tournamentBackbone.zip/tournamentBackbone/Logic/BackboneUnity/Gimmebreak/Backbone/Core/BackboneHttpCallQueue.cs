﻿using System;
using System.Collections.Generic;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000060 RID: 96
	[Serializable]
	public class BackboneHttpCallQueue
	{
		// Token: 0x1700014E RID: 334
		// (get) Token: 0x0600047A RID: 1146 RVA: 0x00015F0C File Offset: 0x0001410C
		public List<BackboneHttpCallQueue.QueueItem> QueueItems
		{
			get
			{
				bool flag = this.queueItems == null;
				if (flag)
				{
					bool flag2 = this.serializedItems != null;
					if (flag2)
					{
						this.queueItems = new List<BackboneHttpCallQueue.QueueItem>(this.serializedItems);
					}
					else
					{
						this.queueItems = new List<BackboneHttpCallQueue.QueueItem>();
					}
				}
				return this.queueItems;
			}
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x00015F64 File Offset: 0x00014164
		public bool NextItem()
		{
			this.iterator++;
			bool flag = this.iterator >= this.QueueItems.Count || this.batch != null;
			bool result;
			if (flag)
			{
				this.iterator = 0;
				result = false;
			}
			else
			{
				result = true;
			}
			return result;
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x00015FB4 File Offset: 0x000141B4
		public BackboneHttpCallQueue.QueueItem CurrentItem()
		{
			bool flag = this.QueueItems.Count == 0 || this.iterator < 0;
			BackboneHttpCallQueue.QueueItem result;
			if (flag)
			{
				result = null;
			}
			else
			{
				bool flag2 = this.batch == null;
				if (flag2)
				{
					this.batch = this.CreateBatch(50);
				}
				result = ((this.batch != null) ? this.batch.GetBatchQueueItem() : this.QueueItems[this.iterator]);
			}
			return result;
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x0001602C File Offset: 0x0001422C
		public void RemoveCurrent()
		{
			bool flag = this.batch != null;
			if (flag)
			{
				for (int i = 0; i < this.batch.BatchItems.Count; i++)
				{
					this.QueueItems.Remove(this.batch.BatchItems[i]);
				}
				this.batch = null;
			}
			else
			{
				this.QueueItems.RemoveAt(this.iterator);
				this.iterator--;
			}
			this.SaveQueue();
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x00005386 File Offset: 0x00003586
		public void AddItem(BackboneHttpCallQueue.QueueItem item)
		{
			this.QueueItems.Add(item);
			this.SaveQueue();
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0000539D File Offset: 0x0000359D
		public void InitializeBatchForUser(long userId, string accessToken)
		{
			this.batchUserId = userId;
			this.batchAccsessToken = accessToken;
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x000160BC File Offset: 0x000142BC
		public BackboneHttpCallQueue.Batch CreateBatch(int itemsPerBatch)
		{
			bool flag = itemsPerBatch < 5;
			if (flag)
			{
				itemsPerBatch = 5;
			}
			BackboneHttpCallQueue.Batch batch = new BackboneHttpCallQueue.Batch(this.batchUserId, this.batchAccsessToken);
			for (int i = this.QueueItems.Count - 1; i >= 0; i--)
			{
				bool flag2 = this.QueueItems[i].UserId == this.batchUserId && BackboneHttpCallQueue.SUPPORTEDBATCHCALLS.Contains(this.QueueItems[i].Endpoint);
				if (flag2)
				{
					batch.BatchItems.Add(this.QueueItems[i]);
				}
				bool flag3 = batch.BatchItems.Count == itemsPerBatch;
				if (flag3)
				{
					break;
				}
			}
			bool flag4 = batch.BatchItems.Count > 0;
			BackboneHttpCallQueue.Batch result;
			if (flag4)
			{
				result = batch;
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x000053AE File Offset: 0x000035AE
		public void SaveQueue()
		{
			this.serializedItems = this.QueueItems.ToArray();
			FileStorage.SaveObjectToFile<BackboneHttpCallQueue>("bhcq.data", this, true);
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x0001619C File Offset: 0x0001439C
		public static BackboneHttpCallQueue LoadQueue()
		{
			BackboneHttpCallQueue backboneHttpCallQueue = FileStorage.LoadObjectFromFile<BackboneHttpCallQueue>("bhcq.data", true);
			return backboneHttpCallQueue ?? new BackboneHttpCallQueue();
		}

		// Token: 0x0400037A RID: 890
		private const string QUEUEFILE = "bhcq.data";

		// Token: 0x0400037B RID: 891
		private static HashSet<string> SUPPORTEDBATCHCALLS = new HashSet<string>
		{
			"updatesoloresults",
			"createfeedback"
		};

		// Token: 0x0400037C RID: 892
		private const int ITEMSPERBATCH = 50;

		// Token: 0x0400037D RID: 893
		private int iterator;

		// Token: 0x0400037E RID: 894
		private long batchUserId;

		// Token: 0x0400037F RID: 895
		private string batchAccsessToken;

		// Token: 0x04000380 RID: 896
		private BackboneHttpCallQueue.Batch batch;

		// Token: 0x04000381 RID: 897
		private BackboneHttpCallQueue.QueueItem[] serializedItems;

		// Token: 0x04000382 RID: 898
		[NonSerialized]
		private List<BackboneHttpCallQueue.QueueItem> queueItems;

		// Token: 0x020000F1 RID: 241
		[Serializable]
		public class QueueItem
		{
			// Token: 0x17000256 RID: 598
			// (get) Token: 0x06000854 RID: 2132 RVA: 0x00006F97 File Offset: 0x00005197
			// (set) Token: 0x06000855 RID: 2133 RVA: 0x00006F9F File Offset: 0x0000519F
			public long UserId { get; set; }

			// Token: 0x17000257 RID: 599
			// (get) Token: 0x06000856 RID: 2134 RVA: 0x00006FA8 File Offset: 0x000051A8
			// (set) Token: 0x06000857 RID: 2135 RVA: 0x00006FB0 File Offset: 0x000051B0
			public string Endpoint { get; set; }

			// Token: 0x17000258 RID: 600
			// (get) Token: 0x06000858 RID: 2136 RVA: 0x00006FB9 File Offset: 0x000051B9
			// (set) Token: 0x06000859 RID: 2137 RVA: 0x00006FC1 File Offset: 0x000051C1
			public HttpType HttpType { get; set; }

			// Token: 0x17000259 RID: 601
			// (get) Token: 0x0600085A RID: 2138 RVA: 0x000246BC File Offset: 0x000228BC
			// (set) Token: 0x0600085B RID: 2139 RVA: 0x00006FCA File Offset: 0x000051CA
			public StringKeyValuePair[] Data
			{
				get
				{
					return this.data;
				}
				set
				{
					this.data = value;
				}
			}

			// Token: 0x0600085C RID: 2140 RVA: 0x000246D4 File Offset: 0x000228D4
			public bool ValidateItem()
			{
				for (int i = 0; i < this.Data.Length; i++)
				{
					bool flag = string.IsNullOrEmpty(this.Data[i].Key) || this.Data[i].Value == null;
					if (flag)
					{
						return false;
					}
				}
				bool flag2 = this.UserId <= 0L || string.IsNullOrEmpty(this.Endpoint);
				return !flag2;
			}

			// Token: 0x040006BF RID: 1727
			private StringKeyValuePair[] data;
		}

		// Token: 0x020000F2 RID: 242
		public class Batch
		{
			// Token: 0x1700025A RID: 602
			// (get) Token: 0x0600085E RID: 2142 RVA: 0x00006FDD File Offset: 0x000051DD
			// (set) Token: 0x0600085F RID: 2143 RVA: 0x00006FE5 File Offset: 0x000051E5
			public List<BackboneHttpCallQueue.QueueItem> BatchItems { get; set; }

			// Token: 0x06000860 RID: 2144 RVA: 0x00006FEE File Offset: 0x000051EE
			public Batch(long userId, string userAccessToken)
			{
				this.userId = userId;
				this.userAccessToken = userAccessToken;
				this.BatchItems = new List<BackboneHttpCallQueue.QueueItem>();
			}

			// Token: 0x06000861 RID: 2145 RVA: 0x00024754 File Offset: 0x00022954
			public BackboneHttpCallQueue.QueueItem GetBatchQueueItem()
			{
				return new BackboneHttpCallQueue.QueueItem
				{
					UserId = this.userId,
					Endpoint = "processbatch",
					HttpType = HttpType.Post,
					Data = new StringKeyValuePair[]
					{
						new StringKeyValuePair("accessToken", this.userAccessToken),
						new StringKeyValuePair("data", this.GetBatchXML())
					}
				};
			}

			// Token: 0x06000862 RID: 2146 RVA: 0x000247C4 File Offset: 0x000229C4
			private string GetBatchXML()
			{
				string text = string.Empty;
				for (int i = 0; i < this.BatchItems.Count; i++)
				{
					bool flag = i == 0;
					if (flag)
					{
						text = this.GetBatchQueueItemXml(this.BatchItems[i]);
					}
					else
					{
						text += this.GetBatchQueueItemXml(this.BatchItems[i]);
					}
				}
				return string.Format("<batch>{0}</batch>", text);
			}

			// Token: 0x06000863 RID: 2147 RVA: 0x00024840 File Offset: 0x00022A40
			private string GetBatchQueueItemXml(BackboneHttpCallQueue.QueueItem item)
			{
				return string.Format("<batch-item method=\"{0}\"><params>{1}</params></batch-item>", item.Endpoint, this.GetBatchQueueItemParameters(item));
			}

			// Token: 0x06000864 RID: 2148 RVA: 0x0002486C File Offset: 0x00022A6C
			private string GetBatchQueueItemParameters(BackboneHttpCallQueue.QueueItem item)
			{
				string text = string.Empty;
				for (int i = 0; i < item.Data.Length; i++)
				{
					bool flag = i == 0;
					if (flag)
					{
						text = string.Format("<{0}>{1}</{2}>", item.Data[i].Key, item.Data[i].Value, item.Data[i].Key);
					}
					else
					{
						text += string.Format("<{0}>{1}</{2}>", item.Data[i].Key, item.Data[i].Value, item.Data[i].Key);
					}
				}
				return text;
			}

			// Token: 0x040006C3 RID: 1731
			private long userId;

			// Token: 0x040006C4 RID: 1732
			private string userAccessToken;
		}
	}
}
