﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000065 RID: 101
	public interface ISerializeVersion
	{
		// Token: 0x17000159 RID: 345
		// (get) Token: 0x060004C2 RID: 1218
		// (set) Token: 0x060004C3 RID: 1219
		Version Version { get; set; }
	}
}
