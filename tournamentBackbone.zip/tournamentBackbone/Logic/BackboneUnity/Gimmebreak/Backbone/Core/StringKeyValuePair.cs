﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200005D RID: 93
	[Serializable]
	public class StringKeyValuePair
	{
		// Token: 0x1700014A RID: 330
		// (get) Token: 0x06000422 RID: 1058 RVA: 0x00004EBF File Offset: 0x000030BF
		// (set) Token: 0x06000423 RID: 1059 RVA: 0x00004EC7 File Offset: 0x000030C7
		public string Key { get; set; }

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x06000424 RID: 1060 RVA: 0x00004ED0 File Offset: 0x000030D0
		// (set) Token: 0x06000425 RID: 1061 RVA: 0x00004ED8 File Offset: 0x000030D8
		public string Value { get; set; }

		// Token: 0x06000426 RID: 1062 RVA: 0x00004EE1 File Offset: 0x000030E1
		public StringKeyValuePair()
		{
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x00004EEB File Offset: 0x000030EB
		public StringKeyValuePair(string key, string value)
		{
			this.Key = key;
			this.Value = value;
		}
	}
}
