﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;
using Gimmebreak.Backbone.Core.JSON;
using Gimmebreak.Backbone.User;
using UnityEngine;
using UnityEngine.Networking;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200005F RID: 95
	internal class BackboneHttpClient
	{
		// Token: 0x1700014C RID: 332
		// (get) Token: 0x06000428 RID: 1064 RVA: 0x00015710 File Offset: 0x00013910
		public bool IsProcessingQueue
		{
			get
			{
				return this.isProcessingQueue;
			}
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x00015728 File Offset: 0x00013928
		public bool HasPendingTransactions(long userId)
		{
			for (int i = 0; i < this.queue.QueueItems.Count; i++)
			{
				bool flag = this.queue.QueueItems[i].UserId == userId;
				if (flag)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x0600042A RID: 1066 RVA: 0x00015780 File Offset: 0x00013980
		public bool IsProcessingServerCall
		{
			get
			{
				return this.activeServerCallsCount > 0;
			}
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x00004F05 File Offset: 0x00003105
		private BackboneHttpClient(Uri baseUri, string applicationId)
		{
			this.baseUri = baseUri;
			this.applicationId = applicationId;
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0001579C File Offset: 0x0001399C
		public static AsyncOperation<BackboneHttpClient> Initialize(Uri baseUri, string applicationId)
		{
			return new AsyncOperation<BackboneHttpClient>(BackboneHttpClient.InitializeRoutine(baseUri, applicationId), true);
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x00004F1D File Offset: 0x0000311D
		private static IEnumerator InitializeRoutine(Uri baseUri, string applicationId)
		{
			yield return new AsyncOperation<BackboneHttpClient>.Result(new BackboneHttpClient(baseUri, applicationId)
			{
				queue = BackboneHttpCallQueue.LoadQueue()
			});
			yield break;
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x000157BC File Offset: 0x000139BC
		public AsyncOperation<bool> ProcessQueue(long userId, string userAccessToken)
		{
			return new AsyncOperation<bool>(this.ProcessQueueRoutine(userId, userAccessToken), false);
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x00004F33 File Offset: 0x00003133
		private IEnumerator ProcessQueueRoutine(long userId, string userAccessToken)
		{
			bool flag = this.isProcessingQueue;
			if (flag)
			{
				yield return new AsyncOperation<bool>.Result(false);
			}
			this.queue.InitializeBatchForUser(userId, userAccessToken);
			this.isProcessingQueue = true;
			yield return this.ProcessQueueItemsRoutine(userId);
			this.isProcessingQueue = false;
			yield return new AsyncOperation<bool>.Result(true);
			yield break;
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x00004F50 File Offset: 0x00003150
		private IEnumerator ProcessQueueItemsRoutine(long userId)
		{
			BackboneHttpCallQueue.QueueItem item = this.queue.CurrentItem();
			bool flag = item != null;
			if (flag)
			{
				bool flag2 = item.ValidateItem();
				if (flag2)
				{
					bool flag3 = item.UserId == userId;
					if (flag3)
					{
						KeyValuePair<string, object>[] data = new KeyValuePair<string, object>[item.Data.Length];
						int num;
						for (int i = 0; i < data.Length; i = num + 1)
						{
							data[i] = new KeyValuePair<string, object>(item.Data[i].Key, item.Data[i].Value);
							num = i;
						}
						AsyncOperation<BackboneHttpResult> serverCallOperation = this.ServerCall(item.HttpType, item.Endpoint, data);
						yield return serverCallOperation;
						bool flag4 = !serverCallOperation.ReturnValue.HasError;
						if (flag4)
						{
							this.queue.RemoveCurrent();
						}
						yield return this.ProcessNextQueueItem(userId);
						data = null;
						serverCallOperation = null;
					}
					else
					{
						yield return this.ProcessNextQueueItem(userId);
					}
				}
				else
				{
					Debug.LogError("Item is not valid and will be removed.");
					this.queue.RemoveCurrent();
					yield return this.ProcessNextQueueItem(userId);
				}
			}
			yield break;
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x000157DC File Offset: 0x000139DC
		private IEnumerator ProcessNextQueueItem(long userId)
		{
			bool flag = this.queue.NextItem();
			IEnumerator result;
			if (flag)
			{
				result = this.ProcessQueueItemsRoutine(userId);
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x0001580C File Offset: 0x00013A0C
		private AsyncOperation<BackboneHttpResult> AuthServerCall(IAuthContext authContext, bool forceAccessTokenRefresh, HttpType httpType, string endpoint, params KeyValuePair<string, object>[] callParams)
		{
			return new AsyncOperation<BackboneHttpResult>(this.AuthServerCallRoutine(authContext, forceAccessTokenRefresh, httpType, endpoint, 3, callParams), false);
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x00015834 File Offset: 0x00013A34
		private AsyncOperation<BackboneHttpResult> AuthServerCall(IAuthContext authContext, bool forceAccessTokenRefresh, HttpType httpType, string endpoint, int retryCount, params KeyValuePair<string, object>[] callParams)
		{
			return new AsyncOperation<BackboneHttpResult>(this.AuthServerCallRoutine(authContext, forceAccessTokenRefresh, httpType, endpoint, retryCount, callParams), false);
		}

		// Token: 0x06000434 RID: 1076 RVA: 0x00004F66 File Offset: 0x00003166
		private IEnumerator AuthServerCallRoutine(IAuthContext authContext, bool forceAccessTokenRefresh, HttpType httpType, string endpoint, int retryCount, params KeyValuePair<string, object>[] callParams)
		{
			bool flag = authContext == null || string.IsNullOrEmpty(authContext.AccessToken) || string.IsNullOrEmpty(authContext.RefreshToken) || string.IsNullOrEmpty(authContext.DeviceId);
			if (flag)
			{
				yield return new AsyncOperation<BackboneHttpResult>.Result(BackboneHttpResult.Error("Invalid auth context. AccessToken/RefreshToken/DeviceId cannot be null or empty.", -1, null));
			}
			AsyncOperation<BackboneHttpResult> refreshTokenOperation = null;
			bool flag2 = authContext.ExpireAt <= ServerTime.UtcNow || forceAccessTokenRefresh;
			if (flag2)
			{
				refreshTokenOperation = this.RefreshAccessToken(authContext);
				yield return refreshTokenOperation;
			}
			bool flag3 = refreshTokenOperation == null || !refreshTokenOperation.ReturnValue.HasError;
			if (flag3)
			{
				AsyncOperation<BackboneHttpResult> serverCallOperation = this.ServerCall(httpType, endpoint, callParams.Concat(new KeyValuePair<string, object>[]
				{
					new KeyValuePair<string, object>("accessToken", authContext.AccessToken)
				}).ToArray<KeyValuePair<string, object>>());
				yield return serverCallOperation;
				bool flag4 = serverCallOperation.ReturnValue.HasError && serverCallOperation.ReturnValue.IsHttpError && serverCallOperation.ReturnValue.ResponseCode == 401 && serverCallOperation.ReturnValue.ErrorCode == 8 && retryCount > 0;
				if (flag4)
				{
					serverCallOperation = this.AuthServerCall(authContext, true, httpType, endpoint, retryCount - 1, callParams);
					yield return serverCallOperation;
				}
				yield return new AsyncOperation<BackboneHttpResult>.Result(serverCallOperation.ReturnValue);
				serverCallOperation = null;
			}
			else
			{
				yield return new AsyncOperation<BackboneHttpResult>.Result(refreshTokenOperation.ReturnValue);
			}
			yield break;
		}

		// Token: 0x06000435 RID: 1077 RVA: 0x0001585C File Offset: 0x00013A5C
		private AsyncOperation<BackboneHttpResult> ServerCall(HttpType httpType, string endpoint, params KeyValuePair<string, object>[] callParams)
		{
			return this.ServerCall(httpType, endpoint, 3, callParams);
		}

		// Token: 0x06000436 RID: 1078 RVA: 0x00015878 File Offset: 0x00013A78
		private AsyncOperation<BackboneHttpResult> ServerCall(HttpType httpType, string endpoint, int retryCount, params KeyValuePair<string, object>[] callParams)
		{
			return new AsyncOperation<BackboneHttpResult>(this.ServerCallRoutine(httpType, endpoint, retryCount, callParams), false);
		}

		// Token: 0x06000437 RID: 1079 RVA: 0x00004FA2 File Offset: 0x000031A2
		private IEnumerator ServerCallRoutine(HttpType httpType, string endpoint, int retryCount, params KeyValuePair<string, object>[] callParams)
		{
			UriBuilder uriBuilder = new UriBuilder(this.baseUri);
			uriBuilder.Path = endpoint;
			UnityWebRequest request = null;
			string accessToken = null;
			bool flag = httpType == HttpType.Get;
			if (flag)
			{
				string queryString = "";
				int num;
				for (int i = 0; i < callParams.Length; i = num + 1)
				{
					bool flag2 = callParams[i].Value is string;
					if (!flag2)
					{
						throw new ArgumentException("KeyValue parameter contains value that is not string. GET can only process string values passed in callParams.", "callParams");
					}
					bool flag3 = callParams[i].Key == "accessToken";
					if (flag3)
					{
						accessToken = (string)callParams[i].Value;
					}
					queryString = string.Concat(new string[]
					{
						queryString,
						(i == 0) ? string.Empty : "&",
						UnityWebRequest.EscapeURL(callParams[i].Key),
						"=",
						UnityWebRequest.EscapeURL((string)callParams[i].Value)
					});
					num = i;
				}
				uriBuilder.Query = queryString;
				request = UnityWebRequest.Get(uriBuilder.Uri.AbsoluteUri);
				request.SetRequestHeader("BACKBONE_APP_ID", this.applicationId);
				bool flag4 = !string.IsNullOrEmpty(accessToken);
				if (flag4)
				{
					request.SetRequestHeader("ACCESS_TOKEN", accessToken);
				}
				queryString = null;
			}
			else
			{
				bool flag5 = httpType == HttpType.Post;
				if (flag5)
				{
					WWWForm form = new WWWForm();
					int num;
					for (int j = 0; j < callParams.Length; j = num + 1)
					{
						bool flag6 = callParams[j].Value is string;
						if (flag6)
						{
							bool flag7 = callParams[j].Key == "accessToken";
							if (flag7)
							{
								accessToken = (string)callParams[j].Value;
							}
							form.AddField(callParams[j].Key, (string)callParams[j].Value);
						}
						else
						{
							bool flag8 = callParams[j].Value is byte[];
							if (!flag8)
							{
								throw new ArgumentException("KeyValue parameter contains value that is not string or byte array. POST can only process string or byte array values passed in callParams.", "callParams");
							}
							form.AddBinaryData(callParams[j].Key, (byte[])callParams[j].Value);
						}
						num = j;
					}
					request = UnityWebRequest.Post(uriBuilder.Uri.AbsoluteUri, form);
					request.SetRequestHeader("BACKBONE_APP_ID", this.applicationId);
					bool flag9 = !string.IsNullOrEmpty(accessToken);
					if (flag9)
					{
						request.SetRequestHeader("ACCESS_TOKEN", accessToken);
					}
					form = null;
				}
			}
			AsyncOperation<BackboneHttpResult> processOperation = this.ProcessServerCall(request);
			yield return processOperation;
			BackboneHttpResult result = processOperation.ReturnValue;
			bool flag10 = result.IsHttpError && result.ResponseCode == 503 && retryCount > 0;
			if (flag10)
			{
				processOperation = this.ServerCall(httpType, endpoint, retryCount - 1, callParams);
				yield return processOperation;
			}
			yield return new AsyncOperation<BackboneHttpResult>.Result(processOperation.ReturnValue);
			yield break;
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x0001589C File Offset: 0x00013A9C
		private AsyncOperation<BackboneHttpResult> ProcessServerCall(UnityWebRequest request)
		{
			return new AsyncOperation<BackboneHttpResult>(this.ProcessServerCallRoutine(request), false);
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x00004FCE File Offset: 0x000031CE
		private IEnumerator ProcessServerCallRoutine(UnityWebRequest request)
		{
			this.activeServerCallsCount++;
			DateTime requestStart = DateTime.UtcNow;
			yield return request.SendWebRequest();
			DateTime requestFinish = DateTime.UtcNow;
			this.activeServerCallsCount = Mathf.Max(0, this.activeServerCallsCount - 1);
			bool isNetworkError = request.isNetworkError;
			if (isNetworkError)
			{
				yield return new AsyncOperation<BackboneHttpResult>.Result(new BackboneHttpResult((int)request.responseCode, null, -1, request.error, null));
			}
			else
			{
				bool flag = (requestFinish - requestStart).TotalSeconds <= 5.0 && request.GetResponseHeaders() != null && request.GetResponseHeaders().ContainsKey("Date");
				if (flag)
				{
					DateTime serverTime;
					bool flag2 = DateTime.TryParse(request.GetResponseHeader("Date"), out serverTime);
					if (flag2)
					{
						ServerTime.UpdateCompensationTimeStamp(serverTime.ToUniversalTime());
					}
				}
				AsyncOperation<JSONObject> parseOperation = null;
				bool flag3;
				if (request.GetResponseHeaders() != null)
				{
					flag3 = !request.GetResponseHeaders().Keys.Any((string key) => key.ToLower() == "content-type");
				}
				else
				{
					flag3 = true;
				}
				bool flag4 = flag3;
				if (flag4)
				{
					throw new InvalidHttpReponseException("Response does not specify 'content-type' header. Response data cannot be correctly processed.");
				}
				string contentTypeKey = request.GetResponseHeaders().Keys.First((string key) => key.ToLower() == "content-type");
				string contentType = request.GetResponseHeaders()[contentTypeKey].ToLower();
				bool flag5 = contentType.ToLower().Contains("application/json");
				if (flag5)
				{
					parseOperation = this.ParseJson(request.downloadHandler.text);
					yield return parseOperation;
				}
				contentTypeKey = null;
				contentType = null;
				BackboneHttpResult result = null;
				try
				{
					JSONObject jsonResult = null;
					bool flag6 = parseOperation != null;
					if (flag6)
					{
						jsonResult = parseOperation.ReturnValue;
					}
					int serverErrorCode = -1;
					string serverErrorMessage = null;
					string serverErrorReference = null;
					bool flag7 = request.responseCode >= 400L && jsonResult != null;
					if (flag7)
					{
						bool flag8 = jsonResult.HasField("code");
						if (flag8)
						{
							serverErrorCode = (int)jsonResult["code"].i;
						}
						bool flag9 = jsonResult.HasField("message");
						if (flag9)
						{
							serverErrorMessage = jsonResult["message"].str;
						}
						bool flag10 = jsonResult.HasField("reference");
						if (flag10)
						{
							serverErrorReference = jsonResult["message"].str;
						}
					}
					result = new BackboneHttpResult((int)request.responseCode, jsonResult, request.downloadHandler.data, serverErrorCode, serverErrorMessage, serverErrorReference);
					jsonResult = null;
					serverErrorMessage = null;
					serverErrorReference = null;
				}
				catch (Exception ex)
				{
					Exception e = ex;
					result = new BackboneHttpResult(-1, null, -1, e.Message, null);
				}
				yield return new AsyncOperation<BackboneHttpResult>.Result(result);
				parseOperation = null;
				result = null;
			}
			yield break;
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x000158BC File Offset: 0x00013ABC
		private AsyncOperation<JSONObject> ParseJson(string json)
		{
			return new AsyncOperation<JSONObject>(this.ParseJsonRoutine(json), true);
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x00004FE4 File Offset: 0x000031E4
		private IEnumerator ParseJsonRoutine(string json)
		{
			JSONObject result = null;
			bool flag = !string.IsNullOrEmpty(json);
			if (flag)
			{
				result = new JSONObject(json, -2, false, false);
			}
			yield return new AsyncOperation<JSONObject>.Result(result);
			yield break;
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x000158DC File Offset: 0x00013ADC
		public AsyncOperation<BackboneHttpResult> Ping()
		{
			return new AsyncOperation<BackboneHttpResult>(this.PingRoutine(), false);
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x00004FFA File Offset: 0x000031FA
		private IEnumerator PingRoutine()
		{
			AsyncOperation<BackboneHttpResult> pingOperation = this.ServerCall(HttpType.Get, "api/v1/ping", new KeyValuePair<string, object>[0]);
			yield return pingOperation;
			yield return new AsyncOperation<BackboneHttpResult>.Result(pingOperation.ReturnValue);
			yield break;
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x000158FC File Offset: 0x00013AFC
		public AsyncOperation<BackboneHttpResult> Login(ILoginProvider loginProvider)
		{
			return new AsyncOperation<BackboneHttpResult>(this.LoginRoutine(loginProvider), false);
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x00005009 File Offset: 0x00003209
		private IEnumerator LoginRoutine(ILoginProvider loginProvider)
		{
			List<KeyValuePair<string, object>> parameters = new List<KeyValuePair<string, object>>();
			parameters.Add(new KeyValuePair<string, object>("createNewUser", loginProvider.CreateNewUser ? "1" : "0"));
			parameters.Add(new KeyValuePair<string, object>("deviceId", loginProvider.DeviceId));
			parameters.Add(new KeyValuePair<string, object>("deviceName", loginProvider.DeviceName));
			parameters.Add(new KeyValuePair<string, object>("devicePlatform", loginProvider.DevicePlatform.ToString()));
			bool flag = loginProvider.Parameters != null && loginProvider.Parameters.Length != 0;
			if (flag)
			{
				parameters.AddRange(loginProvider.Parameters);
			}
			AsyncOperation<BackboneHttpResult> loginOperation = this.ServerCall(HttpType.Post, "api/v1/userLogin" + loginProvider.ProviderName, parameters.ToArray());
			yield return loginOperation;
			yield return new AsyncOperation<BackboneHttpResult>.Result(loginOperation.ReturnValue);
			yield break;
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x0001591C File Offset: 0x00013B1C
		public AsyncOperation<BackboneHttpResult> Connect(IAuthContext authContext, ILoginProvider loginProvider)
		{
			return new AsyncOperation<BackboneHttpResult>(this.ConnectRoutine(authContext, loginProvider), false);
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x0000501F File Offset: 0x0000321F
		private IEnumerator ConnectRoutine(IAuthContext authContext, ILoginProvider loginProvider)
		{
			List<KeyValuePair<string, object>> parameters = new List<KeyValuePair<string, object>>();
			parameters.Add(new KeyValuePair<string, object>("deviceId", loginProvider.DeviceId));
			parameters.Add(new KeyValuePair<string, object>("deviceName", loginProvider.DeviceName));
			parameters.Add(new KeyValuePair<string, object>("devicePlatform", loginProvider.DevicePlatform.ToString()));
			bool flag = loginProvider.Parameters != null && loginProvider.Parameters.Length != 0;
			if (flag)
			{
				parameters.AddRange(loginProvider.Parameters);
			}
			AsyncOperation<BackboneHttpResult> loginOperation = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/userConnect" + loginProvider.ProviderName, parameters.ToArray());
			yield return loginOperation;
			yield return new AsyncOperation<BackboneHttpResult>.Result(loginOperation.ReturnValue);
			yield break;
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0001593C File Offset: 0x00013B3C
		public AsyncOperation<BackboneHttpResult> RefreshAccessToken(IAuthContext authContext)
		{
			return new AsyncOperation<BackboneHttpResult>(this.RefreshAccessTokenRoutine(authContext), false);
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x0000503C File Offset: 0x0000323C
		private IEnumerator RefreshAccessTokenRoutine(IAuthContext authContext)
		{
			bool flag = authContext == null || string.IsNullOrEmpty(authContext.AccessToken) || string.IsNullOrEmpty(authContext.RefreshToken) || string.IsNullOrEmpty(authContext.DeviceId);
			if (flag)
			{
				yield return new AsyncOperation<BackboneHttpResult>.Result(BackboneHttpResult.Error("Invalid auth context. AccessToken/RefreshToken/DeviceId cannot be null or empty.", -1, null));
			}
			AsyncOperation<BackboneHttpResult> serverCall = this.ServerCall(HttpType.Post, "api/v1/refreshAccessToken", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("accessToken", authContext.AccessToken),
				new KeyValuePair<string, object>("refreshToken", authContext.RefreshToken),
				new KeyValuePair<string, object>("deviceId", authContext.DeviceId)
			});
			yield return serverCall;
			bool flag2 = !serverCall.ReturnValue.HasError;
			if (flag2)
			{
				bool flag3 = serverCall.ReturnValue.JsonResult != null && serverCall.ReturnValue.JsonResult.HasField("accessToken") && !string.IsNullOrEmpty(serverCall.ReturnValue.JsonResult["accessToken"].str) && serverCall.ReturnValue.JsonResult.HasField("expireAt") && !string.IsNullOrEmpty(serverCall.ReturnValue.JsonResult["expireAt"].str);
				if (!flag3)
				{
					throw new InvalidHttpReponseException("Endpoint refreshToken returned invalid data.");
				}
				yield return authContext.UpdateAccessToken(serverCall.ReturnValue.JsonResult["accessToken"].str, serverCall.ReturnValue.JsonResult["expireAt"].ToUniversalTime());
			}
			else
			{
				bool flag4 = serverCall.ReturnValue.IsHttpError && serverCall.ReturnValue.ResponseCode == 401 && serverCall.ReturnValue.ErrorCode == 10;
				if (flag4)
				{
					yield return authContext.InvalidateAuthContext();
				}
			}
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x0001595C File Offset: 0x00013B5C
		public AsyncOperation<BackboneHttpResult> UserGet(IAuthContext authContext, DateTime lastUpdate, DateTime lastSynch, XElement userData, bool generateQuests, bool getQuests, bool getTiles, bool getLayouts)
		{
			bool flag = userData != null;
			AsyncOperation<BackboneHttpResult> result;
			if (flag)
			{
				result = new AsyncOperation<BackboneHttpResult>(this.UserGetRoutine(authContext, lastUpdate, lastSynch, userData, generateQuests, getQuests, getTiles, getLayouts), false);
			}
			else
			{
				result = new AsyncOperation<BackboneHttpResult>(this.UserGetRoutine(authContext, lastUpdate, lastSynch, generateQuests, getQuests, getTiles, getLayouts), false);
			}
			return result;
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x000159AC File Offset: 0x00013BAC
		private IEnumerator UserGetRoutine(IAuthContext authContext, DateTime lastUpdate, DateTime lastSynch, XElement userData, bool generateQuests, bool getQuests, bool getTiles, bool getLayouts)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/userGet", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("lastUpdate", BackboneHttpClient.GetSqlDate(lastUpdate)),
				new KeyValuePair<string, object>("lastSync", BackboneHttpClient.GetSqlDate(lastSynch)),
				new KeyValuePair<string, object>("userData", userData.ToString()),
				new KeyValuePair<string, object>("generateQuests", BackboneHttpClient.GetBool(generateQuests)),
				new KeyValuePair<string, object>("getQuests", BackboneHttpClient.GetBool(getQuests)),
				new KeyValuePair<string, object>("getTiles", BackboneHttpClient.GetBool(getTiles)),
				new KeyValuePair<string, object>("getLayouts", BackboneHttpClient.GetBool(getLayouts))
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x00015A04 File Offset: 0x00013C04
		private IEnumerator UserGetRoutine(IAuthContext authContext, DateTime lastUpdate, DateTime lastSynch, bool generateQuests, bool getQuests, bool getTiles, bool getLayouts)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/userGet", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("lastUpdate", BackboneHttpClient.GetSqlDate(lastUpdate)),
				new KeyValuePair<string, object>("lastSync", BackboneHttpClient.GetSqlDate(lastSynch)),
				new KeyValuePair<string, object>("generateQuests", BackboneHttpClient.GetBool(generateQuests)),
				new KeyValuePair<string, object>("getQuests", BackboneHttpClient.GetBool(getQuests)),
				new KeyValuePair<string, object>("getTiles", BackboneHttpClient.GetBool(getTiles)),
				new KeyValuePair<string, object>("getLayouts", BackboneHttpClient.GetBool(getLayouts))
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x00015A54 File Offset: 0x00013C54
		public AsyncOperation<BackboneHttpResult> UserChangeNick(IAuthContext authContext, string nickName, int preferredNickHash)
		{
			bool flag = preferredNickHash <= 0;
			AsyncOperation<BackboneHttpResult> result;
			if (flag)
			{
				result = new AsyncOperation<BackboneHttpResult>(this.UserChangeNickRoutine(authContext, nickName), false);
			}
			else
			{
				result = new AsyncOperation<BackboneHttpResult>(this.UserChangeNickRoutine(authContext, nickName, preferredNickHash), false);
			}
			return result;
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x00005052 File Offset: 0x00003252
		private IEnumerator UserChangeNickRoutine(IAuthContext authContext, string nickName)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/userChangeNick", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("nickName", nickName)
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x0000506F File Offset: 0x0000326F
		private IEnumerator UserChangeNickRoutine(IAuthContext authContext, string nickName, int preferredNickHash)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/userChangeNick", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("nickName", nickName),
				new KeyValuePair<string, object>("preferredNickHash", preferredNickHash.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x00015A94 File Offset: 0x00013C94
		public AsyncOperation<BackboneHttpResult> UserReport(IAuthContext authContext, long userId, ReportReason reportReason, long gameSessionId = 0L, long tournamentMatchId = 0L, long tournamentId = 0L)
		{
			return new AsyncOperation<BackboneHttpResult>(this.UserReportRoutine(authContext, userId, reportReason, gameSessionId, tournamentMatchId, tournamentId), false);
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x00005093 File Offset: 0x00003293
		private IEnumerator UserReportRoutine(IAuthContext authContext, long userId, ReportReason reportReason, long gameSessionId = 0L, long tournamentMatchId = 0L, long tournamentId = 0L)
		{
			bool forceAccessTokenRefresh = false;
			HttpType httpType = HttpType.Post;
			string endpoint = "api/v1/userReport";
			KeyValuePair<string, object>[] array = new KeyValuePair<string, object>[5];
			array[0] = new KeyValuePair<string, object>("reportUserId", userId.ToString());
			int num = 1;
			string key = "reportReason";
			int num2 = (int)reportReason;
			array[num] = new KeyValuePair<string, object>(key, num2.ToString());
			array[2] = new KeyValuePair<string, object>("tournamentId", (tournamentId > 0L) ? tournamentId.ToString() : string.Empty);
			array[3] = new KeyValuePair<string, object>("tournamentMatchId", (tournamentMatchId > 0L) ? tournamentMatchId.ToString() : string.Empty);
			array[4] = new KeyValuePair<string, object>("gameSessionId", (gameSessionId > 0L) ? gameSessionId.ToString() : string.Empty);
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, forceAccessTokenRefresh, httpType, endpoint, array);
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x00015ABC File Offset: 0x00013CBC
		public AsyncOperation<BackboneHttpResult> NotificationGetActive(IAuthContext authContext)
		{
			return new AsyncOperation<BackboneHttpResult>(this.NotificationGetActiveRoutine(authContext), false);
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x000050CF File Offset: 0x000032CF
		private IEnumerator NotificationGetActiveRoutine(IAuthContext authContext)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/notificationGetActive", new KeyValuePair<string, object>[0]);
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x00015ADC File Offset: 0x00013CDC
		public AsyncOperation<BackboneHttpResult> NotificationDismiss(IAuthContext authContext, long notificationId)
		{
			return new AsyncOperation<BackboneHttpResult>(this.NotificationDismissRoutine(authContext, notificationId), false);
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x000050E5 File Offset: 0x000032E5
		private IEnumerator NotificationDismissRoutine(IAuthContext authContext, long notificationId)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/notificationDismiss", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("notificationId", notificationId.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x00015AFC File Offset: 0x00013CFC
		public AsyncOperation<BackboneHttpResult> TournamentGetList(IAuthContext authContext, DateTime sinceDate, DateTime untilDate, int maxResults, int page)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentGetListRoutine(authContext, sinceDate, untilDate, maxResults, page), false);
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x00005102 File Offset: 0x00003302
		private IEnumerator TournamentGetListRoutine(IAuthContext authContext, DateTime sinceDate, DateTime untilDate, int maxResults, int page)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v2/tournamentGetList", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("sinceDate", BackboneHttpClient.GetSqlDate(sinceDate)),
				new KeyValuePair<string, object>("untilDate", BackboneHttpClient.GetSqlDate(untilDate)),
				new KeyValuePair<string, object>("maxResults", maxResults.ToString()),
				new KeyValuePair<string, object>("page", page.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x00015B24 File Offset: 0x00013D24
		public AsyncOperation<BackboneHttpResult> TournamentGetData(IAuthContext authContext, long tournamentId, bool getAllData, bool readyForNextMatch)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentGetDataRoutine(authContext, tournamentId, getAllData, readyForNextMatch), false);
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x00005136 File Offset: 0x00003336
		private IEnumerator TournamentGetDataRoutine(IAuthContext authContext, long tournamentId, bool getAllData, bool readyForNextMatch)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v2/tournamentGetData", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("tournamentId", tournamentId.ToString()),
				new KeyValuePair<string, object>("getAllData", BackboneHttpClient.GetBool(getAllData)),
				new KeyValuePair<string, object>("readyForNextMatch", BackboneHttpClient.GetBool(readyForNextMatch))
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x00015B48 File Offset: 0x00013D48
		public AsyncOperation<BackboneHttpResult> TournamentGetScore(IAuthContext authContext, long tournamentId, byte phaseId, int maxResults, int page, int groupId)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentGetScoreRoutine(authContext, tournamentId, phaseId, maxResults, page, groupId), false);
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x00005162 File Offset: 0x00003362
		private IEnumerator TournamentGetScoreRoutine(IAuthContext authContext, long tournamentId, byte phaseId, int maxResults, int page, int groupId)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/tournamentGetScores", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("tournamentId", tournamentId.ToString()),
				new KeyValuePair<string, object>("phaseId", phaseId.ToString()),
				new KeyValuePair<string, object>("groupId", groupId.ToString()),
				new KeyValuePair<string, object>("maxResults", maxResults.ToString()),
				new KeyValuePair<string, object>("page", page.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x00015B70 File Offset: 0x00013D70
		public AsyncOperation<BackboneHttpResult> TournamentGetMatches(IAuthContext authContext, long tournamentId, byte phaseId, byte fromRoundId, byte toRoundId, int maxResults, int page, bool onlyInProgress, int groupId)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentGetMatchesRoutine(authContext, tournamentId, phaseId, fromRoundId, toRoundId, maxResults, page, onlyInProgress, groupId), false);
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x00015BA0 File Offset: 0x00013DA0
		private IEnumerator TournamentGetMatchesRoutine(IAuthContext authContext, long tournamentId, byte phaseId, byte fromRoundId, byte toRoundId, int maxResults, int page, bool onlyInProgress, int groupId)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/tournamentGetMatches", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("tournamentId", tournamentId.ToString()),
				new KeyValuePair<string, object>("phaseId", phaseId.ToString()),
				new KeyValuePair<string, object>("groupId", groupId.ToString()),
				new KeyValuePair<string, object>("fromRoundId", fromRoundId.ToString()),
				new KeyValuePair<string, object>("toRoundId", toRoundId.ToString()),
				new KeyValuePair<string, object>("maxResults", maxResults.ToString()),
				new KeyValuePair<string, object>("page", page.ToString()),
				new KeyValuePair<string, object>("onlyInProgress", BackboneHttpClient.GetBool(onlyInProgress))
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x00015C00 File Offset: 0x00013E00
		public AsyncOperation<BackboneHttpResult> TournamentGetMatches(IAuthContext authContext, long tournamentId, IEnumerable<long> matchIds)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentGetMatchesRoutine(authContext, tournamentId, matchIds), false);
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0000519E File Offset: 0x0000339E
		private IEnumerator TournamentGetMatchesRoutine(IAuthContext authContext, long tournamentId, IEnumerable<long> matchIds)
		{
			bool forceAccessTokenRefresh = false;
			HttpType httpType = HttpType.Post;
			string endpoint = "api/v1/tournamentGetMatchesByIds";
			KeyValuePair<string, object>[] array = new KeyValuePair<string, object>[2];
			array[0] = new KeyValuePair<string, object>("tournamentId", tournamentId.ToString());
			array[1] = new KeyValuePair<string, object>("matchIds", string.Join(",", (from id in matchIds
			select id.ToString()).ToArray<string>()));
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, forceAccessTokenRefresh, httpType, endpoint, array);
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x00015C24 File Offset: 0x00013E24
		public AsyncOperation<BackboneHttpResult> TournamentMatchGetGameSessions(IAuthContext authContext, long tournamentMatchId)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentMatchGetGameSessionsRoutine(authContext, tournamentMatchId), false);
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x000051C2 File Offset: 0x000033C2
		private IEnumerator TournamentMatchGetGameSessionsRoutine(IAuthContext authContext, long tournamentMatchId)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/tournamentMatchGetGameSessions", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("tournamentMatchId", tournamentMatchId.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x00015C44 File Offset: 0x00013E44
		public AsyncOperation<BackboneHttpResult> TournamentSignup(IAuthContext authContext, long tournamentId)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentSignupRoutine(authContext, tournamentId), false);
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x000051DF File Offset: 0x000033DF
		private IEnumerator TournamentSignupRoutine(IAuthContext authContext, long tournamentId)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/tournamentSignup", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("tournamentId", tournamentId.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x00015C64 File Offset: 0x00013E64
		public AsyncOperation<BackboneHttpResult> TournamentProcessInvite(IAuthContext authContext, long inviteId, int action)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentProcessInviteRoutine(authContext, inviteId, action), false);
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x000051FC File Offset: 0x000033FC
		private IEnumerator TournamentProcessInviteRoutine(IAuthContext authContext, long inviteId, int action)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/tournamentProcessInvite", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("inviteId", inviteId.ToString()),
				new KeyValuePair<string, object>("action", action.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x00015C88 File Offset: 0x00013E88
		public AsyncOperation<BackboneHttpResult> TournamentPartyCreateInvite(IAuthContext authContext, long tournamentId, long inviteUserId, byte inviteUserPlatformType, string inviteUserPlatformlId, string inviteUserNick, int inviteUserHash)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentPartyCreateInviteRoutine(authContext, tournamentId, inviteUserId, inviteUserPlatformType, inviteUserPlatformlId, inviteUserNick, inviteUserHash), false);
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x00015CB4 File Offset: 0x00013EB4
		private IEnumerator TournamentPartyCreateInviteRoutine(IAuthContext authContext, long tournamentId, long inviteUserId, byte inviteUserPlatformType, string inviteUserPlatformlId, string inviteUserNick, int inviteUserHash)
		{
			List<KeyValuePair<string, object>> parameters = new List<KeyValuePair<string, object>>();
			parameters.Add(new KeyValuePair<string, object>("tournamentId", tournamentId.ToString()));
			bool flag = !string.IsNullOrEmpty(inviteUserPlatformlId);
			if (flag)
			{
				parameters.Add(new KeyValuePair<string, object>("inviteUserPlatformType", inviteUserPlatformType.ToString()));
				parameters.Add(new KeyValuePair<string, object>("inviteUserPlatformId", inviteUserPlatformlId));
			}
			else
			{
				bool flag2 = !string.IsNullOrEmpty(inviteUserNick);
				if (flag2)
				{
					parameters.Add(new KeyValuePair<string, object>("inviteUserNick", inviteUserNick));
					parameters.Add(new KeyValuePair<string, object>("inviteUserHash", inviteUserHash.ToString()));
				}
				else
				{
					parameters.Add(new KeyValuePair<string, object>("inviteUserId", inviteUserId.ToString()));
				}
			}
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v2/tournamentPartyCreateInvite", parameters.ToArray());
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x00015D04 File Offset: 0x00013F04
		public AsyncOperation<BackboneHttpResult> TournamentPartyAcceptInvite(IAuthContext authContext, long partyInviteId)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentPartyAcceptInviteRoutine(authContext, partyInviteId), false);
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x00005220 File Offset: 0x00003420
		private IEnumerator TournamentPartyAcceptInviteRoutine(IAuthContext authContext, long partyInviteId)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/tournamentPartyAcceptInvite", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("partyInviteId", partyInviteId.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x00015D24 File Offset: 0x00013F24
		public AsyncOperation<BackboneHttpResult> TournamentPartyCreateCode(IAuthContext authContext, long tournamentId, bool recreate)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentPartyCreateCodeRoutine(authContext, tournamentId, recreate), false);
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x0000523D File Offset: 0x0000343D
		private IEnumerator TournamentPartyCreateCodeRoutine(IAuthContext authContext, long tournamentId, bool recreate)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/tournamentPartyCreateCode", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("tournamentId", tournamentId.ToString()),
				new KeyValuePair<string, object>("recreate", BackboneHttpClient.GetBool(recreate))
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x00015D48 File Offset: 0x00013F48
		public AsyncOperation<BackboneHttpResult> TournamentPartyJoinByCode(IAuthContext authContext, long tournamentId, string partyCode)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentPartyJoinByCodeRoutine(authContext, tournamentId, partyCode), false);
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x00005261 File Offset: 0x00003461
		private IEnumerator TournamentPartyJoinByCodeRoutine(IAuthContext authContext, long tournamentId, string partyCode)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/tournamentPartyJoinByCode", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("tournamentId", tournamentId.ToString()),
				new KeyValuePair<string, object>("partyCode", partyCode)
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x00015D6C File Offset: 0x00013F6C
		public AsyncOperation<BackboneHttpResult> TournamentPartyRemoveUser(IAuthContext authContext, long tournamentId, long removeUserId)
		{
			return new AsyncOperation<BackboneHttpResult>(this.TournamentPartyRemoveUserRoutine(authContext, tournamentId, removeUserId), false);
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x00005285 File Offset: 0x00003485
		private IEnumerator TournamentPartyRemoveUserRoutine(IAuthContext authContext, long tournamentId, long removeUserId)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/tournamentPartyRemoveUser", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("tournamentId", tournamentId.ToString()),
				new KeyValuePair<string, object>("removeUserId", removeUserId.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x00015D90 File Offset: 0x00013F90
		public AsyncOperation<BackboneHttpResult> GameSessionCreate(IAuthContext authContext, XElement gameSessionData)
		{
			return new AsyncOperation<BackboneHttpResult>(this.GameSessionCreateRoutine(authContext, gameSessionData), false);
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x000052A9 File Offset: 0x000034A9
		private IEnumerator GameSessionCreateRoutine(IAuthContext authContext, XElement gameSessionData)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/gameSessionCreate", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("gameSessionData", gameSessionData.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x00015DB0 File Offset: 0x00013FB0
		public AsyncOperation<BackboneHttpResult> GameSessionSetResult(IAuthContext authContext, long gameSessionId, XElement gameSessionData)
		{
			return new AsyncOperation<BackboneHttpResult>(this.GameSessionSetResultRoutine(authContext, gameSessionId, gameSessionData), false);
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x000052C6 File Offset: 0x000034C6
		private IEnumerator GameSessionSetResultRoutine(IAuthContext authContext, long gameSessionId, XElement gameSessionData)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/gameSessionSetResult", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("gameSessionId", gameSessionId.ToString()),
				new KeyValuePair<string, object>("gameSessionData", gameSessionData.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x00015DD4 File Offset: 0x00013FD4
		public AsyncOperation<BackboneHttpResult> GameSessionReplayUserSubmit(IAuthContext authContext, long gameSessionId, byte[] gameSessionReplayData)
		{
			return new AsyncOperation<BackboneHttpResult>(this.GameSessionReplayUserSubmitRoutine(authContext, gameSessionId, gameSessionReplayData), false);
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x000052EA File Offset: 0x000034EA
		private IEnumerator GameSessionReplayUserSubmitRoutine(IAuthContext authContext, long gameSessionId, byte[] gameSessionReplayData)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/gameSessionReplayUserSubmit", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("gameSessionId", gameSessionId.ToString()),
				new KeyValuePair<string, object>("gameSessionReplayData", gameSessionReplayData)
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x00015DF8 File Offset: 0x00013FF8
		public AsyncOperation<BackboneHttpResult> GameSessionReplayGetMetadata(IAuthContext authContext, long gameSessionId)
		{
			return new AsyncOperation<BackboneHttpResult>(this.GameSessionReplayGetMetadataRoutine(authContext, gameSessionId), false);
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x0000530E File Offset: 0x0000350E
		private IEnumerator GameSessionReplayGetMetadataRoutine(IAuthContext authContext, long gameSessionId)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/gameSessionReplayGetMetadata", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("gameSessionId", gameSessionId.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x00015E18 File Offset: 0x00014018
		public AsyncOperation<BackboneHttpResult> GameSessionReplayGetData(IAuthContext authContext, long gameSessionId)
		{
			return new AsyncOperation<BackboneHttpResult>(this.GameSessionReplayGetDataRoutine(authContext, gameSessionId), false);
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x0000532B File Offset: 0x0000352B
		private IEnumerator GameSessionReplayGetDataRoutine(IAuthContext authContext, long gameSessionId)
		{
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/gameSessionReplayGetData", new KeyValuePair<string, object>[]
			{
				new KeyValuePair<string, object>("gameSessionId", gameSessionId.ToString())
			});
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x00015E38 File Offset: 0x00014038
		public AsyncOperation<BackboneHttpResult> StatsGetUserSeasonProfile(IAuthContext authContext, long userId, byte userPlatformType, string userPlatformlId, int season)
		{
			return new AsyncOperation<BackboneHttpResult>(this.StatsGetUserSeasonProfileRoutine(authContext, userId, userPlatformType, userPlatformlId, season), false);
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x00005348 File Offset: 0x00003548
		private IEnumerator StatsGetUserSeasonProfileRoutine(IAuthContext authContext, long userId, byte userPlatformType, string userPlatformlId, int season)
		{
			List<KeyValuePair<string, object>> parameters = new List<KeyValuePair<string, object>>();
			parameters.Add(new KeyValuePair<string, object>("season", season.ToString()));
			bool flag = !string.IsNullOrEmpty(userPlatformlId);
			if (flag)
			{
				parameters.Add(new KeyValuePair<string, object>("userPlatformType", userPlatformType.ToString()));
				parameters.Add(new KeyValuePair<string, object>("userPlatformId", userPlatformlId));
			}
			else
			{
				parameters.Add(new KeyValuePair<string, object>("userId", userId.ToString()));
			}
			AsyncOperation<BackboneHttpResult> serverCall = this.AuthServerCall(authContext, false, HttpType.Post, "api/v1/statsGetUserSeasonProfile", parameters.ToArray());
			yield return serverCall;
			yield return new AsyncOperation<BackboneHttpResult>.Result(serverCall.ReturnValue);
			yield break;
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x00015E60 File Offset: 0x00014060
		public static string GetSqlDate(DateTime dateTime)
		{
			bool flag = dateTime == DateTime.MinValue;
			if (flag)
			{
				dateTime = new DateTime(1900, 1, 1);
			}
			return dateTime.ToString("s");
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x00015EA0 File Offset: 0x000140A0
		public static string GetBool(bool value)
		{
			return value ? "1" : "0";
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x00015EC4 File Offset: 0x000140C4
		public static string GetFloat(float value)
		{
			return value.ToString("0.00", CultureInfo.InvariantCulture);
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x00015EE8 File Offset: 0x000140E8
		public static string GetFloat(decimal value)
		{
			return value.ToString("0.00", CultureInfo.InvariantCulture);
		}

		// Token: 0x04000375 RID: 885
		private readonly Uri baseUri;

		// Token: 0x04000376 RID: 886
		private BackboneHttpCallQueue queue;

		// Token: 0x04000377 RID: 887
		private bool isProcessingQueue;

		// Token: 0x04000378 RID: 888
		private int activeServerCallsCount;

		// Token: 0x04000379 RID: 889
		private readonly string applicationId;
	}
}
