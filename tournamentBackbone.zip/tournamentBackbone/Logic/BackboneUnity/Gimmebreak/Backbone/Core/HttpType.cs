﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200005E RID: 94
	public enum HttpType
	{
		// Token: 0x04000373 RID: 883
		Get,
		// Token: 0x04000374 RID: 884
		Post
	}
}
