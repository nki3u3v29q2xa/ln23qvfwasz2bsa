﻿using System;
using Gimmebreak.Backbone.Notifications;
using Gimmebreak.Backbone.Season;
using Gimmebreak.Backbone.Tournaments;
using Gimmebreak.Backbone.User;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000057 RID: 87
	[Serializable]
	public class BackboneClientData
	{
		// Token: 0x17000132 RID: 306
		// (get) Token: 0x060003EF RID: 1007 RVA: 0x00004D6F File Offset: 0x00002F6F
		// (set) Token: 0x060003F0 RID: 1008 RVA: 0x00004D77 File Offset: 0x00002F77
		public UserData UserData { get; set; }

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x060003F1 RID: 1009 RVA: 0x00004D80 File Offset: 0x00002F80
		// (set) Token: 0x060003F2 RID: 1010 RVA: 0x00004D88 File Offset: 0x00002F88
		public SeasonData SeasonData { get; set; }

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x060003F3 RID: 1011 RVA: 0x00004D91 File Offset: 0x00002F91
		// (set) Token: 0x060003F4 RID: 1012 RVA: 0x00004D99 File Offset: 0x00002F99
		public NotificationData NotificationData { get; set; }

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x060003F5 RID: 1013 RVA: 0x00004DA2 File Offset: 0x00002FA2
		// (set) Token: 0x060003F6 RID: 1014 RVA: 0x00004DAA File Offset: 0x00002FAA
		public TournamentData TournamentData { get; set; }

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x060003F7 RID: 1015 RVA: 0x00004DB3 File Offset: 0x00002FB3
		// (set) Token: 0x060003F8 RID: 1016 RVA: 0x00004DBB File Offset: 0x00002FBB
		public GameData GameData { get; set; }

		// Token: 0x060003F9 RID: 1017 RVA: 0x000151EC File Offset: 0x000133EC
		public BackboneClientData()
		{
			this.UserData = new UserData();
			this.SeasonData = new SeasonData();
			this.NotificationData = new NotificationData();
			this.TournamentData = new TournamentData();
			this.GameData = new GameData();
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x00015240 File Offset: 0x00013440
		internal AsyncOperation<bool> Delete()
		{
			return new AsyncOperation<bool>(delegate()
			{
				FileStorage.Delete(FileStorage.CLIENT_DATA_FILE);
				return true;
			});
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x00015278 File Offset: 0x00013478
		internal AsyncOperation<bool> Save()
		{
			return new AsyncOperation<bool>(delegate()
			{
				FileStorage.SaveObjectToFile<BackboneClientData>(FileStorage.CLIENT_DATA_FILE, this, true);
				return true;
			});
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x0001529C File Offset: 0x0001349C
		internal static AsyncOperation<BackboneClientData> Load()
		{
			return new AsyncOperation<BackboneClientData>(() => FileStorage.LoadObjectFromFile<BackboneClientData>(FileStorage.CLIENT_DATA_FILE, true));
		}
	}
}
