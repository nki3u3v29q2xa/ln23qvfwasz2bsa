﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000066 RID: 102
	public interface IFileStorageProvider
	{
		// Token: 0x1700015A RID: 346
		// (get) Token: 0x060004C4 RID: 1220
		string PersistantDataPath { get; }

		// Token: 0x060004C5 RID: 1221
		bool FileExists(string path);

		// Token: 0x060004C6 RID: 1222
		void FileSave(string path, byte[] data);

		// Token: 0x060004C7 RID: 1223
		byte[] FileLoad(string path);

		// Token: 0x060004C8 RID: 1224
		void FileDelete(string path);

		// Token: 0x060004C9 RID: 1225
		bool DirectoryExists(string path);

		// Token: 0x060004CA RID: 1226
		void DirectoryCreate(string path);

		// Token: 0x060004CB RID: 1227
		void DirectoryDelete(string path);
	}
}
