﻿using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace Gimmebreak.Backbone.Core.JSON
{
	// Token: 0x02000072 RID: 114
	public static class JSONTemplates
	{
		// Token: 0x06000542 RID: 1346 RVA: 0x00017D48 File Offset: 0x00015F48
		public static DateTime ToUniversalTime(this JSONObject obj)
		{
			DateTime dateTime;
			DateTime.TryParse(obj.str, out dateTime);
			return dateTime.ToUniversalTime();
		}

		// Token: 0x06000543 RID: 1347 RVA: 0x00017D70 File Offset: 0x00015F70
		public static JSONObject TOJSON(object obj)
		{
			bool flag = JSONTemplates.touched.Add(obj);
			JSONObject result;
			if (flag)
			{
				JSONObject obj2 = JSONObject.obj;
				FieldInfo[] fields = obj.GetType().GetFields();
				foreach (FieldInfo fieldInfo in fields)
				{
					JSONObject jsonobject = JSONObject.nullJO;
					bool flag2 = !fieldInfo.GetValue(obj).Equals(null);
					if (flag2)
					{
						MethodInfo method = typeof(JSONTemplates).GetMethod("From" + fieldInfo.FieldType.Name);
						bool flag3 = method != null;
						if (flag3)
						{
							jsonobject = (JSONObject)method.Invoke(null, new object[]
							{
								fieldInfo.GetValue(obj)
							});
						}
						else
						{
							bool flag4 = fieldInfo.FieldType == typeof(string);
							if (flag4)
							{
								jsonobject = JSONObject.CreateStringObject(fieldInfo.GetValue(obj).ToString());
							}
							else
							{
								jsonobject = JSONObject.Create(fieldInfo.GetValue(obj).ToString(), -2, false, false);
							}
						}
					}
					bool flag5 = jsonobject;
					if (flag5)
					{
						bool flag6 = jsonobject.type > JSONObject.Type.NULL;
						if (flag6)
						{
							obj2.AddField(fieldInfo.Name, jsonobject);
						}
						else
						{
							Debug.LogWarning(string.Concat(new string[]
							{
								"Null for this non-null object, property ",
								fieldInfo.Name,
								" of class ",
								obj.GetType().Name,
								". Object type is ",
								fieldInfo.FieldType.Name
							}));
						}
					}
				}
				PropertyInfo[] properties = obj.GetType().GetProperties();
				foreach (PropertyInfo propertyInfo in properties)
				{
					JSONObject jsonobject2 = JSONObject.nullJO;
					bool flag7 = !propertyInfo.GetValue(obj, null).Equals(null);
					if (flag7)
					{
						MethodInfo method2 = typeof(JSONTemplates).GetMethod("From" + propertyInfo.PropertyType.Name);
						bool flag8 = method2 != null;
						if (flag8)
						{
							jsonobject2 = (JSONObject)method2.Invoke(null, new object[]
							{
								propertyInfo.GetValue(obj, null)
							});
						}
						else
						{
							bool flag9 = propertyInfo.PropertyType == typeof(string);
							if (flag9)
							{
								jsonobject2 = JSONObject.CreateStringObject(propertyInfo.GetValue(obj, null).ToString());
							}
							else
							{
								jsonobject2 = JSONObject.Create(propertyInfo.GetValue(obj, null).ToString(), -2, false, false);
							}
						}
					}
					bool flag10 = jsonobject2;
					if (flag10)
					{
						bool flag11 = jsonobject2.type > JSONObject.Type.NULL;
						if (flag11)
						{
							obj2.AddField(propertyInfo.Name, jsonobject2);
						}
						else
						{
							Debug.LogWarning(string.Concat(new string[]
							{
								"Null for this non-null object, property ",
								propertyInfo.Name,
								" of class ",
								obj.GetType().Name,
								". Object type is ",
								propertyInfo.PropertyType.Name
							}));
						}
					}
				}
				result = obj2;
			}
			else
			{
				Debug.LogWarning("trying to save the same data twice");
				result = JSONObject.nullJO;
			}
			return result;
		}

		// Token: 0x06000544 RID: 1348 RVA: 0x000180A8 File Offset: 0x000162A8
		public static T ToEnum<T>(this JSONObject obj, T defaultResult)
		{
			bool flag = obj == null;
			T result;
			if (flag)
			{
				result = defaultResult;
			}
			else
			{
				bool isNumber = obj.IsNumber;
				if (isNumber)
				{
					int num = (int)obj.n;
					T t = Enum.IsDefined(typeof(T), num) ? ((T)((object)Enum.ToObject(typeof(T), num))) : defaultResult;
					result = t;
				}
				else
				{
					bool isString = obj.IsString;
					if (isString)
					{
						int num2;
						bool flag2 = int.TryParse(obj.str, out num2);
						if (flag2)
						{
							return Enum.IsDefined(typeof(T), num2) ? ((T)((object)Enum.ToObject(typeof(T), num2))) : defaultResult;
						}
					}
					result = defaultResult;
				}
			}
			return result;
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x00018170 File Offset: 0x00016370
		public static Vector2 ToVector2(JSONObject obj)
		{
			float num = obj["x"] ? obj["x"].f : 0f;
			float num2 = obj["y"] ? obj["y"].f : 0f;
			return new Vector2(num, num2);
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x000181E0 File Offset: 0x000163E0
		public static JSONObject FromVector2(Vector2 v)
		{
			JSONObject obj = JSONObject.obj;
			bool flag = v.x != 0f;
			if (flag)
			{
				obj.AddField("x", v.x);
			}
			bool flag2 = v.y != 0f;
			if (flag2)
			{
				obj.AddField("y", v.y);
			}
			return obj;
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x00018248 File Offset: 0x00016448
		public static JSONObject FromVector3(Vector3 v)
		{
			JSONObject obj = JSONObject.obj;
			bool flag = v.x != 0f;
			if (flag)
			{
				obj.AddField("x", v.x);
			}
			bool flag2 = v.y != 0f;
			if (flag2)
			{
				obj.AddField("y", v.y);
			}
			bool flag3 = v.z != 0f;
			if (flag3)
			{
				obj.AddField("z", v.z);
			}
			return obj;
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x000182D8 File Offset: 0x000164D8
		public static Vector3 ToVector3(JSONObject obj)
		{
			float num = obj["x"] ? obj["x"].f : 0f;
			float num2 = obj["y"] ? obj["y"].f : 0f;
			float num3 = obj["z"] ? obj["z"].f : 0f;
			return new Vector3(num, num2, num3);
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x00018370 File Offset: 0x00016570
		public static JSONObject FromVector4(Vector4 v)
		{
			JSONObject obj = JSONObject.obj;
			bool flag = v.x != 0f;
			if (flag)
			{
				obj.AddField("x", v.x);
			}
			bool flag2 = v.y != 0f;
			if (flag2)
			{
				obj.AddField("y", v.y);
			}
			bool flag3 = v.z != 0f;
			if (flag3)
			{
				obj.AddField("z", v.z);
			}
			bool flag4 = v.w != 0f;
			if (flag4)
			{
				obj.AddField("w", v.w);
			}
			return obj;
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x00018428 File Offset: 0x00016628
		public static Vector4 ToVector4(JSONObject obj)
		{
			float num = obj["x"] ? obj["x"].f : 0f;
			float num2 = obj["y"] ? obj["y"].f : 0f;
			float num3 = obj["z"] ? obj["z"].f : 0f;
			float num4 = obj["w"] ? obj["w"].f : 0f;
			return new Vector4(num, num2, num3, num4);
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x000184F0 File Offset: 0x000166F0
		public static JSONObject FromMatrix4x4(Matrix4x4 m)
		{
			JSONObject obj = JSONObject.obj;
			bool flag = m.m00 != 0f;
			if (flag)
			{
				obj.AddField("m00", m.m00);
			}
			bool flag2 = m.m01 != 0f;
			if (flag2)
			{
				obj.AddField("m01", m.m01);
			}
			bool flag3 = m.m02 != 0f;
			if (flag3)
			{
				obj.AddField("m02", m.m02);
			}
			bool flag4 = m.m03 != 0f;
			if (flag4)
			{
				obj.AddField("m03", m.m03);
			}
			bool flag5 = m.m10 != 0f;
			if (flag5)
			{
				obj.AddField("m10", m.m10);
			}
			bool flag6 = m.m11 != 0f;
			if (flag6)
			{
				obj.AddField("m11", m.m11);
			}
			bool flag7 = m.m12 != 0f;
			if (flag7)
			{
				obj.AddField("m12", m.m12);
			}
			bool flag8 = m.m13 != 0f;
			if (flag8)
			{
				obj.AddField("m13", m.m13);
			}
			bool flag9 = m.m20 != 0f;
			if (flag9)
			{
				obj.AddField("m20", m.m20);
			}
			bool flag10 = m.m21 != 0f;
			if (flag10)
			{
				obj.AddField("m21", m.m21);
			}
			bool flag11 = m.m22 != 0f;
			if (flag11)
			{
				obj.AddField("m22", m.m22);
			}
			bool flag12 = m.m23 != 0f;
			if (flag12)
			{
				obj.AddField("m23", m.m23);
			}
			bool flag13 = m.m30 != 0f;
			if (flag13)
			{
				obj.AddField("m30", m.m30);
			}
			bool flag14 = m.m31 != 0f;
			if (flag14)
			{
				obj.AddField("m31", m.m31);
			}
			bool flag15 = m.m32 != 0f;
			if (flag15)
			{
				obj.AddField("m32", m.m32);
			}
			bool flag16 = m.m33 != 0f;
			if (flag16)
			{
				obj.AddField("m33", m.m33);
			}
			return obj;
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x00018788 File Offset: 0x00016988
		public static Matrix4x4 ToMatrix4x4(JSONObject obj)
		{
			Matrix4x4 result = default(Matrix4x4);
			bool flag = obj["m00"];
			if (flag)
			{
				result.m00 = obj["m00"].f;
			}
			bool flag2 = obj["m01"];
			if (flag2)
			{
				result.m01 = obj["m01"].f;
			}
			bool flag3 = obj["m02"];
			if (flag3)
			{
				result.m02 = obj["m02"].f;
			}
			bool flag4 = obj["m03"];
			if (flag4)
			{
				result.m03 = obj["m03"].f;
			}
			bool flag5 = obj["m10"];
			if (flag5)
			{
				result.m10 = obj["m10"].f;
			}
			bool flag6 = obj["m11"];
			if (flag6)
			{
				result.m11 = obj["m11"].f;
			}
			bool flag7 = obj["m12"];
			if (flag7)
			{
				result.m12 = obj["m12"].f;
			}
			bool flag8 = obj["m13"];
			if (flag8)
			{
				result.m13 = obj["m13"].f;
			}
			bool flag9 = obj["m20"];
			if (flag9)
			{
				result.m20 = obj["m20"].f;
			}
			bool flag10 = obj["m21"];
			if (flag10)
			{
				result.m21 = obj["m21"].f;
			}
			bool flag11 = obj["m22"];
			if (flag11)
			{
				result.m22 = obj["m22"].f;
			}
			bool flag12 = obj["m23"];
			if (flag12)
			{
				result.m23 = obj["m23"].f;
			}
			bool flag13 = obj["m30"];
			if (flag13)
			{
				result.m30 = obj["m30"].f;
			}
			bool flag14 = obj["m31"];
			if (flag14)
			{
				result.m31 = obj["m31"].f;
			}
			bool flag15 = obj["m32"];
			if (flag15)
			{
				result.m32 = obj["m32"].f;
			}
			bool flag16 = obj["m33"];
			if (flag16)
			{
				result.m33 = obj["m33"].f;
			}
			return result;
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x00018A70 File Offset: 0x00016C70
		public static JSONObject FromQuaternion(Quaternion q)
		{
			JSONObject obj = JSONObject.obj;
			bool flag = q.w != 0f;
			if (flag)
			{
				obj.AddField("w", q.w);
			}
			bool flag2 = q.x != 0f;
			if (flag2)
			{
				obj.AddField("x", q.x);
			}
			bool flag3 = q.y != 0f;
			if (flag3)
			{
				obj.AddField("y", q.y);
			}
			bool flag4 = q.z != 0f;
			if (flag4)
			{
				obj.AddField("z", q.z);
			}
			return obj;
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x00018B28 File Offset: 0x00016D28
		public static Quaternion ToQuaternion(JSONObject obj)
		{
			float num = obj["x"] ? obj["x"].f : 0f;
			float num2 = obj["y"] ? obj["y"].f : 0f;
			float num3 = obj["z"] ? obj["z"].f : 0f;
			float num4 = obj["w"] ? obj["w"].f : 0f;
			return new Quaternion(num, num2, num3, num4);
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x00018BF0 File Offset: 0x00016DF0
		public static JSONObject FromColor(Color c)
		{
			JSONObject obj = JSONObject.obj;
			bool flag = c.r != 0f;
			if (flag)
			{
				obj.AddField("r", c.r);
			}
			bool flag2 = c.g != 0f;
			if (flag2)
			{
				obj.AddField("g", c.g);
			}
			bool flag3 = c.b != 0f;
			if (flag3)
			{
				obj.AddField("b", c.b);
			}
			bool flag4 = c.a != 0f;
			if (flag4)
			{
				obj.AddField("a", c.a);
			}
			return obj;
		}

		// Token: 0x06000550 RID: 1360 RVA: 0x00018CA8 File Offset: 0x00016EA8
		public static Color ToColor(JSONObject obj)
		{
			Color result = default(Color);
			for (int i = 0; i < obj.Count; i++)
			{
				string a = obj.keys[i];
				if (!(a == "r"))
				{
					if (!(a == "g"))
					{
						if (!(a == "b"))
						{
							if (a == "a")
							{
								result.a = obj[i].f;
							}
						}
						else
						{
							result.b = obj[i].f;
						}
					}
					else
					{
						result.g = obj[i].f;
					}
				}
				else
				{
					result.r = obj[i].f;
				}
			}
			return result;
		}

		// Token: 0x06000551 RID: 1361 RVA: 0x00018D7C File Offset: 0x00016F7C
		public static JSONObject FromLayerMask(LayerMask l)
		{
			JSONObject obj = JSONObject.obj;
			obj.AddField("value", l.value);
			return obj;
		}

		// Token: 0x06000552 RID: 1362 RVA: 0x00018DA8 File Offset: 0x00016FA8
		public static LayerMask ToLayerMask(JSONObject obj)
		{
			LayerMask result = default(LayerMask);
			result.value = (int)obj["value"].n;
			return result;
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x00018DE0 File Offset: 0x00016FE0
		public static JSONObject FromRect(Rect r)
		{
			JSONObject obj = JSONObject.obj;
			bool flag = r.x != 0f;
			if (flag)
			{
				obj.AddField("x", r.x);
			}
			bool flag2 = r.y != 0f;
			if (flag2)
			{
				obj.AddField("y", r.y);
			}
			bool flag3 = r.height != 0f;
			if (flag3)
			{
				obj.AddField("height", r.height);
			}
			bool flag4 = r.width != 0f;
			if (flag4)
			{
				obj.AddField("width", r.width);
			}
			return obj;
		}

		// Token: 0x06000554 RID: 1364 RVA: 0x00018EA0 File Offset: 0x000170A0
		public static Rect ToRect(JSONObject obj)
		{
			Rect result = default(Rect);
			for (int i = 0; i < obj.Count; i++)
			{
				string a = obj.keys[i];
				if (!(a == "x"))
				{
					if (!(a == "y"))
					{
						if (!(a == "height"))
						{
							if (a == "width")
							{
								result.width = obj[i].f;
							}
						}
						else
						{
							result.height = obj[i].f;
						}
					}
					else
					{
						result.y = obj[i].f;
					}
				}
				else
				{
					result.x = obj[i].f;
				}
			}
			return result;
		}

		// Token: 0x06000555 RID: 1365 RVA: 0x00018F78 File Offset: 0x00017178
		public static JSONObject FromRectOffset(RectOffset r)
		{
			JSONObject obj = JSONObject.obj;
			bool flag = r.bottom != 0;
			if (flag)
			{
				obj.AddField("bottom", r.bottom);
			}
			bool flag2 = r.left != 0;
			if (flag2)
			{
				obj.AddField("left", r.left);
			}
			bool flag3 = r.right != 0;
			if (flag3)
			{
				obj.AddField("right", r.right);
			}
			bool flag4 = r.top != 0;
			if (flag4)
			{
				obj.AddField("top", r.top);
			}
			return obj;
		}

		// Token: 0x06000556 RID: 1366 RVA: 0x00019014 File Offset: 0x00017214
		public static RectOffset ToRectOffset(JSONObject obj)
		{
			RectOffset rectOffset = new RectOffset();
			for (int i = 0; i < obj.Count; i++)
			{
				string a = obj.keys[i];
				if (!(a == "bottom"))
				{
					if (!(a == "left"))
					{
						if (!(a == "right"))
						{
							if (a == "top")
							{
								rectOffset.top = (int)obj[i].n;
							}
						}
						else
						{
							rectOffset.right = (int)obj[i].n;
						}
					}
					else
					{
						rectOffset.left = (int)obj[i].n;
					}
				}
				else
				{
					rectOffset.bottom = (int)obj[i].n;
				}
			}
			return rectOffset;
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x000190E8 File Offset: 0x000172E8
		public static AnimationCurve ToAnimationCurve(JSONObject obj)
		{
			AnimationCurve animationCurve = new AnimationCurve();
			bool flag = obj.HasField("keys");
			if (flag)
			{
				JSONObject field = obj.GetField("keys");
				for (int i = 0; i < field.list.Count; i++)
				{
					animationCurve.AddKey(JSONTemplates.ToKeyframe(field[i]));
				}
			}
			bool flag2 = obj.HasField("preWrapMode");
			if (flag2)
			{
				animationCurve.preWrapMode = (int)obj.GetField("preWrapMode").n;
			}
			bool flag3 = obj.HasField("postWrapMode");
			if (flag3)
			{
				animationCurve.postWrapMode = (int)obj.GetField("postWrapMode").n;
			}
			return animationCurve;
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x000191A4 File Offset: 0x000173A4
		public static JSONObject FromAnimationCurve(AnimationCurve a)
		{
			JSONObject obj = JSONObject.obj;
			obj.AddField("preWrapMode", a.preWrapMode.ToString());
			obj.AddField("postWrapMode", a.postWrapMode.ToString());
			bool flag = a.keys.Length != 0;
			if (flag)
			{
				JSONObject jsonobject = JSONObject.Create();
				for (int i = 0; i < a.keys.Length; i++)
				{
					jsonobject.Add(JSONTemplates.FromKeyframe(a.keys[i]));
				}
				obj.AddField("keys", jsonobject);
			}
			return obj;
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x0001925C File Offset: 0x0001745C
		public static Keyframe ToKeyframe(JSONObject obj)
		{
			Keyframe result;
			result..ctor(obj.HasField("time") ? obj.GetField("time").n : 0f, obj.HasField("value") ? obj.GetField("value").n : 0f);
			bool flag = obj.HasField("inTangent");
			if (flag)
			{
				result.inTangent = obj.GetField("inTangent").n;
			}
			bool flag2 = obj.HasField("outTangent");
			if (flag2)
			{
				result.outTangent = obj.GetField("outTangent").n;
			}
			bool flag3 = obj.HasField("tangentMode");
			if (flag3)
			{
				result.tangentMode = (int)obj.GetField("tangentMode").n;
			}
			return result;
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x00019338 File Offset: 0x00017538
		public static JSONObject FromKeyframe(Keyframe k)
		{
			JSONObject obj = JSONObject.obj;
			bool flag = k.inTangent != 0f;
			if (flag)
			{
				obj.AddField("inTangent", k.inTangent);
			}
			bool flag2 = k.outTangent != 0f;
			if (flag2)
			{
				obj.AddField("outTangent", k.outTangent);
			}
			bool flag3 = k.tangentMode != 0;
			if (flag3)
			{
				obj.AddField("tangentMode", k.tangentMode);
			}
			bool flag4 = k.time != 0f;
			if (flag4)
			{
				obj.AddField("time", k.time);
			}
			bool flag5 = k.value != 0f;
			if (flag5)
			{
				obj.AddField("value", k.value);
			}
			return obj;
		}

		// Token: 0x040003BE RID: 958
		private static readonly HashSet<object> touched = new HashSet<object>();
	}
}
