﻿using System;
using System.Collections;
namespace Gimmebreak.Backbone.Core.JSON
{
	// Token: 0x02000074 RID: 116
	public class JSONObjectEnumer : IEnumerator
	{
		// Token: 0x060005BC RID: 1468 RVA: 0x00005B63 File Offset: 0x00003D63
		public JSONObjectEnumer(JSONObject jsonObject)
		{
			this._jobj = jsonObject;
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x0001AFFC File Offset: 0x000191FC
		public bool MoveNext()
		{
			this.position++;
			return this.position < this._jobj.Count;
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x00005B7B File Offset: 0x00003D7B
		public void Reset()
		{
			this.position = -1;
		}

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x060005BF RID: 1471 RVA: 0x0001B030 File Offset: 0x00019230
		object IEnumerator.Current
		{
			get
			{
				return this.Current;
			}
		}

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x060005C0 RID: 1472 RVA: 0x0001B048 File Offset: 0x00019248
		public JSONObject Current
		{
			get
			{
				bool isArray = this._jobj.IsArray;
				JSONObject result;
				if (isArray)
				{
					result = this._jobj[this.position];
				}
				else
				{
					string index = this._jobj.keys[this.position];
					result = this._jobj[index];
				}
				return result;
			}
		}

		// Token: 0x040003D2 RID: 978
		public JSONObject _jobj;

		// Token: 0x040003D3 RID: 979
		private int position = -1;
	}
}
