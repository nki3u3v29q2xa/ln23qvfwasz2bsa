﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using UnityEngine;

namespace Gimmebreak.Backbone.Core.JSON
{
	// Token: 0x02000073 RID: 115
	public class JSONObject : IEnumerable
	{
		// Token: 0x17000176 RID: 374
		// (get) Token: 0x0600055C RID: 1372 RVA: 0x00019418 File Offset: 0x00017618
		public bool isContainer
		{
			get
			{
				return this.type == JSONObject.Type.ARRAY || this.type == JSONObject.Type.OBJECT;
			}
		}

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x0600055D RID: 1373 RVA: 0x00019440 File Offset: 0x00017640
		public int Count
		{
			get
			{
				bool flag = this.list == null;
				int result;
				if (flag)
				{
					result = -1;
				}
				else
				{
					result = this.list.Count;
				}
				return result;
			}
		}

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x0600055E RID: 1374 RVA: 0x00019470 File Offset: 0x00017670
		public float f
		{
			get
			{
				return this.n;
			}
		}

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x0600055F RID: 1375 RVA: 0x00019488 File Offset: 0x00017688
		public static JSONObject nullJO
		{
			get
			{
				return JSONObject.Create(JSONObject.Type.NULL);
			}
		}

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000560 RID: 1376 RVA: 0x000194A0 File Offset: 0x000176A0
		public static JSONObject obj
		{
			get
			{
				return JSONObject.Create(JSONObject.Type.OBJECT);
			}
		}

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000561 RID: 1377 RVA: 0x000194B8 File Offset: 0x000176B8
		public static JSONObject arr
		{
			get
			{
				return JSONObject.Create(JSONObject.Type.ARRAY);
			}
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x000194D0 File Offset: 0x000176D0
		public JSONObject(JSONObject.Type t)
		{
			this.type = t;
			if (t != JSONObject.Type.OBJECT)
			{
				if (t == JSONObject.Type.ARRAY)
				{
					this.list = new List<JSONObject>();
				}
			}
			else
			{
				this.list = new List<JSONObject>();
				this.keys = new List<string>();
			}
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x0000587C File Offset: 0x00003A7C
		public JSONObject(bool b)
		{
			this.type = JSONObject.Type.BOOL;
			this.b = b;
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x000058A2 File Offset: 0x00003AA2
		public JSONObject(float f)
		{
			this.type = JSONObject.Type.NUMBER;
			this.n = f;
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x000058C8 File Offset: 0x00003AC8
		public JSONObject(int i)
		{
			this.type = JSONObject.Type.NUMBER;
			this.i = (long)i;
			this.useInt = true;
			this.n = (float)i;
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x000058FE File Offset: 0x00003AFE
		public JSONObject(long l)
		{
			this.type = JSONObject.Type.NUMBER;
			this.i = l;
			this.useInt = true;
			this.n = (float)l;
		}

		// Token: 0x06000567 RID: 1383 RVA: 0x00019530 File Offset: 0x00017730
		public JSONObject(Dictionary<string, string> dic)
		{
			this.type = JSONObject.Type.OBJECT;
			this.keys = new List<string>();
			this.list = new List<JSONObject>();
			foreach (KeyValuePair<string, string> keyValuePair in dic)
			{
				this.keys.Add(keyValuePair.Key);
				this.list.Add(JSONObject.CreateStringObject(keyValuePair.Value));
			}
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x000195DC File Offset: 0x000177DC
		public JSONObject(Dictionary<string, JSONObject> dic)
		{
			this.type = JSONObject.Type.OBJECT;
			this.keys = new List<string>();
			this.list = new List<JSONObject>();
			foreach (KeyValuePair<string, JSONObject> keyValuePair in dic)
			{
				this.keys.Add(keyValuePair.Key);
				this.list.Add(keyValuePair.Value);
			}
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x00005933 File Offset: 0x00003B33
		public JSONObject(JSONObject.AddJSONContents content)
		{
			content(this);
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x00005953 File Offset: 0x00003B53
		public JSONObject(JSONObject[] objs)
		{
			this.type = JSONObject.Type.ARRAY;
			this.list = new List<JSONObject>(objs);
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x00019680 File Offset: 0x00017880
		public static JSONObject StringObject(string val)
		{
			return JSONObject.CreateStringObject(val);
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x00019698 File Offset: 0x00017898
		public void Absorb(JSONObject obj)
		{
			this.list.AddRange(obj.list);
			this.keys.AddRange(obj.keys);
			this.str = obj.str;
			this.n = obj.n;
			this.useInt = obj.useInt;
			this.i = obj.i;
			this.b = obj.b;
			this.type = obj.type;
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x00019714 File Offset: 0x00017914
		public static JSONObject Create()
		{
			JSONObject jsonobject = null;
			Queue<JSONObject> obj = JSONObject.releaseQueue;
			lock (obj)
			{
				while (jsonobject == null && JSONObject.releaseQueue.Count > 0)
				{
					jsonobject = JSONObject.releaseQueue.Dequeue();
				}
			}
			bool flag = jsonobject != null;
			JSONObject result;
			if (flag)
			{
				jsonobject.isPooled = false;
				result = jsonobject;
			}
			else
			{
				result = new JSONObject();
			}
			return result;
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x00019794 File Offset: 0x00017994
		public static JSONObject Create(JSONObject.Type t)
		{
			JSONObject jsonobject = JSONObject.Create();
			jsonobject.type = t;
			if (t != JSONObject.Type.OBJECT)
			{
				if (t == JSONObject.Type.ARRAY)
				{
					jsonobject.list = new List<JSONObject>();
				}
			}
			else
			{
				jsonobject.list = new List<JSONObject>();
				jsonobject.keys = new List<string>();
			}
			return jsonobject;
		}

		// Token: 0x0600056F RID: 1391 RVA: 0x000197E8 File Offset: 0x000179E8
		public static JSONObject Create(bool val)
		{
			JSONObject jsonobject = JSONObject.Create();
			jsonobject.type = JSONObject.Type.BOOL;
			jsonobject.b = val;
			return jsonobject;
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x00019810 File Offset: 0x00017A10
		public static JSONObject Create(float val)
		{
			JSONObject jsonobject = JSONObject.Create();
			jsonobject.type = JSONObject.Type.NUMBER;
			jsonobject.n = val;
			return jsonobject;
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x00019838 File Offset: 0x00017A38
		public static JSONObject Create(int val)
		{
			JSONObject jsonobject = JSONObject.Create();
			jsonobject.type = JSONObject.Type.NUMBER;
			jsonobject.n = (float)val;
			jsonobject.useInt = true;
			jsonobject.i = (long)val;
			return jsonobject;
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x00019870 File Offset: 0x00017A70
		public static JSONObject Create(long val)
		{
			JSONObject jsonobject = JSONObject.Create();
			jsonobject.type = JSONObject.Type.NUMBER;
			jsonobject.n = (float)val;
			jsonobject.useInt = true;
			jsonobject.i = val;
			return jsonobject;
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x000198A8 File Offset: 0x00017AA8
		public static JSONObject CreateStringObject(string val)
		{
			JSONObject jsonobject = JSONObject.Create();
			jsonobject.type = JSONObject.Type.STRING;
			jsonobject.str = val;
			return jsonobject;
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x000198D0 File Offset: 0x00017AD0
		public static JSONObject CreateBakedObject(string val)
		{
			JSONObject jsonobject = JSONObject.Create();
			jsonobject.type = JSONObject.Type.BAKED;
			jsonobject.str = val;
			return jsonobject;
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x000198F8 File Offset: 0x00017AF8
		public static JSONObject Create(string val, int maxDepth = -2, bool storeExcessLevels = false, bool strict = false)
		{
			JSONObject jsonobject = JSONObject.Create();
			jsonobject.Parse(val, maxDepth, storeExcessLevels, strict);
			return jsonobject;
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x0001991C File Offset: 0x00017B1C
		public static JSONObject Create(JSONObject.AddJSONContents content)
		{
			JSONObject jsonobject = JSONObject.Create();
			content(jsonobject);
			return jsonobject;
		}

		// Token: 0x06000577 RID: 1399 RVA: 0x00019940 File Offset: 0x00017B40
		public static JSONObject Create(Dictionary<string, string> dic)
		{
			JSONObject jsonobject = JSONObject.Create();
			jsonobject.type = JSONObject.Type.OBJECT;
			jsonobject.keys = new List<string>();
			jsonobject.list = new List<JSONObject>();
			foreach (KeyValuePair<string, string> keyValuePair in dic)
			{
				jsonobject.keys.Add(keyValuePair.Key);
				jsonobject.list.Add(JSONObject.CreateStringObject(keyValuePair.Value));
			}
			return jsonobject;
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x0000597E File Offset: 0x00003B7E
		public JSONObject()
		{
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x00005996 File Offset: 0x00003B96
		public JSONObject(string str, int maxDepth = -2, bool storeExcessLevels = false, bool strict = false)
		{
			this.Parse(str, maxDepth, storeExcessLevels, strict);
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x000199E0 File Offset: 0x00017BE0
		private void Parse(string str, int maxDepth = -2, bool storeExcessLevels = false, bool strict = false)
		{
			bool flag = !string.IsNullOrEmpty(str);
			if (flag)
			{
				str = str.Trim(JSONObject.WHITESPACE);
				if (strict)
				{
					bool flag2 = str[0] != '[' && str[0] != '{';
					if (flag2)
					{
						this.type = JSONObject.Type.NULL;
						Debug.LogWarning("Improper (strict) JSON formatting.  First character must be [ or {");
						return;
					}
				}
				bool flag3 = str.Length > 0;
				if (flag3)
				{
					bool flag4 = string.Compare(str, "true", true) == 0;
					if (flag4)
					{
						this.type = JSONObject.Type.BOOL;
						this.b = true;
					}
					else
					{
						bool flag5 = string.Compare(str, "false", true) == 0;
						if (flag5)
						{
							this.type = JSONObject.Type.BOOL;
							this.b = false;
						}
						else
						{
							bool flag6 = string.Compare(str, "null", true) == 0;
							if (flag6)
							{
								this.type = JSONObject.Type.NULL;
							}
							else
							{
								bool flag7 = str == "\"INFINITY\"";
								if (flag7)
								{
									this.type = JSONObject.Type.NUMBER;
									this.n = float.PositiveInfinity;
								}
								else
								{
									bool flag8 = str == "\"NEGINFINITY\"";
									if (flag8)
									{
										this.type = JSONObject.Type.NUMBER;
										this.n = float.NegativeInfinity;
									}
									else
									{
										bool flag9 = str == "\"NaN\"";
										if (flag9)
										{
											this.type = JSONObject.Type.NUMBER;
											this.n = float.NaN;
										}
										else
										{
											bool flag10 = str[0] == '"';
											if (flag10)
											{
												this.type = JSONObject.Type.STRING;
												this.str = str.Substring(1, str.Length - 2).Replace("\\\\", "\\").Replace("\\\"", "\"");
											}
											else
											{
												int num = 1;
												int num2 = 0;
												char c = str[num2];
												if (c != '[')
												{
													if (c != '{')
													{
														try
														{
															this.n = Convert.ToSingle(str, CultureInfo.InvariantCulture);
															bool flag11 = !str.Contains(".");
															if (flag11)
															{
																this.i = Convert.ToInt64(str);
																this.useInt = true;
															}
															this.type = JSONObject.Type.NUMBER;
														}
														catch (FormatException)
														{
															this.type = JSONObject.Type.NULL;
															Debug.LogWarning("improper JSON formatting:" + str);
														}
														return;
													}
													this.type = JSONObject.Type.OBJECT;
													this.keys = new List<string>();
													this.list = new List<JSONObject>();
												}
												else
												{
													this.type = JSONObject.Type.ARRAY;
													this.list = new List<JSONObject>();
												}
												string item = "";
												bool flag12 = false;
												bool flag13 = false;
												int num3 = 0;
												while (++num2 < str.Length)
												{
													bool flag14 = Array.IndexOf<char>(JSONObject.WHITESPACE, str[num2]) > -1;
													if (!flag14)
													{
														bool flag15 = str[num2] == '\\';
														if (flag15)
														{
															num2++;
														}
														else
														{
															bool flag16 = str[num2] == '"';
															if (flag16)
															{
																bool flag17 = flag12;
																if (flag17)
																{
																	bool flag18 = !flag13 && num3 == 0 && this.type == JSONObject.Type.OBJECT;
																	if (flag18)
																	{
																		item = str.Substring(num + 1, num2 - num - 1);
																	}
																	flag12 = false;
																}
																else
																{
																	bool flag19 = num3 == 0 && this.type == JSONObject.Type.OBJECT;
																	if (flag19)
																	{
																		num = num2;
																	}
																	flag12 = true;
																}
															}
															bool flag20 = flag12;
															if (!flag20)
															{
																bool flag21 = this.type == JSONObject.Type.OBJECT && num3 == 0;
																if (flag21)
																{
																	bool flag22 = str[num2] == ':';
																	if (flag22)
																	{
																		num = num2 + 1;
																		flag13 = true;
																	}
																}
																bool flag23 = str[num2] == '[' || str[num2] == '{';
																if (flag23)
																{
																	num3++;
																}
																else
																{
																	bool flag24 = str[num2] == ']' || str[num2] == '}';
																	if (flag24)
																	{
																		num3--;
																	}
																}
																bool flag25 = (str[num2] == ',' && num3 == 0) || num3 < 0;
																if (flag25)
																{
																	flag13 = false;
																	string text = str.Substring(num, num2 - num).Trim(JSONObject.WHITESPACE);
																	bool flag26 = text.Length > 0;
																	if (flag26)
																	{
																		bool flag27 = this.type == JSONObject.Type.OBJECT;
																		if (flag27)
																		{
																			this.keys.Add(item);
																		}
																		bool flag28 = maxDepth != -1;
																		if (flag28)
																		{
																			this.list.Add(JSONObject.Create(text, (maxDepth < -1) ? -2 : (maxDepth - 1), storeExcessLevels, false));
																		}
																		else if (storeExcessLevels)
																		{
																			this.list.Add(JSONObject.CreateBakedObject(text));
																		}
																	}
																	num = num2 + 1;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				else
				{
					this.type = JSONObject.Type.NULL;
				}
			}
			else
			{
				this.type = JSONObject.Type.NULL;
			}
		}

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x0600057B RID: 1403 RVA: 0x00019EB8 File Offset: 0x000180B8
		public bool IsNumber
		{
			get
			{
				return this.type == JSONObject.Type.NUMBER;
			}
		}

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x0600057C RID: 1404 RVA: 0x00019ED4 File Offset: 0x000180D4
		public bool IsNull
		{
			get
			{
				return this.type == JSONObject.Type.NULL;
			}
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x0600057D RID: 1405 RVA: 0x00019EF0 File Offset: 0x000180F0
		public bool IsString
		{
			get
			{
				return this.type == JSONObject.Type.STRING;
			}
		}

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x0600057E RID: 1406 RVA: 0x00019F0C File Offset: 0x0001810C
		public bool IsBool
		{
			get
			{
				return this.type == JSONObject.Type.BOOL;
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x0600057F RID: 1407 RVA: 0x00019F28 File Offset: 0x00018128
		public bool IsArray
		{
			get
			{
				return this.type == JSONObject.Type.ARRAY;
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x06000580 RID: 1408 RVA: 0x00019F44 File Offset: 0x00018144
		public bool IsObject
		{
			get
			{
				return this.type == JSONObject.Type.OBJECT || this.type == JSONObject.Type.BAKED;
			}
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x000059BA File Offset: 0x00003BBA
		public void Add(bool val)
		{
			this.Add(JSONObject.Create(val));
		}

		// Token: 0x06000582 RID: 1410 RVA: 0x000059CA File Offset: 0x00003BCA
		public void Add(float val)
		{
			this.Add(JSONObject.Create(val));
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x000059DA File Offset: 0x00003BDA
		public void Add(int val)
		{
			this.Add(JSONObject.Create(val));
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x000059EA File Offset: 0x00003BEA
		public void Add(string str)
		{
			this.Add(JSONObject.CreateStringObject(str));
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x000059FA File Offset: 0x00003BFA
		public void Add(JSONObject.AddJSONContents content)
		{
			this.Add(JSONObject.Create(content));
		}

		// Token: 0x06000586 RID: 1414 RVA: 0x00019F6C File Offset: 0x0001816C
		public void Add(JSONObject obj)
		{
			bool flag = obj;
			if (flag)
			{
				bool flag2 = this.type != JSONObject.Type.ARRAY;
				if (flag2)
				{
					this.type = JSONObject.Type.ARRAY;
					bool flag3 = this.list == null;
					if (flag3)
					{
						this.list = new List<JSONObject>();
					}
				}
				this.list.Add(obj);
			}
		}

		// Token: 0x06000587 RID: 1415 RVA: 0x00005A0A File Offset: 0x00003C0A
		public void AddField(string name, bool val)
		{
			this.AddField(name, JSONObject.Create(val));
		}

		// Token: 0x06000588 RID: 1416 RVA: 0x00005A1B File Offset: 0x00003C1B
		public void AddField(string name, float val)
		{
			this.AddField(name, JSONObject.Create(val));
		}

		// Token: 0x06000589 RID: 1417 RVA: 0x00005A2C File Offset: 0x00003C2C
		public void AddField(string name, int val)
		{
			this.AddField(name, JSONObject.Create(val));
		}

		// Token: 0x0600058A RID: 1418 RVA: 0x00005A3D File Offset: 0x00003C3D
		public void AddField(string name, long val)
		{
			this.AddField(name, JSONObject.Create(val));
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x00005A4E File Offset: 0x00003C4E
		public void AddField(string name, JSONObject.AddJSONContents content)
		{
			this.AddField(name, JSONObject.Create(content));
		}

		// Token: 0x0600058C RID: 1420 RVA: 0x00005A5F File Offset: 0x00003C5F
		public void AddField(string name, string val)
		{
			this.AddField(name, JSONObject.CreateStringObject(val));
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x00019FC4 File Offset: 0x000181C4
		public void AddField(string name, JSONObject obj)
		{
			bool flag = obj;
			if (flag)
			{
				bool flag2 = this.type != JSONObject.Type.OBJECT;
				if (flag2)
				{
					bool flag3 = this.keys == null;
					if (flag3)
					{
						this.keys = new List<string>();
					}
					bool flag4 = this.type == JSONObject.Type.ARRAY;
					if (flag4)
					{
						for (int i = 0; i < this.list.Count; i++)
						{
							this.keys.Add(string.Concat(i));
						}
					}
					else
					{
						bool flag5 = this.list == null;
						if (flag5)
						{
							this.list = new List<JSONObject>();
						}
					}
					this.type = JSONObject.Type.OBJECT;
				}
				this.keys.Add(name);
				this.list.Add(obj);
			}
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x00005A70 File Offset: 0x00003C70
		public void SetField(string name, string val)
		{
			this.SetField(name, JSONObject.CreateStringObject(val));
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x00005A81 File Offset: 0x00003C81
		public void SetField(string name, bool val)
		{
			this.SetField(name, JSONObject.Create(val));
		}

		// Token: 0x06000590 RID: 1424 RVA: 0x00005A92 File Offset: 0x00003C92
		public void SetField(string name, float val)
		{
			this.SetField(name, JSONObject.Create(val));
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x00005AA3 File Offset: 0x00003CA3
		public void SetField(string name, int val)
		{
			this.SetField(name, JSONObject.Create(val));
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x0001A094 File Offset: 0x00018294
		public void SetField(string name, JSONObject obj)
		{
			bool flag = this.HasField(name);
			if (flag)
			{
				this.list.Remove(this[name]);
				this.keys.Remove(name);
			}
			this.AddField(name, obj);
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x0001A0D8 File Offset: 0x000182D8
		public void RemoveField(string name)
		{
			bool flag = this.keys.IndexOf(name) > -1;
			if (flag)
			{
				this.list.RemoveAt(this.keys.IndexOf(name));
				this.keys.Remove(name);
			}
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0001A120 File Offset: 0x00018320
		public bool GetField(out bool field, string name, bool fallback)
		{
			field = fallback;
			return this.GetField(ref field, name, null);
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x0001A140 File Offset: 0x00018340
		public bool GetField(ref bool field, string name, JSONObject.FieldNotFound fail = null)
		{
			bool flag = this.type == JSONObject.Type.OBJECT;
			if (flag)
			{
				int num = this.keys.IndexOf(name);
				bool flag2 = num >= 0;
				if (flag2)
				{
					field = this.list[num].b;
					return true;
				}
			}
			bool flag3 = fail != null;
			if (flag3)
			{
				fail(name);
			}
			return false;
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x0001A1A4 File Offset: 0x000183A4
		public bool GetField(out float field, string name, float fallback)
		{
			field = fallback;
			return this.GetField(ref field, name, null);
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x0001A1C4 File Offset: 0x000183C4
		public bool GetField(ref float field, string name, JSONObject.FieldNotFound fail = null)
		{
			bool flag = this.type == JSONObject.Type.OBJECT;
			if (flag)
			{
				int num = this.keys.IndexOf(name);
				bool flag2 = num >= 0;
				if (flag2)
				{
					field = this.list[num].n;
					return true;
				}
			}
			bool flag3 = fail != null;
			if (flag3)
			{
				fail(name);
			}
			return false;
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x0001A228 File Offset: 0x00018428
		public bool GetField(out int field, string name, int fallback)
		{
			field = fallback;
			return this.GetField(ref field, name, null);
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x0001A248 File Offset: 0x00018448
		public bool GetField(ref int field, string name, JSONObject.FieldNotFound fail = null)
		{
			bool isObject = this.IsObject;
			if (isObject)
			{
				int num = this.keys.IndexOf(name);
				bool flag = num >= 0;
				if (flag)
				{
					field = (int)this.list[num].n;
					return true;
				}
			}
			bool flag2 = fail != null;
			if (flag2)
			{
				fail(name);
			}
			return false;
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x0001A2AC File Offset: 0x000184AC
		public bool GetField(out long field, string name, long fallback)
		{
			field = fallback;
			return this.GetField(ref field, name, null);
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x0001A2CC File Offset: 0x000184CC
		public bool GetField(ref long field, string name, JSONObject.FieldNotFound fail = null)
		{
			bool isObject = this.IsObject;
			if (isObject)
			{
				int num = this.keys.IndexOf(name);
				bool flag = num >= 0;
				if (flag)
				{
					field = (long)this.list[num].n;
					return true;
				}
			}
			bool flag2 = fail != null;
			if (flag2)
			{
				fail(name);
			}
			return false;
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x0001A330 File Offset: 0x00018530
		public bool GetField(out uint field, string name, uint fallback)
		{
			field = fallback;
			return this.GetField(ref field, name, null);
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x0001A350 File Offset: 0x00018550
		public bool GetField(ref uint field, string name, JSONObject.FieldNotFound fail = null)
		{
			bool isObject = this.IsObject;
			if (isObject)
			{
				int num = this.keys.IndexOf(name);
				bool flag = num >= 0;
				if (flag)
				{
					field = (uint)this.list[num].n;
					return true;
				}
			}
			bool flag2 = fail != null;
			if (flag2)
			{
				fail(name);
			}
			return false;
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x0001A3B4 File Offset: 0x000185B4
		public bool GetField(out string field, string name, string fallback)
		{
			field = fallback;
			return this.GetField(ref field, name, null);
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x0001A3D4 File Offset: 0x000185D4
		public bool GetField(ref string field, string name, JSONObject.FieldNotFound fail = null)
		{
			bool isObject = this.IsObject;
			if (isObject)
			{
				int num = this.keys.IndexOf(name);
				bool flag = num >= 0;
				if (flag)
				{
					field = this.list[num].str;
					return true;
				}
			}
			bool flag2 = fail != null;
			if (flag2)
			{
				fail(name);
			}
			return false;
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x0001A438 File Offset: 0x00018638
		public void GetField(string name, JSONObject.GetFieldResponse response, JSONObject.FieldNotFound fail = null)
		{
			bool flag = response != null && this.IsObject;
			if (flag)
			{
				int num = this.keys.IndexOf(name);
				bool flag2 = num >= 0;
				if (flag2)
				{
					response(this.list[num]);
					return;
				}
			}
			bool flag3 = fail != null;
			if (flag3)
			{
				fail(name);
			}
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x0001A498 File Offset: 0x00018698
		public JSONObject GetField(string name)
		{
			bool isObject = this.IsObject;
			if (isObject)
			{
				for (int i = 0; i < this.keys.Count; i++)
				{
					bool flag = this.keys[i] == name;
					if (flag)
					{
						return this.list[i];
					}
				}
			}
			return null;
		}

		// Token: 0x060005A2 RID: 1442 RVA: 0x0001A4F8 File Offset: 0x000186F8
		public bool HasFields(string[] names)
		{
			bool flag = !this.IsObject;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				for (int i = 0; i < names.Length; i++)
				{
					bool flag2 = !this.keys.Contains(names[i]);
					if (flag2)
					{
						return false;
					}
				}
				result = true;
			}
			return result;
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x0001A54C File Offset: 0x0001874C
		public bool HasField(string name)
		{
			bool flag = !this.IsObject;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				for (int i = 0; i < this.keys.Count; i++)
				{
					bool flag2 = this.keys[i] == name;
					if (flag2)
					{
						return true;
					}
				}
				result = false;
			}
			return result;
		}

		// Token: 0x060005A4 RID: 1444 RVA: 0x0001A5A8 File Offset: 0x000187A8
		public void Clear()
		{
			this.type = JSONObject.Type.NULL;
			bool flag = this.list != null;
			if (flag)
			{
				this.list.Clear();
			}
			bool flag2 = this.keys != null;
			if (flag2)
			{
				this.keys.Clear();
			}
			this.str = "";
			this.n = 0f;
			this.b = false;
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x0001A60C File Offset: 0x0001880C
		public JSONObject Copy()
		{
			return JSONObject.Create(this.Print(false), -2, false, false);
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x00005AB4 File Offset: 0x00003CB4
		public void Merge(JSONObject obj)
		{
			JSONObject.MergeRecur(this, obj);
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x0001A630 File Offset: 0x00018830
		private static void MergeRecur(JSONObject left, JSONObject right)
		{
			bool flag = left.type == JSONObject.Type.NULL;
			if (flag)
			{
				left.Absorb(right);
			}
			else
			{
				bool flag2 = left.type == JSONObject.Type.OBJECT && right.type == JSONObject.Type.OBJECT;
				if (flag2)
				{
					for (int i = 0; i < right.list.Count; i++)
					{
						string text = right.keys[i];
						bool isContainer = right[i].isContainer;
						if (isContainer)
						{
							bool flag3 = left.HasField(text);
							if (flag3)
							{
								JSONObject.MergeRecur(left[text], right[i]);
							}
							else
							{
								left.AddField(text, right[i]);
							}
						}
						else
						{
							bool flag4 = left.HasField(text);
							if (flag4)
							{
								left.SetField(text, right[i]);
							}
							else
							{
								left.AddField(text, right[i]);
							}
						}
					}
				}
				else
				{
					bool flag5 = left.type == JSONObject.Type.ARRAY && right.type == JSONObject.Type.ARRAY;
					if (flag5)
					{
						bool flag6 = right.Count > left.Count;
						if (flag6)
						{
							Debug.LogError("Cannot merge arrays when right object has more elements");
						}
						else
						{
							for (int j = 0; j < right.list.Count; j++)
							{
								bool flag7 = left[j].type == right[j].type;
								if (flag7)
								{
									bool isContainer2 = left[j].isContainer;
									if (isContainer2)
									{
										JSONObject.MergeRecur(left[j], right[j]);
									}
									else
									{
										left[j] = right[j];
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x0001A7EC File Offset: 0x000189EC
		public void Bake()
		{
			bool flag = this.type != JSONObject.Type.BAKED;
			if (flag)
			{
				this.str = this.Print(false);
				this.type = JSONObject.Type.BAKED;
			}
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x00005ABF File Offset: 0x00003CBF
		public IEnumerable BakeAsync()
		{
			bool flag = this.type != JSONObject.Type.BAKED;
			if (flag)
			{
				foreach (string s in this.PrintAsync(false))
				{
					bool flag2 = s == null;
					if (flag2)
					{
						yield return s;
					}
					else
					{
						this.str = s;
					}
					s = null;
				}
				IEnumerator<string> enumerator = null;
				this.type = JSONObject.Type.BAKED;
			}
			yield break;
			yield break;
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x0001A820 File Offset: 0x00018A20
		public string Print(bool pretty = false)
		{
			StringBuilder stringBuilder = new StringBuilder();
			this.Stringify(0, stringBuilder, pretty);
			return stringBuilder.ToString();
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x00005ACF File Offset: 0x00003CCF
		public IEnumerable<string> PrintAsync(bool pretty = false)
		{
			StringBuilder builder = new StringBuilder();
			JSONObject.printWatch.Reset();
			JSONObject.printWatch.Start();
			foreach (object obj in this.StringifyAsync(0, builder, pretty))
			{
				IEnumerable e = (IEnumerable)obj;
				yield return null;
			}
			IEnumerator enumerator = null;
			yield return builder.ToString();
			yield break;
			yield break;
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x00005AE6 File Offset: 0x00003CE6
		private IEnumerable StringifyAsync(int depth, StringBuilder builder, bool pretty = false)
		{
			int num = depth;
			depth = num + 1;
			bool flag = num > 100;
			if (flag)
			{
				Debug.Log("reached max depth!");
				yield break;
			}
			bool flag2 = JSONObject.printWatch.Elapsed.TotalSeconds > 0.00800000037997961;
			if (flag2)
			{
				JSONObject.printWatch.Reset();
				yield return null;
				JSONObject.printWatch.Start();
			}
			switch (this.type)
			{
			case JSONObject.Type.NULL:
				builder.Append("null");
				break;
			case JSONObject.Type.STRING:
				builder.AppendFormat("\"{0}\"", this.str);
				break;
			case JSONObject.Type.NUMBER:
			{
				bool flag3 = this.useInt;
				if (flag3)
				{
					builder.Append(this.i.ToString());
				}
				else
				{
					bool flag4 = float.IsInfinity(this.n);
					if (flag4)
					{
						builder.Append("\"INFINITY\"");
					}
					else
					{
						bool flag5 = float.IsNegativeInfinity(this.n);
						if (flag5)
						{
							builder.Append("\"NEGINFINITY\"");
						}
						else
						{
							bool flag6 = float.IsNaN(this.n);
							if (flag6)
							{
								builder.Append("\"NaN\"");
							}
							else
							{
								builder.Append(this.n.ToString());
							}
						}
					}
				}
				break;
			}
			case JSONObject.Type.OBJECT:
			{
				builder.Append("{");
				bool flag7 = this.list.Count > 0;
				if (flag7)
				{
					if (pretty)
					{
						builder.Append("\n");
					}
					for (int i = 0; i < this.list.Count; i = num + 1)
					{
						string key = this.keys[i];
						JSONObject obj = this.list[i];
						bool flag8 = obj;
						if (flag8)
						{
							if (pretty)
							{
								for (int j = 0; j < depth; j = num + 1)
								{
									builder.Append("\t");
									num = j;
								}
							}
							builder.AppendFormat("\"{0}\":", key);
							foreach (object obj2 in obj.StringifyAsync(depth, builder, pretty))
							{
								IEnumerable e = (IEnumerable)obj2;
								yield return e;
								e = null;
							}
							IEnumerator enumerator = null;
							builder.Append(",");
							if (pretty)
							{
								builder.Append("\n");
							}
						}
						key = null;
						obj = null;
						num = i;
					}
					if (pretty)
					{
						builder.Length -= 2;
					}
					else
					{
						num = builder.Length;
						builder.Length = num - 1;
					}
				}
				bool flag9 = pretty && this.list.Count > 0;
				if (flag9)
				{
					builder.Append("\n");
					for (int k = 0; k < depth - 1; k = num + 1)
					{
						builder.Append("\t");
						num = k;
					}
				}
				builder.Append("}");
				break;
			}
			case JSONObject.Type.ARRAY:
			{
				builder.Append("[");
				bool flag10 = this.list.Count > 0;
				if (flag10)
				{
					if (pretty)
					{
						builder.Append("\n");
					}
					for (int l = 0; l < this.list.Count; l = num + 1)
					{
						bool flag11 = this.list[l];
						if (flag11)
						{
							if (pretty)
							{
								for (int m = 0; m < depth; m = num + 1)
								{
									builder.Append("\t");
									num = m;
								}
							}
							foreach (object obj3 in this.list[l].StringifyAsync(depth, builder, pretty))
							{
								IEnumerable e2 = (IEnumerable)obj3;
								yield return e2;
								e2 = null;
							}
							IEnumerator enumerator2 = null;
							builder.Append(",");
							if (pretty)
							{
								builder.Append("\n");
							}
						}
						num = l;
					}
					if (pretty)
					{
						builder.Length -= 2;
					}
					else
					{
						num = builder.Length;
						builder.Length = num - 1;
					}
				}
				bool flag12 = pretty && this.list.Count > 0;
				if (flag12)
				{
					builder.Append("\n");
					for (int n = 0; n < depth - 1; n = num + 1)
					{
						builder.Append("\t");
						num = n;
					}
				}
				builder.Append("]");
				break;
			}
			case JSONObject.Type.BOOL:
			{
				bool flag13 = this.b;
				if (flag13)
				{
					builder.Append("true");
				}
				else
				{
					builder.Append("false");
				}
				break;
			}
			case JSONObject.Type.BAKED:
				builder.Append(this.str);
				break;
			}
			yield break;
			yield break;
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x0001A848 File Offset: 0x00018A48
		private void Stringify(int depth, StringBuilder builder, bool pretty = false)
		{
			bool flag = depth++ > 100;
			if (flag)
			{
				Debug.Log("reached max depth!");
			}
			else
			{
				switch (this.type)
				{
				case JSONObject.Type.NULL:
					builder.Append("null");
					break;
				case JSONObject.Type.STRING:
					builder.AppendFormat("\"{0}\"", this.str);
					break;
				case JSONObject.Type.NUMBER:
				{
					bool flag2 = this.useInt;
					if (flag2)
					{
						builder.Append(this.i.ToString());
					}
					else
					{
						bool flag3 = float.IsInfinity(this.n);
						if (flag3)
						{
							builder.Append("\"INFINITY\"");
						}
						else
						{
							bool flag4 = float.IsNegativeInfinity(this.n);
							if (flag4)
							{
								builder.Append("\"NEGINFINITY\"");
							}
							else
							{
								bool flag5 = float.IsNaN(this.n);
								if (flag5)
								{
									builder.Append("\"NaN\"");
								}
								else
								{
									builder.Append(this.n.ToString());
								}
							}
						}
					}
					break;
				}
				case JSONObject.Type.OBJECT:
				{
					builder.Append("{");
					bool flag6 = this.list.Count > 0;
					if (flag6)
					{
						if (pretty)
						{
							builder.Append("\n");
						}
						for (int i = 0; i < this.list.Count; i++)
						{
							string arg = this.keys[i];
							JSONObject jsonobject = this.list[i];
							bool flag7 = jsonobject;
							if (flag7)
							{
								if (pretty)
								{
									for (int j = 0; j < depth; j++)
									{
										builder.Append("\t");
									}
								}
								builder.AppendFormat("\"{0}\":", arg);
								jsonobject.Stringify(depth, builder, pretty);
								builder.Append(",");
								if (pretty)
								{
									builder.Append("\n");
								}
							}
						}
						if (pretty)
						{
							builder.Length -= 2;
						}
						else
						{
							int length = builder.Length;
							builder.Length = length - 1;
						}
					}
					bool flag8 = pretty && this.list.Count > 0;
					if (flag8)
					{
						builder.Append("\n");
						for (int k = 0; k < depth - 1; k++)
						{
							builder.Append("\t");
						}
					}
					builder.Append("}");
					break;
				}
				case JSONObject.Type.ARRAY:
				{
					builder.Append("[");
					bool flag9 = this.list.Count > 0;
					if (flag9)
					{
						if (pretty)
						{
							builder.Append("\n");
						}
						for (int l = 0; l < this.list.Count; l++)
						{
							bool flag10 = this.list[l];
							if (flag10)
							{
								if (pretty)
								{
									for (int m = 0; m < depth; m++)
									{
										builder.Append("\t");
									}
								}
								this.list[l].Stringify(depth, builder, pretty);
								builder.Append(",");
								if (pretty)
								{
									builder.Append("\n");
								}
							}
						}
						if (pretty)
						{
							builder.Length -= 2;
						}
						else
						{
							int length = builder.Length;
							builder.Length = length - 1;
						}
					}
					bool flag11 = pretty && this.list.Count > 0;
					if (flag11)
					{
						builder.Append("\n");
						for (int n = 0; n < depth - 1; n++)
						{
							builder.Append("\t");
						}
					}
					builder.Append("]");
					break;
				}
				case JSONObject.Type.BOOL:
				{
					bool flag12 = this.b;
					if (flag12)
					{
						builder.Append("true");
					}
					else
					{
						builder.Append("false");
					}
					break;
				}
				case JSONObject.Type.BAKED:
					builder.Append(this.str);
					break;
				}
			}
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x0001AC6C File Offset: 0x00018E6C
		public static implicit operator WWWForm(JSONObject obj)
		{
			WWWForm wwwform = new WWWForm();
			for (int i = 0; i < obj.list.Count; i++)
			{
				string text = string.Concat(i);
				bool flag = obj.type == JSONObject.Type.OBJECT;
				if (flag)
				{
					text = obj.keys[i];
				}
				string text2 = obj.list[i].ToString();
				bool flag2 = obj.list[i].type == JSONObject.Type.STRING;
				if (flag2)
				{
					text2 = text2.Replace("\"", "");
				}
				wwwform.AddField(text, text2);
			}
			return wwwform;
		}

		// Token: 0x17000182 RID: 386
		public JSONObject this[int index]
		{
			get
			{
				bool flag = this.list.Count > index;
				JSONObject result;
				if (flag)
				{
					result = this.list[index];
				}
				else
				{
					result = null;
				}
				return result;
			}
			set
			{
				bool flag = this.list.Count > index;
				if (flag)
				{
					this.list[index] = value;
				}
			}
		}

		// Token: 0x17000183 RID: 387
		public JSONObject this[string index]
		{
			get
			{
				return this.GetField(index);
			}
			set
			{
				this.SetField(index, value);
			}
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x0001AD98 File Offset: 0x00018F98
		public override string ToString()
		{
			return this.Print(false);
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x0001ADB4 File Offset: 0x00018FB4
		public string ToString(bool pretty)
		{
			return this.Print(pretty);
		}

		// Token: 0x060005B5 RID: 1461 RVA: 0x0001ADD0 File Offset: 0x00018FD0
		public Dictionary<string, string> ToDictionary()
		{
			bool flag = this.type == JSONObject.Type.OBJECT;
			Dictionary<string, string> result;
			if (flag)
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				int i = 0;
				while (i < this.list.Count)
				{
					JSONObject jsonobject = this.list[i];
					switch (jsonobject.type)
					{
					case JSONObject.Type.STRING:
						dictionary.Add(this.keys[i], jsonobject.str);
						break;
					case JSONObject.Type.NUMBER:
						dictionary.Add(this.keys[i], string.Concat(jsonobject.n));
						break;
					case JSONObject.Type.OBJECT:
					case JSONObject.Type.ARRAY:
						goto IL_BD;
					case JSONObject.Type.BOOL:
						dictionary.Add(this.keys[i], jsonobject.b.ToString() ?? "");
						break;
					default:
						goto IL_BD;
					}
					IL_E0:
					i++;
					continue;
					IL_BD:
					Debug.LogWarning("Omitting object: " + this.keys[i] + " in dictionary conversion");
					goto IL_E0;
				}
				result = dictionary;
			}
			else
			{
				Debug.Log("Tried to turn non-Object JSONObject into a dictionary");
				result = null;
			}
			return result;
		}

		// Token: 0x060005B6 RID: 1462 RVA: 0x0001AEF0 File Offset: 0x000190F0
		public static implicit operator bool(JSONObject o)
		{
			return o != null;
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x00005B17 File Offset: 0x00003D17
		public static void ClearPool()
		{
			JSONObject.pool = false;
			JSONObject.releaseQueue.Clear();
			JSONObject.pool = true;
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x0001AF08 File Offset: 0x00019108
		protected override void Finalize()
		{
			try
			{
				bool flag = JSONObject.pool && !this.isPooled && JSONObject.releaseQueue.Count < 10000;
				if (flag)
				{
					this.type = JSONObject.Type.NULL;
					this.list = null;
					this.keys = null;
					this.str = "";
					this.n = 0f;
					this.b = false;
					this.isPooled = true;
					Queue<JSONObject> obj = JSONObject.releaseQueue;
					lock (obj)
					{
						JSONObject.releaseQueue.Enqueue(this);
					}
					GC.ReRegisterForFinalize(this);
				}
			}
			finally
			{
				base.Finalize();
			}
		}

		// Token: 0x060005B9 RID: 1465 RVA: 0x0001AFCC File Offset: 0x000191CC
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x060005BA RID: 1466 RVA: 0x0001AFE4 File Offset: 0x000191E4
		public JSONObjectEnumer GetEnumerator()
		{
			return new JSONObjectEnumer(this);
		}

		// Token: 0x040003BF RID: 959
		private const int MAX_POOL_SIZE = 10000;

		// Token: 0x040003C0 RID: 960
		public static Queue<JSONObject> releaseQueue = new Queue<JSONObject>();

		// Token: 0x040003C1 RID: 961
		private bool isPooled = false;

		// Token: 0x040003C2 RID: 962
		private const int MAX_DEPTH = 100;

		// Token: 0x040003C3 RID: 963
		private const string INFINITY = "\"INFINITY\"";

		// Token: 0x040003C4 RID: 964
		private const string NEGINFINITY = "\"NEGINFINITY\"";

		// Token: 0x040003C5 RID: 965
		private const string NaN = "\"NaN\"";

		// Token: 0x040003C6 RID: 966
		public static readonly char[] WHITESPACE = new char[]
		{
			' ',
			'\r',
			'\n',
			'\t',
			'﻿',
			'\t'
		};

		// Token: 0x040003C7 RID: 967
		public JSONObject.Type type = JSONObject.Type.NULL;

		// Token: 0x040003C8 RID: 968
		public List<JSONObject> list;

		// Token: 0x040003C9 RID: 969
		public List<string> keys;

		// Token: 0x040003CA RID: 970
		public string str;

		// Token: 0x040003CB RID: 971
		public float n;

		// Token: 0x040003CC RID: 972
		public bool useInt;

		// Token: 0x040003CD RID: 973
		public long i;

		// Token: 0x040003CE RID: 974
		public bool b;

		// Token: 0x040003CF RID: 975
		private const float maxFrameTime = 0.008f;

		// Token: 0x040003D0 RID: 976
		private static readonly Stopwatch printWatch = new Stopwatch();

		// Token: 0x040003D1 RID: 977
		private static bool pool = true;

		// Token: 0x02000109 RID: 265
		public enum Type
		{
			// Token: 0x04000729 RID: 1833
			NULL,
			// Token: 0x0400072A RID: 1834
			STRING,
			// Token: 0x0400072B RID: 1835
			NUMBER,
			// Token: 0x0400072C RID: 1836
			OBJECT,
			// Token: 0x0400072D RID: 1837
			ARRAY,
			// Token: 0x0400072E RID: 1838
			BOOL,
			// Token: 0x0400072F RID: 1839
			BAKED
		}

		// Token: 0x0200010A RID: 266
		// (Invoke) Token: 0x060008DA RID: 2266
		public delegate void AddJSONContents(JSONObject self);

		// Token: 0x0200010B RID: 267
		// (Invoke) Token: 0x060008DE RID: 2270
		public delegate void FieldNotFound(string name);

		// Token: 0x0200010C RID: 268
		// (Invoke) Token: 0x060008E2 RID: 2274
		public delegate void GetFieldResponse(JSONObject obj);
	}
}
