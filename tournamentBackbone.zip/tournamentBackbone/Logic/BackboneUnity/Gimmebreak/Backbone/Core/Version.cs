﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000071 RID: 113
	[Serializable]
	public struct Version
	{
		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000539 RID: 1337 RVA: 0x00017B98 File Offset: 0x00015D98
		// (set) Token: 0x0600053A RID: 1338 RVA: 0x00005852 File Offset: 0x00003A52
		public int MainVersion
		{
			get
			{
				return this.mainVersion;
			}
			set
			{
				this.mainVersion = value;
			}
		}

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x0600053B RID: 1339 RVA: 0x00017BB0 File Offset: 0x00015DB0
		// (set) Token: 0x0600053C RID: 1340 RVA: 0x0000585C File Offset: 0x00003A5C
		public int MajorVersion
		{
			get
			{
				return this.majorVersion;
			}
			set
			{
				this.majorVersion = value;
			}
		}

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x0600053D RID: 1341 RVA: 0x00017BC8 File Offset: 0x00015DC8
		// (set) Token: 0x0600053E RID: 1342 RVA: 0x00005866 File Offset: 0x00003A66
		public int MinorVersion
		{
			get
			{
				return this.minorVersion;
			}
			set
			{
				this.minorVersion = value;
			}
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x00017BE0 File Offset: 0x00015DE0
		public Version(string versionString)
		{
			this = default(Version);
			string[] array = versionString.Split(new char[]
			{
				'.'
			});
			bool flag = array.Length != 3;
			if (flag)
			{
				throw new ArgumentException("Version string is not in valid format.");
			}
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			bool flag2 = !int.TryParse(array[0], out num) || !int.TryParse(array[1], out num2) || !int.TryParse(array[2], out num3);
			if (flag2)
			{
				throw new ArgumentException("Version string is not in valid format.");
			}
			this.mainVersion = num;
			this.majorVersion = num2;
			this.minorVersion = num3;
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x00017C78 File Offset: 0x00015E78
		public UpdateInfo CompareWithNewVersion(Version newVersion)
		{
			bool flag = this.MainVersion < newVersion.MainVersion;
			UpdateInfo result;
			if (flag)
			{
				result = UpdateInfo.MainUpdate;
			}
			else
			{
				bool flag2 = this.MainVersion > newVersion.MainVersion;
				if (flag2)
				{
					result = UpdateInfo.NoUpdate;
				}
				else
				{
					bool flag3 = this.MajorVersion < newVersion.MajorVersion;
					if (flag3)
					{
						result = UpdateInfo.MajorUpdate;
					}
					else
					{
						bool flag4 = this.MajorVersion > newVersion.MajorVersion;
						if (flag4)
						{
							result = UpdateInfo.NoUpdate;
						}
						else
						{
							bool flag5 = this.MinorVersion < newVersion.MinorVersion;
							if (flag5)
							{
								result = UpdateInfo.MinorUpdate;
							}
							else
							{
								result = UpdateInfo.NoUpdate;
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x00017D08 File Offset: 0x00015F08
		public override string ToString()
		{
			return string.Format("{0}.{1}.{2}", this.MainVersion, this.MajorVersion, this.MinorVersion);
		}

		// Token: 0x040003BB RID: 955
		private int mainVersion;

		// Token: 0x040003BC RID: 956
		private int majorVersion;

		// Token: 0x040003BD RID: 957
		private int minorVersion;
	}
}
