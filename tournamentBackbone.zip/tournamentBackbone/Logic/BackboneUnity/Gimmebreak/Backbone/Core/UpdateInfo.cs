﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000070 RID: 112
	public enum UpdateInfo
	{
		// Token: 0x040003B7 RID: 951
		NoUpdate,
		// Token: 0x040003B8 RID: 952
		MainUpdate,
		// Token: 0x040003B9 RID: 953
		MajorUpdate,
		// Token: 0x040003BA RID: 954
		MinorUpdate
	}
}
