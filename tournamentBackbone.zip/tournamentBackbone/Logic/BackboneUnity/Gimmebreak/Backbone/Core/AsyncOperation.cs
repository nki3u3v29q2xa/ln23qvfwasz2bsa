﻿using System;
using System.Collections;
using System.Threading;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000063 RID: 99
	public class AsyncOperation<T> : IAsyncOperation, IEnumerator
	{
		// Token: 0x17000152 RID: 338
		// (get) Token: 0x06000490 RID: 1168 RVA: 0x0001626C File Offset: 0x0001446C
		object IEnumerator.Current
		{
			get
			{
				return (this.isDone || this.runInThread) ? null : this.routine.Current;
			}
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x06000491 RID: 1169 RVA: 0x0001629C File Offset: 0x0001449C
		public T ReturnValue
		{
			get
			{
				bool flag = this.isDone;
				if (!flag)
				{
					throw new InvalidOperationException("Cannot access return value before coroutine is finished.");
				}
				bool flag2 = this.executionException == null;
				if (flag2)
				{
					return this.returnValue;
				}
				throw new Exception("Coroutine threw an exception, return value not available.", this.executionException);
			}
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x06000492 RID: 1170 RVA: 0x0000541F File Offset: 0x0000361F
		// (set) Token: 0x06000493 RID: 1171 RVA: 0x00005427 File Offset: 0x00003627
		bool IAsyncOperation.AutoThrowExecutionException { get; set; }

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000494 RID: 1172 RVA: 0x00005430 File Offset: 0x00003630
		// (set) Token: 0x06000495 RID: 1173 RVA: 0x00005438 File Offset: 0x00003638
		bool IAsyncOperation.IsNestedOperation { get; set; }

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x06000496 RID: 1174 RVA: 0x000162EC File Offset: 0x000144EC
		Exception IAsyncOperation.ExecutionException
		{
			get
			{
				return this.executionException;
			}
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x06000497 RID: 1175 RVA: 0x00016304 File Offset: 0x00014504
		public bool IsDone
		{
			get
			{
				return this.isDone;
			}
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x0001631C File Offset: 0x0001451C
		public AsyncOperation(IEnumerator routine, bool runInThread = false)
		{
			this.routine = routine;
			this.executionException = null;
			this.isDone = false;
			this.returnValue = default(T);
			this.runInThread = runInThread;
			bool flag = this.routine == null;
			if (flag)
			{
				this.isDone = true;
			}
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x00005441 File Offset: 0x00003641
		public AsyncOperation(Func<T> threadedWorker) : this(AsyncOperation<T>.ThreadedWorkerRoutine(threadedWorker), true)
		{
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x00005452 File Offset: 0x00003652
		private static IEnumerator ThreadedWorkerRoutine(Func<T> threadedWorker)
		{
			yield return new AsyncOperation<T>.Result(threadedWorker());
			yield break;
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x00016370 File Offset: 0x00014570
		bool IEnumerator.MoveNext()
		{
			bool flag = this.isDone;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					bool flag2 = this.runInThread;
					if (flag2)
					{
						bool flag3 = this.thread == null;
						if (flag3)
						{
							this.thread = delegate(object state)
							{
								try
								{
									while (this.routine.MoveNext())
									{
										object obj2 = this.routine.Current;
										bool flag10 = obj2 is AsyncOperation<T>.Result;
										if (flag10)
										{
											this.isDone = true;
											this.returnValue = ((AsyncOperation<T>.Result)obj2).Value;
											return;
										}
									}
									throw new InvalidOperationException("Corutine did not return result value. Last yield return instruction must be 'new AsyncOperation<T>.Result(value)'.");
								}
								catch (Exception ex2)
								{
									this.executionException = ex2;
									this.isDone = true;
								}
							};
							ThreadPool.QueueUserWorkItem(this.thread);
						}
						result = true;
					}
					else
					{
						object obj = this.routine.Current;
						bool flag4 = obj is IAsyncOperation;
						if (flag4)
						{
							IAsyncOperation asyncOperation = (IAsyncOperation)obj;
							bool flag5 = asyncOperation.AutoThrowExecutionException && asyncOperation.ExecutionException != null;
							if (flag5)
							{
								throw new Exception("Coroutine exception rethrow.", asyncOperation.ExecutionException);
							}
						}
						bool flag6 = this.routine.MoveNext();
						if (!flag6)
						{
							throw new InvalidOperationException("Corutine did not return result value. Last yield return instruction must be 'new AsyncOperation<T>.Result(value)'.");
						}
						obj = this.routine.Current;
						bool flag7 = obj is AsyncOperation<T>.Result;
						if (flag7)
						{
							this.isDone = true;
							this.returnValue = ((AsyncOperation<T>.Result)obj).Value;
							result = false;
						}
						else
						{
							bool flag8 = obj is IAsyncOperation;
							if (flag8)
							{
								((IAsyncOperation)obj).IsNestedOperation = true;
							}
							result = true;
						}
					}
				}
				catch (Exception ex)
				{
					this.executionException = ex;
					this.isDone = true;
					bool flag9 = ((IAsyncOperation)this).AutoThrowExecutionException && !((IAsyncOperation)this).IsNestedOperation;
					if (flag9)
					{
						throw;
					}
					result = false;
				}
			}
			return result;
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x00005461 File Offset: 0x00003661
		void IEnumerator.Reset()
		{
			throw new InvalidOperationException("Coroutine cannot be reset.");
		}

		// Token: 0x04000383 RID: 899
		private readonly IEnumerator routine;

		// Token: 0x04000384 RID: 900
		private T returnValue;

		// Token: 0x04000385 RID: 901
		private bool isDone;

		// Token: 0x04000386 RID: 902
		private Exception executionException;

		// Token: 0x04000387 RID: 903
		private readonly bool runInThread;

		// Token: 0x04000388 RID: 904
		private WaitCallback thread;

		// Token: 0x020000F5 RID: 245
		public class Result
		{
			// Token: 0x1700025F RID: 607
			// (get) Token: 0x06000871 RID: 2161 RVA: 0x00024A58 File Offset: 0x00022C58
			public T Value
			{
				get
				{
					return this.value;
				}
			}

			// Token: 0x06000872 RID: 2162 RVA: 0x00007064 File Offset: 0x00005264
			public Result(T value)
			{
				this.value = value;
			}

			// Token: 0x040006CE RID: 1742
			private readonly T value;
		}
	}
}
