﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x0200006B RID: 107
	public class ResourceCache : MonoBehaviour
	{
		// Token: 0x17000164 RID: 356
		// (get) Token: 0x060004EC RID: 1260 RVA: 0x0001731C File Offset: 0x0001551C
		public static bool IsInitialized
		{
			get
			{
				return ResourceCache.instance != null && ResourceCache.isInitialized;
			}
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x00017344 File Offset: 0x00015544
		private void Awake()
		{
			bool flag = ResourceCache.instance == null;
			if (flag)
			{
				FileStorage.Initialize();
				SystemInfoExtensions.GetBackboneDeviceUniqueId();
				ResourceCache.instance = this;
				ResourceCache.isInitialized = false;
			}
			else
			{
				Debug.LogWarning("ResourceCache already exists in the scene. Destroying redundant ResourceCache script.");
				Object.Destroy(this);
			}
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x000055C7 File Offset: 0x000037C7
		private IEnumerator Start()
		{
			AsyncOperation<ResourceCacheData> loadResourceCacheOperation = this.LoadResourceCacheData();
			yield return loadResourceCacheOperation;
			this.cacheData = loadResourceCacheOperation.ReturnValue;
			this.RefreshStats();
			ResourceCache.isInitialized = true;
			yield break;
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x00017394 File Offset: 0x00015594
		private static AsyncOperation<bool> WaitUntilInitialized()
		{
			bool flag = ResourceCache.isInitialized;
			AsyncOperation<bool> result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new AsyncOperation<bool>(ResourceCache.WaitUntilInitializedRoutine(), false);
			}
			return result;
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x000055D6 File Offset: 0x000037D6
		private static IEnumerator WaitUntilInitializedRoutine()
		{
			bool flag = ResourceCache.instance == null;
			if (flag)
			{
				Debug.LogError("Resource cache does not have initialized instance. Add ResourceCache script to scene.");
			}
			else
			{
				while (!ResourceCache.isInitialized)
				{
					yield return null;
				}
				yield return new AsyncOperation<bool>.Result(true);
			}
			yield return new AsyncOperation<bool>.Result(false);
			yield break;
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x000173C0 File Offset: 0x000155C0
		private static AsyncOperation<bool> LockUri(string uri, double lockTime)
		{
			return new AsyncOperation<bool>(ResourceCache.LockUriRoutine(uri, lockTime), false);
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x000055DE File Offset: 0x000037DE
		private static IEnumerator LockUriRoutine(string uri, double lockTime)
		{
			DateTime lockedUntil;
			while (ResourceCache.uriLocks.TryGetValue(uri, out lockedUntil))
			{
				bool flag = lockedUntil <= DateTime.UtcNow;
				if (flag)
				{
					ResourceCache.uriLocks[uri] = DateTime.UtcNow.AddMilliseconds(lockTime);
					yield return new AsyncOperation<bool>.Result(false);
				}
				yield return null;
			}
			ResourceCache.uriLocks.Add(uri, DateTime.UtcNow.AddMilliseconds(lockTime));
			yield return new AsyncOperation<bool>.Result(true);
			yield break;
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x000055F4 File Offset: 0x000037F4
		private static void UnlockUri(string uri)
		{
			ResourceCache.uriLocks.Remove(uri);
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x000173E0 File Offset: 0x000155E0
		private AsyncOperation<ResourceCacheData> LoadResourceCacheData()
		{
			return new AsyncOperation<ResourceCacheData>(delegate()
			{
				ResourceCacheData resourceCacheData = FileStorage.LoadObjectFromFile<ResourceCacheData>("ResourceCache/cachedresources.data", new Version("2.0.0"), true);
				bool flag = resourceCacheData == null;
				if (flag)
				{
					bool flag2 = FileStorage.CheckDirectory("ResourceCache/");
					if (flag2)
					{
						FileStorage.DeleteDirectory("ResourceCache/");
					}
					FileStorage.CreateDirectory("ResourceCache/");
					resourceCacheData = new ResourceCacheData();
				}
				else
				{
					resourceCacheData.OnAfterDeserialize();
				}
				return resourceCacheData;
			});
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x00005603 File Offset: 0x00003803
		private void RefreshStats()
		{
			this.cachedObjects = this.cacheData.CachedObjectsCount;
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x00017418 File Offset: 0x00015618
		public static AsyncOperation<Texture2D> DownloadTexture(string url)
		{
			return new AsyncOperation<Texture2D>(ResourceCache.DownloadTextureRoutine(url), false);
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x00005617 File Offset: 0x00003817
		private static IEnumerator DownloadTextureRoutine(string url)
		{
			bool flag = !string.IsNullOrEmpty(url);
			if (flag)
			{
				UnityWebRequest request = UnityWebRequestTexture.GetTexture(url);
				yield return request.SendWebRequest();
				bool flag2 = !request.isHttpError && !request.isNetworkError;
				if (flag2)
				{
					Texture2D texture = DownloadHandlerTexture.GetContent(request);
					yield return new AsyncOperation<Texture2D>.Result(texture);
					texture = null;
				}
				request = null;
			}
			yield return new AsyncOperation<Texture2D>.Result(null);
			yield break;
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x00017438 File Offset: 0x00015638
		public AsyncOperation<bool> SaveData()
		{
			return new AsyncOperation<bool>(delegate()
			{
				bool flag = ResourceCache.isInitialized;
				if (flag)
				{
					ResourceCacheData obj = this.cacheData;
					lock (obj)
					{
						this.cacheData.OnBeforeSerialize();
						FileStorage.SaveObjectToFile<ResourceCacheData>("ResourceCache/cachedresources.data", this.cacheData, true);
						this.RefreshStats();
						return true;
					}
				}
				return false;
			});
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x0001745C File Offset: 0x0001565C
		public static AsyncOperation<ResourceCacheObject> CreateResource<T>(string uri, int version, bool canExpire, bool canExtendExpiryDate, int lifespan, T data) where T : class
		{
			return new AsyncOperation<ResourceCacheObject>(ResourceCache.CreateResourceRoutine<T>(uri, version, canExpire, canExtendExpiryDate, lifespan, data), false);
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x00005626 File Offset: 0x00003826
		private static IEnumerator CreateResourceRoutine<T>(string uri, int version, bool canExpire, bool canExtendExpiryDate, int lifespan, T data) where T : class
		{
			yield return ResourceCache.WaitUntilInitialized();
			ResourceCacheObject resourceCacheObject = new ResourceCacheObject();
			resourceCacheObject.Uri = uri;
			resourceCacheObject.Version = version;
			resourceCacheObject.CanExpire = canExpire;
			resourceCacheObject.CanExtendExpiryDate = canExtendExpiryDate;
			resourceCacheObject.CreatedDate = DateTime.UtcNow;
			resourceCacheObject.ExpiryDate = DateTime.UtcNow.AddSeconds((double)lifespan);
			resourceCacheObject.Lifespan = lifespan;
			resourceCacheObject.Size = 0;
			resourceCacheObject.FileDataPath = ResourceCache.CreateFileDataPath();
			bool flag = ResourceCache.instance.cacheData.AddCachedObject(resourceCacheObject);
			if (flag)
			{
				yield return resourceCacheObject.SetData<T>(data, false, true);
			}
			yield return ResourceCache.instance.SaveData();
			yield return new AsyncOperation<ResourceCacheObject>.Result(ResourceCache.instance.cacheData.GetChachedObject(uri));
			yield break;
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x00017484 File Offset: 0x00015684
		public static AsyncOperation<ResourceCacheObject> CreateResource(string uri, int version, bool canExpire, bool canExtendExpiryDate, int lifespan, byte[] data)
		{
			return new AsyncOperation<ResourceCacheObject>(ResourceCache.CreateResourceRoutine(uri, version, canExpire, canExtendExpiryDate, lifespan, data), false);
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x0000565A File Offset: 0x0000385A
		private static IEnumerator CreateResourceRoutine(string uri, int version, bool canExpire, bool canExtendExpiryDate, int lifespan, byte[] data)
		{
			yield return ResourceCache.WaitUntilInitialized();
			ResourceCacheObject resourceCacheObject = new ResourceCacheObject();
			resourceCacheObject.Uri = uri;
			resourceCacheObject.Version = version;
			resourceCacheObject.CanExpire = canExpire;
			resourceCacheObject.CanExtendExpiryDate = canExtendExpiryDate;
			resourceCacheObject.CreatedDate = DateTime.UtcNow;
			resourceCacheObject.ExpiryDate = DateTime.UtcNow.AddSeconds((double)lifespan);
			resourceCacheObject.Lifespan = lifespan;
			resourceCacheObject.Size = data.Length;
			resourceCacheObject.FileDataPath = ResourceCache.CreateFileDataPath();
			bool flag = ResourceCache.instance.cacheData.AddCachedObject(resourceCacheObject);
			if (flag)
			{
				yield return resourceCacheObject.SetData(data, false, true);
			}
			yield return ResourceCache.instance.SaveData();
			yield return new AsyncOperation<ResourceCacheObject>.Result(ResourceCache.instance.cacheData.GetChachedObject(uri));
			yield break;
		}

		// Token: 0x060004FD RID: 1277 RVA: 0x000174AC File Offset: 0x000156AC
		private static string CreateFileDataPath()
		{
			return "ResourceCache/" + Guid.NewGuid().ToString() + ".data";
		}

		// Token: 0x060004FE RID: 1278 RVA: 0x000174E0 File Offset: 0x000156E0
		public static AsyncOperation<ResourceCacheObject> LoadResource(string uri, int version)
		{
			return new AsyncOperation<ResourceCacheObject>(ResourceCache.LoadResourceRoutine(uri, version), false);
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x0000568E File Offset: 0x0000388E
		private static IEnumerator LoadResourceRoutine(string uri, int version)
		{
			yield return ResourceCache.WaitUntilInitialized();
			ResourceCacheObject cachedObject = ResourceCache.instance.cacheData.GetChachedObject(uri);
			bool flag = cachedObject != null && cachedObject.Version >= version;
			if (flag)
			{
				bool flag2 = !FileStorage.Exists(cachedObject.FileDataPath);
				if (flag2)
				{
					ResourceCache.instance.cacheData.RemoveCachedObject(uri);
					cachedObject = null;
				}
				else
				{
					bool flag3 = cachedObject.CanExtendExpiryDate && cachedObject.ExpiryDate.AddSeconds((double)(-(double)cachedObject.Lifespan / 3)) < DateTime.UtcNow;
					if (flag3)
					{
						cachedObject.ExtendExpiration();
						yield return ResourceCache.instance.SaveData();
					}
				}
			}
			else
			{
				cachedObject = null;
			}
			yield return new AsyncOperation<ResourceCacheObject>.Result(cachedObject);
			yield break;
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x00017500 File Offset: 0x00015700
		public static AsyncOperation<Texture2D> LoadResourceTexture(string uri, int version)
		{
			return new AsyncOperation<Texture2D>(ResourceCache.LoadResourceRoutine(uri, version), false);
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x000056A4 File Offset: 0x000038A4
		private static IEnumerator LoadResourceTextureRoutine(string uri, int version)
		{
			yield return ResourceCache.WaitUntilInitialized();
			AsyncOperation<ResourceCacheObject> loadResourceOperation = ResourceCache.LoadResource(uri, version);
			yield return loadResourceOperation;
			bool flag = loadResourceOperation.ReturnValue != null;
			if (flag)
			{
				AsyncOperation<Texture2D> getDataOperation = loadResourceOperation.ReturnValue.GetDataAsTexture2d();
				yield return getDataOperation;
				yield return new AsyncOperation<Texture2D>.Result(getDataOperation.ReturnValue);
				getDataOperation = null;
			}
			yield return new AsyncOperation<Texture2D>.Result(null);
			yield break;
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x00017520 File Offset: 0x00015720
		public static AsyncOperation<Texture2D> LoadResourceTextureFromCacheOrUrl(string url, int version, bool canExpire)
		{
			return ResourceCache.LoadResourceTextureFromCacheOrUrl(url, version, canExpire, true, (int)TimeSpan.FromDays((double)ResourceCache.instance.defaultLifespan).TotalSeconds, null);
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x00017558 File Offset: 0x00015758
		public static AsyncOperation<Texture2D> LoadResourceTextureFromCacheOrUrl(string url, int version, bool canExpire, bool canExtendExpiryDate, int lifeSpan, Func<Texture2D, Texture2D> modifyTexture = null)
		{
			return new AsyncOperation<Texture2D>(ResourceCache.LoadResourceTextureFromCacheOrUrlRoutine(url, version, canExpire, canExtendExpiryDate, lifeSpan, modifyTexture), false);
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x000056BA File Offset: 0x000038BA
		private static IEnumerator LoadResourceTextureFromCacheOrUrlRoutine(string url, int version, bool canExpire, bool canExtendExpiryDate, int lifeSpan, Func<Texture2D, Texture2D> modifyTexture = null)
		{
			yield return ResourceCache.WaitUntilInitialized();
			yield return ResourceCache.LockUri(url, 10000.0);
			Texture2D texture = null;
			AsyncOperation<ResourceCacheObject> loadResourceOperation = ResourceCache.LoadResource(url, version);
			yield return loadResourceOperation;
			ResourceCacheObject cachedObject = loadResourceOperation.ReturnValue;
			bool flag = cachedObject == null;
			if (flag)
			{
				AsyncOperation<Texture2D> downloadImageOperation = ResourceCache.DownloadTexture(url);
				yield return downloadImageOperation;
				bool flag2 = downloadImageOperation.ReturnValue != null;
				if (flag2)
				{
					texture = downloadImageOperation.ReturnValue;
					bool flag3 = modifyTexture != null;
					if (flag3)
					{
						texture = modifyTexture(texture);
					}
					ResourceCacheObject.SerializableTexture serializableTexture = new ResourceCacheObject.SerializableTexture();
					serializableTexture.LoadDataFromTexture(texture);
					Object.Destroy(texture);
					texture = null;
					AsyncOperation<ResourceCacheObject> createResourceOperation = ResourceCache.CreateResource<ResourceCacheObject.SerializableTexture>(url, version, canExpire, canExtendExpiryDate, lifeSpan, serializableTexture);
					yield return createResourceOperation;
					bool flag4 = createResourceOperation.ReturnValue != null;
					if (flag4)
					{
						AsyncOperation<Texture2D> getDataOperation = createResourceOperation.ReturnValue.GetDataAsTexture2d();
						yield return getDataOperation;
						texture = getDataOperation.ReturnValue;
						getDataOperation = null;
					}
					serializableTexture = null;
					createResourceOperation = null;
				}
				downloadImageOperation = null;
			}
			else
			{
				bool flag5 = cachedObject.CanExpire && cachedObject.ExpiryDate < DateTime.UtcNow;
				if (flag5)
				{
					AsyncOperation<Texture2D> downloadImageOperation2 = ResourceCache.DownloadTexture(url);
					yield return downloadImageOperation2;
					bool flag6 = downloadImageOperation2.ReturnValue != null;
					if (flag6)
					{
						texture = downloadImageOperation2.ReturnValue;
						bool flag7 = modifyTexture != null;
						if (flag7)
						{
							texture = modifyTexture(texture);
						}
						yield return cachedObject.SetDataAsTexture2d(texture);
						cachedObject.ExtendExpiration();
						yield return ResourceCache.instance.SaveData();
						AsyncOperation<Texture2D> getDataOperation2 = cachedObject.GetDataAsTexture2d();
						yield return getDataOperation2;
						texture = getDataOperation2.ReturnValue;
						getDataOperation2 = null;
					}
					downloadImageOperation2 = null;
				}
				else
				{
					AsyncOperation<Texture2D> getDataOperation3 = cachedObject.GetDataAsTexture2d();
					yield return getDataOperation3;
					texture = getDataOperation3.ReturnValue;
					getDataOperation3 = null;
				}
			}
			ResourceCache.UnlockUri(url);
			yield return new AsyncOperation<Texture2D>.Result(texture);
			yield break;
		}

		// Token: 0x0400039D RID: 925
		private const string CACHE_DIRECTORY = "ResourceCache/";

		// Token: 0x0400039E RID: 926
		private const string CACHE_DATA = "ResourceCache/cachedresources.data";

		// Token: 0x0400039F RID: 927
		private static ResourceCache instance;

		// Token: 0x040003A0 RID: 928
		private static bool isInitialized;

		// Token: 0x040003A1 RID: 929
		private static Dictionary<string, DateTime> uriLocks = new Dictionary<string, DateTime>();

		// Token: 0x040003A2 RID: 930
		private ResourceCacheData cacheData;

		// Token: 0x040003A3 RID: 931
		[SerializeField]
		private int defaultLifespan = 7;

		// Token: 0x040003A4 RID: 932
		[SerializeField]
		private int cachedObjects;
	}
}
