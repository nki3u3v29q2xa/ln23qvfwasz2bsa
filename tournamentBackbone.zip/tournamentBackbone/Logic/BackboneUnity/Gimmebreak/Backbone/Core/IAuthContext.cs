﻿using System;

namespace Gimmebreak.Backbone.Core
{
	// Token: 0x02000069 RID: 105
	public interface IAuthContext
	{
		// Token: 0x17000160 RID: 352
		// (get) Token: 0x060004E2 RID: 1250
		string AccessToken { get; }

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x060004E3 RID: 1251
		string RefreshToken { get; }

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x060004E4 RID: 1252
		DateTime ExpireAt { get; }

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x060004E5 RID: 1253
		string DeviceId { get; }

		// Token: 0x060004E6 RID: 1254
		AsyncOperation<bool> UpdateAccessToken(string newAccessToken, DateTime expireAt);

		// Token: 0x060004E7 RID: 1255
		AsyncOperation<bool> InvalidateAuthContext();
	}
}
