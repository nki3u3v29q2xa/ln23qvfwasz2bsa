﻿using System;

namespace Gimmebreak.Backbone.GameSessions
{
	// Token: 0x02000055 RID: 85
	public class Submission
	{
		// Token: 0x17000126 RID: 294
		// (get) Token: 0x0600038E RID: 910 RVA: 0x00004951 File Offset: 0x00002B51
		// (set) Token: 0x0600038F RID: 911 RVA: 0x00004959 File Offset: 0x00002B59
		public Submission.SubmissionType Type { get; internal set; }

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x06000390 RID: 912 RVA: 0x00004962 File Offset: 0x00002B62
		// (set) Token: 0x06000391 RID: 913 RVA: 0x0000496A File Offset: 0x00002B6A
		public long Id { get; internal set; }

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x06000392 RID: 914 RVA: 0x00004973 File Offset: 0x00002B73
		// (set) Token: 0x06000393 RID: 915 RVA: 0x0000497B File Offset: 0x00002B7B
		public byte[] Data { get; internal set; }

		// Token: 0x020000A3 RID: 163
		public enum SubmissionType
		{
			// Token: 0x04000496 RID: 1174
			Unkown = -1,
			// Token: 0x04000497 RID: 1175
			User,
			// Token: 0x04000498 RID: 1176
			Server
		}
	}
}
