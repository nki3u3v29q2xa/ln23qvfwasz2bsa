﻿using System;

namespace Gimmebreak.Backbone.GameSessions
{
	// Token: 0x02000051 RID: 81
	public enum GameSessionStatEntityType
	{
		// Token: 0x04000327 RID: 807
		Unkown = -1,
		// Token: 0x04000328 RID: 808
		GameSessionStat,
		// Token: 0x04000329 RID: 809
		UserStat = 2
	}
}
