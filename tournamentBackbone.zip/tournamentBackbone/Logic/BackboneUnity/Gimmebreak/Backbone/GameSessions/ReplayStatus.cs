﻿using System;

namespace Gimmebreak.Backbone.GameSessions
{
	// Token: 0x02000053 RID: 83
	public enum ReplayStatus
	{
		// Token: 0x04000347 RID: 839
		Unavailable,
		// Token: 0x04000348 RID: 840
		Processing,
		// Token: 0x04000349 RID: 841
		Ready,
		// Token: 0x0400034A RID: 842
		Expired
	}
}
