﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.GameSessions
{
	// Token: 0x02000054 RID: 84
	[Serializable]
	public class Replay
	{
		// Token: 0x17000122 RID: 290
		// (get) Token: 0x06000382 RID: 898 RVA: 0x000048B9 File Offset: 0x00002AB9
		// (set) Token: 0x06000383 RID: 899 RVA: 0x000048C1 File Offset: 0x00002AC1
		public ReplayStatus Status { get; set; }

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x06000384 RID: 900 RVA: 0x000048CA File Offset: 0x00002ACA
		// (set) Token: 0x06000385 RID: 901 RVA: 0x000048D2 File Offset: 0x00002AD2
		[XmlIgnore]
		public bool IsLoaded { get; internal set; }

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x06000386 RID: 902 RVA: 0x000048DB File Offset: 0x00002ADB
		// (set) Token: 0x06000387 RID: 903 RVA: 0x000048E3 File Offset: 0x00002AE3
		[XmlIgnore]
		public Submission ServerSubmission { get; internal set; }

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000388 RID: 904 RVA: 0x000048EC File Offset: 0x00002AEC
		// (set) Token: 0x06000389 RID: 905 RVA: 0x000048F4 File Offset: 0x00002AF4
		[XmlIgnore]
		public List<Submission> UserSubmissions { get; internal set; }

		// Token: 0x0600038A RID: 906 RVA: 0x000048FD File Offset: 0x00002AFD
		public Replay()
		{
			this.UserSubmissions = new List<Submission>();
		}

		// Token: 0x0600038B RID: 907 RVA: 0x00014744 File Offset: 0x00012944
		internal void LoadSubmissions(Submission[] submissions)
		{
			this.UserSubmissions.Clear();
			this.ServerSubmission = null;
			for (int i = 0; i < submissions.Length; i++)
			{
				switch (submissions[i].Type)
				{
				case Submission.SubmissionType.User:
					this.UserSubmissions.Add(submissions[i]);
					break;
				case Submission.SubmissionType.Server:
					this.ServerSubmission = submissions[i];
					break;
				}
			}
			this.IsLoaded = true;
		}

		// Token: 0x0600038C RID: 908 RVA: 0x000147C4 File Offset: 0x000129C4
		internal static Submission[] ParseReplayData(JSONObject replayMetadata, byte[] replayData)
		{
			Submission[] array = null;
			bool flag = replayMetadata.HasField(Replay.FIELD_BLOCKS);
			if (flag)
			{
				List<JSONObject> list = replayMetadata[Replay.FIELD_BLOCKS].list;
				array = new Submission[list.Count];
				for (int i = 0; i < list.Count; i++)
				{
					JSONObject jsonobject = list[i];
					long sourceIndex = 0L;
					long num = 0L;
					Submission submission = new Submission();
					bool flag2 = jsonobject.HasField(Replay.FIELD_STARTINDEX);
					if (flag2)
					{
						sourceIndex = jsonobject[Replay.FIELD_STARTINDEX].i;
					}
					bool flag3 = jsonobject.HasField(Replay.FIELD_SIZE);
					if (flag3)
					{
						num = jsonobject[Replay.FIELD_SIZE].i;
					}
					bool flag4 = jsonobject.HasField(Replay.FIELD_ID) && !jsonobject[Replay.FIELD_ID].IsNull;
					if (flag4)
					{
						submission.Id = long.Parse(jsonobject[Replay.FIELD_ID].str);
					}
					submission.Data = new byte[num];
					Array.Copy(replayData, sourceIndex, submission.Data, 0L, num);
					submission.Type = Submission.SubmissionType.Unkown;
					bool flag5 = jsonobject.HasField(Replay.FIELD_TYPE) && !jsonobject[Replay.FIELD_TYPE].IsNull;
					if (flag5)
					{
						string str = jsonobject[Replay.FIELD_TYPE].str;
						if (!(str == "user"))
						{
							if (!(str == "server"))
							{
								submission.Type = Submission.SubmissionType.Unkown;
							}
							else
							{
								submission.Type = Submission.SubmissionType.Server;
							}
						}
						else
						{
							submission.Type = Submission.SubmissionType.User;
						}
					}
					array[i] = submission;
				}
			}
			bool flag6 = array == null;
			if (flag6)
			{
				array = new Submission[0];
			}
			return array;
		}

		// Token: 0x0400034B RID: 843
		internal static readonly string FIELD_ISREPLAYAVAILABLE = "isReplayAvailable";

		// Token: 0x0400034C RID: 844
		private static readonly string FIELD_BLOCKS = "blocks";

		// Token: 0x0400034D RID: 845
		private static readonly string FIELD_STARTINDEX = "startIndex";

		// Token: 0x0400034E RID: 846
		private static readonly string FIELD_SIZE = "size";

		// Token: 0x0400034F RID: 847
		private static readonly string FIELD_TYPE = "type";

		// Token: 0x04000350 RID: 848
		private static readonly string FIELD_ID = "id";
	}
}
