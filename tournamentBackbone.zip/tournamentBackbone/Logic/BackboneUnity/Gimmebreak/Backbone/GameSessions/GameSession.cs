﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.GameSessions
{
	// Token: 0x02000052 RID: 82
	[XmlType(Namespace = "GameSession")]
	[Serializable]
	public class GameSession
	{
		// Token: 0x17000119 RID: 281
		// (get) Token: 0x0600035F RID: 863 RVA: 0x000047F2 File Offset: 0x000029F2
		// (set) Token: 0x06000360 RID: 864 RVA: 0x000047FA File Offset: 0x000029FA
		public long Id { get; set; }

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06000361 RID: 865 RVA: 0x00004803 File Offset: 0x00002A03
		// (set) Token: 0x06000362 RID: 866 RVA: 0x0000480B File Offset: 0x00002A0B
		public byte SessionType { get; set; }

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06000363 RID: 867 RVA: 0x00004814 File Offset: 0x00002A14
		// (set) Token: 0x06000364 RID: 868 RVA: 0x0000481C File Offset: 0x00002A1C
		public long TournamentMatchId { get; set; }

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06000365 RID: 869 RVA: 0x00004825 File Offset: 0x00002A25
		// (set) Token: 0x06000366 RID: 870 RVA: 0x0000482D File Offset: 0x00002A2D
		[XmlIgnore]
		internal bool IsRanked { get; set; }

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x06000367 RID: 871 RVA: 0x00004836 File Offset: 0x00002A36
		// (set) Token: 0x06000368 RID: 872 RVA: 0x0000483E File Offset: 0x00002A3E
		public decimal PlayTime { get; set; }

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x06000369 RID: 873 RVA: 0x00004847 File Offset: 0x00002A47
		// (set) Token: 0x0600036A RID: 874 RVA: 0x0000484F File Offset: 0x00002A4F
		public DateTime PlayDate { get; set; }

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x0600036B RID: 875 RVA: 0x00004858 File Offset: 0x00002A58
		// (set) Token: 0x0600036C RID: 876 RVA: 0x00004860 File Offset: 0x00002A60
		public List<GameSession.Stat> Stats { get; set; }

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x0600036D RID: 877 RVA: 0x00004869 File Offset: 0x00002A69
		// (set) Token: 0x0600036E RID: 878 RVA: 0x00004871 File Offset: 0x00002A71
		public List<GameSession.User> Users { get; set; }

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x0600036F RID: 879 RVA: 0x0000487A File Offset: 0x00002A7A
		// (set) Token: 0x06000370 RID: 880 RVA: 0x00004882 File Offset: 0x00002A82
		public Replay Replay { get; set; }

		// Token: 0x06000371 RID: 881 RVA: 0x0000488B File Offset: 0x00002A8B
		public GameSession()
		{
			this.Users = new List<GameSession.User>();
			this.Stats = new List<GameSession.Stat>();
			this.Replay = new Replay();
		}

		// Token: 0x06000372 RID: 882 RVA: 0x00013B88 File Offset: 0x00011D88
		public GameSession(long id, byte sessionType, List<GameSession.User> users, long tournamentMatchId)
		{
			this.Id = id;
			this.SessionType = sessionType;
			this.Users = users;
			this.TournamentMatchId = tournamentMatchId;
			this.Stats = new List<GameSession.Stat>();
			this.Replay = new Replay();
			this.Users.Sort(delegate(GameSession.User user1, GameSession.User user2)
			{
				bool flag = user1.TeamId != user2.TeamId;
				int result;
				if (flag)
				{
					result = user1.TeamId.CompareTo(user2.TeamId);
				}
				else
				{
					result = user1.UserId.CompareTo(user2.UserId);
				}
				return result;
			});
		}

		// Token: 0x06000373 RID: 883 RVA: 0x00013C04 File Offset: 0x00011E04
		internal XElement GetCreateXmlData()
		{
			XName name = "data";
			XName name2 = "game-session";
			object[] array = new object[3];
			array[0] = new XAttribute("type", this.SessionType);
			array[1] = new XAttribute("tournament-match-id", this.ShouldSerializeTournamentMatchId() ? this.GetTournamentMatchId().ToString() : null);
			array[2] = (from user in this.Users
			select new XElement("user", new object[]
			{
				new XAttribute("user-id", user.UserId),
				new XAttribute("team-id", user.TeamId)
			})).ToArray<XElement>();
			return new XElement(name, new XElement(name2, array));
		}

		// Token: 0x06000374 RID: 884 RVA: 0x00013CB4 File Offset: 0x00011EB4
		internal XElement GetResultXmlData()
		{
			XName name = "data";
			XName name2 = "game-session";
			object[] array = new object[7];
			array[0] = new XAttribute("type", this.SessionType);
			array[1] = new XAttribute("tournament-match-id", this.ShouldSerializeTournamentMatchId() ? this.GetTournamentMatchId().ToString() : null);
			array[2] = new XAttribute("is-ranked", BackboneHttpClient.GetBool(this.IsRanked));
			array[3] = new XAttribute("time", BackboneHttpClient.GetFloat(this.PlayTime));
			array[4] = new XAttribute("play-date", BackboneHttpClient.GetSqlDate(this.PlayDate));
			int num = 5;
			XName name3 = "stats";
			object[] content = (from stat in this.Stats
			select new XElement("stat", new object[]
			{
				new XAttribute("entity-type", (int)stat.EntityType),
				new XAttribute("entity-id", stat.EntityId),
				new XAttribute("stat-id", stat.StatId),
				string.IsNullOrEmpty(stat.TextValue) ? new XAttribute("float-value", BackboneHttpClient.GetFloat(stat.FloatValue)) : new XAttribute("text-value", stat.TextValue)
			})).ToArray<XElement>();
			array[num] = new XElement(name3, content);
			array[6] = (from user in this.Users
			select new XElement("user", new object[]
			{
				new XAttribute("user-id", user.UserId),
				new XAttribute("team-id", user.TeamId),
				new XAttribute("place", user.Place)
			})).ToArray<XElement>();
			return new XElement(name, new XElement(name2, array));
		}

		// Token: 0x06000375 RID: 885 RVA: 0x00013E00 File Offset: 0x00012000
		internal void LoadJSONGameSession(JSONObject data)
		{
			bool flag = data.HasField(GameSession.FIELD_ID) && !data[GameSession.FIELD_ID].IsNull;
			if (flag)
			{
				this.Id = long.Parse(data[GameSession.FIELD_ID].str);
			}
			bool flag2 = data.HasField(GameSession.FIELD_PLAYDATE);
			if (flag2)
			{
				this.PlayDate = data[GameSession.FIELD_PLAYDATE].ToUniversalTime();
			}
			bool flag3 = data.HasField(GameSession.FIELD_TIME) && !data[GameSession.FIELD_TIME].IsNull;
			if (flag3)
			{
				this.PlayTime = decimal.Parse(data[GameSession.FIELD_TIME].str, NumberStyles.Float, CultureInfo.InvariantCulture);
			}
			bool flag4 = data.HasField(GameSession.FIELD_TYPE) && !data[GameSession.FIELD_TYPE].IsNull;
			if (flag4)
			{
				this.SessionType = byte.Parse(data[GameSession.FIELD_TYPE].str);
			}
			bool flag5 = data.HasField(GameSession.FIELD_TOURNAMENTMATCHID) && !data[GameSession.FIELD_TOURNAMENTMATCHID].IsNull;
			if (flag5)
			{
				this.TournamentMatchId = long.Parse(data[GameSession.FIELD_TOURNAMENTMATCHID].str);
			}
			else
			{
				this.TournamentMatchId = 0L;
			}
			bool flag6 = data.HasField(GameSession.FIELD_REPLAYSTATUS);
			if (flag6)
			{
				this.Replay.Status = data[GameSession.FIELD_REPLAYSTATUS].ToEnum(ReplayStatus.Unavailable);
			}
			bool flag7 = data.HasField(GameSession.FIELD_STATS) && data[GameSession.FIELD_STATS].Count > 0 && data[GameSession.FIELD_STATS][0].HasField(GameSession.FIELD_STAT);
			if (flag7)
			{
				this.Stats.Clear();
				List<JSONObject> list = data[GameSession.FIELD_STATS][0][GameSession.FIELD_STAT].list;
				for (int i = 0; i < list.Count; i++)
				{
					JSONObject jsonobject = list[i];
					GameSession.Stat item = default(GameSession.Stat);
					item.EntityType = GameSessionStatEntityType.Unkown;
					bool flag8 = jsonobject.HasField(GameSession.FIELD_ENTITYTYPE);
					if (flag8)
					{
						item.EntityType = jsonobject[GameSession.FIELD_ENTITYTYPE].ToEnum(GameSessionStatEntityType.Unkown);
					}
					bool flag9 = jsonobject.HasField(GameSession.FIELD_ENTITYID);
					if (flag9)
					{
						item.EntityId = long.Parse(jsonobject[GameSession.FIELD_ENTITYID].str);
					}
					bool flag10 = jsonobject.HasField(GameSession.FIELD_STATID);
					if (flag10)
					{
						item.StatId = byte.Parse(jsonobject[GameSession.FIELD_STATID].str);
					}
					bool flag11 = jsonobject.HasField(GameSession.FIELD_FLOATVALUE);
					if (flag11)
					{
						item.FloatValue = decimal.Parse(jsonobject[GameSession.FIELD_FLOATVALUE].str, NumberStyles.Float, CultureInfo.InvariantCulture);
					}
					bool flag12 = jsonobject.HasField(GameSession.FIELD_TEXTVALUE);
					if (flag12)
					{
						item.TextValue = jsonobject[GameSession.FIELD_TEXTVALUE].str;
					}
					bool flag13 = item.EntityType != GameSessionStatEntityType.Unkown;
					if (flag13)
					{
						this.Stats.Add(item);
					}
				}
			}
			bool flag14 = data.HasField(GameSession.FIELD_USER);
			if (flag14)
			{
				this.Users.Clear();
				List<JSONObject> list2 = data[GameSession.FIELD_USER].list;
				for (int j = 0; j < list2.Count; j++)
				{
					JSONObject jsonobject2 = list2[j];
					GameSession.User item2 = default(GameSession.User);
					bool flag15 = jsonobject2.HasField(GameSession.FIELD_USERID);
					if (flag15)
					{
						item2.UserId = long.Parse(jsonobject2[GameSession.FIELD_USERID].str);
					}
					bool flag16 = jsonobject2.HasField(GameSession.FIELD_TEAMID);
					if (flag16)
					{
						item2.TeamId = byte.Parse(jsonobject2[GameSession.FIELD_TEAMID].str);
					}
					bool flag17 = jsonobject2.HasField(GameSession.FIELD_PLACE);
					if (flag17)
					{
						item2.Place = (int)byte.Parse(jsonobject2[GameSession.FIELD_PLACE].str);
					}
					bool flag18 = jsonobject2.HasField(GameSession.FIELD_NICK);
					if (flag18)
					{
						item2.Nick = jsonobject2[GameSession.FIELD_NICK].str;
					}
					bool flag19 = jsonobject2.HasField(GameSession.FIELD_RANKSCORE);
					if (flag19)
					{
						item2.RankScore = int.Parse(jsonobject2[GameSession.FIELD_RANKSCORE].str);
					}
					this.Users.Add(item2);
				}
				this.Users.Sort(delegate(GameSession.User user1, GameSession.User user2)
				{
					bool flag20 = user1.TeamId != user2.TeamId;
					int result;
					if (flag20)
					{
						result = user1.TeamId.CompareTo(user2.TeamId);
					}
					else
					{
						result = user1.UserId.CompareTo(user2.UserId);
					}
					return result;
				});
			}
		}

		// Token: 0x06000376 RID: 886 RVA: 0x00014304 File Offset: 0x00012504
		internal long GetTournamentMatchId()
		{
			return this.TournamentMatchId;
		}

		// Token: 0x06000377 RID: 887 RVA: 0x0001431C File Offset: 0x0001251C
		public bool ShouldSerializeTournamentMatchId()
		{
			return true;
		}

		// Token: 0x06000378 RID: 888 RVA: 0x00014330 File Offset: 0x00012530
		public void SetPlace(long userId, int place)
		{
			for (int i = 0; i < this.Users.Count; i++)
			{
				bool flag = this.Users[i].UserId == userId;
				if (flag)
				{
					GameSession.User value = this.Users[i];
					value.Place = place;
					this.Users[i] = value;
				}
			}
		}

		// Token: 0x06000379 RID: 889 RVA: 0x000143A0 File Offset: 0x000125A0
		public void AddStat(byte statId, decimal value)
		{
			this.Stats.Add(new GameSession.Stat
			{
				EntityType = GameSessionStatEntityType.GameSessionStat,
				EntityId = this.Id,
				StatId = statId,
				FloatValue = value
			});
		}

		// Token: 0x0600037A RID: 890 RVA: 0x000143EC File Offset: 0x000125EC
		public void AddStat(byte statId, string value)
		{
			this.Stats.Add(new GameSession.Stat
			{
				EntityType = GameSessionStatEntityType.GameSessionStat,
				EntityId = this.Id,
				StatId = statId,
				TextValue = value
			});
		}

		// Token: 0x0600037B RID: 891 RVA: 0x00014438 File Offset: 0x00012638
		public void AddStat(byte statId, long userId, decimal value)
		{
			this.Stats.Add(new GameSession.Stat
			{
				EntityType = GameSessionStatEntityType.UserStat,
				EntityId = userId,
				StatId = statId,
				FloatValue = value
			});
		}

		// Token: 0x0600037C RID: 892 RVA: 0x00014480 File Offset: 0x00012680
		public void AddStat(byte statId, long userId, string value)
		{
			this.Stats.Add(new GameSession.Stat
			{
				EntityType = GameSessionStatEntityType.UserStat,
				EntityId = userId,
				StatId = statId,
				TextValue = value
			});
		}

		// Token: 0x0600037D RID: 893 RVA: 0x000144C8 File Offset: 0x000126C8
		public bool GetStat(byte statId, out GameSession.Stat stat)
		{
			for (int i = 0; i < this.Stats.Count; i++)
			{
				bool flag = this.Stats[i].EntityType == GameSessionStatEntityType.GameSessionStat && this.Stats[i].StatId == statId;
				if (flag)
				{
					stat = this.Stats[i];
					return true;
				}
			}
			stat = default(GameSession.Stat);
			stat.EntityType = GameSessionStatEntityType.Unkown;
			return false;
		}

		// Token: 0x0600037E RID: 894 RVA: 0x00014554 File Offset: 0x00012754
		public bool GetStat(byte statId, long userId, out GameSession.Stat stat)
		{
			for (int i = 0; i < this.Stats.Count; i++)
			{
				bool flag = this.Stats[i].EntityType == GameSessionStatEntityType.UserStat && this.Stats[i].EntityId == userId && this.Stats[i].StatId == statId;
				if (flag)
				{
					stat = this.Stats[i];
					return true;
				}
			}
			stat = default(GameSession.Stat);
			stat.EntityType = GameSessionStatEntityType.Unkown;
			return false;
		}

		// Token: 0x0600037F RID: 895 RVA: 0x000145F8 File Offset: 0x000127F8
		public GameSession.Stat[] GetStats(byte statId)
		{
			return (from stat in this.Stats
			where stat.EntityType == GameSessionStatEntityType.GameSessionStat && stat.StatId == statId
			select stat).ToArray<GameSession.Stat>();
		}

		// Token: 0x06000380 RID: 896 RVA: 0x00014634 File Offset: 0x00012834
		public GameSession.Stat[] GetStats(byte statId, long userId)
		{
			return (from stat in this.Stats
			where stat.EntityType == GameSessionStatEntityType.UserStat && stat.EntityId == userId && stat.StatId == statId
			select stat).ToArray<GameSession.Stat>();
		}

		// Token: 0x0400032A RID: 810
		internal static readonly string FIELD_ID = "@id";

		// Token: 0x0400032B RID: 811
		private static readonly string FIELD_PLAYDATE = "@play-date";

		// Token: 0x0400032C RID: 812
		private static readonly string FIELD_TIME = "@time";

		// Token: 0x0400032D RID: 813
		private static readonly string FIELD_TYPE = "@type";

		// Token: 0x0400032E RID: 814
		private static readonly string FIELD_TOURNAMENTMATCHID = "@tournament-match-id";

		// Token: 0x0400032F RID: 815
		private static readonly string FIELD_REPLAYSTATUS = "@replay-status";

		// Token: 0x04000330 RID: 816
		private static readonly string FIELD_STATS = "stats";

		// Token: 0x04000331 RID: 817
		private static readonly string FIELD_STAT = "stat";

		// Token: 0x04000332 RID: 818
		private static readonly string FIELD_ENTITYTYPE = "@entity-type";

		// Token: 0x04000333 RID: 819
		private static readonly string FIELD_ENTITYID = "@entity-id";

		// Token: 0x04000334 RID: 820
		private static readonly string FIELD_STATID = "@stat-id";

		// Token: 0x04000335 RID: 821
		private static readonly string FIELD_FLOATVALUE = "@float-value";

		// Token: 0x04000336 RID: 822
		private static readonly string FIELD_TEXTVALUE = "@text-value";

		// Token: 0x04000337 RID: 823
		private static readonly string FIELD_USER = "user";

		// Token: 0x04000338 RID: 824
		private static readonly string FIELD_USERID = "@user-id";

		// Token: 0x04000339 RID: 825
		private static readonly string FIELD_TEAMID = "@team-id";

		// Token: 0x0400033A RID: 826
		private static readonly string FIELD_PLACE = "@place";

		// Token: 0x0400033B RID: 827
		private static readonly string FIELD_NICK = "@nick";

		// Token: 0x0400033C RID: 828
		private static readonly string FIELD_RANKSCORE = "@rank-score";

		// Token: 0x0200009E RID: 158
		[Serializable]
		public struct Stat
		{
			// Token: 0x170001C2 RID: 450
			// (get) Token: 0x0600067D RID: 1661 RVA: 0x00006231 File Offset: 0x00004431
			// (set) Token: 0x0600067E RID: 1662 RVA: 0x00006239 File Offset: 0x00004439
			public GameSessionStatEntityType EntityType { get; set; }

			// Token: 0x170001C3 RID: 451
			// (get) Token: 0x0600067F RID: 1663 RVA: 0x00006242 File Offset: 0x00004442
			// (set) Token: 0x06000680 RID: 1664 RVA: 0x0000624A File Offset: 0x0000444A
			public long EntityId { get; set; }

			// Token: 0x170001C4 RID: 452
			// (get) Token: 0x06000681 RID: 1665 RVA: 0x00006253 File Offset: 0x00004453
			// (set) Token: 0x06000682 RID: 1666 RVA: 0x0000625B File Offset: 0x0000445B
			public byte StatId { get; set; }

			// Token: 0x170001C5 RID: 453
			// (get) Token: 0x06000683 RID: 1667 RVA: 0x00006264 File Offset: 0x00004464
			// (set) Token: 0x06000684 RID: 1668 RVA: 0x0000626C File Offset: 0x0000446C
			public decimal FloatValue { get; set; }

			// Token: 0x170001C6 RID: 454
			// (get) Token: 0x06000685 RID: 1669 RVA: 0x00006275 File Offset: 0x00004475
			// (set) Token: 0x06000686 RID: 1670 RVA: 0x0000627D File Offset: 0x0000447D
			public string TextValue { get; set; }
		}

		// Token: 0x0200009F RID: 159
		[Serializable]
		public struct User
		{
			// Token: 0x170001C7 RID: 455
			// (get) Token: 0x06000687 RID: 1671 RVA: 0x00006286 File Offset: 0x00004486
			// (set) Token: 0x06000688 RID: 1672 RVA: 0x0000628E File Offset: 0x0000448E
			public long UserId { get; set; }

			// Token: 0x170001C8 RID: 456
			// (get) Token: 0x06000689 RID: 1673 RVA: 0x00006297 File Offset: 0x00004497
			// (set) Token: 0x0600068A RID: 1674 RVA: 0x0000629F File Offset: 0x0000449F
			public byte TeamId { get; set; }

			// Token: 0x170001C9 RID: 457
			// (get) Token: 0x0600068B RID: 1675 RVA: 0x000062A8 File Offset: 0x000044A8
			// (set) Token: 0x0600068C RID: 1676 RVA: 0x000062B0 File Offset: 0x000044B0
			public int Place { get; set; }

			// Token: 0x170001CA RID: 458
			// (get) Token: 0x0600068D RID: 1677 RVA: 0x000062B9 File Offset: 0x000044B9
			// (set) Token: 0x0600068E RID: 1678 RVA: 0x000062C1 File Offset: 0x000044C1
			public string Nick { get; set; }

			// Token: 0x170001CB RID: 459
			// (get) Token: 0x0600068F RID: 1679 RVA: 0x000062CA File Offset: 0x000044CA
			// (set) Token: 0x06000690 RID: 1680 RVA: 0x000062D2 File Offset: 0x000044D2
			[XmlIgnore]
			internal int RankScore { get; set; }

			// Token: 0x06000691 RID: 1681 RVA: 0x000062DB File Offset: 0x000044DB
			public User(long userId, byte teamId)
			{
				this.Place = 0;
				this.UserId = userId;
				this.TeamId = teamId;
				this.Nick = string.Empty;
				this.RankScore = 0;
			}
		}
	}
}
