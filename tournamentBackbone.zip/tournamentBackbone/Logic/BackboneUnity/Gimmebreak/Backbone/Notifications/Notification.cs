﻿using System;
using System.Xml.Serialization;

namespace Gimmebreak.Backbone.Notifications
{
	// Token: 0x0200004D RID: 77
	[Serializable]
	public class Notification
	{
		// Token: 0x1700010E RID: 270
		// (get) Token: 0x06000341 RID: 833 RVA: 0x000046DE File Offset: 0x000028DE
		// (set) Token: 0x06000342 RID: 834 RVA: 0x000046E6 File Offset: 0x000028E6
		public long Id { get; set; }

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x06000343 RID: 835 RVA: 0x000046EF File Offset: 0x000028EF
		// (set) Token: 0x06000344 RID: 836 RVA: 0x000046F7 File Offset: 0x000028F7
		public NotificationType Type { get; set; }

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x06000345 RID: 837 RVA: 0x00004700 File Offset: 0x00002900
		// (set) Token: 0x06000346 RID: 838 RVA: 0x00004708 File Offset: 0x00002908
		public string Message { get; set; }

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x06000347 RID: 839 RVA: 0x00004711 File Offset: 0x00002911
		// (set) Token: 0x06000348 RID: 840 RVA: 0x00004719 File Offset: 0x00002919
		public bool IsDismissed { get; set; }

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000349 RID: 841 RVA: 0x00004722 File Offset: 0x00002922
		// (set) Token: 0x0600034A RID: 842 RVA: 0x0000472A File Offset: 0x0000292A
		public DateTime Created { get; set; }

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x0600034B RID: 843 RVA: 0x00004733 File Offset: 0x00002933
		// (set) Token: 0x0600034C RID: 844 RVA: 0x0000473B File Offset: 0x0000293B
		public long GroupId { get; set; }

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x0600034D RID: 845 RVA: 0x00004744 File Offset: 0x00002944
		// (set) Token: 0x0600034E RID: 846 RVA: 0x0000474C File Offset: 0x0000294C
		[XmlIgnore]
		public bool Processing { get; internal set; }

		// Token: 0x0600034F RID: 847 RVA: 0x000137B8 File Offset: 0x000119B8
		internal void CopyTo(Notification notification)
		{
			notification.Id = this.Id;
			notification.Type = this.Type;
			notification.Message = this.Message;
			notification.IsDismissed = this.IsDismissed;
			notification.Created = this.Created;
			notification.GroupId = this.GroupId;
			notification.Processing = this.Processing;
		}

		// Token: 0x06000350 RID: 848 RVA: 0x00004755 File Offset: 0x00002955
		internal virtual void DismissNotification()
		{
			this.IsDismissed = true;
		}
	}
}
