﻿using System;
using Gimmebreak.Backbone.Core.JSON;
using UnityEngine;

namespace Gimmebreak.Backbone.Notifications
{
	// Token: 0x0200004C RID: 76
	public class NewsNotification : Notification
	{
		// Token: 0x17000106 RID: 262
		// (get) Token: 0x0600032E RID: 814 RVA: 0x0000461F File Offset: 0x0000281F
		// (set) Token: 0x0600032F RID: 815 RVA: 0x00004627 File Offset: 0x00002827
		public Color TitleColor { get; private set; }

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x06000330 RID: 816 RVA: 0x00004630 File Offset: 0x00002830
		// (set) Token: 0x06000331 RID: 817 RVA: 0x00004638 File Offset: 0x00002838
		public string Title { get; private set; }

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x06000332 RID: 818 RVA: 0x00004641 File Offset: 0x00002841
		// (set) Token: 0x06000333 RID: 819 RVA: 0x00004649 File Offset: 0x00002849
		public string SubTitle { get; private set; }

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x06000334 RID: 820 RVA: 0x00004652 File Offset: 0x00002852
		// (set) Token: 0x06000335 RID: 821 RVA: 0x0000465A File Offset: 0x0000285A
		public string Text { get; private set; }

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x06000336 RID: 822 RVA: 0x00004663 File Offset: 0x00002863
		// (set) Token: 0x06000337 RID: 823 RVA: 0x0000466B File Offset: 0x0000286B
		public string ImageUrl { get; private set; }

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x06000338 RID: 824 RVA: 0x00004674 File Offset: 0x00002874
		// (set) Token: 0x06000339 RID: 825 RVA: 0x0000467C File Offset: 0x0000287C
		public NewsNotification.ActionType Action { get; private set; }

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x0600033A RID: 826 RVA: 0x00004685 File Offset: 0x00002885
		// (set) Token: 0x0600033B RID: 827 RVA: 0x0000468D File Offset: 0x0000288D
		public string ActionText { get; private set; }

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x0600033C RID: 828 RVA: 0x00004696 File Offset: 0x00002896
		// (set) Token: 0x0600033D RID: 829 RVA: 0x0000469E File Offset: 0x0000289E
		public string ActionUrl { get; private set; }

		// Token: 0x0600033E RID: 830 RVA: 0x000046A7 File Offset: 0x000028A7
		public NewsNotification(Notification notification)
		{
			this.notification = notification;
			notification.CopyTo(this);
			this.Initialize();
		}

		// Token: 0x0600033F RID: 831 RVA: 0x000046C7 File Offset: 0x000028C7
		internal override void DismissNotification()
		{
			this.notification.DismissNotification();
			base.IsDismissed = true;
		}

		// Token: 0x06000340 RID: 832 RVA: 0x00013674 File Offset: 0x00011874
		private void Initialize()
		{
			this.jsonData = new JSONObject(this.notification.Message, -2, false, false);
			Color titleColor;
			ColorUtility.TryParseHtmlString(this.jsonData["titlecolor"].str, ref titleColor);
			this.Title = this.jsonData["title"].str;
			this.SubTitle = this.jsonData["subtitle"].str;
			this.Text = this.jsonData["text"].str;
			this.ImageUrl = this.jsonData["image"].str;
			this.Action = (Enum.IsDefined(typeof(NewsNotification.ActionType), (int)this.jsonData["buttontype"].n) ? ((NewsNotification.ActionType)this.jsonData["buttontype"].n) : NewsNotification.ActionType.Unkown);
			this.ActionText = this.jsonData["buttontext"].str;
			this.ActionUrl = this.jsonData["buttonurl"].str;
			this.TitleColor = titleColor;
		}

		// Token: 0x0400030B RID: 779
		private Notification notification;

		// Token: 0x0400030C RID: 780
		private JSONObject jsonData;

		// Token: 0x0200009D RID: 157
		public enum ActionType
		{
			// Token: 0x0400047D RID: 1149
			Unkown,
			// Token: 0x0400047E RID: 1150
			ExternalLink,
			// Token: 0x0400047F RID: 1151
			RegisterTournament,
			// Token: 0x04000480 RID: 1152
			Store,
			// Token: 0x04000481 RID: 1153
			StoreOffer
		}
	}
}
