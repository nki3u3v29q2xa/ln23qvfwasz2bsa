﻿using System;

namespace Gimmebreak.Backbone.Notifications
{
	// Token: 0x0200004E RID: 78
	public enum NotificationType
	{
		// Token: 0x0400031D RID: 797
		Unknown,
		// Token: 0x0400031E RID: 798
		News = 2,
		// Token: 0x0400031F RID: 799
		TournamentPartyInvite = 5,
		// Token: 0x04000320 RID: 800
		FriendRequest = 1,
		// Token: 0x04000321 RID: 801
		NewInventory = 4
	}
}
