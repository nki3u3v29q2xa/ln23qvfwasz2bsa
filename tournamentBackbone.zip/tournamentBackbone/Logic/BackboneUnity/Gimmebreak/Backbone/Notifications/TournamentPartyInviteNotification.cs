﻿using System;

namespace Gimmebreak.Backbone.Notifications
{
	// Token: 0x02000050 RID: 80
	public class TournamentPartyInviteNotification : Notification
	{
		// Token: 0x17000117 RID: 279
		// (get) Token: 0x0600035A RID: 858 RVA: 0x00013B58 File Offset: 0x00011D58
		public long TournamentId
		{
			get
			{
				return base.GroupId;
			}
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x0600035B RID: 859 RVA: 0x00013B70 File Offset: 0x00011D70
		public long PartyInviteId
		{
			get
			{
				return base.Id;
			}
		}

		// Token: 0x0600035C RID: 860 RVA: 0x000047B8 File Offset: 0x000029B8
		public TournamentPartyInviteNotification(Notification notification)
		{
			this.notification = notification;
			notification.CopyTo(this);
			this.Initialize();
		}

		// Token: 0x0600035D RID: 861 RVA: 0x000047D8 File Offset: 0x000029D8
		internal override void DismissNotification()
		{
			this.notification.DismissNotification();
			base.IsDismissed = true;
		}

		// Token: 0x0600035E RID: 862 RVA: 0x000047EF File Offset: 0x000029EF
		private void Initialize()
		{
		}

		// Token: 0x04000325 RID: 805
		private Notification notification;
	}
}
