﻿using System;
using System.Collections.Generic;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Notifications
{
	// Token: 0x0200004F RID: 79
	[Serializable]
	public class NotificationData
	{
		// Token: 0x17000115 RID: 277
		// (get) Token: 0x06000352 RID: 850 RVA: 0x00004769 File Offset: 0x00002969
		// (set) Token: 0x06000353 RID: 851 RVA: 0x00004771 File Offset: 0x00002971
		public List<Notification> NotificationList { get; set; }

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x06000354 RID: 852 RVA: 0x0000477A File Offset: 0x0000297A
		// (set) Token: 0x06000355 RID: 853 RVA: 0x00004782 File Offset: 0x00002982
		public DateTime LastNotificationUpdate { get; set; }

		// Token: 0x06000356 RID: 854 RVA: 0x0000478B File Offset: 0x0000298B
		public NotificationData()
		{
			this.NotificationList = new List<Notification>();
			this.LastNotificationUpdate = DateTime.MinValue;
			this.notificationsByType = new Dictionary<int, List<Notification>>();
		}

		// Token: 0x06000357 RID: 855 RVA: 0x00013824 File Offset: 0x00011A24
		private void SortNotifications()
		{
			foreach (KeyValuePair<int, List<Notification>> keyValuePair in this.notificationsByType)
			{
				keyValuePair.Value.Clear();
			}
			int i = 0;
			while (i < this.NotificationList.Count)
			{
				Notification notification = this.NotificationList[i];
				bool flag = !this.notificationsByType.ContainsKey((int)notification.Type);
				if (flag)
				{
					this.notificationsByType.Add((int)notification.Type, new List<Notification>());
				}
				switch (notification.Type)
				{
				case NotificationType.FriendRequest:
				case (NotificationType)3:
					goto IL_10D;
				case NotificationType.News:
					this.notificationsByType[(int)notification.Type].Add(new NewsNotification(notification));
					break;
				case NotificationType.NewInventory:
					this.notificationsByType[(int)notification.Type].Add(new NewInventoryNotification(notification));
					break;
				case NotificationType.TournamentPartyInvite:
					this.notificationsByType[(int)notification.Type].Add(new TournamentPartyInviteNotification(notification));
					break;
				default:
					goto IL_10D;
				}
				IL_127:
				i++;
				continue;
				IL_10D:
				this.notificationsByType[(int)notification.Type].Add(notification);
				goto IL_127;
			}
		}

		// Token: 0x06000358 RID: 856 RVA: 0x00013984 File Offset: 0x00011B84
		public List<Notification> GetNotificationByType(NotificationType type)
		{
			bool flag = this.notificationsByType.Count == 0 && this.NotificationList.Count > 0;
			if (flag)
			{
				this.SortNotifications();
			}
			bool flag2 = !this.notificationsByType.ContainsKey((int)type);
			if (flag2)
			{
				this.notificationsByType.Add((int)type, new List<Notification>());
			}
			return this.notificationsByType[(int)type];
		}

		// Token: 0x06000359 RID: 857 RVA: 0x000139F4 File Offset: 0x00011BF4
		internal void LoadJsonNotifications(JSONObject data)
		{
			bool flag = data != null && data.IsArray;
			if (flag)
			{
				this.NotificationList.Clear();
				for (int i = 0; i < data.list.Count; i++)
				{
					JSONObject jsonobject = data.list[i];
					bool flag2 = Enum.IsDefined(typeof(NotificationType), (int)jsonobject["type"].n);
					if (flag2)
					{
						long num = 0L;
						long groupId = 0L;
						long.TryParse(jsonobject["groupId"].str, out groupId);
						bool flag3 = long.TryParse(jsonobject["id"].str, out num) && num > 0L;
						if (flag3)
						{
							this.NotificationList.Add(new Notification
							{
								Id = num,
								GroupId = groupId,
								Type = (NotificationType)jsonobject["type"].n,
								Message = jsonobject["message"].str,
								IsDismissed = jsonobject["isDismissed"].b,
								Created = jsonobject["created"].ToUniversalTime()
							});
						}
					}
				}
				this.SortNotifications();
			}
		}

		// Token: 0x04000322 RID: 802
		private Dictionary<int, List<Notification>> notificationsByType;
	}
}
