﻿using System;
using System.Collections.Generic;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Notifications
{
	// Token: 0x0200004B RID: 75
	public class NewInventoryNotification : Notification
	{
		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000329 RID: 809 RVA: 0x000045D7 File Offset: 0x000027D7
		// (set) Token: 0x0600032A RID: 810 RVA: 0x000045DF File Offset: 0x000027DF
		public List<string> StoreIds { get; private set; }

		// Token: 0x0600032B RID: 811 RVA: 0x000045E8 File Offset: 0x000027E8
		public NewInventoryNotification(Notification notification)
		{
			this.notification = notification;
			notification.CopyTo(this);
			this.Initialize();
		}

		// Token: 0x0600032C RID: 812 RVA: 0x00004608 File Offset: 0x00002808
		internal override void DismissNotification()
		{
			this.notification.DismissNotification();
			base.IsDismissed = true;
		}

		// Token: 0x0600032D RID: 813 RVA: 0x000135C8 File Offset: 0x000117C8
		private void Initialize()
		{
			this.StoreIds = new List<string>();
			this.jsonData = new JSONObject(this.notification.Message, -2, false, false);
			bool flag = this.jsonData.HasField("ids") && this.jsonData["ids"].IsArray;
			if (flag)
			{
				List<JSONObject> list = this.jsonData["ids"].list;
				for (int i = 0; i < list.Count; i++)
				{
					this.StoreIds.Add(list[i].str);
				}
			}
		}

		// Token: 0x04000308 RID: 776
		private Notification notification;

		// Token: 0x04000309 RID: 777
		private JSONObject jsonData;
	}
}
