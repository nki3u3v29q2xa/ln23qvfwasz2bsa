﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core;
using Gimmebreak.Backbone.Core.JSON;
using Gimmebreak.Backbone.GameSessions;
using Gimmebreak.Backbone.Tournaments;

namespace Gimmebreak.Backbone.Season
{
	// Token: 0x0200004A RID: 74
	[Serializable]
	public class UserSeasonProfile
	{
		// Token: 0x170000FA RID: 250
		// (get) Token: 0x06000310 RID: 784 RVA: 0x0000451C File Offset: 0x0000271C
		// (set) Token: 0x06000311 RID: 785 RVA: 0x00004524 File Offset: 0x00002724
		public long UserId { get; set; }

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x06000312 RID: 786 RVA: 0x0000452D File Offset: 0x0000272D
		// (set) Token: 0x06000313 RID: 787 RVA: 0x00004535 File Offset: 0x00002735
		public int Season { get; set; }

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x06000314 RID: 788 RVA: 0x0000453E File Offset: 0x0000273E
		// (set) Token: 0x06000315 RID: 789 RVA: 0x00004546 File Offset: 0x00002746
		public List<UserSeasonProfile.GameSessionCount> GameSessionTypeCountStats { get; set; }

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x06000316 RID: 790 RVA: 0x0000454F File Offset: 0x0000274F
		// (set) Token: 0x06000317 RID: 791 RVA: 0x00004557 File Offset: 0x00002757
		public List<UserSeasonProfile.ValueStat> GameSessionValueStats { get; set; }

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x06000318 RID: 792 RVA: 0x00004560 File Offset: 0x00002760
		// (set) Token: 0x06000319 RID: 793 RVA: 0x00004568 File Offset: 0x00002768
		public List<UserSeasonProfile.CounterStat> GameSessionCounterStats { get; set; }

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x0600031A RID: 794 RVA: 0x00004571 File Offset: 0x00002771
		// (set) Token: 0x0600031B RID: 795 RVA: 0x00004579 File Offset: 0x00002779
		public int TournamentsPlayedCount { get; set; }

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x0600031C RID: 796 RVA: 0x00004582 File Offset: 0x00002782
		// (set) Token: 0x0600031D RID: 797 RVA: 0x0000458A File Offset: 0x0000278A
		public int TournamentsWinCount { get; set; }

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x0600031E RID: 798 RVA: 0x00004593 File Offset: 0x00002793
		// (set) Token: 0x0600031F RID: 799 RVA: 0x0000459B File Offset: 0x0000279B
		public List<UserSeasonProfile.PrizeItem> TournamentWinnings { get; set; }

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000320 RID: 800 RVA: 0x000045A4 File Offset: 0x000027A4
		// (set) Token: 0x06000321 RID: 801 RVA: 0x000045AC File Offset: 0x000027AC
		public SerializableDictionary<string, string> Properties { get; set; }

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x06000322 RID: 802 RVA: 0x000045B5 File Offset: 0x000027B5
		// (set) Token: 0x06000323 RID: 803 RVA: 0x000045BD File Offset: 0x000027BD
		public List<GameSession> LastGameSessions { get; set; }

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x06000324 RID: 804 RVA: 0x000045C6 File Offset: 0x000027C6
		// (set) Token: 0x06000325 RID: 805 RVA: 0x000045CE File Offset: 0x000027CE
		[XmlIgnore]
		internal DateTime LastUpdate { get; set; }

		// Token: 0x06000326 RID: 806 RVA: 0x00012A04 File Offset: 0x00010C04
		public UserSeasonProfile()
		{
			this.GameSessionTypeCountStats = new List<UserSeasonProfile.GameSessionCount>();
			this.GameSessionValueStats = new List<UserSeasonProfile.ValueStat>();
			this.GameSessionCounterStats = new List<UserSeasonProfile.CounterStat>();
			this.TournamentWinnings = new List<UserSeasonProfile.PrizeItem>();
			this.Properties = new SerializableDictionary<string, string>();
			this.LastGameSessions = new List<GameSession>();
			this.LastUpdate = DateTime.MinValue;
		}

		// Token: 0x06000327 RID: 807 RVA: 0x00012A70 File Offset: 0x00010C70
		internal void LoadJSONUserSeasonProfile(JSONObject data)
		{
			bool flag = data != null && data.isContainer && data.HasField(UserSeasonProfile.FIELD_STATS) && !data[UserSeasonProfile.FIELD_STATS].IsNull;
			if (flag)
			{
				bool flag2 = data[UserSeasonProfile.FIELD_STATS].HasField(UserSeasonProfile.FIELD_USERPROFILE) && !data[UserSeasonProfile.FIELD_STATS][UserSeasonProfile.FIELD_USERPROFILE].IsNull;
				if (flag2)
				{
					JSONObject jsonobject = data[UserSeasonProfile.FIELD_STATS][UserSeasonProfile.FIELD_USERPROFILE];
					bool flag3 = jsonobject.HasField(UserSeasonProfile.FIELD_GAMESESSIONSTATS);
					if (flag3)
					{
						this.GameSessionTypeCountStats.Clear();
						this.GameSessionValueStats.Clear();
						this.GameSessionCounterStats.Clear();
						JSONObject jsonobject2 = jsonobject[UserSeasonProfile.FIELD_GAMESESSIONSTATS][0];
						bool flag4 = jsonobject2.HasField(UserSeasonProfile.FIELD_GAMESESSIONCOUNT) && jsonobject2[UserSeasonProfile.FIELD_GAMESESSIONCOUNT][0].HasField(UserSeasonProfile.FIELD_RECORD);
						if (flag4)
						{
							List<JSONObject> list = jsonobject2[UserSeasonProfile.FIELD_GAMESESSIONCOUNT][0][UserSeasonProfile.FIELD_RECORD].list;
							for (int i = 0; i < list.Count; i++)
							{
								JSONObject jsonobject3 = list[i];
								this.GameSessionTypeCountStats.Add(new UserSeasonProfile.GameSessionCount
								{
									SessionType = byte.Parse(jsonobject3[UserSeasonProfile.FIELD_TYPE].str),
									TotalGames = int.Parse(jsonobject3[UserSeasonProfile.FIELD_TOTALGAMES].str),
									Wins = int.Parse(jsonobject3[UserSeasonProfile.FIELD_WINS].str)
								});
							}
						}
						bool flag5 = jsonobject2.HasField(UserSeasonProfile.FIELD_VALUESTATS) && jsonobject2[UserSeasonProfile.FIELD_VALUESTATS][0].HasField(UserSeasonProfile.FIELD_RECORD);
						if (flag5)
						{
							List<JSONObject> list2 = jsonobject2[UserSeasonProfile.FIELD_VALUESTATS][0][UserSeasonProfile.FIELD_RECORD].list;
							for (int j = 0; j < list2.Count; j++)
							{
								JSONObject jsonobject4 = list2[j];
								this.GameSessionValueStats.Add(new UserSeasonProfile.ValueStat
								{
									SessionType = byte.Parse(jsonobject4[UserSeasonProfile.FIELD_TYPE].str),
									EntityType = jsonobject4[UserSeasonProfile.FIELD_ENTITYTYPE].ToEnum(GameSessionStatEntityType.Unkown),
									StatId = byte.Parse(jsonobject4[UserSeasonProfile.FIELD_STATID].str),
									Total = int.Parse(jsonobject4[UserSeasonProfile.FIELD_TOTAL].str),
									Wins = int.Parse(jsonobject4[UserSeasonProfile.FIELD_WINS].str),
									Avg = float.Parse(jsonobject4[UserSeasonProfile.FIELD_AVG].str, NumberStyles.Float, CultureInfo.InvariantCulture),
									Max = float.Parse(jsonobject4[UserSeasonProfile.FIELD_MAX].str, NumberStyles.Float, CultureInfo.InvariantCulture),
									Min = float.Parse(jsonobject4[UserSeasonProfile.FIELD_MIN].str, NumberStyles.Float, CultureInfo.InvariantCulture),
									Sum = float.Parse(jsonobject4[UserSeasonProfile.FIELD_SUM].str, NumberStyles.Float, CultureInfo.InvariantCulture)
								});
							}
						}
						bool flag6 = jsonobject2.HasField(UserSeasonProfile.FIELD_COUNTERSTATS) && jsonobject2[UserSeasonProfile.FIELD_COUNTERSTATS][0].HasField(UserSeasonProfile.FIELD_RECORD);
						if (flag6)
						{
							List<JSONObject> list3 = jsonobject2[UserSeasonProfile.FIELD_COUNTERSTATS][0][UserSeasonProfile.FIELD_RECORD].list;
							for (int k = 0; k < list3.Count; k++)
							{
								JSONObject jsonobject5 = list3[k];
								this.GameSessionCounterStats.Add(new UserSeasonProfile.CounterStat
								{
									SessionType = byte.Parse(jsonobject5[UserSeasonProfile.FIELD_TYPE].str),
									EntityType = jsonobject5[UserSeasonProfile.FIELD_ENTITYTYPE].ToEnum(GameSessionStatEntityType.Unkown),
									StatId = byte.Parse(jsonobject5[UserSeasonProfile.FIELD_STATID].str),
									Total = int.Parse(jsonobject5[UserSeasonProfile.FIELD_TOTAL].str),
									Wins = int.Parse(jsonobject5[UserSeasonProfile.FIELD_WINS].str),
									FloatValue = (jsonobject5.HasField(UserSeasonProfile.FIELD_FLOATVALUE) ? float.Parse(jsonobject5[UserSeasonProfile.FIELD_FLOATVALUE].str, NumberStyles.Float, CultureInfo.InvariantCulture) : 0f),
									TextValue = (jsonobject5.HasField(UserSeasonProfile.FIELD_TEXTVALUE) ? jsonobject5[UserSeasonProfile.FIELD_TEXTVALUE].str : string.Empty)
								});
							}
						}
						this.TournamentsPlayedCount = 0;
						this.TournamentsWinCount = 0;
						JSONObject jsonobject6 = jsonobject[UserSeasonProfile.FIELD_TOURNAMENTSTATS][0];
						bool flag7 = jsonobject6.HasField(UserSeasonProfile.FIELD_STATS);
						if (flag7)
						{
							JSONObject jsonobject7 = jsonobject6[UserSeasonProfile.FIELD_STATS][0];
							this.TournamentsPlayedCount = int.Parse(jsonobject7[UserSeasonProfile.FIELD_TOURNAMENTPLAYED].str);
							this.TournamentsWinCount = int.Parse(jsonobject7[UserSeasonProfile.FIELD_TOURNAMENTWINS].str);
						}
						this.TournamentWinnings.Clear();
						bool flag8 = jsonobject6.HasField(UserSeasonProfile.FIELD_WINNINGS) && jsonobject6[UserSeasonProfile.FIELD_WINNINGS][0].HasField(UserSeasonProfile.FIELD_RECORD);
						if (flag8)
						{
							List<JSONObject> list4 = jsonobject6[UserSeasonProfile.FIELD_WINNINGS][0][UserSeasonProfile.FIELD_RECORD].list;
							for (int l = 0; l < list4.Count; l++)
							{
								JSONObject jsonobject8 = list4[l];
								this.TournamentWinnings.Add(new UserSeasonProfile.PrizeItem
								{
									ItemType = jsonobject8[UserSeasonProfile.FIELD_ITEMTYPE].ToEnum(TournamentItemType.Unkown),
									ItemId = long.Parse(jsonobject8[UserSeasonProfile.FIELD_ITEMID].str),
									ItemExternalId = (jsonobject8.HasField(UserSeasonProfile.FIELD_ITEMEXTERNALID) ? jsonobject8[UserSeasonProfile.FIELD_ITEMEXTERNALID].str : null),
									Amount = int.Parse(jsonobject8[UserSeasonProfile.FIELD_AMOUNT].str)
								});
							}
						}
						this.Properties.Clear();
						JSONObject jsonobject9 = jsonobject[UserSeasonProfile.FIELD_USER][0];
						bool flag9 = jsonobject9.HasField(UserSeasonProfile.FIELD_USERDATA);
						if (flag9)
						{
							JSONObject jsonobject10 = jsonobject9[UserSeasonProfile.FIELD_USERDATA][0];
							bool flag10 = jsonobject10.HasField(UserSeasonProfile.FIELD_PROPERTIES) && jsonobject10[UserSeasonProfile.FIELD_PROPERTIES][0].HasField(UserSeasonProfile.FIELD_PROPERTY);
							if (flag10)
							{
								JSONObject jsonobject11 = jsonobject10[UserSeasonProfile.FIELD_PROPERTIES][0][UserSeasonProfile.FIELD_PROPERTY];
								bool flag11 = !jsonobject11.IsNull && jsonobject11.IsArray && jsonobject11.Count > 0;
								if (flag11)
								{
									List<JSONObject> list5 = jsonobject11.list;
									for (int m = 0; m < list5.Count; m++)
									{
										string str = list5[m][UserSeasonProfile.FIELD_NAME][0][UserSeasonProfile.FIELD_TEXT][0][UserSeasonProfile.FIELD_VALUE].str;
										bool flag12 = !this.Properties.ContainsKey(str);
										if (flag12)
										{
											string str2 = list5[m][UserSeasonProfile.FIELD_VALUE][0][UserSeasonProfile.FIELD_TEXT][0][UserSeasonProfile.FIELD_VALUE].str;
											this.Properties.Add(str, str2);
										}
									}
								}
							}
						}
						bool flag13 = jsonobject.HasField(UserSeasonProfile.FIELD_LASTGAMESESSIONS) && jsonobject[UserSeasonProfile.FIELD_LASTGAMESESSIONS][0].HasField(UserSeasonProfile.FIELD_GAMESESSION);
						if (flag13)
						{
							JSONObject jsonobject12 = jsonobject[UserSeasonProfile.FIELD_LASTGAMESESSIONS][0];
							Dictionary<long, GameSession> dictionary = new Dictionary<long, GameSession>();
							for (int n = 0; n < this.LastGameSessions.Count; n++)
							{
								dictionary.Add(this.LastGameSessions[n].Id, this.LastGameSessions[n]);
							}
							this.LastGameSessions.Clear();
							List<JSONObject> list6 = jsonobject12[UserSeasonProfile.FIELD_GAMESESSION].list;
							for (int num = 0; num < list6.Count; num++)
							{
								JSONObject jsonobject13 = list6[num];
								bool flag14 = jsonobject13.HasField(GameSession.FIELD_ID);
								if (flag14)
								{
									long key = long.Parse(jsonobject13[GameSession.FIELD_ID].str);
									GameSession gameSession;
									bool flag15 = !dictionary.TryGetValue(key, out gameSession);
									if (flag15)
									{
										gameSession = new GameSession();
									}
									gameSession.LoadJSONGameSession(jsonobject13);
									this.LastGameSessions.Add(gameSession);
								}
							}
							dictionary.Clear();
						}
					}
				}
			}
		}

		// Token: 0x040002D9 RID: 729
		internal static readonly string FIELD_STATS = "stats";

		// Token: 0x040002DA RID: 730
		private static readonly string FIELD_USERPROFILE = "user-profile";

		// Token: 0x040002DB RID: 731
		private static readonly string FIELD_GAMESESSIONSTATS = "game-session-stats";

		// Token: 0x040002DC RID: 732
		private static readonly string FIELD_GAMESESSIONCOUNT = "game-session-count";

		// Token: 0x040002DD RID: 733
		private static readonly string FIELD_RECORD = "record";

		// Token: 0x040002DE RID: 734
		private static readonly string FIELD_TYPE = "@type";

		// Token: 0x040002DF RID: 735
		private static readonly string FIELD_TOTALGAMES = "@total-games";

		// Token: 0x040002E0 RID: 736
		private static readonly string FIELD_WINS = "@wins";

		// Token: 0x040002E1 RID: 737
		private static readonly string FIELD_VALUESTATS = "value-stats";

		// Token: 0x040002E2 RID: 738
		private static readonly string FIELD_ENTITYTYPE = "@entity-type";

		// Token: 0x040002E3 RID: 739
		private static readonly string FIELD_STATID = "@stat-id";

		// Token: 0x040002E4 RID: 740
		private static readonly string FIELD_TOTAL = "@total";

		// Token: 0x040002E5 RID: 741
		private static readonly string FIELD_AVG = "@avg";

		// Token: 0x040002E6 RID: 742
		private static readonly string FIELD_MAX = "@max";

		// Token: 0x040002E7 RID: 743
		private static readonly string FIELD_MIN = "@min";

		// Token: 0x040002E8 RID: 744
		private static readonly string FIELD_SUM = "@sum";

		// Token: 0x040002E9 RID: 745
		private static readonly string FIELD_COUNTERSTATS = "counter-stats";

		// Token: 0x040002EA RID: 746
		private static readonly string FIELD_FLOATVALUE = "@float-value";

		// Token: 0x040002EB RID: 747
		private static readonly string FIELD_TEXTVALUE = "@text-value";

		// Token: 0x040002EC RID: 748
		private static readonly string FIELD_TOURNAMENTSTATS = "tournament-stats";

		// Token: 0x040002ED RID: 749
		private static readonly string FIELD_TOURNAMENTPLAYED = "@tournament-played";

		// Token: 0x040002EE RID: 750
		private static readonly string FIELD_TOURNAMENTWINS = "@tournament-wins";

		// Token: 0x040002EF RID: 751
		private static readonly string FIELD_WINNINGS = "winnings";

		// Token: 0x040002F0 RID: 752
		private static readonly string FIELD_ITEMTYPE = "@item-type";

		// Token: 0x040002F1 RID: 753
		private static readonly string FIELD_ITEMID = "@item-id";

		// Token: 0x040002F2 RID: 754
		private static readonly string FIELD_ITEMEXTERNALID = "@item-external-id";

		// Token: 0x040002F3 RID: 755
		private static readonly string FIELD_AMOUNT = "@amount";

		// Token: 0x040002F4 RID: 756
		private static readonly string FIELD_USER = "user";

		// Token: 0x040002F5 RID: 757
		private static readonly string FIELD_USERDATA = "user-data";

		// Token: 0x040002F6 RID: 758
		private static readonly string FIELD_PROPERTIES = "properties";

		// Token: 0x040002F7 RID: 759
		private static readonly string FIELD_PROPERTY = "property";

		// Token: 0x040002F8 RID: 760
		private static readonly string FIELD_NAME = "name";

		// Token: 0x040002F9 RID: 761
		private static readonly string FIELD_TEXT = "#text";

		// Token: 0x040002FA RID: 762
		private static readonly string FIELD_VALUE = "value";

		// Token: 0x040002FB RID: 763
		private static readonly string FIELD_LASTGAMESESSIONS = "last-game-sessions";

		// Token: 0x040002FC RID: 764
		private static readonly string FIELD_GAMESESSION = "game-session";

		// Token: 0x02000099 RID: 153
		public struct GameSessionCount
		{
			// Token: 0x170001AB RID: 427
			// (get) Token: 0x0600064F RID: 1615 RVA: 0x000060AA File Offset: 0x000042AA
			// (set) Token: 0x06000650 RID: 1616 RVA: 0x000060B2 File Offset: 0x000042B2
			public byte SessionType { get; set; }

			// Token: 0x170001AC RID: 428
			// (get) Token: 0x06000651 RID: 1617 RVA: 0x000060BB File Offset: 0x000042BB
			// (set) Token: 0x06000652 RID: 1618 RVA: 0x000060C3 File Offset: 0x000042C3
			public int TotalGames { get; set; }

			// Token: 0x170001AD RID: 429
			// (get) Token: 0x06000653 RID: 1619 RVA: 0x000060CC File Offset: 0x000042CC
			// (set) Token: 0x06000654 RID: 1620 RVA: 0x000060D4 File Offset: 0x000042D4
			public int Wins { get; set; }
		}

		// Token: 0x0200009A RID: 154
		public struct ValueStat
		{
			// Token: 0x170001AE RID: 430
			// (get) Token: 0x06000655 RID: 1621 RVA: 0x000060DD File Offset: 0x000042DD
			// (set) Token: 0x06000656 RID: 1622 RVA: 0x000060E5 File Offset: 0x000042E5
			public byte SessionType { get; set; }

			// Token: 0x170001AF RID: 431
			// (get) Token: 0x06000657 RID: 1623 RVA: 0x000060EE File Offset: 0x000042EE
			// (set) Token: 0x06000658 RID: 1624 RVA: 0x000060F6 File Offset: 0x000042F6
			public GameSessionStatEntityType EntityType { get; set; }

			// Token: 0x170001B0 RID: 432
			// (get) Token: 0x06000659 RID: 1625 RVA: 0x000060FF File Offset: 0x000042FF
			// (set) Token: 0x0600065A RID: 1626 RVA: 0x00006107 File Offset: 0x00004307
			public byte StatId { get; set; }

			// Token: 0x170001B1 RID: 433
			// (get) Token: 0x0600065B RID: 1627 RVA: 0x00006110 File Offset: 0x00004310
			// (set) Token: 0x0600065C RID: 1628 RVA: 0x00006118 File Offset: 0x00004318
			public int Total { get; set; }

			// Token: 0x170001B2 RID: 434
			// (get) Token: 0x0600065D RID: 1629 RVA: 0x00006121 File Offset: 0x00004321
			// (set) Token: 0x0600065E RID: 1630 RVA: 0x00006129 File Offset: 0x00004329
			public int Wins { get; set; }

			// Token: 0x170001B3 RID: 435
			// (get) Token: 0x0600065F RID: 1631 RVA: 0x00006132 File Offset: 0x00004332
			// (set) Token: 0x06000660 RID: 1632 RVA: 0x0000613A File Offset: 0x0000433A
			public float Avg { get; set; }

			// Token: 0x170001B4 RID: 436
			// (get) Token: 0x06000661 RID: 1633 RVA: 0x00006143 File Offset: 0x00004343
			// (set) Token: 0x06000662 RID: 1634 RVA: 0x0000614B File Offset: 0x0000434B
			public float Max { get; set; }

			// Token: 0x170001B5 RID: 437
			// (get) Token: 0x06000663 RID: 1635 RVA: 0x00006154 File Offset: 0x00004354
			// (set) Token: 0x06000664 RID: 1636 RVA: 0x0000615C File Offset: 0x0000435C
			public float Min { get; set; }

			// Token: 0x170001B6 RID: 438
			// (get) Token: 0x06000665 RID: 1637 RVA: 0x00006165 File Offset: 0x00004365
			// (set) Token: 0x06000666 RID: 1638 RVA: 0x0000616D File Offset: 0x0000436D
			public float Sum { get; set; }
		}

		// Token: 0x0200009B RID: 155
		public struct CounterStat
		{
			// Token: 0x170001B7 RID: 439
			// (get) Token: 0x06000667 RID: 1639 RVA: 0x00006176 File Offset: 0x00004376
			// (set) Token: 0x06000668 RID: 1640 RVA: 0x0000617E File Offset: 0x0000437E
			public byte SessionType { get; set; }

			// Token: 0x170001B8 RID: 440
			// (get) Token: 0x06000669 RID: 1641 RVA: 0x00006187 File Offset: 0x00004387
			// (set) Token: 0x0600066A RID: 1642 RVA: 0x0000618F File Offset: 0x0000438F
			public GameSessionStatEntityType EntityType { get; set; }

			// Token: 0x170001B9 RID: 441
			// (get) Token: 0x0600066B RID: 1643 RVA: 0x00006198 File Offset: 0x00004398
			// (set) Token: 0x0600066C RID: 1644 RVA: 0x000061A0 File Offset: 0x000043A0
			public byte StatId { get; set; }

			// Token: 0x170001BA RID: 442
			// (get) Token: 0x0600066D RID: 1645 RVA: 0x000061A9 File Offset: 0x000043A9
			// (set) Token: 0x0600066E RID: 1646 RVA: 0x000061B1 File Offset: 0x000043B1
			public int Total { get; set; }

			// Token: 0x170001BB RID: 443
			// (get) Token: 0x0600066F RID: 1647 RVA: 0x000061BA File Offset: 0x000043BA
			// (set) Token: 0x06000670 RID: 1648 RVA: 0x000061C2 File Offset: 0x000043C2
			public int Wins { get; set; }

			// Token: 0x170001BC RID: 444
			// (get) Token: 0x06000671 RID: 1649 RVA: 0x000061CB File Offset: 0x000043CB
			// (set) Token: 0x06000672 RID: 1650 RVA: 0x000061D3 File Offset: 0x000043D3
			public float FloatValue { get; set; }

			// Token: 0x170001BD RID: 445
			// (get) Token: 0x06000673 RID: 1651 RVA: 0x000061DC File Offset: 0x000043DC
			// (set) Token: 0x06000674 RID: 1652 RVA: 0x000061E4 File Offset: 0x000043E4
			public string TextValue { get; set; }
		}

		// Token: 0x0200009C RID: 156
		public struct PrizeItem
		{
			// Token: 0x170001BE RID: 446
			// (get) Token: 0x06000675 RID: 1653 RVA: 0x000061ED File Offset: 0x000043ED
			// (set) Token: 0x06000676 RID: 1654 RVA: 0x000061F5 File Offset: 0x000043F5
			public TournamentItemType ItemType { get; set; }

			// Token: 0x170001BF RID: 447
			// (get) Token: 0x06000677 RID: 1655 RVA: 0x000061FE File Offset: 0x000043FE
			// (set) Token: 0x06000678 RID: 1656 RVA: 0x00006206 File Offset: 0x00004406
			public long ItemId { get; set; }

			// Token: 0x170001C0 RID: 448
			// (get) Token: 0x06000679 RID: 1657 RVA: 0x0000620F File Offset: 0x0000440F
			// (set) Token: 0x0600067A RID: 1658 RVA: 0x00006217 File Offset: 0x00004417
			public string ItemExternalId { get; set; }

			// Token: 0x170001C1 RID: 449
			// (get) Token: 0x0600067B RID: 1659 RVA: 0x00006220 File Offset: 0x00004420
			// (set) Token: 0x0600067C RID: 1660 RVA: 0x00006228 File Offset: 0x00004428
			public int Amount { get; set; }
		}
	}
}
