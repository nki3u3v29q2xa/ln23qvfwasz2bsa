﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Season
{
	// Token: 0x02000049 RID: 73
	[Serializable]
	public class SeasonData
	{
		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x060002FC RID: 764 RVA: 0x0000446D File Offset: 0x0000266D
		// (set) Token: 0x060002FD RID: 765 RVA: 0x00004475 File Offset: 0x00002675
		public long SeasonId { get; set; }

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x060002FE RID: 766 RVA: 0x0000447E File Offset: 0x0000267E
		// (set) Token: 0x060002FF RID: 767 RVA: 0x00004486 File Offset: 0x00002686
		public int Season { get; set; }

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000300 RID: 768 RVA: 0x0000448F File Offset: 0x0000268F
		// (set) Token: 0x06000301 RID: 769 RVA: 0x00004497 File Offset: 0x00002697
		public int SeasonDay { get; set; }

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000302 RID: 770 RVA: 0x000044A0 File Offset: 0x000026A0
		// (set) Token: 0x06000303 RID: 771 RVA: 0x000044A8 File Offset: 0x000026A8
		public int SeasonSeed { get; set; }

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000304 RID: 772 RVA: 0x000044B1 File Offset: 0x000026B1
		// (set) Token: 0x06000305 RID: 773 RVA: 0x000044B9 File Offset: 0x000026B9
		public int PreviousSeasonSeed { get; set; }

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000306 RID: 774 RVA: 0x000044C2 File Offset: 0x000026C2
		// (set) Token: 0x06000307 RID: 775 RVA: 0x000044CA File Offset: 0x000026CA
		public DateTime SeasonPartEnd { get; set; }

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x06000308 RID: 776 RVA: 0x000044D3 File Offset: 0x000026D3
		// (set) Token: 0x06000309 RID: 777 RVA: 0x000044DB File Offset: 0x000026DB
		public float SeasonProgress { get; set; }

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x0600030A RID: 778 RVA: 0x000044E4 File Offset: 0x000026E4
		// (set) Token: 0x0600030B RID: 779 RVA: 0x000044EC File Offset: 0x000026EC
		public UserSeasonProfile UserSeasonProfile { get; set; }

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x0600030C RID: 780 RVA: 0x000044F5 File Offset: 0x000026F5
		// (set) Token: 0x0600030D RID: 781 RVA: 0x000044FD File Offset: 0x000026FD
		[XmlIgnore]
		internal Dictionary<long, UserSeasonProfile> UserSeasonProfiles { get; set; }

		// Token: 0x0600030E RID: 782 RVA: 0x00004506 File Offset: 0x00002706
		public SeasonData()
		{
			this.UserSeasonProfiles = new Dictionary<long, UserSeasonProfile>();
		}

		// Token: 0x0600030F RID: 783 RVA: 0x00012930 File Offset: 0x00010B30
		internal void LoadJsonSeason(JSONObject data)
		{
			this.SeasonId = long.Parse(data["seasonid"].str);
			this.Season = (int)data["season"].i;
			this.SeasonDay = (int)data["seasonday"].i;
			int num;
			bool flag = int.TryParse(data["csseed"].str, out num);
			if (flag)
			{
				this.SeasonSeed = num;
			}
			bool flag2 = int.TryParse(data["psseed"].str, out num);
			if (flag2)
			{
				this.PreviousSeasonSeed = num;
			}
			this.SeasonPartEnd = data["seasonseedend"].ToUniversalTime();
			this.SeasonProgress = data["seasonprogress"].n;
		}
	}
}
