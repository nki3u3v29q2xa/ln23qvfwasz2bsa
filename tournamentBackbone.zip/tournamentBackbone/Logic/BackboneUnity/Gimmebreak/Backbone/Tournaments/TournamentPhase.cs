﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000044 RID: 68
	[Serializable]
	public class TournamentPhase
	{
		// Token: 0x170000CA RID: 202
		// (get) Token: 0x0600029D RID: 669 RVA: 0x00004146 File Offset: 0x00002346
		// (set) Token: 0x0600029E RID: 670 RVA: 0x0000414E File Offset: 0x0000234E
		public int Id { get; set; }

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x0600029F RID: 671 RVA: 0x00004157 File Offset: 0x00002357
		// (set) Token: 0x060002A0 RID: 672 RVA: 0x0000415F File Offset: 0x0000235F
		public TournamentPhaseType Type { get; set; }

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060002A1 RID: 673 RVA: 0x00004168 File Offset: 0x00002368
		// (set) Token: 0x060002A2 RID: 674 RVA: 0x00004170 File Offset: 0x00002370
		public int MaxPlayers { get; set; }

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060002A3 RID: 675 RVA: 0x00004179 File Offset: 0x00002379
		// (set) Token: 0x060002A4 RID: 676 RVA: 0x00004181 File Offset: 0x00002381
		public int MaxTeams { get; set; }

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060002A5 RID: 677 RVA: 0x0000418A File Offset: 0x0000238A
		// (set) Token: 0x060002A6 RID: 678 RVA: 0x00004192 File Offset: 0x00002392
		public int MaxLoses { get; set; }

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060002A7 RID: 679 RVA: 0x0000419B File Offset: 0x0000239B
		// (set) Token: 0x060002A8 RID: 680 RVA: 0x000041A3 File Offset: 0x000023A3
		public List<TournamentRound> Rounds { get; set; }

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x060002A9 RID: 681 RVA: 0x000041AC File Offset: 0x000023AC
		// (set) Token: 0x060002AA RID: 682 RVA: 0x000041B4 File Offset: 0x000023B4
		public int UserPositionTop { get; set; }

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060002AB RID: 683 RVA: 0x000041BD File Offset: 0x000023BD
		// (set) Token: 0x060002AC RID: 684 RVA: 0x000041C5 File Offset: 0x000023C5
		public int UserPositionBottom { get; set; }

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060002AD RID: 685 RVA: 0x000041CE File Offset: 0x000023CE
		// (set) Token: 0x060002AE RID: 686 RVA: 0x000041D6 File Offset: 0x000023D6
		public int UserLoses { get; set; }

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060002AF RID: 687 RVA: 0x000041DF File Offset: 0x000023DF
		// (set) Token: 0x060002B0 RID: 688 RVA: 0x000041E7 File Offset: 0x000023E7
		public int UserPoints { get; set; }

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060002B1 RID: 689 RVA: 0x000041F0 File Offset: 0x000023F0
		// (set) Token: 0x060002B2 RID: 690 RVA: 0x000041F8 File Offset: 0x000023F8
		public int UserPlayedRoundCount { get; set; }

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060002B3 RID: 691 RVA: 0x00004201 File Offset: 0x00002401
		// (set) Token: 0x060002B4 RID: 692 RVA: 0x00004209 File Offset: 0x00002409
		public bool UserIsParticipating { get; set; }

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060002B5 RID: 693 RVA: 0x00011C4C File Offset: 0x0000FE4C
		[XmlIgnore]
		public bool UserIsGroupAssigned
		{
			get
			{
				return this.HasGroups && this.UserGroupId > 0;
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060002B6 RID: 694 RVA: 0x00004212 File Offset: 0x00002412
		// (set) Token: 0x060002B7 RID: 695 RVA: 0x0000421A File Offset: 0x0000241A
		public int UserGroupId { get; set; }

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060002B8 RID: 696 RVA: 0x00004223 File Offset: 0x00002423
		// (set) Token: 0x060002B9 RID: 697 RVA: 0x0000422B File Offset: 0x0000242B
		public int MinTeamsPerMatch { get; set; }

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060002BA RID: 698 RVA: 0x00004234 File Offset: 0x00002434
		// (set) Token: 0x060002BB RID: 699 RVA: 0x0000423C File Offset: 0x0000243C
		public int MaxTeamsPerMatch { get; set; }

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060002BC RID: 700 RVA: 0x00004245 File Offset: 0x00002445
		// (set) Token: 0x060002BD RID: 701 RVA: 0x0000424D File Offset: 0x0000244D
		public int GroupCount { get; set; }

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060002BE RID: 702 RVA: 0x00011C74 File Offset: 0x0000FE74
		[XmlIgnore]
		public int GroupSize
		{
			get
			{
				return this.GetGroupSize();
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060002BF RID: 703 RVA: 0x00011C8C File Offset: 0x0000FE8C
		[XmlIgnore]
		public bool HasGroups
		{
			get
			{
				return this.GroupCount > 0;
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060002C0 RID: 704 RVA: 0x00004256 File Offset: 0x00002456
		// (set) Token: 0x060002C1 RID: 705 RVA: 0x0000425E File Offset: 0x0000245E
		public bool IsLoserBracketSeeded { get; set; }

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060002C2 RID: 706 RVA: 0x00004267 File Offset: 0x00002467
		// (set) Token: 0x060002C3 RID: 707 RVA: 0x0000426F File Offset: 0x0000246F
		public int MinCheckinsPerTeam { get; set; }

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060002C4 RID: 708 RVA: 0x00004278 File Offset: 0x00002478
		// (set) Token: 0x060002C5 RID: 709 RVA: 0x00004280 File Offset: 0x00002480
		public bool IsSkipAllowed { get; set; }

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060002C6 RID: 710 RVA: 0x00004289 File Offset: 0x00002489
		// (set) Token: 0x060002C7 RID: 711 RVA: 0x00004291 File Offset: 0x00002491
		public List<TournamentScore> Scores { get; set; }

		// Token: 0x060002C8 RID: 712 RVA: 0x00011CA8 File Offset: 0x0000FEA8
		public TournamentPhase()
		{
			this.Rounds = new List<TournamentRound>();
			this.roundsById = new Dictionary<int, TournamentRound>();
			this.Scores = new List<TournamentScore>();
			this.scoresById = new Dictionary<long, TournamentScore>();
			this.scoresByUserId = new Dictionary<long, TournamentScore>();
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x00011CF8 File Offset: 0x0000FEF8
		private int GetGroupSize()
		{
			bool hasGroups = this.HasGroups;
			int result;
			if (hasGroups)
			{
				TournamentPhaseType type = this.Type;
				if (type != TournamentPhaseType.DynamicBrackets)
				{
					result = this.MaxTeams / this.GroupCount;
				}
				else
				{
					result = (int)Math.Pow(2.0, (double)Math.Max(this.Rounds.Count - 1, 0)) * this.MaxTeamsPerMatch;
				}
			}
			else
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x060002CA RID: 714 RVA: 0x00011D60 File Offset: 0x0000FF60
		public TournamentRound GetRoundById(int roundId)
		{
			bool flag = this.Rounds.Count != this.roundsById.Count;
			if (flag)
			{
				this.roundsById.Clear();
				for (int i = 0; i < this.Rounds.Count; i++)
				{
					bool flag2 = !this.roundsById.ContainsKey(this.Rounds[i].Id);
					if (flag2)
					{
						this.roundsById.Add(this.Rounds[i].Id, this.Rounds[i]);
					}
				}
			}
			return this.roundsById.ContainsKey(roundId) ? this.roundsById[roundId] : null;
		}

		// Token: 0x060002CB RID: 715 RVA: 0x00011E28 File Offset: 0x00010028
		public TournamentScore GetScoreByPartyId(long partyId)
		{
			TournamentScore result = null;
			this.scoresById.TryGetValue(partyId, out result);
			return result;
		}

		// Token: 0x060002CC RID: 716 RVA: 0x00011E4C File Offset: 0x0001004C
		public TournamentScore GetScoreByUserId(long userId)
		{
			TournamentScore result = null;
			this.scoresByUserId.TryGetValue(userId, out result);
			return result;
		}

		// Token: 0x060002CD RID: 717 RVA: 0x00011E70 File Offset: 0x00010070
		internal List<TournamentScore> LoadJsonScores(JSONObject data)
		{
			List<TournamentScore> list = null;
			bool flag = this.Scores.Count != this.scoresById.Count;
			if (flag)
			{
				this.scoresById.Clear();
				this.scoresByUserId.Clear();
				for (int i = 0; i < this.Scores.Count; i++)
				{
					long partyId = this.Scores[i].PartyId;
					bool flag2 = !this.scoresById.ContainsKey(partyId);
					if (flag2)
					{
						this.scoresById.Add(partyId, this.Scores[i]);
						for (int j = 0; j < this.Scores[i].Users.Count; j++)
						{
							long userId = this.Scores[i].Users[j].UserId;
							bool flag3 = !this.scoresByUserId.ContainsKey(userId);
							if (flag3)
							{
								this.scoresByUserId.Add(userId, this.Scores[i]);
							}
						}
					}
				}
			}
			bool flag4 = !data.IsNull && data.IsArray;
			if (flag4)
			{
				list = new List<TournamentScore>(data.Count);
				for (int k = 0; k < data.Count; k++)
				{
					JSONObject jsonobject = data[k];
					bool flag5 = jsonobject.HasField(TournamentScore.FIELD_PARTYID);
					if (flag5)
					{
						long key = long.Parse(jsonobject[TournamentScore.FIELD_PARTYID].str);
						bool flag6 = false;
						bool flag7 = !this.scoresById.ContainsKey(key);
						TournamentScore tournamentScore;
						if (flag7)
						{
							tournamentScore = new TournamentScore();
							this.Scores.Add(tournamentScore);
							this.scoresById.Add(key, tournamentScore);
							flag6 = true;
						}
						tournamentScore = this.scoresById[key];
						tournamentScore.LoadJSONScore(jsonobject);
						list.Add(tournamentScore);
						bool flag8 = flag6;
						if (flag8)
						{
							for (int l = 0; l < tournamentScore.Users.Count; l++)
							{
								long userId2 = tournamentScore.Users[l].UserId;
								bool flag9 = !this.scoresByUserId.ContainsKey(userId2);
								if (flag9)
								{
									this.scoresByUserId.Add(userId2, tournamentScore);
								}
							}
						}
					}
				}
			}
			return list;
		}

		// Token: 0x0400029A RID: 666
		private Dictionary<int, TournamentRound> roundsById;

		// Token: 0x0400029B RID: 667
		private Dictionary<long, TournamentScore> scoresById;

		// Token: 0x0400029C RID: 668
		private Dictionary<long, TournamentScore> scoresByUserId;
	}
}
