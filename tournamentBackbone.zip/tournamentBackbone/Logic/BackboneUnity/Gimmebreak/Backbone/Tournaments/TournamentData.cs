﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200003A RID: 58
	[Serializable]
	public class TournamentData
	{
		// Token: 0x1700009E RID: 158
		// (get) Token: 0x06000214 RID: 532 RVA: 0x00003D0A File Offset: 0x00001F0A
		// (set) Token: 0x06000215 RID: 533 RVA: 0x00003D12 File Offset: 0x00001F12
		public List<Tournament> TournamentList { get; set; }

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x06000216 RID: 534 RVA: 0x0000F9E8 File Offset: 0x0000DBE8
		public Tournament UpcomingTournament
		{
			get
			{
				bool flag = this.TournamentList.Count((Tournament tournament) => tournament.Status != TournamentStatus.Finished && tournament.Status != TournamentStatus.Canceled && tournament.Status != TournamentStatus.Unknown) > 0;
				Tournament result;
				if (flag)
				{
					result = this.TournamentList.Last((Tournament tournament) => tournament.Status != TournamentStatus.Finished && tournament.Status != TournamentStatus.Canceled && tournament.Status != TournamentStatus.Unknown);
				}
				else
				{
					result = null;
				}
				return result;
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x06000217 RID: 535 RVA: 0x00003D1B File Offset: 0x00001F1B
		// (set) Token: 0x06000218 RID: 536 RVA: 0x00003D23 File Offset: 0x00001F23
		[XmlIgnore]
		public DateTime LastTournamentListUpdate { get; set; }

		// Token: 0x06000219 RID: 537 RVA: 0x00003D2C File Offset: 0x00001F2C
		public TournamentData()
		{
			this.tournamentListById = new Dictionary<long, Tournament>();
			this.TournamentList = new List<Tournament>();
			this.LastTournamentListUpdate = DateTime.MinValue;
			this.isLoading = false;
			this.removeTournaments = new HashSet<long>();
		}

		// Token: 0x0600021A RID: 538 RVA: 0x0000FA5C File Offset: 0x0000DC5C
		public Tournament GetTournamentById(long tournamentId)
		{
			bool flag = this.TournamentList.Count != this.tournamentListById.Count;
			if (flag)
			{
				this.tournamentListById.Clear();
				for (int i = 0; i < this.TournamentList.Count; i++)
				{
					this.tournamentListById.Add(this.TournamentList[i].Id, this.TournamentList[i]);
				}
			}
			bool flag2 = this.tournamentListById.ContainsKey(tournamentId);
			Tournament result;
			if (flag2)
			{
				result = this.tournamentListById[tournamentId];
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600021B RID: 539 RVA: 0x0000FB08 File Offset: 0x0000DD08
		internal void LoadTournamentList(List<Tournament> data)
		{
			this.removeTournaments.Clear();
			bool flag = this.TournamentList.Count != this.tournamentListById.Count;
			if (flag)
			{
				this.tournamentListById.Clear();
				for (int i = 0; i < this.TournamentList.Count; i++)
				{
					this.tournamentListById.Add(this.TournamentList[i].Id, this.TournamentList[i]);
				}
			}
			for (int j = 0; j < this.TournamentList.Count; j++)
			{
				this.removeTournaments.Add(this.TournamentList[j].Id);
			}
			for (int k = 0; k < data.Count; k++)
			{
				Tournament tournament = data[k];
				long id = tournament.Id;
				this.removeTournaments.Remove(id);
				bool flag2 = !this.tournamentListById.ContainsKey(id);
				if (flag2)
				{
					this.TournamentList.Add(tournament);
					this.tournamentListById.Add(tournament.Id, tournament);
				}
			}
			foreach (long key in this.removeTournaments)
			{
				Tournament tournament2 = this.tournamentListById[key];
				this.tournamentListById.Remove(tournament2.Id);
				this.TournamentList.Remove(tournament2);
			}
			this.TournamentList.Sort((Tournament x, Tournament y) => y.Time.CompareTo(x.Time));
			this.removeTournaments.Clear();
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0000FCF4 File Offset: 0x0000DEF4
		internal void LoadJsonTournamentList(JSONObject data, List<Tournament> loadedTournaments)
		{
			bool flag = data != null && loadedTournaments != null && data.IsArray;
			if (flag)
			{
				for (int i = 0; i < data.Count; i++)
				{
					JSONObject jsonobject = data[i];
					bool flag2 = jsonobject.HasField("id");
					if (flag2)
					{
						long num = long.Parse(jsonobject["id"].str);
						Tournament tournament = this.GetTournamentById(num);
						bool flag3 = tournament == null;
						if (flag3)
						{
							tournament = new Tournament();
							tournament.Id = num;
						}
						tournament.LoadJsonTournamentData(jsonobject);
						loadedTournaments.Add(tournament);
					}
				}
			}
		}

		// Token: 0x04000209 RID: 521
		public static int tournamentListUpdateLimit = 15;

		// Token: 0x0400020A RID: 522
		public static TimeSpan tournamentListSinceOffset = TimeSpan.FromDays(-3.0);

		// Token: 0x0400020B RID: 523
		public static TimeSpan tournamentListUntilOffset = TimeSpan.FromDays(3.0);

		// Token: 0x0400020C RID: 524
		private bool isLoading;

		// Token: 0x0400020D RID: 525
		private bool isLoadingList;

		// Token: 0x0400020E RID: 526
		private Dictionary<long, Tournament> tournamentListById;

		// Token: 0x0400020F RID: 527
		private HashSet<long> removeTournaments;
	}
}