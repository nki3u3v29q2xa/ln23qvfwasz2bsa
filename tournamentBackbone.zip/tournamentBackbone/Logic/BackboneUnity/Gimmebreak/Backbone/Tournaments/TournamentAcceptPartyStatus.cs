﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000036 RID: 54
	public enum TournamentAcceptPartyStatus
	{
		// Token: 0x040001E9 RID: 489
		Unknown = -1,
		// Token: 0x040001EA RID: 490
		NotAttempted,
		// Token: 0x040001EB RID: 491
		Ok,
		// Token: 0x040001EC RID: 492
		InviteNotExits,
		// Token: 0x040001ED RID: 493
		InviteIsMalformed,
		// Token: 0x040001EE RID: 494
		PartyIsFull,
		// Token: 0x040001EF RID: 495
		PartyNoLongerExits,
		// Token: 0x040001F0 RID: 496
		TournamentRegistrationClosed,
		// Token: 0x040001F1 RID: 497
		UserIsNotSignedUp
	}
}
