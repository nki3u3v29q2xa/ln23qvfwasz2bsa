﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;
using Gimmebreak.Backbone.GameSessions;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000041 RID: 65
	[XmlType(Namespace = "TournamentMatch")]
	[Serializable]
	public class TournamentMatch
	{
		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x06000260 RID: 608 RVA: 0x00003F2A File Offset: 0x0000212A
		// (set) Token: 0x06000261 RID: 609 RVA: 0x00003F32 File Offset: 0x00002132
		public long Id { get; set; }

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x06000262 RID: 610 RVA: 0x00003F3B File Offset: 0x0000213B
		// (set) Token: 0x06000263 RID: 611 RVA: 0x00003F43 File Offset: 0x00002143
		public string Secret { get; set; }

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000264 RID: 612 RVA: 0x00003F4C File Offset: 0x0000214C
		// (set) Token: 0x06000265 RID: 613 RVA: 0x00003F54 File Offset: 0x00002154
		public DateTime Deadline { get; set; }

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000266 RID: 614 RVA: 0x00003F5D File Offset: 0x0000215D
		// (set) Token: 0x06000267 RID: 615 RVA: 0x00003F65 File Offset: 0x00002165
		public int MatchId { get; set; }

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x06000268 RID: 616 RVA: 0x00003F6E File Offset: 0x0000216E
		// (set) Token: 0x06000269 RID: 617 RVA: 0x00003F76 File Offset: 0x00002176
		public int PhaseId { get; set; }

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x0600026A RID: 618 RVA: 0x00003F7F File Offset: 0x0000217F
		// (set) Token: 0x0600026B RID: 619 RVA: 0x00003F87 File Offset: 0x00002187
		public int GroupId { get; set; }

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x0600026C RID: 620 RVA: 0x00003F90 File Offset: 0x00002190
		// (set) Token: 0x0600026D RID: 621 RVA: 0x00003F98 File Offset: 0x00002198
		public int RoundId { get; set; }

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x0600026E RID: 622 RVA: 0x00003FA1 File Offset: 0x000021A1
		// (set) Token: 0x0600026F RID: 623 RVA: 0x00003FA9 File Offset: 0x000021A9
		public TournamentMatchStatus Status { get; set; }

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x06000270 RID: 624 RVA: 0x00003FB2 File Offset: 0x000021B2
		// (set) Token: 0x06000271 RID: 625 RVA: 0x00003FBA File Offset: 0x000021BA
		public List<TournamentMatch.User> Users { get; set; }

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x06000272 RID: 626 RVA: 0x00003FC3 File Offset: 0x000021C3
		// (set) Token: 0x06000273 RID: 627 RVA: 0x00003FCB File Offset: 0x000021CB
		public int WinScore { get; set; }

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x06000274 RID: 628 RVA: 0x00003FD4 File Offset: 0x000021D4
		// (set) Token: 0x06000275 RID: 629 RVA: 0x00003FDC File Offset: 0x000021DC
		public int MaxGameCount { get; set; }

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000276 RID: 630 RVA: 0x00003FE5 File Offset: 0x000021E5
		// (set) Token: 0x06000277 RID: 631 RVA: 0x00003FED File Offset: 0x000021ED
		public int CurrentGameCount { get; set; }

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06000278 RID: 632 RVA: 0x00003FF6 File Offset: 0x000021F6
		// (set) Token: 0x06000279 RID: 633 RVA: 0x00003FFE File Offset: 0x000021FE
		public List<GameSession> GameSessions { get; set; }

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x0600027A RID: 634 RVA: 0x00004007 File Offset: 0x00002207
		// (set) Token: 0x0600027B RID: 635 RVA: 0x0000400F File Offset: 0x0000220F
		public int FullyCheckedInTeamCount { get; set; }

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x0600027C RID: 636 RVA: 0x00004018 File Offset: 0x00002218
		// (set) Token: 0x0600027D RID: 637 RVA: 0x00004020 File Offset: 0x00002220
		public int PartiallyCheckedInTeamCount { get; set; }

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x0600027E RID: 638 RVA: 0x00004029 File Offset: 0x00002229
		// (set) Token: 0x0600027F RID: 639 RVA: 0x00004031 File Offset: 0x00002231
		public int CheckedInUserCount { get; set; }

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x06000280 RID: 640 RVA: 0x0000403A File Offset: 0x0000223A
		// (set) Token: 0x06000281 RID: 641 RVA: 0x00004042 File Offset: 0x00002242
		public int MinCheckinsPerTeam { get; set; }

		// Token: 0x06000282 RID: 642 RVA: 0x0000404B File Offset: 0x0000224B
		public TournamentMatch()
		{
			this.removeUsers = new HashSet<long>();
			this.Users = new List<TournamentMatch.User>();
			this.GameSessions = new List<GameSession>();
			this.MinCheckinsPerTeam = 1;
		}

		// Token: 0x06000283 RID: 643 RVA: 0x00010FF0 File Offset: 0x0000F1F0
		internal void LoadJSONMatch(JSONObject data)
		{
			bool flag = data.HasField(TournamentMatch.FIELD_ID) && !data[TournamentMatch.FIELD_ID].IsNull;
			if (flag)
			{
				this.Id = long.Parse(data[TournamentMatch.FIELD_ID].str);
			}
			bool flag2 = data.HasField(TournamentMatch.FIELD_SECRET);
			if (flag2)
			{
				this.Secret = data[TournamentMatch.FIELD_SECRET].str;
			}
			else
			{
				this.Secret = null;
			}
			bool flag3 = data.HasField(TournamentMatch.FIELD_DEADLINE);
			if (flag3)
			{
				this.Deadline = data[TournamentMatch.FIELD_DEADLINE].ToUniversalTime();
			}
			bool flag4 = data.HasField(TournamentMatch.FIELD_MATCHID);
			if (flag4)
			{
				this.MatchId = (int)data[TournamentMatch.FIELD_MATCHID].f;
			}
			bool flag5 = data.HasField(TournamentMatch.FIELD_PHASEID);
			if (flag5)
			{
				this.PhaseId = (int)data[TournamentMatch.FIELD_PHASEID].f;
			}
			bool flag6 = data.HasField(TournamentMatch.FIELD_GROUPID);
			if (flag6)
			{
				this.GroupId = (int)data[TournamentMatch.FIELD_GROUPID].f;
			}
			bool flag7 = data.HasField(TournamentMatch.FIELD_ROUNDID);
			if (flag7)
			{
				this.RoundId = (int)data[TournamentMatch.FIELD_ROUNDID].f;
			}
			bool flag8 = data.HasField(TournamentMatch.FIELD_PLAYEDGAMECOUNT);
			if (flag8)
			{
				this.CurrentGameCount = (int)data[TournamentMatch.FIELD_PLAYEDGAMECOUNT].i;
			}
			bool flag9 = data.HasField(TournamentMatch.FIELD_STATUS);
			if (flag9)
			{
				this.Status = data[TournamentMatch.FIELD_STATUS].ToEnum(TournamentMatchStatus.Unkown);
			}
			this.removeUsers.Clear();
			for (int i = 0; i < this.Users.Count; i++)
			{
				this.removeUsers.Add(this.Users[i].UserId);
			}
			bool flag10 = data.HasField(TournamentMatch.FIELD_USERS) && !data[TournamentMatch.FIELD_USERS].IsNull;
			if (flag10)
			{
				List<JSONObject> list = data[TournamentMatch.FIELD_USERS].list;
				for (int j = 0; j < list.Count; j++)
				{
					JSONObject jsonobject = list[j];
					bool flag11 = jsonobject.HasField(TournamentMatch.FIELD_USER_USERID);
					if (flag11)
					{
						long num = long.Parse(jsonobject[TournamentMatch.FIELD_USER_USERID].str);
						TournamentMatch.User user3 = this.GetMatchUserById(num);
						bool flag12 = user3 == null;
						if (flag12)
						{
							user3 = new TournamentMatch.User();
							user3.UserId = num;
							this.Users.Add(user3);
						}
						bool flag13 = jsonobject.HasField(TournamentMatch.FIELD_USER_TEAMID);
						if (flag13)
						{
							user3.TeamId = byte.Parse(jsonobject[TournamentMatch.FIELD_USER_TEAMID].str);
						}
						bool flag14 = jsonobject.HasField(TournamentMatch.FIELD_USER_CHECKEDIN);
						if (flag14)
						{
							user3.IsCheckedIn = (jsonobject[TournamentMatch.FIELD_USER_CHECKEDIN].str == "1");
						}
						bool flag15 = jsonobject.HasField(TournamentMatch.FIELD_USER_USERSCORE);
						if (flag15)
						{
							user3.UserScore = int.Parse(jsonobject[TournamentMatch.FIELD_USER_USERSCORE].str);
						}
						bool flag16 = jsonobject.HasField(TournamentMatch.FIELD_USER_TEAMSCORE);
						if (flag16)
						{
							user3.TeamScore = int.Parse(jsonobject[TournamentMatch.FIELD_USER_TEAMSCORE].str);
						}
						bool flag17 = jsonobject.HasField(TournamentMatch.FIELD_USER_USERPOINTS);
						if (flag17)
						{
							user3.UserPoints = int.Parse(jsonobject[TournamentMatch.FIELD_USER_USERPOINTS].str);
						}
						bool flag18 = jsonobject.HasField(TournamentMatch.FIELD_USER_TEAMPOINTS);
						if (flag18)
						{
							user3.TeamPoints = int.Parse(jsonobject[TournamentMatch.FIELD_USER_TEAMPOINTS].str);
						}
						bool flag19 = jsonobject.HasField(TournamentMatch.FIELD_USER_MATCHPOINTS);
						if (flag19)
						{
							user3.MatchPoints = int.Parse(jsonobject[TournamentMatch.FIELD_USER_MATCHPOINTS].str);
						}
						bool flag20 = jsonobject.HasField(TournamentMatch.FIELD_USER_MATCHWINNER);
						if (flag20)
						{
							user3.IsWinner = (jsonobject[TournamentMatch.FIELD_USER_MATCHWINNER].str == "1");
						}
						bool flag21 = jsonobject.HasField(TournamentMatch.FIELD_USER_NICK);
						if (flag21)
						{
							user3.Nick = jsonobject[TournamentMatch.FIELD_USER_NICK].str;
						}
						this.removeUsers.Remove(num);
					}
				}
			}
			this.Users.RemoveAll((TournamentMatch.User user) => this.removeUsers.Contains(user.UserId));
			this.Users.Sort(delegate(TournamentMatch.User user1, TournamentMatch.User user2)
			{
				bool flag22 = user1.TeamId != user2.TeamId;
				int result;
				if (flag22)
				{
					result = user1.TeamId.CompareTo(user2.TeamId);
				}
				else
				{
					result = user1.UserId.CompareTo(user2.UserId);
				}
				return result;
			});
			this.FullyCheckedInTeamCount = (from user in this.Users
			group user by user.TeamId).Count((IGrouping<byte, TournamentMatch.User> team) => team.All((TournamentMatch.User user) => user.IsCheckedIn));
			this.PartiallyCheckedInTeamCount = (from user in this.Users
			group user by user.TeamId).Count((IGrouping<byte, TournamentMatch.User> team) => team.Count((TournamentMatch.User user) => user.IsCheckedIn) >= this.MinCheckinsPerTeam);
			this.CheckedInUserCount = this.Users.Count((TournamentMatch.User user) => user.IsCheckedIn);
		}

		// Token: 0x06000284 RID: 644 RVA: 0x000115A0 File Offset: 0x0000F7A0
		internal void LoadJSONGameSessions(JSONObject data)
		{
			bool flag = data.HasField(TournamentMatch.FIELD_GAMESESSIONS);
			if (flag)
			{
				List<JSONObject> list = data[TournamentMatch.FIELD_GAMESESSIONS].list;
				for (int i = 0; i < list.Count; i++)
				{
					JSONObject jsonobject = list[i];
					bool flag2 = jsonobject.HasField(GameSession.FIELD_ID);
					if (flag2)
					{
						long id = long.Parse(jsonobject[GameSession.FIELD_ID].str);
						GameSession gameSession = this.GameSessions.FirstOrDefault((GameSession item) => item.Id == id);
						bool flag3 = gameSession == null;
						if (flag3)
						{
							gameSession = new GameSession();
							this.GameSessions.Add(gameSession);
						}
						gameSession.LoadJSONGameSession(jsonobject);
					}
				}
			}
		}

		// Token: 0x06000285 RID: 645 RVA: 0x00011678 File Offset: 0x0000F878
		public TournamentMatch.User GetMatchUserById(long userId)
		{
			return this.Users.FirstOrDefault((TournamentMatch.User user) => user.UserId == userId);
		}

		// Token: 0x06000286 RID: 646 RVA: 0x000116B0 File Offset: 0x0000F8B0
		public IEnumerable<TournamentMatch.User> GetCheckInTeamUsers()
		{
			return from user in this.Users
			where this.IsTeamPartiallyCheckedIn(user)
			select user;
		}

		// Token: 0x06000287 RID: 647 RVA: 0x000116DC File Offset: 0x0000F8DC
		public bool IsTeamFullyCheckedIn(TournamentMatch.User teamMember)
		{
			return this.IsTeamFullyCheckedIn(teamMember.TeamId);
		}

		// Token: 0x06000288 RID: 648 RVA: 0x000116FC File Offset: 0x0000F8FC
		public bool IsTeamFullyCheckedIn(byte teamId)
		{
			bool result;
			if (this.Users.Any((TournamentMatch.User user) => user.TeamId == teamId))
			{
				result = (from user in this.Users
				where user.TeamId == teamId
				select user).All((TournamentMatch.User user) => user.IsCheckedIn);
			}
			else
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000289 RID: 649 RVA: 0x00011774 File Offset: 0x0000F974
		public bool IsTeamPartiallyCheckedIn(TournamentMatch.User teamMember)
		{
			return this.IsTeamPartiallyCheckedIn(teamMember.TeamId);
		}

		// Token: 0x0600028A RID: 650 RVA: 0x00011794 File Offset: 0x0000F994
		public bool IsTeamPartiallyCheckedIn(byte teamId)
		{
			bool result;
			if (this.Users.Any((TournamentMatch.User user) => user.TeamId == teamId))
			{
				result = ((from user in this.Users
				where user.TeamId == teamId
				select user).Count((TournamentMatch.User user) => user.IsCheckedIn) >= this.MinCheckinsPerTeam);
			}
			else
			{
				result = false;
			}
			return result;
		}

		// Token: 0x04000260 RID: 608
		internal static readonly string FIELD_ID = "id";

		// Token: 0x04000261 RID: 609
		internal static readonly string FIELD_MATCHID = "matchid";

		// Token: 0x04000262 RID: 610
		internal static readonly string FIELD_PHASEID = "phaseid";

		// Token: 0x04000263 RID: 611
		internal static readonly string FIELD_GROUPID = "groupid";

		// Token: 0x04000264 RID: 612
		internal static readonly string FIELD_ROUNDID = "roundid";

		// Token: 0x04000265 RID: 613
		private static readonly string FIELD_SECRET = "secret";

		// Token: 0x04000266 RID: 614
		private static readonly string FIELD_DEADLINE = "deadline";

		// Token: 0x04000267 RID: 615
		private static readonly string FIELD_STATUS = "status";

		// Token: 0x04000268 RID: 616
		private static readonly string FIELD_USERS = "users";

		// Token: 0x04000269 RID: 617
		private static readonly string FIELD_USER_USERID = "@user-id";

		// Token: 0x0400026A RID: 618
		private static readonly string FIELD_USER_TEAMID = "@team-id";

		// Token: 0x0400026B RID: 619
		private static readonly string FIELD_USER_CHECKEDIN = "@checked-in";

		// Token: 0x0400026C RID: 620
		private static readonly string FIELD_USER_USERSCORE = "@user-score";

		// Token: 0x0400026D RID: 621
		private static readonly string FIELD_USER_TEAMSCORE = "@team-score";

		// Token: 0x0400026E RID: 622
		private static readonly string FIELD_USER_USERPOINTS = "@user-points";

		// Token: 0x0400026F RID: 623
		private static readonly string FIELD_USER_TEAMPOINTS = "@team-points";

		// Token: 0x04000270 RID: 624
		private static readonly string FIELD_USER_MATCHPOINTS = "@match-points";

		// Token: 0x04000271 RID: 625
		private static readonly string FIELD_USER_MATCHWINNER = "@match-winner";

		// Token: 0x04000272 RID: 626
		private static readonly string FIELD_USER_NICK = "@nick";

		// Token: 0x04000273 RID: 627
		private static readonly string FIELD_GAMESESSIONS = "gameSessions";

		// Token: 0x04000274 RID: 628
		private static readonly string FIELD_PLAYEDGAMECOUNT = "playedgamecount";

		// Token: 0x04000275 RID: 629
		private HashSet<long> removeUsers;

		// Token: 0x0200008A RID: 138
		[Serializable]
		public class User
		{
			// Token: 0x1700018F RID: 399
			// (get) Token: 0x060005F7 RID: 1527 RVA: 0x00005D5C File Offset: 0x00003F5C
			// (set) Token: 0x060005F8 RID: 1528 RVA: 0x00005D64 File Offset: 0x00003F64
			public long UserId { get; set; }

			// Token: 0x17000190 RID: 400
			// (get) Token: 0x060005F9 RID: 1529 RVA: 0x00005D6D File Offset: 0x00003F6D
			// (set) Token: 0x060005FA RID: 1530 RVA: 0x00005D75 File Offset: 0x00003F75
			public byte TeamId { get; set; }

			// Token: 0x17000191 RID: 401
			// (get) Token: 0x060005FB RID: 1531 RVA: 0x00005D7E File Offset: 0x00003F7E
			// (set) Token: 0x060005FC RID: 1532 RVA: 0x00005D86 File Offset: 0x00003F86
			public bool IsCheckedIn { get; set; }

			// Token: 0x17000192 RID: 402
			// (get) Token: 0x060005FD RID: 1533 RVA: 0x00005D8F File Offset: 0x00003F8F
			// (set) Token: 0x060005FE RID: 1534 RVA: 0x00005D97 File Offset: 0x00003F97
			public int UserScore { get; set; }

			// Token: 0x17000193 RID: 403
			// (get) Token: 0x060005FF RID: 1535 RVA: 0x00005DA0 File Offset: 0x00003FA0
			// (set) Token: 0x06000600 RID: 1536 RVA: 0x00005DA8 File Offset: 0x00003FA8
			public int TeamScore { get; set; }

			// Token: 0x17000194 RID: 404
			// (get) Token: 0x06000601 RID: 1537 RVA: 0x00005DB1 File Offset: 0x00003FB1
			// (set) Token: 0x06000602 RID: 1538 RVA: 0x00005DB9 File Offset: 0x00003FB9
			public int UserPoints { get; set; }

			// Token: 0x17000195 RID: 405
			// (get) Token: 0x06000603 RID: 1539 RVA: 0x00005DC2 File Offset: 0x00003FC2
			// (set) Token: 0x06000604 RID: 1540 RVA: 0x00005DCA File Offset: 0x00003FCA
			public int TeamPoints { get; set; }

			// Token: 0x17000196 RID: 406
			// (get) Token: 0x06000605 RID: 1541 RVA: 0x00005DD3 File Offset: 0x00003FD3
			// (set) Token: 0x06000606 RID: 1542 RVA: 0x00005DDB File Offset: 0x00003FDB
			public int MatchPoints { get; set; }

			// Token: 0x17000197 RID: 407
			// (get) Token: 0x06000607 RID: 1543 RVA: 0x00005DE4 File Offset: 0x00003FE4
			// (set) Token: 0x06000608 RID: 1544 RVA: 0x00005DEC File Offset: 0x00003FEC
			public bool IsWinner { get; set; }

			// Token: 0x17000198 RID: 408
			// (get) Token: 0x06000609 RID: 1545 RVA: 0x00005DF5 File Offset: 0x00003FF5
			// (set) Token: 0x0600060A RID: 1546 RVA: 0x00005DFD File Offset: 0x00003FFD
			public string Nick { get; set; }
		}
	}
}
