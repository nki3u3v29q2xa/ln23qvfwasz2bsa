﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000038 RID: 56
	public enum TournamentSignUpStatus
	{
		// Token: 0x040001FA RID: 506
		NotSigned,
		// Token: 0x040001FB RID: 507
		Ok,
		// Token: 0x040001FC RID: 508
		InvalidTournamentIdOrData,
		// Token: 0x040001FD RID: 509
		RequirementsNotMet,
		// Token: 0x040001FE RID: 510
		NotEnoughtForEntry,
		// Token: 0x040001FF RID: 511
		NotOpenedForSignUp,
		// Token: 0x04000200 RID: 512
		TournamentIsFull,
		// Token: 0x04000201 RID: 513
		DatabaseError
	}
}
