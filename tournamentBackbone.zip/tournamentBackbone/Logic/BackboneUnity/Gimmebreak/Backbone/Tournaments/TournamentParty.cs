﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000042 RID: 66
	[XmlType(Namespace = "TournamentParty")]
	[Serializable]
	public class TournamentParty
	{
		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x0600028F RID: 655 RVA: 0x000040CE File Offset: 0x000022CE
		// (set) Token: 0x06000290 RID: 656 RVA: 0x000040D6 File Offset: 0x000022D6
		public long PartyId { get; set; }

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000291 RID: 657 RVA: 0x000040DF File Offset: 0x000022DF
		// (set) Token: 0x06000292 RID: 658 RVA: 0x000040E7 File Offset: 0x000022E7
		public bool IsPartyLeader { get; set; }

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000293 RID: 659 RVA: 0x000040F0 File Offset: 0x000022F0
		// (set) Token: 0x06000294 RID: 660 RVA: 0x000040F8 File Offset: 0x000022F8
		public List<TournamentParty.User> PartyUsers { get; set; }

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000295 RID: 661 RVA: 0x00004101 File Offset: 0x00002301
		// (set) Token: 0x06000296 RID: 662 RVA: 0x00004109 File Offset: 0x00002309
		public string PartyCode { get; set; }

		// Token: 0x06000297 RID: 663 RVA: 0x00004112 File Offset: 0x00002312
		public TournamentParty()
		{
			this.PartyUsers = new List<TournamentParty.User>();
			this.removeUsers = new HashSet<long>();
		}

		// Token: 0x06000298 RID: 664 RVA: 0x000118F8 File Offset: 0x0000FAF8
		internal void LoadJSONParty(JSONObject data)
		{
			bool flag = data == null || !data.IsObject;
			if (!flag)
			{
				bool flag2 = data.HasField(TournamentParty.FIELD_DATA_PARTYID);
				if (flag2)
				{
					this.PartyId = long.Parse(data[TournamentParty.FIELD_DATA_PARTYID].str);
					bool flag3 = data.HasField(TournamentParty.FIELD_DATA_ISPARTYLEADER);
					if (flag3)
					{
						this.IsPartyLeader = data[TournamentParty.FIELD_DATA_ISPARTYLEADER].b;
					}
					bool flag4 = data.HasField(TournamentParty.FIELD_DATA_PARTYCODE);
					if (flag4)
					{
						this.PartyCode = data[TournamentParty.FIELD_DATA_PARTYCODE].str;
					}
				}
				else
				{
					this.PartyId = -1L;
					this.IsPartyLeader = false;
					this.PartyUsers.Clear();
					this.PartyCode = null;
				}
			}
		}

		// Token: 0x06000299 RID: 665 RVA: 0x000119C8 File Offset: 0x0000FBC8
		internal void LoadJSONPartyUsers(JSONObject data)
		{
			bool flag = data == null || data.IsNull || !data.IsArray;
			if (!flag)
			{
				List<JSONObject> list = data.list;
				this.removeUsers.Clear();
				for (int i = 0; i < this.PartyUsers.Count; i++)
				{
					this.removeUsers.Add(this.PartyUsers[i].UserId);
				}
				for (int j = 0; j < list.Count; j++)
				{
					JSONObject jsonobject = list[j];
					bool flag2 = jsonobject.HasField(TournamentParty.FIELD_USERPARTY_USERID);
					if (flag2)
					{
						long num = long.Parse(jsonobject[TournamentParty.FIELD_USERPARTY_USERID].str);
						TournamentParty.User user2 = this.GetPartyUserById(num);
						bool flag3 = user2 == null;
						if (flag3)
						{
							user2 = new TournamentParty.User();
							user2.UserId = num;
							this.PartyUsers.Add(user2);
						}
						bool flag4 = jsonobject.HasField(TournamentParty.FIELD_USERPARTY_STATUS);
						if (flag4)
						{
							user2.Status = jsonobject[TournamentParty.FIELD_USERPARTY_STATUS].ToEnum(TournamentUserStatus.Unkown);
						}
						bool flag5 = jsonobject.HasField(TournamentParty.FIELD_USERPARTY_USERNICK);
						if (flag5)
						{
							user2.Nick = jsonobject[TournamentParty.FIELD_USERPARTY_USERNICK].str;
						}
						bool flag6 = jsonobject.HasField(TournamentParty.FIELD_USERPARTY_ISPARTYLEADER);
						if (flag6)
						{
							user2.IsPartyLeader = jsonobject[TournamentParty.FIELD_USERPARTY_ISPARTYLEADER].b;
						}
						bool flag7 = jsonobject.HasField(TournamentParty.FIELD_USERPARTY_CHECKIN);
						if (flag7)
						{
							user2.IsCheckedIn = jsonobject[TournamentParty.FIELD_USERPARTY_CHECKIN].b;
						}
						this.removeUsers.Remove(num);
					}
				}
				this.PartyUsers.RemoveAll((TournamentParty.User user) => this.removeUsers.Contains(user.UserId));
			}
		}

		// Token: 0x0600029A RID: 666 RVA: 0x00011BB4 File Offset: 0x0000FDB4
		public TournamentParty.User GetPartyUserById(long userId)
		{
			return this.PartyUsers.FirstOrDefault((TournamentParty.User user) => user.UserId == userId);
		}

		// Token: 0x04000287 RID: 647
		private static readonly string FIELD_USERPARTY_STATUS = "status";

		// Token: 0x04000288 RID: 648
		private static readonly string FIELD_USERPARTY_USERID = "userId";

		// Token: 0x04000289 RID: 649
		private static readonly string FIELD_USERPARTY_CHECKIN = "checkIn";

		// Token: 0x0400028A RID: 650
		private static readonly string FIELD_USERPARTY_ISPARTYLEADER = "isPartyLeader";

		// Token: 0x0400028B RID: 651
		private static readonly string FIELD_USERPARTY_USERNICK = "nick";

		// Token: 0x0400028C RID: 652
		internal static readonly string FIELD_DATA_PARTYID = "invitePartyId";

		// Token: 0x0400028D RID: 653
		private static readonly string FIELD_DATA_ISPARTYLEADER = "inviteIsPartyLeader";

		// Token: 0x0400028E RID: 654
		private static readonly string FIELD_DATA_PARTYCODE = "invitePartyCode";

		// Token: 0x0400028F RID: 655
		private HashSet<long> removeUsers;

		// Token: 0x02000090 RID: 144
		[Serializable]
		public class User
		{
			// Token: 0x17000199 RID: 409
			// (get) Token: 0x06000621 RID: 1569 RVA: 0x00005F07 File Offset: 0x00004107
			// (set) Token: 0x06000622 RID: 1570 RVA: 0x00005F0F File Offset: 0x0000410F
			public long UserId { get; set; }

			// Token: 0x1700019A RID: 410
			// (get) Token: 0x06000623 RID: 1571 RVA: 0x00005F18 File Offset: 0x00004118
			// (set) Token: 0x06000624 RID: 1572 RVA: 0x00005F20 File Offset: 0x00004120
			public TournamentUserStatus Status { get; set; }

			// Token: 0x1700019B RID: 411
			// (get) Token: 0x06000625 RID: 1573 RVA: 0x00005F29 File Offset: 0x00004129
			// (set) Token: 0x06000626 RID: 1574 RVA: 0x00005F31 File Offset: 0x00004131
			public bool IsCheckedIn { get; set; }

			// Token: 0x1700019C RID: 412
			// (get) Token: 0x06000627 RID: 1575 RVA: 0x00005F3A File Offset: 0x0000413A
			// (set) Token: 0x06000628 RID: 1576 RVA: 0x00005F42 File Offset: 0x00004142
			public bool IsPartyLeader { get; set; }

			// Token: 0x1700019D RID: 413
			// (get) Token: 0x06000629 RID: 1577 RVA: 0x00005F4B File Offset: 0x0000414B
			// (set) Token: 0x0600062A RID: 1578 RVA: 0x00005F53 File Offset: 0x00004153
			public string Nick { get; set; }
		}
	}
}
