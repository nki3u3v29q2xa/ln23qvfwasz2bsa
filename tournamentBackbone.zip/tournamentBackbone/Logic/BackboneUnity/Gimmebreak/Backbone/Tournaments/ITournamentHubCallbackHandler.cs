﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200002A RID: 42
	public interface ITournamentHubCallbackHandler
	{
		// Token: 0x0600016F RID: 367
		void OnInitialized(ITournamentHubController controller);

		// Token: 0x06000170 RID: 368
		void OnHubStatusChanged(TournamentHubStatus newStatus);

		// Token: 0x06000171 RID: 369
		void OnHubMatchStatusChanged(TournamentHubMatchStatus newStatus);

		// Token: 0x06000172 RID: 370
		void OnHubMatchUpdate();

		// Token: 0x06000173 RID: 371
		void OnTournamentUpdate();
	}
}
