﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000031 RID: 49
	public enum TournamentProcessInviteAction
	{
		// Token: 0x04000146 RID: 326
		Accept = 1,
		// Token: 0x04000147 RID: 327
		Decline
	}
}
