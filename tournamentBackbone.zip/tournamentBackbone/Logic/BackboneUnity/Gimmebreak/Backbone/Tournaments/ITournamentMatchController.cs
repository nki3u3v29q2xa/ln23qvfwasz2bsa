﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000024 RID: 36
	public interface ITournamentMatchController
	{
		// Token: 0x06000138 RID: 312
		void ReportJoinedUser(long userId);

		// Token: 0x06000139 RID: 313
		void ReportStatusChange();

		// Token: 0x0600013A RID: 314
		void ReportDisconnectedUser(long userId);
	}
}
