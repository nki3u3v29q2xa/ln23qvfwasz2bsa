﻿using System;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200003F RID: 63
	[Serializable]
	public class TournamentInvite
	{
		// Token: 0x170000AE RID: 174
		// (get) Token: 0x0600024F RID: 591 RVA: 0x00003EAA File Offset: 0x000020AA
		// (set) Token: 0x06000250 RID: 592 RVA: 0x00003EB2 File Offset: 0x000020B2
		public long Id { get; set; }

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000251 RID: 593 RVA: 0x00003EBB File Offset: 0x000020BB
		// (set) Token: 0x06000252 RID: 594 RVA: 0x00003EC3 File Offset: 0x000020C3
		public TournamentUserStatus Status { get; set; }

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000253 RID: 595 RVA: 0x00003ECC File Offset: 0x000020CC
		// (set) Token: 0x06000254 RID: 596 RVA: 0x00003ED4 File Offset: 0x000020D4
		public DateTime AcceptedAt { get; set; }

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000255 RID: 597 RVA: 0x00003EDD File Offset: 0x000020DD
		// (set) Token: 0x06000256 RID: 598 RVA: 0x00003EE5 File Offset: 0x000020E5
		public DateTime DeclinedAt { get; set; }

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000257 RID: 599 RVA: 0x00003EEE File Offset: 0x000020EE
		// (set) Token: 0x06000258 RID: 600 RVA: 0x00003EF6 File Offset: 0x000020F6
		public int FinalPlace { get; set; }

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x06000259 RID: 601 RVA: 0x00003EFF File Offset: 0x000020FF
		// (set) Token: 0x0600025A RID: 602 RVA: 0x00003F07 File Offset: 0x00002107
		public bool PrizeDelivered { get; set; }

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x0600025B RID: 603 RVA: 0x00003F10 File Offset: 0x00002110
		// (set) Token: 0x0600025C RID: 604 RVA: 0x00003F18 File Offset: 0x00002118
		public bool IsCheckedIn { get; set; }

		// Token: 0x0600025D RID: 605 RVA: 0x00010E68 File Offset: 0x0000F068
		internal void LoadJsonInvite(JSONObject data)
		{
			bool flag = data.HasField(TournamentInvite.FIELD_INVITEID);
			if (flag)
			{
				this.Id = long.Parse(data[TournamentInvite.FIELD_INVITEID].str);
			}
			bool flag2 = data.HasField(TournamentInvite.FIELD_INVITESTATUS);
			if (flag2)
			{
				this.Status = data[TournamentInvite.FIELD_INVITESTATUS].ToEnum(TournamentUserStatus.Unkown);
			}
			bool flag3 = data.HasField(TournamentInvite.FIELD_INVITEACCEPTEDAT);
			if (flag3)
			{
				this.AcceptedAt = data[TournamentInvite.FIELD_INVITEACCEPTEDAT].ToUniversalTime();
			}
			bool flag4 = data.HasField(TournamentInvite.FIELD_INVITEDECLINEDAT);
			if (flag4)
			{
				this.DeclinedAt = data[TournamentInvite.FIELD_INVITEDECLINEDAT].ToUniversalTime();
			}
			bool flag5 = data.HasField(TournamentInvite.FIELD_USERPLACE);
			if (flag5)
			{
				this.FinalPlace = (int)data[TournamentInvite.FIELD_USERPLACE].i;
			}
			bool flag6 = data.HasField(TournamentInvite.FIELD_PRIZEDELIVERED);
			if (flag6)
			{
				this.PrizeDelivered = data[TournamentInvite.FIELD_PRIZEDELIVERED].b;
			}
			bool flag7 = data.HasField(TournamentInvite.FIELD_CHECKIN);
			if (flag7)
			{
				this.IsCheckedIn = data[TournamentInvite.FIELD_CHECKIN].b;
			}
		}

		// Token: 0x04000249 RID: 585
		internal static readonly string FIELD_INVITEID = "inviteId";

		// Token: 0x0400024A RID: 586
		private static readonly string FIELD_INVITEACCEPTEDAT = "inviteAceptedAt";

		// Token: 0x0400024B RID: 587
		private static readonly string FIELD_INVITEDECLINEDAT = "inviteDeclinedAt";

		// Token: 0x0400024C RID: 588
		private static readonly string FIELD_INVITESTATUS = "inviteStatus";

		// Token: 0x0400024D RID: 589
		private static readonly string FIELD_CHECKIN = "checkIn";

		// Token: 0x0400024E RID: 590
		private static readonly string FIELD_PRIZEDELIVERED = "prizeDelivered";

		// Token: 0x0400024F RID: 591
		private static readonly string FIELD_USERPLACE = "userPlace";
	}
}
