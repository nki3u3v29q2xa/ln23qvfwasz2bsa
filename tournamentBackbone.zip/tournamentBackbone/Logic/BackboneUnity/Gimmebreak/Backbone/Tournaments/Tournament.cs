﻿using System;
using System.Collections.Generic;
using System.Linq;
using Gimmebreak.Backbone.Core.JSON;
using UnityEngine;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000032 RID: 50
	[Serializable]
	public class Tournament
	{
		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000194 RID: 404 RVA: 0x000039A1 File Offset: 0x00001BA1
		// (set) Token: 0x06000195 RID: 405 RVA: 0x000039A9 File Offset: 0x00001BA9
		public long Id { get; set; }

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000196 RID: 406 RVA: 0x000039B2 File Offset: 0x00001BB2
		// (set) Token: 0x06000197 RID: 407 RVA: 0x000039BA File Offset: 0x00001BBA
		public TournamentType Type { get; set; }

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000198 RID: 408 RVA: 0x000039C3 File Offset: 0x00001BC3
		// (set) Token: 0x06000199 RID: 409 RVA: 0x000039CB File Offset: 0x00001BCB
		public TournamentStatus Status { get; set; }

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x0600019A RID: 410 RVA: 0x000039D4 File Offset: 0x00001BD4
		// (set) Token: 0x0600019B RID: 411 RVA: 0x000039DC File Offset: 0x00001BDC
		public DateTime Time { get; set; }

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x0600019C RID: 412 RVA: 0x000039E5 File Offset: 0x00001BE5
		// (set) Token: 0x0600019D RID: 413 RVA: 0x000039ED File Offset: 0x00001BED
		public DateTime InvitationOpenTime { get; set; }

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600019E RID: 414 RVA: 0x000039F6 File Offset: 0x00001BF6
		// (set) Token: 0x0600019F RID: 415 RVA: 0x000039FE File Offset: 0x00001BFE
		public DateTime RegistrationOpenTime { get; set; }

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x00003A07 File Offset: 0x00001C07
		// (set) Token: 0x060001A1 RID: 417 RVA: 0x00003A0F File Offset: 0x00001C0F
		public DateTime InvitationCloseTime { get; set; }

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x060001A2 RID: 418 RVA: 0x00003A18 File Offset: 0x00001C18
		// (set) Token: 0x060001A3 RID: 419 RVA: 0x00003A20 File Offset: 0x00001C20
		public bool IsInvitationOnly { get; set; }

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x060001A4 RID: 420 RVA: 0x00003A29 File Offset: 0x00001C29
		// (set) Token: 0x060001A5 RID: 421 RVA: 0x00003A31 File Offset: 0x00001C31
		public int Season { get; set; }

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x060001A6 RID: 422 RVA: 0x00003A3A File Offset: 0x00001C3A
		// (set) Token: 0x060001A7 RID: 423 RVA: 0x00003A42 File Offset: 0x00001C42
		public int SeasonPart { get; set; }

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x00003A4B File Offset: 0x00001C4B
		// (set) Token: 0x060001A9 RID: 425 RVA: 0x00003A53 File Offset: 0x00001C53
		public int MaxInvites { get; set; }

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x060001AA RID: 426 RVA: 0x00003A5C File Offset: 0x00001C5C
		// (set) Token: 0x060001AB RID: 427 RVA: 0x00003A64 File Offset: 0x00001C64
		public int CurrentInvites { get; set; }

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x060001AC RID: 428 RVA: 0x00003A6D File Offset: 0x00001C6D
		// (set) Token: 0x060001AD RID: 429 RVA: 0x00003A75 File Offset: 0x00001C75
		public int PhaseCount { get; set; }

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060001AE RID: 430 RVA: 0x00003A7E File Offset: 0x00001C7E
		// (set) Token: 0x060001AF RID: 431 RVA: 0x00003A86 File Offset: 0x00001C86
		public int RoundCount { get; set; }

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x060001B0 RID: 432 RVA: 0x00003A8F File Offset: 0x00001C8F
		// (set) Token: 0x060001B1 RID: 433 RVA: 0x00003A97 File Offset: 0x00001C97
		public int CurrentPhaseId { get; set; }

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x060001B2 RID: 434 RVA: 0x00003AA0 File Offset: 0x00001CA0
		// (set) Token: 0x060001B3 RID: 435 RVA: 0x00003AA8 File Offset: 0x00001CA8
		public DateTime NextPhase { get; set; }

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x060001B4 RID: 436 RVA: 0x00003AB1 File Offset: 0x00001CB1
		// (set) Token: 0x060001B5 RID: 437 RVA: 0x00003AB9 File Offset: 0x00001CB9
		public DateTime CurrentPhaseStarted { get; set; }

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060001B6 RID: 438 RVA: 0x00003AC2 File Offset: 0x00001CC2
		// (set) Token: 0x060001B7 RID: 439 RVA: 0x00003ACA File Offset: 0x00001CCA
		public string SponsorName { get; set; }

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x060001B8 RID: 440 RVA: 0x00003AD3 File Offset: 0x00001CD3
		// (set) Token: 0x060001B9 RID: 441 RVA: 0x00003ADB File Offset: 0x00001CDB
		public string SponsorImageUrl { get; set; }

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x060001BA RID: 442 RVA: 0x00003AE4 File Offset: 0x00001CE4
		// (set) Token: 0x060001BB RID: 443 RVA: 0x00003AEC File Offset: 0x00001CEC
		public string TournamentName { get; set; }

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x060001BC RID: 444 RVA: 0x00003AF5 File Offset: 0x00001CF5
		// (set) Token: 0x060001BD RID: 445 RVA: 0x00003AFD File Offset: 0x00001CFD
		public string ReplayUrl { get; set; }

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x060001BE RID: 446 RVA: 0x00003B06 File Offset: 0x00001D06
		// (set) Token: 0x060001BF RID: 447 RVA: 0x00003B0E File Offset: 0x00001D0E
		public DateTime ReplayExpires { get; set; }

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x060001C0 RID: 448 RVA: 0x00003B17 File Offset: 0x00001D17
		// (set) Token: 0x060001C1 RID: 449 RVA: 0x00003B1F File Offset: 0x00001D1F
		public string StreamUrl { get; set; }

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x060001C2 RID: 450 RVA: 0x00003B28 File Offset: 0x00001D28
		// (set) Token: 0x060001C3 RID: 451 RVA: 0x00003B30 File Offset: 0x00001D30
		public string HighlightsUrl { get; set; }

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060001C4 RID: 452 RVA: 0x00003B39 File Offset: 0x00001D39
		// (set) Token: 0x060001C5 RID: 453 RVA: 0x00003B41 File Offset: 0x00001D41
		public bool HasAllDataLoaded { get; set; }

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060001C6 RID: 454 RVA: 0x00003B4A File Offset: 0x00001D4A
		// (set) Token: 0x060001C7 RID: 455 RVA: 0x00003B52 File Offset: 0x00001D52
		public string PolicyURL { get; set; }

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060001C8 RID: 456 RVA: 0x00003B5B File Offset: 0x00001D5B
		// (set) Token: 0x060001C9 RID: 457 RVA: 0x00003B63 File Offset: 0x00001D63
		public string IconUrl { get; set; }

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060001CA RID: 458 RVA: 0x00003B6C File Offset: 0x00001D6C
		// (set) Token: 0x060001CB RID: 459 RVA: 0x00003B74 File Offset: 0x00001D74
		public string ImageUrl { get; set; }

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x060001CC RID: 460 RVA: 0x00003B7D File Offset: 0x00001D7D
		// (set) Token: 0x060001CD RID: 461 RVA: 0x00003B85 File Offset: 0x00001D85
		public string ThemeColor { get; set; }

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x060001CE RID: 462 RVA: 0x00003B8E File Offset: 0x00001D8E
		// (set) Token: 0x060001CF RID: 463 RVA: 0x00003B96 File Offset: 0x00001D96
		public string Description { get; set; }

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x060001D0 RID: 464 RVA: 0x00003B9F File Offset: 0x00001D9F
		// (set) Token: 0x060001D1 RID: 465 RVA: 0x00003BA7 File Offset: 0x00001DA7
		public string AdditionalDescription { get; set; }

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060001D2 RID: 466 RVA: 0x00003BB0 File Offset: 0x00001DB0
		// (set) Token: 0x060001D3 RID: 467 RVA: 0x00003BB8 File Offset: 0x00001DB8
		public TournamentEntryFee EntryFee { get; set; }

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060001D4 RID: 468 RVA: 0x00003BC1 File Offset: 0x00001DC1
		// (set) Token: 0x060001D5 RID: 469 RVA: 0x00003BC9 File Offset: 0x00001DC9
		public List<TournamentPhase> Phases { get; set; }

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060001D6 RID: 470 RVA: 0x00003BD2 File Offset: 0x00001DD2
		// (set) Token: 0x060001D7 RID: 471 RVA: 0x00003BDA File Offset: 0x00001DDA
		public TournamentRequirements Requirements { get; set; }

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060001D8 RID: 472 RVA: 0x00003BE3 File Offset: 0x00001DE3
		// (set) Token: 0x060001D9 RID: 473 RVA: 0x00003BEB File Offset: 0x00001DEB
		public List<TournamentPrize> Prizes { get; set; }

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x060001DA RID: 474 RVA: 0x00003BF4 File Offset: 0x00001DF4
		// (set) Token: 0x060001DB RID: 475 RVA: 0x00003BFC File Offset: 0x00001DFC
		public TournamentMatch UserActiveMatch { get; set; }

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x060001DC RID: 476 RVA: 0x00003C05 File Offset: 0x00001E05
		// (set) Token: 0x060001DD RID: 477 RVA: 0x00003C0D File Offset: 0x00001E0D
		public List<TournamentMatch> UserMatches { get; set; }

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x060001DE RID: 478 RVA: 0x00003C16 File Offset: 0x00001E16
		// (set) Token: 0x060001DF RID: 479 RVA: 0x00003C1E File Offset: 0x00001E1E
		public List<TournamentMatch> AllMatches { get; set; }

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x060001E0 RID: 480 RVA: 0x00003C27 File Offset: 0x00001E27
		// (set) Token: 0x060001E1 RID: 481 RVA: 0x00003C2F File Offset: 0x00001E2F
		public DateTime LastUpdate { get; set; }

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x060001E2 RID: 482 RVA: 0x00003C38 File Offset: 0x00001E38
		// (set) Token: 0x060001E3 RID: 483 RVA: 0x00003C40 File Offset: 0x00001E40
		public int LastMatchRoundId { get; set; }

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x060001E4 RID: 484 RVA: 0x00003C49 File Offset: 0x00001E49
		// (set) Token: 0x060001E5 RID: 485 RVA: 0x00003C51 File Offset: 0x00001E51
		public TournamentParty Party { get; set; }

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x00003C5A File Offset: 0x00001E5A
		// (set) Token: 0x060001E7 RID: 487 RVA: 0x00003C62 File Offset: 0x00001E62
		public int PartySize { get; set; }

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x060001E8 RID: 488 RVA: 0x00003C6B File Offset: 0x00001E6B
		// (set) Token: 0x060001E9 RID: 489 RVA: 0x00003C73 File Offset: 0x00001E73
		public TournamentWinner Winner { get; set; }

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x060001EA RID: 490 RVA: 0x00003C7C File Offset: 0x00001E7C
		// (set) Token: 0x060001EB RID: 491 RVA: 0x00003C84 File Offset: 0x00001E84
		public TournamentInvite Invite { get; set; }

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x060001EC RID: 492 RVA: 0x00003C8D File Offset: 0x00001E8D
		// (set) Token: 0x060001ED RID: 493 RVA: 0x00003C95 File Offset: 0x00001E95
		public TournamentCustomProperties CustomProperties { get; set; }

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060001EE RID: 494 RVA: 0x00003C9E File Offset: 0x00001E9E
		// (set) Token: 0x060001EF RID: 495 RVA: 0x00003CA6 File Offset: 0x00001EA6
		public bool IsAdministrator { get; set; }

		// Token: 0x060001F0 RID: 496 RVA: 0x0000CEEC File Offset: 0x0000B0EC
		public Tournament()
		{
			this.UserMatches = new List<TournamentMatch>();
			this.AllMatches = new List<TournamentMatch>();
			this.EntryFee = new TournamentEntryFee();
			this.Phases = new List<TournamentPhase>();
			this.Requirements = new TournamentRequirements();
			this.Prizes = new List<TournamentPrize>();
			this.CustomProperties = new TournamentCustomProperties();
			this.userMatchesById = new Dictionary<long, TournamentMatch>();
			this.allMatchesById = new Dictionary<long, TournamentMatch>();
			this.phaseById = new Dictionary<int, TournamentPhase>();
			this.prizeByPlace = new Dictionary<int, TournamentPrize>();
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x0000CF84 File Offset: 0x0000B184
		internal List<TournamentMatch> LoadJsonAllMatches(JSONObject data)
		{
			List<TournamentMatch> list = null;
			bool flag = this.AllMatches.Count != this.allMatchesById.Count;
			if (flag)
			{
				this.allMatchesById.Clear();
				for (int i = 0; i < this.AllMatches.Count; i++)
				{
					long id = this.AllMatches[i].Id;
					bool flag2 = !this.allMatchesById.ContainsKey(id);
					if (flag2)
					{
						this.allMatchesById.Add(id, this.AllMatches[i]);
					}
				}
			}
			bool flag3 = !data.IsNull && data.IsArray;
			if (flag3)
			{
				list = new List<TournamentMatch>(data.Count);
				for (int j = 0; j < data.Count; j++)
				{
					JSONObject jsonobject = data[j];
					bool flag4 = jsonobject.HasField(TournamentMatch.FIELD_ID);
					if (flag4)
					{
						long key = long.Parse(jsonobject[TournamentMatch.FIELD_ID].str);
						bool flag5 = !this.allMatchesById.ContainsKey(key);
						TournamentMatch tournamentMatch;
						if (flag5)
						{
							tournamentMatch = new TournamentMatch();
							this.AllMatches.Add(tournamentMatch);
							this.allMatchesById.Add(key, tournamentMatch);
						}
						tournamentMatch = this.allMatchesById[key];
						tournamentMatch.MinCheckinsPerTeam = this.GetTournamentMatchMinCheckinsPerTeam(tournamentMatch);
						tournamentMatch.LoadJSONMatch(jsonobject);
						tournamentMatch.WinScore = this.GetTournamentMatchWinScore(tournamentMatch);
						tournamentMatch.MaxGameCount = this.GetTournamentMatchMaxGameCount(tournamentMatch);
						list.Add(tournamentMatch);
					}
				}
			}
			return list;
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x0000D13C File Offset: 0x0000B33C
		private void LoadJSONUserMatches(JSONObject data)
		{
			bool flag = this.UserMatches.Count != this.userMatchesById.Count;
			if (flag)
			{
				this.userMatchesById.Clear();
				for (int i = 0; i < this.UserMatches.Count; i++)
				{
					long id = this.UserMatches[i].Id;
					bool flag2 = !this.userMatchesById.ContainsKey(id);
					if (flag2)
					{
						this.userMatchesById.Add(id, this.UserMatches[i]);
					}
				}
			}
			bool flag3 = !data.IsNull && data.IsArray;
			if (flag3)
			{
				for (int j = 0; j < data.Count; j++)
				{
					JSONObject jsonobject = data[j];
					bool flag4 = jsonobject.HasField(TournamentMatch.FIELD_ID);
					if (flag4)
					{
						long key = long.Parse(jsonobject[TournamentMatch.FIELD_ID].str);
						bool flag5 = !this.userMatchesById.ContainsKey(key);
						TournamentMatch tournamentMatch;
						if (flag5)
						{
							tournamentMatch = new TournamentMatch();
							this.UserMatches.Add(tournamentMatch);
							this.userMatchesById.Add(key, tournamentMatch);
						}
						tournamentMatch = this.userMatchesById[key];
						tournamentMatch.MinCheckinsPerTeam = this.GetTournamentMatchMinCheckinsPerTeam(tournamentMatch);
						tournamentMatch.LoadJSONMatch(jsonobject);
						tournamentMatch.WinScore = this.GetTournamentMatchWinScore(tournamentMatch);
						tournamentMatch.MaxGameCount = this.GetTournamentMatchMaxGameCount(tournamentMatch);
					}
				}
			}
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x0000D2D4 File Offset: 0x0000B4D4
		private void LoadJSONUserMatch(JSONObject data)
		{
			bool flag = !data.IsNull;
			if (flag)
			{
				long key = 0L;
				bool flag2 = data.HasField(Tournament.FIELD_ID) && !data[Tournament.FIELD_ID].IsNull;
				if (flag2)
				{
					key = long.Parse(data[Tournament.FIELD_ID].str);
				}
				bool flag3 = !this.userMatchesById.ContainsKey(key);
				if (flag3)
				{
					this.UserActiveMatch = new TournamentMatch();
					this.UserMatches.Add(this.UserActiveMatch);
					this.userMatchesById.Add(key, this.UserActiveMatch);
				}
				else
				{
					this.UserActiveMatch = this.userMatchesById[key];
				}
				this.UserActiveMatch.MinCheckinsPerTeam = this.GetTournamentMatchMinCheckinsPerTeam(this.UserActiveMatch);
				this.UserActiveMatch.LoadJSONMatch(data);
				this.UserActiveMatch.WinScore = this.GetTournamentMatchWinScore(this.UserActiveMatch);
				this.UserActiveMatch.MaxGameCount = this.GetTournamentMatchMaxGameCount(this.UserActiveMatch);
			}
			else
			{
				this.UserActiveMatch = null;
			}
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0000D3F4 File Offset: 0x0000B5F4
		private void LoadJSONUserPosition(JSONObject data)
		{
			bool flag = !data.IsNull && data.IsArray;
			if (flag)
			{
				for (int i = 0; i < data.Count; i++)
				{
					JSONObject jsonobject = data[i];
					bool flag2 = jsonobject.HasField(Tournament.FIELD_USERPOSITION_PHASEID) && jsonobject.HasField(Tournament.FIELD_USERPOSITION_RANKPOSITION) && jsonobject.HasField(Tournament.FIELD_USERPOSITION_SAMEPOSITION) && jsonobject.HasField(Tournament.FIELD_USERPOSITION_MATCHLOSES) && jsonobject.HasField(Tournament.FIELD_USERPOSITION_GROUPID);
					if (flag2)
					{
						int phaseId = (int)jsonobject[Tournament.FIELD_USERPOSITION_PHASEID].f;
						int num = (int)jsonobject[Tournament.FIELD_USERPOSITION_RANKPOSITION].f;
						int userPositionTop = num - (int)jsonobject[Tournament.FIELD_USERPOSITION_SAMEPOSITION].f;
						int userLoses = (int)jsonobject[Tournament.FIELD_USERPOSITION_MATCHLOSES].f;
						int userPoints = (int)jsonobject[Tournament.FIELD_USERPOSITION_TOTALPOINTS].f;
						int userPlayedRoundCount = (int)jsonobject[Tournament.FIELD_USERPOSITION_TOTALROUNDS].f;
						int userGroupId = (int)jsonobject[Tournament.FIELD_USERPOSITION_GROUPID].f;
						TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(phaseId);
						bool flag3 = tournamentPhaseById != null;
						if (flag3)
						{
							tournamentPhaseById.UserPositionTop = userPositionTop;
							tournamentPhaseById.UserPositionBottom = num;
							tournamentPhaseById.UserLoses = userLoses;
							tournamentPhaseById.UserPoints = userPoints;
							tournamentPhaseById.UserPlayedRoundCount = userPlayedRoundCount;
							tournamentPhaseById.UserIsParticipating = true;
							tournamentPhaseById.UserGroupId = userGroupId;
						}
					}
				}
			}
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x0000D574 File Offset: 0x0000B774
		private void LoadJSONPartyUsers(JSONObject data)
		{
			bool flag = this.Party != null && !data.IsNull && data.IsArray;
			if (flag)
			{
				this.Party.LoadJSONPartyUsers(data);
			}
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x0000D5B0 File Offset: 0x0000B7B0
		private void LoadJSONParty(JSONObject data)
		{
			bool flag = data.HasField(TournamentParty.FIELD_DATA_PARTYID) && !data[TournamentParty.FIELD_DATA_PARTYID].IsNull;
			if (flag)
			{
				bool flag2 = this.Party == null;
				if (flag2)
				{
					this.Party = new TournamentParty();
				}
				this.Party.LoadJSONParty(data);
			}
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x0000D610 File Offset: 0x0000B810
		private void LoadJSONInvite(JSONObject data)
		{
			bool flag = data.HasField(TournamentInvite.FIELD_INVITEID) && !data[TournamentInvite.FIELD_INVITEID].IsNull;
			if (flag)
			{
				bool flag2 = this.Invite == null;
				if (flag2)
				{
					this.Invite = new TournamentInvite();
				}
				this.Invite.LoadJsonInvite(data);
			}
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x0000D670 File Offset: 0x0000B870
		internal void LoadJsonTournamentData(JSONObject data)
		{
			bool flag = !data.HasField("id") || data["id"].str != this.Id.ToString();
			if (!flag)
			{
				bool flag2 = data.HasField(Tournament.FIELD_TYPE);
				if (flag2)
				{
					this.Type = data[Tournament.FIELD_TYPE].ToEnum(TournamentType.GenericTournament);
				}
				bool flag3 = data.HasField(Tournament.FIELD_CURRENTPHASEID);
				if (flag3)
				{
					bool flag4 = this.CurrentPhaseId != (int)data[Tournament.FIELD_CURRENTPHASEID].f;
					if (flag4)
					{
						this.LastMatchRoundId = 0;
					}
					this.CurrentPhaseId = (int)data[Tournament.FIELD_CURRENTPHASEID].f;
				}
				bool flag5 = data.HasField(Tournament.FIELD_STATUS);
				if (flag5)
				{
					TournamentStatus tournamentStatus = data[Tournament.FIELD_STATUS].ToEnum(TournamentStatus.Unknown);
					bool flag6 = tournamentStatus == TournamentStatus.InvitationClose && this.CurrentPhaseId > 0;
					if (flag6)
					{
						tournamentStatus = TournamentStatus.Running;
					}
					bool flag7 = tournamentStatus != this.Status;
					if (flag7)
					{
						this.LastMatchRoundId = 0;
					}
					this.Status = tournamentStatus;
				}
				bool flag8 = data.HasField(Tournament.FIELD_TOURNAMENTTIME);
				if (flag8)
				{
					this.Time = data[Tournament.FIELD_TOURNAMENTTIME].ToUniversalTime();
				}
				bool flag9 = data.HasField(Tournament.FIELD_SEASON);
				if (flag9)
				{
					this.Season = (int)data[Tournament.FIELD_SEASON].f;
				}
				bool flag10 = data.HasField(Tournament.FIELD_SEASONPART);
				if (flag10)
				{
					this.SeasonPart = (int)data[Tournament.FIELD_SEASONPART].f;
				}
				bool flag11 = data.HasField(Tournament.FIELD_INVITATIONOPENS);
				if (flag11)
				{
					this.InvitationOpenTime = data[Tournament.FIELD_INVITATIONOPENS].ToUniversalTime();
				}
				bool flag12 = data.HasField(Tournament.FIELD_INVITATIONCLOSES);
				if (flag12)
				{
					this.InvitationCloseTime = data[Tournament.FIELD_INVITATIONCLOSES].ToUniversalTime();
				}
				bool flag13 = data.HasField(Tournament.FIELD_REGISTRATIONOPENS) && !data[Tournament.FIELD_REGISTRATIONOPENS].IsNull;
				if (flag13)
				{
					this.IsInvitationOnly = false;
					int num = (int)data[Tournament.FIELD_REGISTRATIONOPENS].f;
					this.RegistrationOpenTime = this.InvitationOpenTime.AddHours((double)num);
				}
				else
				{
					this.IsInvitationOnly = true;
				}
				bool flag14 = data.HasField(Tournament.FIELD_MAXINVITES);
				if (flag14)
				{
					this.MaxInvites = (int)data[Tournament.FIELD_MAXINVITES].f;
				}
				bool flag15 = data.HasField(Tournament.FIELD_PARTYSIZE);
				if (flag15)
				{
					this.PartySize = (int)data[Tournament.FIELD_PARTYSIZE].f;
				}
				bool flag16 = data.HasField(Tournament.FIELD_CURRENTINVITES);
				if (flag16)
				{
					this.CurrentInvites = (int)data[Tournament.FIELD_CURRENTINVITES].f;
				}
				bool flag17 = data.HasField(Tournament.FIELD_PHASECOUNT);
				if (flag17)
				{
					this.PhaseCount = (int)data[Tournament.FIELD_PHASECOUNT].f;
				}
				bool flag18 = data.HasField(Tournament.FIELD_ROUNDCOUNT);
				if (flag18)
				{
					this.RoundCount = (int)data[Tournament.FIELD_ROUNDCOUNT].f;
				}
				bool flag19 = data.HasField(Tournament.FIELD_SPONSORNAME);
				if (flag19)
				{
					this.SponsorName = data[Tournament.FIELD_SPONSORNAME].str;
				}
				bool flag20 = data.HasField(Tournament.FIELD_SPONSORIMAGE);
				if (flag20)
				{
					this.SponsorImageUrl = data[Tournament.FIELD_SPONSORIMAGE].str;
				}
				bool flag21 = data.HasField(Tournament.FIELD_NAME);
				if (flag21)
				{
					this.TournamentName = data[Tournament.FIELD_NAME].str;
				}
				bool flag22 = data.HasField(Tournament.FIELD_CURRENTPHASESTARTED);
				if (flag22)
				{
					this.CurrentPhaseStarted = data[Tournament.FIELD_CURRENTPHASESTARTED].ToUniversalTime();
				}
				bool flag23 = data.HasField(Tournament.FIELD_NEXTPHASE);
				if (flag23)
				{
					this.NextPhase = data[Tournament.FIELD_NEXTPHASE].ToUniversalTime();
				}
				bool flag24 = data.HasField(Tournament.FIELD_IMAGE);
				if (flag24)
				{
					this.ImageUrl = data[Tournament.FIELD_IMAGE].str;
				}
				bool flag25 = data.HasField(Tournament.FIELD_ICON);
				if (flag25)
				{
					this.IconUrl = data[Tournament.FIELD_ICON].str;
				}
				bool flag26 = data.HasField(Tournament.FIELD_THEMECOLOR);
				if (flag26)
				{
					this.ThemeColor = data[Tournament.FIELD_THEMECOLOR].str;
				}
				bool flag27 = data.HasField(Tournament.FIELD_HIGHLIGHTS);
				if (flag27)
				{
					bool isNull = data[Tournament.FIELD_HIGHLIGHTS].IsNull;
					if (isNull)
					{
						this.HighlightsUrl = null;
					}
					else
					{
						this.HighlightsUrl = data[Tournament.FIELD_HIGHLIGHTS].str;
					}
				}
				bool flag28 = data.HasField(Tournament.FIELD_STREAMURL);
				if (flag28)
				{
					bool isNull2 = data[Tournament.FIELD_STREAMURL].IsNull;
					if (isNull2)
					{
						this.StreamUrl = null;
					}
					else
					{
						this.StreamUrl = data[Tournament.FIELD_STREAMURL].str;
					}
				}
				bool flag29 = data.HasField(Tournament.FIELD_ISADMINISTRATOR);
				if (flag29)
				{
					this.IsAdministrator = data[Tournament.FIELD_ISADMINISTRATOR].b;
				}
				bool flag30 = data.HasField(Tournament.FIELD_DATA) && !data[Tournament.FIELD_DATA].IsNull;
				if (flag30)
				{
					JSONObject jsonobject = data[Tournament.FIELD_DATA][Tournament.FIELD_DATA_TOURNAMENTDATA];
					JSONObject jsonobject2 = jsonobject[Tournament.FIELD_DATA_INVITATIONSETTING][0];
					bool flag31 = jsonobject2.HasField(Tournament.FIELD_DATA_REQUIREMENTS);
					if (flag31)
					{
						JSONObject jsonobject3 = jsonobject2[Tournament.FIELD_DATA_REQUIREMENTS][0];
						this.Requirements.CustomRequirements.Clear();
						bool flag32 = jsonobject3.HasField(Tournament.FIELD_DATA_CUSTOMREQUIREMENT);
						if (flag32)
						{
							JSONObject jsonobject4 = jsonobject3[Tournament.FIELD_DATA_CUSTOMREQUIREMENT];
							for (int i = 0; i < jsonobject4.Count; i++)
							{
								JSONObject jsonobject5 = jsonobject4[i];
								bool flag33 = jsonobject5.HasField(Tournament.FIELD_DATA_CUSTOMREQUIREMENT_NAME);
								if (flag33)
								{
									string str = jsonobject5[Tournament.FIELD_DATA_CUSTOMREQUIREMENT_NAME].str;
									string value = null;
									bool flag34 = jsonobject5.HasField(Tournament.FIELD_DATA_CUSTOMREQUIREMENT_VALUE);
									if (flag34)
									{
										value = jsonobject5[Tournament.FIELD_DATA_CUSTOMREQUIREMENT_VALUE].str;
									}
									bool flag35 = !this.Requirements.CustomRequirements.ContainsKey(str);
									if (flag35)
									{
										this.Requirements.CustomRequirements.Add(str, value);
									}
								}
							}
						}
					}
					bool flag36 = jsonobject2.HasField(TournamentEntryFee.FIELD_DATA_ENTRYFEE);
					if (flag36)
					{
						this.EntryFee.LoadJSONEntryFee(jsonobject2[TournamentEntryFee.FIELD_DATA_ENTRYFEE][0]);
					}
					bool flag37 = jsonobject.HasField(Tournament.FIELD_DATA_RULESSETTING);
					if (flag37)
					{
						JSONObject jsonobject6 = jsonobject[Tournament.FIELD_DATA_RULESSETTING][0];
						JSONObject jsonobject7 = jsonobject6[Tournament.FIELD_DATA_PHASE];
						bool flag38 = this.Phases.Count != jsonobject7.Count;
						if (flag38)
						{
							this.Phases.Clear();
							this.phaseById.Clear();
						}
						else
						{
							bool flag39 = this.Phases.Count != this.phaseById.Count;
							if (flag39)
							{
								for (int j = 0; j < this.Phases.Count; j++)
								{
									bool flag40 = !this.phaseById.ContainsKey(this.Phases[j].Id);
									if (flag40)
									{
										this.phaseById.Add(this.Phases[j].Id, this.Phases[j]);
									}
								}
							}
						}
						for (int k = 0; k < jsonobject7.Count; k++)
						{
							JSONObject jsonobject8 = jsonobject7[k];
							int num2 = int.Parse(jsonobject8[Tournament.FIELD_DATA_ID].str);
							TournamentPhaseType type = (TournamentPhaseType)(Enum.IsDefined(typeof(TournamentPhaseType), int.Parse(jsonobject8[Tournament.FIELD_DATA_TYPE].str)) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_TYPE].str) : 1);
							int num3 = jsonobject8.HasField(Tournament.FIELD_DATA_ALLOWEDREBUYCOUNT) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_ALLOWEDREBUYCOUNT].str) : 0;
							int num4 = jsonobject8.HasField(Tournament.FIELD_DATA_ALLOWEDREBUYUNTILROUNDID) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_ALLOWEDREBUYUNTILROUNDID].str) : 0;
							int num5 = jsonobject8.HasField(Tournament.FIELD_DATA_REBUYPRICE) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_REBUYPRICE].str) : 0;
							int num6 = jsonobject8.HasField(Tournament.FIELD_DATA_MAXTEAMS) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_MAXTEAMS].str) : 0;
							int minTeamsPerMatch = jsonobject8.HasField(Tournament.FIELD_DATA_MINTEAMSPERMATCH) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_MINTEAMSPERMATCH].str) : 0;
							int maxTeamsPerMatch = jsonobject8.HasField(Tournament.FIELD_DATA_MAXTEAMSPERMATCH) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_MAXTEAMSPERMATCH].str) : 0;
							int minCheckinsPerTeam = jsonobject8.HasField(Tournament.FIELD_DATA_MINCHECKINSPERTEAM) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_MINCHECKINSPERTEAM].str) : 1;
							int groupCount = jsonobject8.HasField(Tournament.FIELD_DATA_GROUPCOUNT) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_GROUPCOUNT].str) : 0;
							bool isLoserBracketSeeded = jsonobject8.HasField(Tournament.FIELD_DATA_SEEDLOSERBRACKET) && int.Parse(jsonobject8[Tournament.FIELD_DATA_SEEDLOSERBRACKET].str) == 1;
							bool isSkipAllowed = jsonobject8.HasField(Tournament.FIELD_DATA_ALLOWSKIP) && int.Parse(jsonobject8[Tournament.FIELD_DATA_ALLOWSKIP].str) == 1;
							string text = jsonobject8.HasField(Tournament.FIELD_DATA_GAMEPOINTDISTRIBUTION) ? jsonobject8[Tournament.FIELD_DATA_GAMEPOINTDISTRIBUTION].str : string.Empty;
							string text2 = jsonobject8.HasField(Tournament.FIELD_DATA_MATCHPOINTDISTRIBUTION) ? jsonobject8[Tournament.FIELD_DATA_MATCHPOINTDISTRIBUTION].str : string.Empty;
							int maxLoses;
							switch (type)
							{
							case TournamentPhaseType.Arena:
							case TournamentPhaseType.RoundRobin:
								maxLoses = (jsonobject8.HasField(Tournament.FIELD_DATA_MAXLOSES) ? int.Parse(jsonobject8[Tournament.FIELD_DATA_MAXLOSES].str) : 0);
								break;
							case TournamentPhaseType.SingleEliminationBracket:
							case TournamentPhaseType.DynamicBrackets:
								maxLoses = 1;
								break;
							case TournamentPhaseType.DoubleEliminationBracket:
								maxLoses = 2;
								break;
							default:
								maxLoses = 0;
								break;
							}
							JSONObject jsonobject9 = jsonobject8[Tournament.FIELD_DATA_ROUND];
							bool flag41 = !this.phaseById.ContainsKey(num2);
							TournamentPhase tournamentPhase;
							if (flag41)
							{
								tournamentPhase = new TournamentPhase();
								tournamentPhase.Id = num2;
								this.Phases.Add(tournamentPhase);
								this.phaseById.Add(tournamentPhase.Id, tournamentPhase);
							}
							else
							{
								tournamentPhase = this.phaseById[num2];
							}
							tournamentPhase.Type = type;
							tournamentPhase.MinTeamsPerMatch = minTeamsPerMatch;
							tournamentPhase.MaxTeamsPerMatch = maxTeamsPerMatch;
							tournamentPhase.MinCheckinsPerTeam = minCheckinsPerTeam;
							tournamentPhase.MaxPlayers = num6 * this.PartySize;
							tournamentPhase.MaxTeams = num6;
							tournamentPhase.MaxLoses = maxLoses;
							tournamentPhase.GroupCount = groupCount;
							tournamentPhase.UserPositionTop = 0;
							tournamentPhase.UserPositionBottom = 0;
							tournamentPhase.UserLoses = 0;
							tournamentPhase.UserPoints = 0;
							tournamentPhase.UserPlayedRoundCount = 0;
							tournamentPhase.UserIsParticipating = false;
							tournamentPhase.UserGroupId = 0;
							tournamentPhase.IsLoserBracketSeeded = isLoserBracketSeeded;
							tournamentPhase.IsSkipAllowed = isSkipAllowed;
							bool flag42 = tournamentPhase.Rounds.Count != jsonobject9.Count;
							if (flag42)
							{
								tournamentPhase.Rounds.Clear();
							}
							for (int l = 0; l < jsonobject9.Count; l++)
							{
								JSONObject jsonobject10 = jsonobject9[l];
								int num7 = jsonobject10.HasField(Tournament.FIELD_DATA_ID) ? int.Parse(jsonobject10[Tournament.FIELD_DATA_ID].str) : 0;
								int maxLength = jsonobject10.HasField(Tournament.FIELD_DATA_MAXLENGTH) ? int.Parse(jsonobject10[Tournament.FIELD_DATA_MAXLENGTH].str) : 0;
								int minGameLength = jsonobject10.HasField(Tournament.FIELD_DATA_MINGAMELENGTH) ? int.Parse(jsonobject10[Tournament.FIELD_DATA_MINGAMELENGTH].str) : 2;
								int winScore = jsonobject10.HasField(Tournament.FIELD_DATA_WINSCORE) ? int.Parse(jsonobject10[Tournament.FIELD_DATA_WINSCORE].str) : 0;
								int maxGameCount = jsonobject10.HasField(Tournament.FIELD_DATA_MAXGAMECOUNT) ? int.Parse(jsonobject10[Tournament.FIELD_DATA_MAXGAMECOUNT].str) : 0;
								string gamePointDistribution = jsonobject10.HasField(Tournament.FIELD_DATA_GAMEPOINTDISTRIBUTION) ? jsonobject10[Tournament.FIELD_DATA_GAMEPOINTDISTRIBUTION].str : text;
								string matchPointDistribution = jsonobject10.HasField(Tournament.FIELD_DATA_MATCHPOINTDISTRIBUTION) ? jsonobject10[Tournament.FIELD_DATA_MATCHPOINTDISTRIBUTION].str : text2;
								TournamentRound tournamentRound = tournamentPhase.GetRoundById(num7);
								bool flag43 = tournamentRound == null;
								if (flag43)
								{
									tournamentRound = new TournamentRound();
									tournamentRound.Id = num7;
									tournamentPhase.Rounds.Add(tournamentRound);
								}
								tournamentRound.MaxLength = maxLength;
								tournamentRound.WinScore = winScore;
								tournamentRound.MinGameLength = minGameLength;
								tournamentRound.MaxGameCount = maxGameCount;
								tournamentRound.LoadGamePointDistribution(gamePointDistribution);
								tournamentRound.LoadMatchPointDistribution(matchPointDistribution);
							}
						}
					}
					bool flag44 = jsonobject.HasField(Tournament.FIELD_DATA_PRIZESETTING);
					if (flag44)
					{
						JSONObject jsonobject11 = jsonobject[Tournament.FIELD_DATA_PRIZESETTING][0];
						bool flag45 = jsonobject11.HasField(Tournament.FIELD_DATA_REWARD);
						if (flag45)
						{
							JSONObject jsonobject12 = jsonobject11[Tournament.FIELD_DATA_REWARD];
							bool flag46 = this.Prizes.Count != jsonobject12.Count;
							if (flag46)
							{
								this.Prizes.Clear();
								this.prizeByPlace.Clear();
							}
							else
							{
								bool flag47 = this.Prizes.Count != this.prizeByPlace.Count;
								if (flag47)
								{
									for (int m = 0; m < this.Prizes.Count; m++)
									{
										bool flag48 = !this.prizeByPlace.ContainsKey(this.Prizes[m].ToPlace);
										if (flag48)
										{
											this.prizeByPlace.Add(this.Prizes[m].ToPlace, this.Prizes[m]);
										}
									}
								}
							}
							int fromPlace = 1;
							for (int n = 0; n < jsonobject12.Count; n++)
							{
								JSONObject jsonobject13 = jsonobject12[n];
								int num8 = int.Parse(jsonobject13[TournamentPrize.FIELD_DATA_POSITION].str);
								bool flag49 = !this.prizeByPlace.ContainsKey(num8);
								TournamentPrize tournamentPrize;
								if (flag49)
								{
									tournamentPrize = new TournamentPrize();
									tournamentPrize.ToPlace = num8;
									this.Prizes.Add(tournamentPrize);
									this.prizeByPlace.Add(tournamentPrize.ToPlace, tournamentPrize);
								}
								else
								{
									tournamentPrize = this.prizeByPlace[num8];
								}
								tournamentPrize.FromPlace = fromPlace;
								fromPlace = tournamentPrize.ToPlace + 1;
								tournamentPrize.LoadJsonPrize(jsonobject13, this.EntryFee, this.CurrentInvites);
							}
						}
						else
						{
							this.Prizes.Clear();
							this.prizeByPlace.Clear();
						}
					}
					bool flag50 = jsonobject.HasField(Tournament.FIELD_DATA_DESCRIPTIONDATA);
					if (flag50)
					{
						JSONObject jsonobject14 = jsonobject[Tournament.FIELD_DATA_DESCRIPTIONDATA][0][Tournament.FIELD_DATA_LANGUAGE][0];
						string text3 = jsonobject14.HasField(Tournament.FIELD_DATA_CODE) ? jsonobject14[Tournament.FIELD_DATA_CODE].str : null;
						this.PolicyURL = ((jsonobject14.HasField(Tournament.FIELD_DATA_POLICY) && jsonobject14[Tournament.FIELD_DATA_POLICY][0].HasField(Tournament.FIELD_DATA_URL)) ? jsonobject14[Tournament.FIELD_DATA_POLICY][0][Tournament.FIELD_DATA_URL].str : null);
						this.TournamentName = (jsonobject14.HasField(Tournament.FIELD_DATA_NAME) ? jsonobject14[Tournament.FIELD_DATA_NAME][0][Tournament.FIELD_DATA_HTEXT][0][Tournament.FIELD_DATA_HVALUE].str : null);
						this.Description = (jsonobject14.HasField(Tournament.FIELD_DATA_DESCRIPTION) ? jsonobject14[Tournament.FIELD_DATA_DESCRIPTION][0][Tournament.FIELD_DATA_HTEXT][0][Tournament.FIELD_DATA_HVALUE].str : null);
						this.AdditionalDescription = (jsonobject14.HasField(Tournament.FIELD_DATA_ADDITIONALDESCRIPTION) ? jsonobject14[Tournament.FIELD_DATA_ADDITIONALDESCRIPTION][0][Tournament.FIELD_DATA_HTEXT][0][Tournament.FIELD_DATA_HVALUE].str : null);
					}
					bool flag51 = jsonobject.HasField(TournamentCustomProperties.FIELD_DATA_PROPERTYSETTING);
					if (flag51)
					{
						this.CustomProperties.LoadJsonCusomProperties(jsonobject);
					}
					bool flag52 = jsonobject.HasField(Tournament.FIELD_DATA_STREAMDATA);
					if (flag52)
					{
						JSONObject jsonobject15 = jsonobject[Tournament.FIELD_DATA_STREAMDATA][0];
						this.StreamUrl = (jsonobject15.HasField(Tournament.FIELD_DATA_STREAMLINK) ? jsonobject15[Tournament.FIELD_DATA_STREAMLINK].str : null);
					}
					bool flag53 = jsonobject.HasField(Tournament.FIELD_DATA_REPLAYDATA);
					if (flag53)
					{
						JSONObject jsonobject16 = jsonobject[Tournament.FIELD_DATA_REPLAYDATA][0];
						this.ReplayUrl = (jsonobject16.HasField(Tournament.FIELD_DATA_REPLAYLINK) ? jsonobject16[Tournament.FIELD_DATA_REPLAYLINK].str : null);
						bool flag54 = jsonobject16.HasField(Tournament.FIELD_DATA_REPLAYEXPIRES);
						if (flag54)
						{
							DateTime dateTime;
							DateTime.TryParse(jsonobject16[Tournament.FIELD_DATA_REPLAYEXPIRES].str, out dateTime);
							this.ReplayExpires = dateTime.ToUniversalTime();
						}
						this.HighlightsUrl = (jsonobject16.HasField(Tournament.FIELD_DATA_HIGHLIGHTSLINK) ? jsonobject16[Tournament.FIELD_DATA_HIGHLIGHTSLINK].str : null);
					}
					bool flag55 = jsonobject.HasField(TournamentWinner.FIELD_WINNERDATA);
					if (flag55)
					{
						bool flag56 = this.Winner == null;
						if (flag56)
						{
							this.Winner = new TournamentWinner();
						}
						this.Winner.LoadJSONWinners(jsonobject);
					}
					else
					{
						this.Winner = null;
					}
				}
				this.LoadJSONParty(data);
				this.LoadJSONInvite(data);
			}
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x0000E97C File Offset: 0x0000CB7C
		internal void LoadJsonTournamentFull(JSONObject data, bool containsAllData)
		{
			if (containsAllData)
			{
				this.HasAllDataLoaded = true;
			}
			bool flag = data.HasField(Tournament.FIELD_TOURNAMENTDATA) && containsAllData;
			if (flag)
			{
				this.LoadJsonTournamentData(data[Tournament.FIELD_TOURNAMENTDATA][0]);
			}
			bool flag2 = data.HasField(Tournament.FIELD_USERPARTY) && containsAllData;
			if (flag2)
			{
				this.LoadJSONPartyUsers(data[Tournament.FIELD_USERPARTY]);
			}
			bool flag3 = data.HasField(Tournament.FIELD_USERMATCH);
			if (flag3)
			{
				this.LoadJSONUserMatch(data[Tournament.FIELD_USERMATCH]);
			}
			bool flag4 = data.HasField(Tournament.FIELD_USERMATCHES) && containsAllData;
			if (flag4)
			{
				this.LoadJSONUserMatches(data[Tournament.FIELD_USERMATCHES]);
			}
			bool flag5 = data.HasField(Tournament.FIELD_USERPOSITION) && containsAllData;
			if (flag5)
			{
				this.LoadJSONUserPosition(data[Tournament.FIELD_USERPOSITION]);
			}
		}

		// Token: 0x060001FA RID: 506 RVA: 0x0000EA5C File Offset: 0x0000CC5C
		public TournamentPhase GetTournamentPhaseById(int phaseId)
		{
			bool flag = this.Phases.Count != this.phaseById.Count;
			if (flag)
			{
				for (int i = 0; i < this.Phases.Count; i++)
				{
					bool flag2 = !this.phaseById.ContainsKey(this.Phases[i].Id);
					if (flag2)
					{
						this.phaseById.Add(this.Phases[i].Id, this.Phases[i]);
					}
				}
			}
			bool flag3 = this.phaseById.ContainsKey(phaseId);
			TournamentPhase result;
			if (flag3)
			{
				result = this.phaseById[phaseId];
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060001FB RID: 507 RVA: 0x0000EB20 File Offset: 0x0000CD20
		public TournamentPhase GetCurrentTournamentPhase()
		{
			return this.GetTournamentPhaseById(this.CurrentPhaseId);
		}

		// Token: 0x060001FC RID: 508 RVA: 0x0000EB40 File Offset: 0x0000CD40
		public int GetTournamentPhaseMaxLength(int phaseId)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(phaseId);
			bool flag = tournamentPhaseById != null;
			int result;
			if (flag)
			{
				result = tournamentPhaseById.Rounds.Sum((TournamentRound round) => round.MaxLength);
			}
			else
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x060001FD RID: 509 RVA: 0x0000EB94 File Offset: 0x0000CD94
		public DateTime GetTournamentPhaseStartTime(int phaseId)
		{
			bool flag = this.CurrentPhaseId == phaseId;
			DateTime result;
			if (flag)
			{
				result = this.CurrentPhaseStarted;
			}
			else
			{
				DateTime dateTime = this.Time;
				for (int i = 1; i < phaseId; i++)
				{
					bool flag2 = this.CurrentPhaseId == i;
					if (flag2)
					{
						dateTime = this.CurrentPhaseStarted;
					}
					dateTime = dateTime.AddMinutes((double)this.GetTournamentPhaseMaxLength(i));
				}
				result = dateTime;
			}
			return result;
		}

		// Token: 0x060001FE RID: 510 RVA: 0x0000EC04 File Offset: 0x0000CE04
		public DateTime GetTournamentPhaseFinishTime(int phaseId)
		{
			bool flag = this.CurrentPhaseId == phaseId;
			DateTime result;
			if (flag)
			{
				result = this.CurrentPhaseStarted.AddMinutes((double)this.GetTournamentPhaseMaxLength(phaseId));
			}
			else
			{
				DateTime dateTime = this.Time;
				for (int i = 1; i <= phaseId; i++)
				{
					bool flag2 = this.CurrentPhaseId == i;
					if (flag2)
					{
						dateTime = this.CurrentPhaseStarted;
					}
					dateTime = dateTime.AddMinutes((double)this.GetTournamentPhaseMaxLength(i));
				}
				result = dateTime;
			}
			return result;
		}

		// Token: 0x060001FF RID: 511 RVA: 0x0000EC8C File Offset: 0x0000CE8C
		public DateTime GetTournamentPhaseRoundStartTime(int phaseId, int roundId)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(phaseId);
			DateTime result = this.GetTournamentPhaseStartTime(phaseId);
			for (int i = 0; i < tournamentPhaseById.Rounds.Count; i++)
			{
				TournamentRound tournamentRound = tournamentPhaseById.Rounds[i];
				bool flag = tournamentRound.Id < roundId;
				if (flag)
				{
					result = result.AddMinutes((double)tournamentRound.MaxLength);
				}
			}
			return result;
		}

		// Token: 0x06000200 RID: 512 RVA: 0x0000ECFC File Offset: 0x0000CEFC
		public DateTime GetTournamentPhaseRoundFinishTime(int phaseId, int roundId)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(phaseId);
			DateTime result = this.GetTournamentPhaseStartTime(phaseId);
			for (int i = 0; i < tournamentPhaseById.Rounds.Count; i++)
			{
				TournamentRound tournamentRound = tournamentPhaseById.Rounds[i];
				bool flag = tournamentRound.Id <= roundId;
				if (flag)
				{
					result = result.AddMinutes((double)tournamentRound.MaxLength);
				}
			}
			return result;
		}

		// Token: 0x06000201 RID: 513 RVA: 0x0000ED70 File Offset: 0x0000CF70
		public TournamentMatch GetTournamentMatchById(long tournamentMatchId)
		{
			bool flag = this.UserMatches.Count != this.userMatchesById.Count;
			if (flag)
			{
				this.userMatchesById.Clear();
				for (int i = 0; i < this.UserMatches.Count; i++)
				{
					long id = this.UserMatches[i].Id;
					bool flag2 = !this.userMatchesById.ContainsKey(id);
					if (flag2)
					{
						this.userMatchesById.Add(id, this.UserMatches[i]);
					}
				}
			}
			bool flag3 = this.AllMatches.Count != this.allMatchesById.Count;
			if (flag3)
			{
				this.allMatchesById.Clear();
				for (int j = 0; j < this.AllMatches.Count; j++)
				{
					long id2 = this.AllMatches[j].Id;
					bool flag4 = !this.allMatchesById.ContainsKey(id2);
					if (flag4)
					{
						this.allMatchesById.Add(id2, this.AllMatches[j]);
					}
				}
			}
			bool flag5 = this.userMatchesById.ContainsKey(tournamentMatchId);
			TournamentMatch result;
			if (flag5)
			{
				result = this.userMatchesById[tournamentMatchId];
			}
			else
			{
				bool flag6 = this.allMatchesById.ContainsKey(tournamentMatchId);
				if (flag6)
				{
					result = this.allMatchesById[tournamentMatchId];
				}
				else
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06000202 RID: 514 RVA: 0x0000EEF0 File Offset: 0x0000D0F0
		public int GetTournamentMatchWinScore(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null;
			if (flag)
			{
				TournamentRound roundById = tournamentPhaseById.GetRoundById(match.RoundId);
				bool flag2 = roundById != null;
				if (flag2)
				{
					return roundById.WinScore;
				}
			}
			return 0;
		}

		// Token: 0x06000203 RID: 515 RVA: 0x0000EF3C File Offset: 0x0000D13C
		public int GetTournamentMatchMaxGameCount(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null;
			if (flag)
			{
				TournamentRound roundById = tournamentPhaseById.GetRoundById(match.RoundId);
				bool flag2 = roundById != null;
				if (flag2)
				{
					return roundById.MaxGameCount;
				}
			}
			return 0;
		}

		// Token: 0x06000204 RID: 516 RVA: 0x0000EF88 File Offset: 0x0000D188
		public int GetTournamentMatchMinCheckinsPerTeam(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null;
			int result;
			if (flag)
			{
				result = tournamentPhaseById.MinCheckinsPerTeam;
			}
			else
			{
				result = 1;
			}
			return result;
		}

		// Token: 0x06000205 RID: 517 RVA: 0x0000EFBC File Offset: 0x0000D1BC
		public Color GetThemeColor()
		{
			Color result;
			ColorUtility.TryParseHtmlString("#F1B221FF", ref result);
			bool flag = !string.IsNullOrEmpty(this.ThemeColor);
			if (flag)
			{
				bool flag2 = !ColorUtility.TryParseHtmlString(this.ThemeColor, ref result);
				if (flag2)
				{
					ColorUtility.TryParseHtmlString("#F1B221FF", ref result);
				}
			}
			return result;
		}

		// Token: 0x06000206 RID: 518 RVA: 0x0000F014 File Offset: 0x0000D214
		public int GetMatchMinGameLength(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null;
			if (flag)
			{
				TournamentRound roundById = tournamentPhaseById.GetRoundById(match.RoundId);
				bool flag2 = roundById != null;
				if (flag2)
				{
					return roundById.MinGameLength;
				}
			}
			return 2;
		}

		// Token: 0x06000207 RID: 519 RVA: 0x0000F060 File Offset: 0x0000D260
		[Obsolete("Use GetMatchNextGameFinishDeadline() instead.")]
		public DateTime GetMatchNextGameDeadline(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null;
			if (flag)
			{
				TournamentRound roundById = tournamentPhaseById.GetRoundById(match.RoundId);
				bool flag2 = roundById != null;
				if (flag2)
				{
					int num = Math.Max(1, match.MaxGameCount - match.CurrentGameCount);
					bool flag3 = match.Status == TournamentMatchStatus.WaitingForOpponent;
					if (flag3)
					{
						return match.Deadline.AddSeconds(-30.0).AddMinutes((double)roundById.MinGameLength);
					}
					return match.Deadline.AddSeconds(-30.0).AddMinutes((double)(-(double)((num - 1) * roundById.MinGameLength)));
				}
			}
			return match.Deadline.AddSeconds(-30.0);
		}

		// Token: 0x06000208 RID: 520 RVA: 0x0000F144 File Offset: 0x0000D344
		public DateTime GetMatchNextGameFinishDeadline(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null;
			if (flag)
			{
				TournamentRound roundById = tournamentPhaseById.GetRoundById(match.RoundId);
				bool flag2 = roundById != null;
				if (flag2)
				{
					int num = Math.Max(1, match.MaxGameCount - match.CurrentGameCount);
					bool flag3 = match.Status == TournamentMatchStatus.WaitingForOpponent;
					if (flag3)
					{
						return match.Deadline.AddSeconds(-30.0).AddMinutes((double)roundById.MinGameLength);
					}
					return match.Deadline.AddSeconds(-30.0).AddMinutes((double)(-(double)((num - 1) * roundById.MinGameLength)));
				}
			}
			return match.Deadline.AddSeconds(-30.0);
		}

		// Token: 0x06000209 RID: 521 RVA: 0x0000F228 File Offset: 0x0000D428
		public DateTime GetMatchNextGameStartDeadline(TournamentMatch match)
		{
			bool flag = match.CurrentGameCount == 0;
			DateTime result;
			if (flag)
			{
				result = this.GetMatchStartDeadline(match);
			}
			else
			{
				TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
				bool flag2 = tournamentPhaseById != null;
				if (flag2)
				{
					TournamentRound roundById = tournamentPhaseById.GetRoundById(match.RoundId);
					bool flag3 = roundById != null;
					if (flag3)
					{
						int num = Math.Max(1, match.MaxGameCount - match.CurrentGameCount);
						bool flag4 = match.Status == TournamentMatchStatus.WaitingForOpponent;
						if (flag4)
						{
							return match.Deadline;
						}
						return match.Deadline.AddSeconds(-30.0).AddMinutes((double)(-(double)(num * roundById.MinGameLength)));
					}
				}
				result = match.Deadline.AddSeconds(-90.0);
			}
			return result;
		}

		// Token: 0x0600020A RID: 522 RVA: 0x0000F300 File Offset: 0x0000D500
		public DateTime GetMatchStartDeadline(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null;
			if (flag)
			{
				TournamentRound roundById = tournamentPhaseById.GetRoundById(match.RoundId);
				bool flag2 = roundById != null;
				if (flag2)
				{
					bool flag3 = match.Status == TournamentMatchStatus.WaitingForOpponent;
					if (flag3)
					{
						return match.Deadline;
					}
					int num = match.MaxGameCount * roundById.MinGameLength;
					bool flag4 = num == roundById.MaxLength;
					if (flag4)
					{
						num--;
					}
					return match.Deadline.AddMinutes((double)(-(double)num)).AddSeconds(-15.0);
				}
			}
			bool flag5 = match.Status == TournamentMatchStatus.WaitingForOpponent;
			DateTime result;
			if (flag5)
			{
				result = match.Deadline;
			}
			else
			{
				result = match.Deadline.AddMinutes((double)(-(double)match.MaxGameCount));
			}
			return result;
		}

		// Token: 0x0600020B RID: 523 RVA: 0x0000F3E4 File Offset: 0x0000D5E4
		public bool IsMatchInWinnerBracket(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null && tournamentPhaseById.Type == TournamentPhaseType.DoubleEliminationBracket;
			return flag && ((1 << (tournamentPhaseById.Rounds.Count + 1 - match.RoundId) / 2) + 1) / 2 >= match.MatchId;
		}

		// Token: 0x0600020C RID: 524 RVA: 0x0000F448 File Offset: 0x0000D648
		public bool IsMatchInLoserBracket(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null && tournamentPhaseById.Type == TournamentPhaseType.DoubleEliminationBracket;
			return flag && !this.IsMatchInWinnerBracket(match);
		}

		// Token: 0x0600020D RID: 525 RVA: 0x0000F48C File Offset: 0x0000D68C
		public bool IsMatchMergingInLoserBracket(TournamentMatch match)
		{
			TournamentPhase tournamentPhaseById = this.GetTournamentPhaseById(match.PhaseId);
			bool flag = tournamentPhaseById != null && tournamentPhaseById.Type == TournamentPhaseType.DoubleEliminationBracket && this.IsMatchInLoserBracket(match);
			bool result;
			if (flag)
			{
				bool flag2 = (tournamentPhaseById.IsLoserBracketSeeded && match.RoundId % 2 == 1) || (!tournamentPhaseById.IsLoserBracketSeeded && match.RoundId % 2 == 0);
				result = !flag2;
			}
			else
			{
				result = false;
			}
			return result;
		}

		// Token: 0x04000148 RID: 328
		private static readonly string FIELD_ID = "id";

		// Token: 0x04000149 RID: 329
		private static readonly string FIELD_TYPE = "type";

		// Token: 0x0400014A RID: 330
		private static readonly string FIELD_STATUS = "status";

		// Token: 0x0400014B RID: 331
		private static readonly string FIELD_TOURNAMENTTIME = "tournamenttime";

		// Token: 0x0400014C RID: 332
		private static readonly string FIELD_CASHSTATUS = "cashStatus";

		// Token: 0x0400014D RID: 333
		private static readonly string FIELD_CASHTOURNAMENT = "cashTournament";

		// Token: 0x0400014E RID: 334
		private static readonly string FIELD_SEASON = "season";

		// Token: 0x0400014F RID: 335
		private static readonly string FIELD_SEASONPART = "seasonpart";

		// Token: 0x04000150 RID: 336
		private static readonly string FIELD_WINNER = "winner";

		// Token: 0x04000151 RID: 337
		private static readonly string FIELD_INVITATIONOPENS = "invitationopens";

		// Token: 0x04000152 RID: 338
		private static readonly string FIELD_INVITATIONCLOSES = "invitationcloses";

		// Token: 0x04000153 RID: 339
		private static readonly string FIELD_MAXINVITES = "maxinvites";

		// Token: 0x04000154 RID: 340
		private static readonly string FIELD_PARTYSIZE = "partysize";

		// Token: 0x04000155 RID: 341
		private static readonly string FIELD_CURRENTINVITES = "currentinvites";

		// Token: 0x04000156 RID: 342
		private static readonly string FIELD_REGISTRATIONOPENS = "openregistration";

		// Token: 0x04000157 RID: 343
		private static readonly string FIELD_PHASECOUNT = "phasecount";

		// Token: 0x04000158 RID: 344
		private static readonly string FIELD_ROUNDCOUNT = "roundcount";

		// Token: 0x04000159 RID: 345
		private static readonly string FIELD_SPONSORNAME = "sponsorname";

		// Token: 0x0400015A RID: 346
		private static readonly string FIELD_SPONSORIMAGE = "sponsorimage";

		// Token: 0x0400015B RID: 347
		private static readonly string FIELD_NAME = "name";

		// Token: 0x0400015C RID: 348
		private static readonly string FIELD_DATA = "data";

		// Token: 0x0400015D RID: 349
		private static readonly string FIELD_CURRENTPHASEID = "currentphaseid";

		// Token: 0x0400015E RID: 350
		private static readonly string FIELD_NEXTPHASE = "nextphase";

		// Token: 0x0400015F RID: 351
		private static readonly string FIELD_CURRENTPHASESTARTED = "currentphasestarted";

		// Token: 0x04000160 RID: 352
		private static readonly string FIELD_IMAGE = "image";

		// Token: 0x04000161 RID: 353
		private static readonly string FIELD_ICON = "icon";

		// Token: 0x04000162 RID: 354
		private static readonly string FIELD_THEMECOLOR = "theme-color";

		// Token: 0x04000163 RID: 355
		private static readonly string FIELD_HIGHLIGHTS = "highlightsurl";

		// Token: 0x04000164 RID: 356
		private static readonly string FIELD_STREAMURL = "streamurl";

		// Token: 0x04000165 RID: 357
		private static readonly string FIELD_ISADMINISTRATOR = "isAdministrator";

		// Token: 0x04000166 RID: 358
		private static readonly string FIELD_USERPARTY = "party";

		// Token: 0x04000167 RID: 359
		private static readonly string FIELD_USERPOSITION = "userPosition";

		// Token: 0x04000168 RID: 360
		private static readonly string FIELD_USERMATCH = "userMatch";

		// Token: 0x04000169 RID: 361
		private static readonly string FIELD_BRACKETMATCHES = "bracketMatches";

		// Token: 0x0400016A RID: 362
		private static readonly string FIELD_USERMATCHES = "userMatches";

		// Token: 0x0400016B RID: 363
		private static readonly string FIELD_TOURNAMENTDATA = "tournamentData";

		// Token: 0x0400016C RID: 364
		private static readonly string FIELD_USERPOSITION_PHASEID = "phaseid";

		// Token: 0x0400016D RID: 365
		private static readonly string FIELD_USERPOSITION_RANKPOSITION = "rankposition";

		// Token: 0x0400016E RID: 366
		private static readonly string FIELD_USERPOSITION_SAMEPOSITION = "sameposition";

		// Token: 0x0400016F RID: 367
		private static readonly string FIELD_USERPOSITION_MATCHLOSES = "matchloses";

		// Token: 0x04000170 RID: 368
		private static readonly string FIELD_USERPOSITION_TOTALPOINTS = "totalpoints";

		// Token: 0x04000171 RID: 369
		private static readonly string FIELD_USERPOSITION_TOTALROUNDS = "totalrounds";

		// Token: 0x04000172 RID: 370
		private static readonly string FIELD_USERPOSITION_GROUPID = "groupid";

		// Token: 0x04000173 RID: 371
		private static readonly string FIELD_DATA_TOURNAMENTDATA = "tournament-data";

		// Token: 0x04000174 RID: 372
		private static readonly string FIELD_DATA_INVITATIONSETTING = "invitation-setting";

		// Token: 0x04000175 RID: 373
		private static readonly string FIELD_DATA_REQUIREMENTS = "requirements";

		// Token: 0x04000176 RID: 374
		private static readonly string FIELD_DATA_CUSTOMREQUIREMENT = "custom-requirement";

		// Token: 0x04000177 RID: 375
		private static readonly string FIELD_DATA_CUSTOMREQUIREMENT_NAME = "@name";

		// Token: 0x04000178 RID: 376
		private static readonly string FIELD_DATA_CUSTOMREQUIREMENT_VALUE = "@value";

		// Token: 0x04000179 RID: 377
		private static readonly string FIELD_DATA_MINRANK = "@min-rank";

		// Token: 0x0400017A RID: 378
		private static readonly string FIELD_DATA_RULESSETTING = "rules-setting";

		// Token: 0x0400017B RID: 379
		private static readonly string FIELD_DATA_PHASE = "phase";

		// Token: 0x0400017C RID: 380
		private static readonly string FIELD_DATA_MINTEAMSPERMATCH = "@min-teams-per-match";

		// Token: 0x0400017D RID: 381
		private static readonly string FIELD_DATA_MAXTEAMSPERMATCH = "@max-teams-per-match";

		// Token: 0x0400017E RID: 382
		private static readonly string FIELD_DATA_MINCHECKINSPERTEAM = "@min-checkins-per-team";

		// Token: 0x0400017F RID: 383
		private static readonly string FIELD_DATA_GROUPCOUNT = "@group-count";

		// Token: 0x04000180 RID: 384
		private static readonly string FIELD_DATA_SEEDLOSERBRACKET = "@seed-loser-bracket";

		// Token: 0x04000181 RID: 385
		private static readonly string FIELD_DATA_TYPE = "@type";

		// Token: 0x04000182 RID: 386
		private static readonly string FIELD_DATA_ID = "@id";

		// Token: 0x04000183 RID: 387
		private static readonly string FIELD_DATA_ALLOWEDREBUYCOUNT = "@allowed-rebuy-count";

		// Token: 0x04000184 RID: 388
		private static readonly string FIELD_DATA_ALLOWEDREBUYUNTILROUNDID = "@allowed-rebuy-until-round-id";

		// Token: 0x04000185 RID: 389
		private static readonly string FIELD_DATA_REBUYPRICE = "@rebuy-price";

		// Token: 0x04000186 RID: 390
		private static readonly string FIELD_DATA_ROUND = "round";

		// Token: 0x04000187 RID: 391
		private static readonly string FIELD_DATA_MAXLENGTH = "@max-length";

		// Token: 0x04000188 RID: 392
		private static readonly string FIELD_DATA_MINGAMELENGTH = "@min-length";

		// Token: 0x04000189 RID: 393
		private static readonly string FIELD_DATA_WINSCORE = "@win-score";

		// Token: 0x0400018A RID: 394
		private static readonly string FIELD_DATA_MAXGAMECOUNT = "@max-game-count";

		// Token: 0x0400018B RID: 395
		private static readonly string FIELD_DATA_ALLOWSKIP = "@allow-skip";

		// Token: 0x0400018C RID: 396
		private static readonly string FIELD_DATA_GAMEPOINTDISTRIBUTION = "@game-point-distribution";

		// Token: 0x0400018D RID: 397
		private static readonly string FIELD_DATA_MATCHPOINTDISTRIBUTION = "@match-point-distribution";

		// Token: 0x0400018E RID: 398
		private static readonly string FIELD_DATA_MAXTEAMS = "@max-players";

		// Token: 0x0400018F RID: 399
		private static readonly string FIELD_DATA_MAXLOSES = "@max-loses";

		// Token: 0x04000190 RID: 400
		private static readonly string FIELD_DATA_PRIZESETTING = "prize-setting";

		// Token: 0x04000191 RID: 401
		private static readonly string FIELD_DATA_REWARD = "reward";

		// Token: 0x04000192 RID: 402
		private static readonly string FIELD_DATA_ITEM = "item";

		// Token: 0x04000193 RID: 403
		private static readonly string FIELD_DATA_DESCRIPTIONDATA = "description-data";

		// Token: 0x04000194 RID: 404
		private static readonly string FIELD_DATA_LANGUAGE = "language";

		// Token: 0x04000195 RID: 405
		private static readonly string FIELD_DATA_CODE = "@code";

		// Token: 0x04000196 RID: 406
		private static readonly string FIELD_DATA_POLICY = "policy";

		// Token: 0x04000197 RID: 407
		private static readonly string FIELD_DATA_NAME = "name";

		// Token: 0x04000198 RID: 408
		private static readonly string FIELD_DATA_URL = "@url";

		// Token: 0x04000199 RID: 409
		private static readonly string FIELD_DATA_HTEXT = "#text";

		// Token: 0x0400019A RID: 410
		private static readonly string FIELD_DATA_HVALUE = "value";

		// Token: 0x0400019B RID: 411
		private static readonly string FIELD_DATA_DESCRIPTION = "description";

		// Token: 0x0400019C RID: 412
		private static readonly string FIELD_DATA_ADDITIONALDESCRIPTION = "additional-description";

		// Token: 0x0400019D RID: 413
		private static readonly string FIELD_DATA_SPONSORDATA = "sponsor-data";

		// Token: 0x0400019E RID: 414
		private static readonly string FIELD_DATA_SPONSORNAME = "@name";

		// Token: 0x0400019F RID: 415
		private static readonly string FIELD_DATA_STREAMDATA = "stream-data";

		// Token: 0x040001A0 RID: 416
		private static readonly string FIELD_DATA_STREAMLINK = "@stream-link";

		// Token: 0x040001A1 RID: 417
		private static readonly string FIELD_DATA_REPLAYDATA = "replay-data";

		// Token: 0x040001A2 RID: 418
		private static readonly string FIELD_DATA_REPLAYLINK = "@replay-link";

		// Token: 0x040001A3 RID: 419
		private static readonly string FIELD_DATA_REPLAYEXPIRES = "@replay-expires";

		// Token: 0x040001A4 RID: 420
		private static readonly string FIELD_DATA_HIGHLIGHTSLINK = "@highlights-link";

		// Token: 0x040001A5 RID: 421
		private bool isLoading;

		// Token: 0x040001A6 RID: 422
		private Dictionary<long, TournamentMatch> userMatchesById;

		// Token: 0x040001A7 RID: 423
		private Dictionary<long, TournamentMatch> allMatchesById;

		// Token: 0x040001A8 RID: 424
		private Dictionary<int, TournamentPhase> phaseById;

		// Token: 0x040001A9 RID: 425
		private Dictionary<int, TournamentPrize> prizeByPlace;
	}
}
