﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000034 RID: 52
	public enum TournamentCreatePartyInviteStatus
	{
		// Token: 0x040001DF RID: 479
		Unknown = -1,
		// Token: 0x040001E0 RID: 480
		NotAttempted,
		// Token: 0x040001E1 RID: 481
		Ok,
		// Token: 0x040001E2 RID: 482
		InvalidTournamentId
	}
}
