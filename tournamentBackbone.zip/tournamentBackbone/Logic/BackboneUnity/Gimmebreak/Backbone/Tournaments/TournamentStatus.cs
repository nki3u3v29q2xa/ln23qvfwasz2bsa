﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200002F RID: 47
	public enum TournamentStatus
	{
		// Token: 0x04000133 RID: 307
		Unknown = -1,
		// Token: 0x04000134 RID: 308
		NotStarted,
		// Token: 0x04000135 RID: 309
		InvitationOpen,
		// Token: 0x04000136 RID: 310
		InvitationClose,
		// Token: 0x04000137 RID: 311
		Finished,
		// Token: 0x04000138 RID: 312
		Canceled,
		// Token: 0x04000139 RID: 313
		Running
	}
}
