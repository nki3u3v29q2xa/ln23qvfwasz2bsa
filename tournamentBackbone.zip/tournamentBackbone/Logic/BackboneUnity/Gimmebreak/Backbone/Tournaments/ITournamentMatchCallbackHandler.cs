﻿using System;
using System.Collections.Generic;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000023 RID: 35
	public interface ITournamentMatchCallbackHandler
	{
		// Token: 0x06000131 RID: 305
		void OnJoinTournamentMatch(Tournament tournament, TournamentMatch match, ITournamentMatchController controller);

		// Token: 0x06000132 RID: 306
		bool IsConnectedToGameServerNetwork();

		// Token: 0x06000133 RID: 307
		bool IsUserConnectedToMatch(long userId);

		// Token: 0x06000134 RID: 308
		bool IsUserReadyForMatch(long userId);

		// Token: 0x06000135 RID: 309
		bool IsGameSessionInProgress();

		// Token: 0x06000136 RID: 310
		void StartGameSession(IEnumerable<TournamentMatch.User> checkedInUsers);

		// Token: 0x06000137 RID: 311
		void OnLeaveTournamentMatch();
	}
}
