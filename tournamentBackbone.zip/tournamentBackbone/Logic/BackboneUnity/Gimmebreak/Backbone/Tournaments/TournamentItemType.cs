﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000039 RID: 57
	public enum TournamentItemType
	{
		// Token: 0x04000203 RID: 515
		Unkown = -1,
		// Token: 0x04000204 RID: 516
		VirtualCurrency = 1,
		// Token: 0x04000205 RID: 517
		StoreItem,
		// Token: 0x04000206 RID: 518
		CustomImage = 5,
		// Token: 0x04000207 RID: 519
		ExternalVirtualCurrency = 10,
		// Token: 0x04000208 RID: 520
		ExternalStoreItem
	}
}
