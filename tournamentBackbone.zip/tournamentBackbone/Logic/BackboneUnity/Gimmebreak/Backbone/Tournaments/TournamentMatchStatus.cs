﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000040 RID: 64
	public enum TournamentMatchStatus
	{
		// Token: 0x04000258 RID: 600
		Unkown = -1,
		// Token: 0x04000259 RID: 601
		Created,
		// Token: 0x0400025A RID: 602
		WaitingForOpponent,
		// Token: 0x0400025B RID: 603
		GameReady,
		// Token: 0x0400025C RID: 604
		GameInProgress,
		// Token: 0x0400025D RID: 605
		GameFinished,
		// Token: 0x0400025E RID: 606
		MatchFinished,
		// Token: 0x0400025F RID: 607
		Closed = 8
	}
}
