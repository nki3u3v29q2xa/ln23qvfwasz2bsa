﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;
using UnityEngine;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000045 RID: 69
	[XmlType(Namespace = "TournamentPrize")]
	[Serializable]
	public class TournamentPrize
	{
		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060002CE RID: 718 RVA: 0x0000429A File Offset: 0x0000249A
		// (set) Token: 0x060002CF RID: 719 RVA: 0x000042A2 File Offset: 0x000024A2
		public int FromPlace { get; set; }

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x060002D0 RID: 720 RVA: 0x000042AB File Offset: 0x000024AB
		// (set) Token: 0x060002D1 RID: 721 RVA: 0x000042B3 File Offset: 0x000024B3
		public int ToPlace { get; set; }

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x060002D2 RID: 722 RVA: 0x000042BC File Offset: 0x000024BC
		// (set) Token: 0x060002D3 RID: 723 RVA: 0x000042C4 File Offset: 0x000024C4
		public float PotShare { get; set; }

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x060002D4 RID: 724 RVA: 0x000042CD File Offset: 0x000024CD
		// (set) Token: 0x060002D5 RID: 725 RVA: 0x000042D5 File Offset: 0x000024D5
		public string Text { get; set; }

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x060002D6 RID: 726 RVA: 0x000042DE File Offset: 0x000024DE
		// (set) Token: 0x060002D7 RID: 727 RVA: 0x000042E6 File Offset: 0x000024E6
		public string ImageUrl { get; set; }

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x060002D8 RID: 728 RVA: 0x000042EF File Offset: 0x000024EF
		// (set) Token: 0x060002D9 RID: 729 RVA: 0x000042F7 File Offset: 0x000024F7
		public List<TournamentPrize.Item> Items { get; set; }

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x060002DA RID: 730 RVA: 0x00004300 File Offset: 0x00002500
		// (set) Token: 0x060002DB RID: 731 RVA: 0x00004308 File Offset: 0x00002508
		public List<string> Images { get; set; }

		// Token: 0x060002DC RID: 732 RVA: 0x00004311 File Offset: 0x00002511
		public TournamentPrize()
		{
			this.Items = new List<TournamentPrize.Item>();
			this.Images = new List<string>();
			this.removeItems = new HashSet<long>();
		}

		// Token: 0x060002DD RID: 733 RVA: 0x00012100 File Offset: 0x00010300
		internal void LoadJsonPrize(JSONObject data, TournamentEntryFee entryFee, int currentInvites)
		{
			int num = int.Parse(data[TournamentPrize.FIELD_DATA_POSITION].str);
			float potShare = data.HasField(TournamentPrize.FIELD_DATA_POTSHARE) ? float.Parse(data[TournamentPrize.FIELD_DATA_POTSHARE].str, NumberStyles.Float, CultureInfo.InvariantCulture) : 0f;
			string text = data.HasField(TournamentPrize.FIELD_DATA_TEXT) ? data[TournamentPrize.FIELD_DATA_TEXT].str : null;
			string imageUrl = data.HasField(TournamentPrize.FIELD_DATA_IMAGE) ? data[TournamentPrize.FIELD_DATA_IMAGE].str : null;
			this.PotShare = potShare;
			this.Text = text;
			this.ImageUrl = imageUrl;
			this.Images.Clear();
			this.removeItems.Clear();
			for (int i = 0; i < this.Items.Count; i++)
			{
				this.removeItems.Add(this.Items[i].Id);
				this.Items[i].BaseAmount = 0m;
				this.Items[i].PotAmount = 0m;
				this.Items[i].ExternalId = null;
			}
			bool flag = data.HasField(TournamentPrize.FIELD_DATA_ITEM);
			if (flag)
			{
				List<JSONObject> list = data[TournamentPrize.FIELD_DATA_ITEM].list;
				int j = 0;
				while (j < list.Count)
				{
					JSONObject jsonobject = list[j];
					TournamentItemType tournamentItemType = jsonobject[TournamentPrize.FIELD_DATA_TYPE].ToEnum(TournamentItemType.Unkown);
					TournamentItemType tournamentItemType2 = tournamentItemType;
					switch (tournamentItemType2)
					{
					case TournamentItemType.Unkown:
					case (TournamentItemType)0:
					case (TournamentItemType)3:
					case (TournamentItemType)4:
						break;
					case TournamentItemType.VirtualCurrency:
					case TournamentItemType.StoreItem:
						goto IL_1C8;
					case TournamentItemType.CustomImage:
					{
						bool flag2 = jsonobject.HasField(TournamentPrize.FIELD_DATA_IMAGE);
						if (flag2)
						{
							this.Images.Add(jsonobject[TournamentPrize.FIELD_DATA_IMAGE].str);
						}
						break;
					}
					default:
						if (tournamentItemType2 - TournamentItemType.ExternalVirtualCurrency <= 1)
						{
							goto IL_1C8;
						}
						break;
					}
					IL_2C4:
					j++;
					continue;
					IL_1C8:
					long num2 = long.Parse(jsonobject[TournamentPrize.FIELD_DATA_ID].str);
					TournamentPrize.Item item4 = this.GetPrizeItemById(num2);
					bool flag3 = item4 == null;
					if (flag3)
					{
						item4 = new TournamentPrize.Item();
						item4.Id = num2;
						this.Items.Add(item4);
					}
					bool flag4 = jsonobject.HasField(TournamentPrize.FIELD_DATA_EXTERNALID);
					if (flag4)
					{
						item4.ExternalId = jsonobject[TournamentPrize.FIELD_DATA_EXTERNALID].str;
					}
					item4.Type = tournamentItemType;
					int value = int.Parse(jsonobject[TournamentPrize.FIELD_DATA_AMOUNT].str);
					item4.BaseAmount += value;
					this.removeItems.Remove(num2);
					goto IL_2C4;
				}
			}
			for (int k = 0; k < entryFee.Items.Count; k++)
			{
				TournamentEntryFee.Item item2 = entryFee.Items[k];
				bool flag5 = item2.PotAmount > 0m;
				if (flag5)
				{
					TournamentPrize.Item item3 = this.GetPrizeItemById(item2.Id);
					bool flag6 = item3 == null;
					if (flag6)
					{
						item3 = new TournamentPrize.Item();
						item3.Id = item2.Id;
						item3.Type = item2.Type;
						item3.ExternalId = item2.ExternalId;
						this.Items.Add(item3);
					}
					else
					{
						bool flag7 = item3.Type != item2.Type;
						if (flag7)
						{
							item3.Type = item2.Type;
						}
						bool flag8 = item3.ExternalId != item2.ExternalId;
						if (flag8)
						{
							item3.ExternalId = item2.ExternalId;
						}
					}
					TournamentItemType type = item3.Type;
					if (type != TournamentItemType.Unkown)
					{
						if (type - TournamentItemType.VirtualCurrency <= 1 || type - TournamentItemType.ExternalVirtualCurrency <= 1)
						{
							item3.PotAmount = Mathf.RoundToInt((float)item2.PotAmount * (float)currentInvites * this.PotShare / 100f);
						}
					}
					IL_41B:
					this.removeItems.Remove(item3.Id);
					goto IL_42F;
					goto IL_41B;
				}
				IL_42F:;
			}
			this.Items.RemoveAll((TournamentPrize.Item item) => this.removeItems.Contains(item.Id));
		}

		// Token: 0x060002DE RID: 734 RVA: 0x00012574 File Offset: 0x00010774
		public TournamentPrize.Item GetPrizeItemById(long itemId)
		{
			return this.Items.FirstOrDefault((TournamentPrize.Item item) => item.Id == itemId);
		}

		// Token: 0x060002DF RID: 735 RVA: 0x000125AC File Offset: 0x000107AC
		public TournamentPrize.Item GetPrizeItemByExternalId(string itemExternalId)
		{
			return this.Items.FirstOrDefault((TournamentPrize.Item item) => item.ExternalId == itemExternalId);
		}

		// Token: 0x040002B1 RID: 689
		private static readonly string FIELD_DATA_ITEM = "item";

		// Token: 0x040002B2 RID: 690
		private static readonly string FIELD_DATA_ID = "@id";

		// Token: 0x040002B3 RID: 691
		private static readonly string FIELD_DATA_TYPE = "@type";

		// Token: 0x040002B4 RID: 692
		private static readonly string FIELD_DATA_AMOUNT = "@amount";

		// Token: 0x040002B5 RID: 693
		private static readonly string FIELD_DATA_EXTERNALID = "@external-id";

		// Token: 0x040002B6 RID: 694
		internal static readonly string FIELD_DATA_POSITION = "@position";

		// Token: 0x040002B7 RID: 695
		private static readonly string FIELD_DATA_POTSHARE = "@pot-share";

		// Token: 0x040002B8 RID: 696
		private static readonly string FIELD_DATA_TEXT = "@text";

		// Token: 0x040002B9 RID: 697
		private static readonly string FIELD_DATA_IMAGE = "@image";

		// Token: 0x040002BA RID: 698
		private HashSet<long> removeItems;

		// Token: 0x02000092 RID: 146
		[Serializable]
		public class Item
		{
			// Token: 0x1700019E RID: 414
			// (get) Token: 0x0600062E RID: 1582 RVA: 0x00005F7E File Offset: 0x0000417E
			// (set) Token: 0x0600062F RID: 1583 RVA: 0x00005F86 File Offset: 0x00004186
			public long Id { get; set; }

			// Token: 0x1700019F RID: 415
			// (get) Token: 0x06000630 RID: 1584 RVA: 0x00005F8F File Offset: 0x0000418F
			// (set) Token: 0x06000631 RID: 1585 RVA: 0x00005F97 File Offset: 0x00004197
			public TournamentItemType Type { get; set; }

			// Token: 0x170001A0 RID: 416
			// (get) Token: 0x06000632 RID: 1586 RVA: 0x00005FA0 File Offset: 0x000041A0
			// (set) Token: 0x06000633 RID: 1587 RVA: 0x00005FA8 File Offset: 0x000041A8
			public decimal PotAmount { get; set; }

			// Token: 0x170001A1 RID: 417
			// (get) Token: 0x06000634 RID: 1588 RVA: 0x00005FB1 File Offset: 0x000041B1
			// (set) Token: 0x06000635 RID: 1589 RVA: 0x00005FB9 File Offset: 0x000041B9
			public decimal BaseAmount { get; set; }

			// Token: 0x170001A2 RID: 418
			// (get) Token: 0x06000636 RID: 1590 RVA: 0x00005FC2 File Offset: 0x000041C2
			// (set) Token: 0x06000637 RID: 1591 RVA: 0x00005FCA File Offset: 0x000041CA
			public string ExternalId { get; set; }

			// Token: 0x170001A3 RID: 419
			// (get) Token: 0x06000638 RID: 1592 RVA: 0x0001C5A8 File Offset: 0x0001A7A8
			[XmlIgnore]
			public decimal Amount
			{
				get
				{
					return this.BaseAmount + this.PotAmount;
				}
			}
		}
	}
}
