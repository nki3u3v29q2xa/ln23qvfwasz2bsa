﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000035 RID: 53
	public enum TournamentCreatePartyCodeStatus
	{
		// Token: 0x040001E4 RID: 484
		Unknown = -1,
		// Token: 0x040001E5 RID: 485
		NotAttempted,
		// Token: 0x040001E6 RID: 486
		Ok,
		// Token: 0x040001E7 RID: 487
		InvalidTournamentId
	}
}
