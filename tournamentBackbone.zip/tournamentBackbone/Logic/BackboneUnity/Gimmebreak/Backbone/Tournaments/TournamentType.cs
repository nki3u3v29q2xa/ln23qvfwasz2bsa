﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200002E RID: 46
	public enum TournamentType
	{
		// Token: 0x0400012E RID: 302
		GenericTournament,
		// Token: 0x0400012F RID: 303
		PremiumTournament,
		// Token: 0x04000130 RID: 304
		PrivateTournament,
		// Token: 0x04000131 RID: 305
		TestingTournament
	}
}
