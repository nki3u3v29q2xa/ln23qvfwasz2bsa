﻿using System;
using System.Collections.Generic;

namespace Gimmebreak.Backbone.Tournaments
{
	[Serializable]
	public class TournamentRound
	{
		public int Id { get; set; }

		public int MaxLength { get; set; }

		public int MinGameLength { get; set; }

		public int WinScore { get; set; }

		public int MaxGameCount { get; set; }

		public List<TournamentRound.GamePositionPoints> GamePointDistribution { get; set; }

		public List<TournamentRound.MatchPositionPoints> MatchPointDistribution { get; set; }

		public TournamentRound()
		{
			this.GamePointDistribution = new List<TournamentRound.GamePositionPoints>();
			this.MatchPointDistribution = new List<TournamentRound.MatchPositionPoints>();
		}

		internal void LoadGamePointDistribution(string gamePointDistribution)
		{
			this.GamePointDistribution.Clear();
			bool flag = !string.IsNullOrEmpty(gamePointDistribution);
			if (flag)
			{
				string[] array = gamePointDistribution.Split(new char[]
				{
					','
				});
				for (int i = 0; i < array.Length; i++)
				{
					int points;
					bool flag2 = int.TryParse(array[i], out points);
					if (flag2)
					{
						this.GamePointDistribution.Add(new TournamentRound.GamePositionPoints
						{
							Position = i + 1,
							Points = points
						});
					}
				}
			}
		}

		internal void LoadMatchPointDistribution(string matchPointDistribution)
		{
			this.MatchPointDistribution.Clear();
			bool flag = !string.IsNullOrEmpty(matchPointDistribution);
			if (flag)
			{
				string[] array = matchPointDistribution.Split(new char[]
				{
					','
				});
				for (int i = 0; i < array.Length; i++)
				{
					int num;
					bool flag2 = int.TryParse(array[i], out num);
					if (flag2)
					{
						this.MatchPointDistribution.Add(new TournamentRound.MatchPositionPoints
						{
							Position = i + 1,
							Points = Math.Abs(num),
							GrantsMatchWin = (num > 0)
						});
					}
				}
			}
		}

		public struct GamePositionPoints
		{
		
			public int Position { get; set; }

		
			public int Points { get; set; }
		}

		
		public struct MatchPositionPoints
		{

			public int Position { get; set; }
			public int Points { get; set; }
			public bool GrantsMatchWin { get; set; }
		}
	}
}
