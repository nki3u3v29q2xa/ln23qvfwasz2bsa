﻿using System;
using Gimmebreak.Backbone.Core;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000046 RID: 70
	[Serializable]
	public class TournamentRequirements
	{
		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x060002E2 RID: 738 RVA: 0x00004351 File Offset: 0x00002551
		// (set) Token: 0x060002E3 RID: 739 RVA: 0x00004359 File Offset: 0x00002559
		public SerializableDictionary<string, string> CustomRequirements { get; set; }

		// Token: 0x060002E4 RID: 740 RVA: 0x00004362 File Offset: 0x00002562
		public TournamentRequirements()
		{
			this.CustomRequirements = new SerializableDictionary<string, string>();
		}
	}
}
