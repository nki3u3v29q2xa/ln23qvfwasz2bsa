﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Gimmebreak.Backbone.Core;
using Gimmebreak.Backbone.Notifications;
using UnityEngine;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200003E RID: 62
	internal class TournamentHub : MonoBehaviour, ITournamentHubController, ITournamentMatchController
	{
		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x06000225 RID: 549 RVA: 0x00010064 File Offset: 0x0000E264
		public bool IsInitialized
		{
			get
			{
				return this.isInitialized;
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x06000226 RID: 550 RVA: 0x0001007C File Offset: 0x0000E27C
		public TimeSpan NextEventCountdown
		{
			get
			{
				TimeSpan timeSpan = this.nextEventTime - ServerTime.UtcNow;
				bool flag = timeSpan < TimeSpan.Zero;
				if (flag)
				{
					timeSpan = TimeSpan.Zero;
				}
				return timeSpan;
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x06000227 RID: 551 RVA: 0x000100B8 File Offset: 0x0000E2B8
		public TournamentHubStatus Status
		{
			get
			{
				return this.hubStatus;
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x06000228 RID: 552 RVA: 0x000100D0 File Offset: 0x0000E2D0
		public bool IsTournamentRunning
		{
			get
			{
				return this.tournament != null && this.tournament.Status == TournamentStatus.Running;
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x06000229 RID: 553 RVA: 0x000100FC File Offset: 0x0000E2FC
		public bool IsUserKnockedOut
		{
			get
			{
				bool flag = this.isInitialized && this.tournament != null;
				bool result;
				if (flag)
				{
					TournamentPhase currentTournamentPhase = this.tournament.GetCurrentTournamentPhase();
					result = (!currentTournamentPhase.UserIsParticipating || (currentTournamentPhase.MaxLoses > 0 && currentTournamentPhase.UserLoses >= currentTournamentPhase.MaxLoses));
				}
				else
				{
					result = false;
				}
				return result;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x0600022A RID: 554 RVA: 0x00010160 File Offset: 0x0000E360
		public TimeSpan ActiveMatchFinishDeadlineCountdown
		{
			get
			{
				TimeSpan timeSpan = this.matchDeadline - ServerTime.UtcNow;
				bool flag = timeSpan < TimeSpan.Zero;
				if (flag)
				{
					timeSpan = TimeSpan.Zero;
				}
				return timeSpan;
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x0600022B RID: 555 RVA: 0x0001019C File Offset: 0x0000E39C
		public TimeSpan ActiveMatchStartDeadlineCountdown
		{
			get
			{
				TimeSpan timeSpan = this.matchStart - ServerTime.UtcNow;
				bool flag = timeSpan < TimeSpan.Zero;
				if (flag)
				{
					timeSpan = TimeSpan.Zero;
				}
				return timeSpan;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x0600022C RID: 556 RVA: 0x000101D8 File Offset: 0x0000E3D8
		public Tournament Tournament
		{
			get
			{
				return this.tournament;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x0600022D RID: 557 RVA: 0x000101F0 File Offset: 0x0000E3F0
		public IEnumerable<TournamentPartyInviteNotification> PartyInvites
		{
			get
			{
				return from notification in this.backboneClient.Notifications.GetNotificationByType(NotificationType.TournamentPartyInvite)
				select (TournamentPartyInviteNotification)notification into notification
				where this.tournament != null && notification.TournamentId == this.tournament.Id
				select notification;
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x0600022E RID: 558 RVA: 0x00010248 File Offset: 0x0000E448
		public bool IsMatchHandlerInitialized
		{
			get
			{
				return this.tournamentMatch != null && this.tournamentMatchCallbackHandler != null;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x0600022F RID: 559 RVA: 0x00010270 File Offset: 0x0000E470
		public bool IsConnectedToGameServerNetwork
		{
			get
			{
				return this.IsMatchHandlerInitialized && this.tournamentMatchCallbackHandler.IsConnectedToGameServerNetwork();
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x06000230 RID: 560 RVA: 0x00010298 File Offset: 0x0000E498
		public bool IsGameSessionInProgress
		{
			get
			{
				return this.IsMatchHandlerInitialized && this.tournamentMatchCallbackHandler.IsGameSessionInProgress();
			}
		}

		// Token: 0x06000231 RID: 561 RVA: 0x000102C0 File Offset: 0x0000E4C0
		public void Initialize(ITournamentHubCallbackHandler tournamentHubCallbacks, BackboneClient backboneClient, Tournament tournament)
		{
			this.isInitialized = false;
			this.isProcessingUserReadyRequest = false;
			this.isProcessingRefreshActiveMatchRequest = false;
			this.isProcessingRefreshJoinedMatchRequest = false;
			this.lastSetUserReadyUpdate = DateTime.MinValue;
			this.tournament = tournament;
			this.backboneClient = backboneClient;
			this.tournamentHubCallbackHandler = tournamentHubCallbacks;
			base.StopAllCoroutines();
			base.StartCoroutine(this.TimerRutine());
		}

		// Token: 0x06000232 RID: 562 RVA: 0x00003DDF File Offset: 0x00001FDF
		public void DeInitialize()
		{
			base.StopAllCoroutines();
			this.tournamentHubCallbackHandler = null;
			this.isInitialized = false;
			this.tournamentMatch = null;
			this.tournamentMatchCallbackHandler = null;
		}

		// Token: 0x06000233 RID: 563 RVA: 0x00003E05 File Offset: 0x00002005
		private IEnumerator TimerRutine()
		{
			for (;;)
			{
				bool flag = this.tournament != null;
				if (flag)
				{
					bool flag2 = !this.isInitialized;
					if (flag2)
					{
						yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(30.0));
					}
					bool flag3 = this.tournament.Status == TournamentStatus.NotStarted && ((this.tournament.IsInvitationOnly && this.tournament.InvitationOpenTime > ServerTime.UtcNow) || (!this.tournament.IsInvitationOnly && this.tournament.RegistrationOpenTime > ServerTime.UtcNow));
					if (flag3)
					{
						this.nextEventTime = (this.tournament.IsInvitationOnly ? this.tournament.InvitationOpenTime : this.tournament.RegistrationOpenTime);
						this.SetHubStatus(TournamentHubStatus.RegistrationClosed);
					}
					else
					{
						bool flag4 = this.tournament.Status == TournamentStatus.NotStarted && ((this.tournament.IsInvitationOnly && this.tournament.InvitationOpenTime < ServerTime.UtcNow) || (!this.tournament.IsInvitationOnly && this.tournament.RegistrationOpenTime < ServerTime.UtcNow));
						if (flag4)
						{
							this.SetHubStatus(TournamentHubStatus.RegistrationOpening);
							yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(30.0));
						}
						else
						{
							bool flag5 = this.tournament.Status == TournamentStatus.InvitationOpen && this.tournament.RegistrationOpenTime < ServerTime.UtcNow && this.tournament.InvitationCloseTime > ServerTime.UtcNow;
							if (flag5)
							{
								this.nextEventTime = this.tournament.InvitationCloseTime;
								this.SetHubStatus(TournamentHubStatus.RegistrationOpened);
							}
							else
							{
								bool flag6 = this.tournament.Status == TournamentStatus.InvitationOpen && this.tournament.InvitationCloseTime < ServerTime.UtcNow;
								if (flag6)
								{
									this.SetHubStatus(TournamentHubStatus.RegistrationClosing);
									yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(30.0));
								}
								else
								{
									bool flag7 = this.tournament.Status == TournamentStatus.InvitationClose && this.tournament.Time.AddSeconds(15.0) > ServerTime.UtcNow;
									if (flag7)
									{
										this.nextEventTime = this.tournament.Time.AddSeconds(15.0);
										this.SetHubStatus(TournamentHubStatus.WaitingForTournamentStart);
										bool flag8 = this.tournament.Invite != null && !this.tournament.Invite.IsCheckedIn && this.tournament.Time.AddMinutes(-5.0) < ServerTime.UtcNow;
										if (flag8)
										{
											yield return this.backboneClient.LoadTournament(this.tournament.Id, true, true, TimeSpan.FromSeconds(10.0));
										}
									}
									else
									{
										bool flag9 = this.tournament.Status == TournamentStatus.InvitationClose && this.tournament.CurrentPhaseId == 0 && this.tournament.Time.AddSeconds(15.0) <= ServerTime.UtcNow;
										if (flag9)
										{
											this.SetHubStatus(TournamentHubStatus.Starting);
											yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(10.0));
										}
										else
										{
											bool isTournamentRunning = this.IsTournamentRunning;
											if (isTournamentRunning)
											{
												bool flag10 = this.hubStatus < TournamentHubStatus.Started;
												if (flag10)
												{
													this.SetHubStatus(TournamentHubStatus.Started);
												}
												yield return this.TournamentControlLoop();
											}
											else
											{
												bool flag11 = this.tournament.Status == TournamentStatus.Finished || this.tournament.Status == TournamentStatus.Canceled;
												if (flag11)
												{
													this.SetHubStatus(TournamentHubStatus.Finished);
												}
											}
										}
									}
								}
							}
						}
					}
					this.ProcessJoinedTournamentMatch();
					bool flag12 = !this.isInitialized;
					if (flag12)
					{
						this.isInitialized = true;
						bool flag13 = this.tournamentHubCallbackHandler != null;
						if (flag13)
						{
							this.tournamentHubCallbackHandler.OnInitialized(this);
						}
					}
				}
				yield return this.waitOneSecond;
			}
			yield break;
		}

		// Token: 0x06000234 RID: 564 RVA: 0x00003E14 File Offset: 0x00002014
		private IEnumerator TournamentControlLoop()
		{
			this.nextEventTime = this.tournament.NextPhase.AddSeconds(15.0);
			bool flag = this.tournament.NextPhase.AddSeconds(15.0) < ServerTime.UtcNow;
			if (flag)
			{
				bool flag2 = this.tournament.CurrentPhaseId == this.tournament.PhaseCount;
				if (flag2)
				{
					this.SetHubStatus(TournamentHubStatus.Finishing);
				}
				yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(15.0));
				bool flag3 = this.tournament.Status == TournamentStatus.Finished;
				if (flag3)
				{
					this.SetHubStatus(TournamentHubStatus.Finished);
				}
			}
			bool flag4 = this.tournament.UserActiveMatch != null && this.tournament.UserActiveMatch.PhaseId > this.tournament.CurrentPhaseId;
			if (flag4)
			{
				this.SetHubStatus(TournamentHubStatus.WaitingForNextPhase);
				yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.Zero);
			}
			else
			{
				bool flag5 = this.tournament.CurrentPhaseId != this.tournament.PhaseCount && this.tournament.GetTournamentPhaseById(this.tournament.CurrentPhaseId + 1).MaxPlayers >= this.tournament.CurrentInvites && this.tournament.GetCurrentTournamentPhase().IsSkipAllowed;
				if (flag5)
				{
					bool userIsParticipating = this.tournament.GetCurrentTournamentPhase().UserIsParticipating;
					if (userIsParticipating)
					{
						this.SetHubStatus(TournamentHubStatus.WaitingForNextPhase);
					}
					yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(15.0));
				}
				else
				{
					bool flag6 = this.tournament.Invite != null && this.tournament.Invite.Status == TournamentUserStatus.Confirmed && this.tournament.Invite.FinalPlace == 0;
					if (flag6)
					{
						TournamentPhase currentPhase = this.tournament.GetCurrentTournamentPhase();
						TournamentMatch userActiveMatch = this.tournament.UserActiveMatch;
						bool flag7 = userActiveMatch != null;
						if (flag7)
						{
							TournamentHub.c__DisplayClass44_0 TournamentSDK = new TournamentHub.c__DisplayClass44_0();
							TournamentPhase matchPhase = this.tournament.GetTournamentPhaseById(userActiveMatch.PhaseId);
							TournamentSDK.matchRound = matchPhase.GetRoundById(userActiveMatch.RoundId);
							this.matchDeadline = userActiveMatch.Deadline;
							this.matchStart = this.tournament.GetMatchStartDeadline(userActiveMatch);
							this.tournament.LastMatchRoundId = userActiveMatch.RoundId;
							bool flag8 = this.matchDeadline < ServerTime.UtcNow && userActiveMatch.Status == TournamentMatchStatus.WaitingForOpponent;
							if (flag8)
							{
								this.SetHubStatus(TournamentHubStatus.ResolvingPartiallyFilledMatch);
								bool flag9 = this.matchDeadline.AddSeconds(5.0) < ServerTime.UtcNow;
								if (flag9)
								{
									yield return this.backboneClient.LoadTournament(this.tournament.Id, true, true, TimeSpan.FromSeconds(5.0));
								}
							}
							else
							{
								bool flag10 = this.matchDeadline < ServerTime.UtcNow || userActiveMatch.Users.Any((TournamentMatch.User user) => user.TeamScore >= TournamentSDK.matchRound.WinScore) || userActiveMatch.CurrentGameCount >= userActiveMatch.MaxGameCount || userActiveMatch.Status == TournamentMatchStatus.MatchFinished || userActiveMatch.Status == TournamentMatchStatus.Closed;
								if (flag10)
								{
									bool flag11 = (userActiveMatch.Status == TournamentMatchStatus.MatchFinished || userActiveMatch.Status == TournamentMatchStatus.Closed) && userActiveMatch.RoundId != currentPhase.UserPlayedRoundCount;
									if (flag11)
									{
										yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.Zero);
									}
									bool flag12 = !this.IsUserKnockedOut;
									if (flag12)
									{
										bool flag13 = userActiveMatch.RoundId == matchPhase.Rounds.Count;
										if (flag13)
										{
											bool flag14 = userActiveMatch.PhaseId == this.tournament.PhaseCount;
											if (flag14)
											{
												this.SetHubStatus(TournamentHubStatus.WaitingForTournamentToFinish);
												yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(180.0));
											}
											else
											{
												this.SetHubStatus(TournamentHubStatus.WaitingForNextPhase);
												yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(60.0));
											}
										}
										else
										{
											bool flag15 = this.matchDeadline < ServerTime.UtcNow && userActiveMatch.Status != TournamentMatchStatus.MatchFinished && userActiveMatch.Status != TournamentMatchStatus.Closed;
											if (flag15)
											{
												bool flag16 = ((currentPhase.Type == TournamentPhaseType.Arena && matchPhase.Type == TournamentPhaseType.Arena) || (currentPhase.Type == TournamentPhaseType.RoundRobin && matchPhase.Type == TournamentPhaseType.RoundRobin) || (currentPhase.Type == TournamentPhaseType.DynamicBrackets && matchPhase.Type == TournamentPhaseType.DynamicBrackets)) && userActiveMatch.Status == TournamentMatchStatus.WaitingForOpponent;
												if (flag16)
												{
													this.SetHubStatus(TournamentHubStatus.ResolvingPartiallyFilledMatch);
													bool flag17 = this.matchDeadline.AddSeconds(5.0) < ServerTime.UtcNow;
													if (flag17)
													{
														yield return this.backboneClient.LoadTournament(this.tournament.Id, true, true, TimeSpan.FromSeconds(5.0));
													}
												}
												else
												{
													this.SetHubStatus(TournamentHubStatus.ClosingOverdueMatch);
													bool flag18 = this.matchDeadline.AddSeconds(5.0) < ServerTime.UtcNow;
													if (flag18)
													{
														yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(10.0));
													}
												}
											}
											else
											{
												this.SetHubStatus(TournamentHubStatus.WaitingForUserReadyConfirmation);
											}
										}
									}
								}
								else
								{
									this.SetHubStatus(TournamentHubStatus.MatchInProgress);
									bool flag19 = userActiveMatch.RoundId - matchPhase.UserPlayedRoundCount > 1;
									if (flag19)
									{
										yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.Zero);
									}
								}
							}
							TournamentSDK = null;
							matchPhase = null;
						}
						else
						{
							bool flag20 = !this.IsUserKnockedOut;
							if (flag20)
							{
								bool flag21 = this.tournament.LastMatchRoundId != currentPhase.Rounds.Count && currentPhase.UserPlayedRoundCount < currentPhase.Rounds.Count;
								if (flag21)
								{
									this.SetHubStatus(TournamentHubStatus.WaitingForUserReadyConfirmation);
									yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(30.0));
								}
								else
								{
									bool flag22 = this.tournament.CurrentPhaseId == this.tournament.PhaseCount;
									if (flag22)
									{
										this.SetHubStatus(TournamentHubStatus.WaitingForTournamentToFinish);
										yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(180.0));
									}
									else
									{
										this.SetHubStatus(TournamentHubStatus.WaitingForNextPhase);
										yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(60.0));
									}
								}
							}
						}
						bool isUserKnockedOut = this.IsUserKnockedOut;
						if (isUserKnockedOut)
						{
							bool flag23 = currentPhase.UserIsParticipating && this.tournament.CurrentPhaseId < this.tournament.PhaseCount && this.tournament.GetTournamentPhaseById(this.tournament.CurrentPhaseId + 1).MaxTeams * 2 > currentPhase.UserPositionTop;
							if (flag23)
							{
								this.SetHubStatus(TournamentHubStatus.WaitingForNextPhase);
								yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(60.0));
							}
							else
							{
								this.SetHubStatus(TournamentHubStatus.WaitingForTournamentToFinish);
								yield return this.backboneClient.LoadTournament(this.tournament.Id, true, false, TimeSpan.FromSeconds(180.0));
							}
						}
						currentPhase = null;
						userActiveMatch = null;
					}
					else
					{
						bool flag24 = this.tournament.Invite != null && this.tournament.Invite.Status == TournamentUserStatus.Confirmed && this.tournament.Invite.FinalPlace != 0;
						if (flag24)
						{
							this.SetHubStatus(TournamentHubStatus.WaitingForTournamentToFinish);
						}
						else
						{
							bool flag25 = this.tournament.Invite != null && this.tournament.Invite.Status == TournamentUserStatus.KickedOutByAdmin;
							if (flag25)
							{
								this.SetHubStatus(TournamentHubStatus.KickedOutByAdmin);
							}
						}
					}
				}
			}
			yield break;
		}

		// Token: 0x06000235 RID: 565 RVA: 0x00010320 File Offset: 0x0000E520
		private void ProcessJoinedTournamentMatch()
		{
			bool flag = this.IsInitialized && this.IsMatchHandlerInitialized;
			if (flag)
			{
				TournamentMatch.User matchUserById = this.tournamentMatch.GetMatchUserById(this.backboneClient.User.UserId);
				bool flag2 = !this.tournamentMatchCallbackHandler.IsConnectedToGameServerNetwork();
				if (flag2)
				{
					this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectingToGameServerNetwork);
				}
				else
				{
					bool flag3 = !this.tournamentMatchCallbackHandler.IsUserConnectedToMatch(this.backboneClient.User.UserId);
					if (flag3)
					{
						this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectingToMatch);
					}
					else
					{
						bool flag4 = !this.tournamentMatchCallbackHandler.IsGameSessionInProgress();
						if (flag4)
						{
							switch (this.tournamentMatch.Status)
							{
							case TournamentMatchStatus.Created:
							case TournamentMatchStatus.WaitingForOpponent:
							{
								bool flag5 = matchUserById != null && this.tournamentMatchCallbackHandler.IsUserReadyForMatch(matchUserById.UserId);
								if (flag5)
								{
									this.SetUserReady();
								}
								bool flag6 = matchUserById != null && !this.tournamentMatch.IsTeamFullyCheckedIn(matchUserById);
								if (flag6)
								{
									this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedWaitingForTeamatesToCheckIn);
								}
								else
								{
									this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedWaitingForMatchToFill);
									bool flag7 = matchUserById == null && this.tournamentMatch.Deadline <= ServerTime.UtcNow;
									if (flag7)
									{
										this.RefreshJoinedMatch();
									}
								}
								break;
							}
							case TournamentMatchStatus.GameReady:
							{
								DateTime matchStartDeadline = this.tournament.GetMatchStartDeadline(this.tournamentMatch);
								bool flag8 = this.tournamentMatch.FullyCheckedInTeamCount == this.tournament.GetTournamentPhaseById(this.tournamentMatch.PhaseId).MaxTeamsPerMatch;
								bool flag9 = this.tournamentMatch.PartiallyCheckedInTeamCount >= this.tournament.GetTournamentPhaseById(this.tournamentMatch.PhaseId).MinTeamsPerMatch;
								bool flag10 = matchUserById != null && this.tournamentMatchCallbackHandler.IsUserReadyForMatch(matchUserById.UserId) && (matchStartDeadline > ServerTime.UtcNow || matchUserById.IsCheckedIn || !flag9);
								if (flag10)
								{
									this.SetUserReady();
								}
								bool flag11 = (matchUserById == null || this.tournamentMatch.IsTeamPartiallyCheckedIn(matchUserById)) && this.tournamentMatchCallbackHandler.IsUserReadyForMatch(this.backboneClient.User.UserId) && this.IsJoinedTournamentMatchReady();
								if (flag11)
								{
									this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedStartingMatch);
									this.tournamentMatchCallbackHandler.StartGameSession(this.tournamentMatch.GetCheckInTeamUsers());
								}
								else
								{
									bool flag12 = matchUserById != null && !this.tournamentMatch.IsTeamFullyCheckedIn(matchUserById);
									if (flag12)
									{
										this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedWaitingForTeamatesToCheckIn);
									}
									else
									{
										bool flag13 = !flag9;
										if (flag13)
										{
											this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedWaitingForMatchToFill);
										}
										else
										{
											bool flag14 = !flag8 && matchStartDeadline > ServerTime.UtcNow;
											if (flag14)
											{
												this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedWaitingForMatchToFill);
											}
											else
											{
												this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedWaitingForStart);
											}
										}
									}
								}
								break;
							}
							case TournamentMatchStatus.GameInProgress:
							case TournamentMatchStatus.GameFinished:
							{
								bool flag15 = (matchUserById == null || this.tournamentMatch.IsTeamPartiallyCheckedIn(matchUserById)) && this.tournamentMatchCallbackHandler.IsUserReadyForMatch(this.backboneClient.User.UserId) && this.IsJoinedTournamentMatchReady();
								if (flag15)
								{
									this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedStartingMatch);
									this.tournamentMatchCallbackHandler.StartGameSession(this.tournamentMatch.GetCheckInTeamUsers());
								}
								else
								{
									bool flag16 = matchUserById != null && !this.tournamentMatch.IsTeamPartiallyCheckedIn(matchUserById);
									if (flag16)
									{
										this.SetHubMatchStatus(TournamentHubMatchStatus.PartyNotReadyInTime);
									}
									else
									{
										this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedWaitingForStart);
									}
								}
								break;
							}
							case TournamentMatchStatus.MatchFinished:
							case TournamentMatchStatus.Closed:
								this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedMatchFinished);
								break;
							}
						}
						else
						{
							this.SetHubMatchStatus(TournamentHubMatchStatus.ConnectedMatchInProgress);
						}
					}
				}
			}
		}

		// Token: 0x06000236 RID: 566 RVA: 0x000106D0 File Offset: 0x0000E8D0
		private bool IsJoinedTournamentMatchReady()
		{
			bool flag = this.tournamentMatch.FullyCheckedInTeamCount == this.tournament.GetTournamentPhaseById(this.tournamentMatch.PhaseId).MaxTeamsPerMatch;
			bool flag2 = this.tournamentMatch.PartiallyCheckedInTeamCount >= this.tournament.GetTournamentPhaseById(this.tournamentMatch.PhaseId).MinTeamsPerMatch;
			bool flag3 = true;
			DateTime matchStartDeadline = this.tournament.GetMatchStartDeadline(this.tournamentMatch);
			for (int i = 0; i < this.tournamentMatch.Users.Count; i++)
			{
				TournamentMatch.User user = this.tournamentMatch.Users[i];
				bool flag4 = this.tournamentMatch.IsTeamFullyCheckedIn(user);
				if (flag4)
				{
					flag3 &= this.tournamentMatchCallbackHandler.IsUserReadyForMatch(user.UserId);
				}
			}
			return (flag && flag3) || (flag2 && matchStartDeadline <= ServerTime.UtcNow);
		}

		// Token: 0x06000237 RID: 567 RVA: 0x000107CC File Offset: 0x0000E9CC
		private void SetHubMatchStatus(TournamentHubMatchStatus newStatus)
		{
			bool flag = this.matchStatus != newStatus;
			if (flag)
			{
				this.matchStatus = newStatus;
				bool flag2 = this.isInitialized && this.tournamentHubCallbackHandler != null;
				if (flag2)
				{
					this.tournamentHubCallbackHandler.OnHubMatchStatusChanged(this.matchStatus);
				}
			}
		}

		// Token: 0x06000238 RID: 568 RVA: 0x00010820 File Offset: 0x0000EA20
		private void SetHubStatus(TournamentHubStatus newStatus)
		{
			bool flag = this.hubStatus != newStatus;
			if (flag)
			{
				this.hubStatus = newStatus;
				bool flag2 = this.isInitialized && this.tournamentHubCallbackHandler != null;
				if (flag2)
				{
					this.tournamentHubCallbackHandler.OnHubStatusChanged(this.hubStatus);
				}
			}
		}

		// Token: 0x06000239 RID: 569 RVA: 0x00010874 File Offset: 0x0000EA74
		public void SetUserReady()
		{
			bool flag = !this.isProcessingUserReadyRequest && this.Tournament.Invite != null && this.Tournament.Invite.Status == TournamentUserStatus.Confirmed;
			if (flag)
			{
				this.isProcessingUserReadyRequest = true;
				bool flag2 = this.Status == TournamentHubStatus.WaitingForUserReadyConfirmation || (this.Tournament.UserActiveMatch != null && !this.Tournament.UserActiveMatch.GetMatchUserById(this.backboneClient.User.UserId).IsCheckedIn);
				if (flag2)
				{
					bool getAllData = this.Tournament.UserActiveMatch == null;
					this.backboneClient.LoadTournament(this.tournament.Id, getAllData, true, TimeSpan.Zero).FinishCallback(delegate
					{
						this.isProcessingUserReadyRequest = false;
					}).Run(this);
				}
				else
				{
					bool flag3 = this.lastSetUserReadyUpdate.AddSeconds(30.0) <= ServerTime.UtcNow;
					if (flag3)
					{
						this.backboneClient.LoadTournament(this.tournament.Id, false, true, TimeSpan.Zero).FinishCallback(delegate
						{
							this.isProcessingUserReadyRequest = false;
						}).ResultCallback(delegate(bool result)
						{
							if (result)
							{
								this.lastSetUserReadyUpdate = ServerTime.UtcNow;
								this.OnHubMatchUpdate();
							}
						}).Run(this);
					}
					else
					{
						this.isProcessingUserReadyRequest = false;
					}
				}
			}
		}

		// Token: 0x0600023A RID: 570 RVA: 0x000109C8 File Offset: 0x0000EBC8
		public void RefreshActiveMatch()
		{
			bool flag = !this.isProcessingRefreshActiveMatchRequest && this.Tournament.Invite != null && this.Tournament.Invite.Status == TournamentUserStatus.Confirmed;
			if (flag)
			{
				bool flag2 = this.Tournament.UserActiveMatch != null && (this.Tournament.UserActiveMatch.Status != TournamentMatchStatus.MatchFinished || this.Tournament.UserActiveMatch.Status != TournamentMatchStatus.Closed);
				if (flag2)
				{
					this.isProcessingRefreshActiveMatchRequest = true;
					this.backboneClient.LoadTournament(this.tournament.Id, false, false, TimeSpan.Zero).FinishCallback(delegate
					{
						this.isProcessingRefreshActiveMatchRequest = false;
					}).ResultCallback(delegate(bool result)
					{
						if (result)
						{
							this.OnHubMatchUpdate();
						}
					}).Run(this);
				}
			}
		}

		// Token: 0x0600023B RID: 571 RVA: 0x00010A9C File Offset: 0x0000EC9C
		private void RefreshJoinedMatch()
		{
			bool flag = !this.isProcessingRefreshJoinedMatchRequest;
			if (flag)
			{
				bool flag2 = this.tournamentMatch != null && (this.tournamentMatch.Status != TournamentMatchStatus.MatchFinished || this.tournamentMatch.Status != TournamentMatchStatus.Closed);
				if (flag2)
				{
					this.isProcessingRefreshJoinedMatchRequest = true;
					this.tournamentMatchIds[0] = this.tournamentMatch.Id;
					this.backboneClient.LoadTournamentMatches(this.tournament.Id, this.tournamentMatchIds).FinishCallback(delegate
					{
						this.isProcessingRefreshJoinedMatchRequest = false;
					}).ResultCallback(delegate(List<TournamentMatch> result)
					{
						bool flag3 = this.IsMatchHandlerInitialized && result != null && result.Count == 1 && result[0].Id == this.tournamentMatch.Id;
						if (flag3)
						{
							this.OnHubMatchUpdate();
						}
					}).Run(this);
				}
			}
		}

		// Token: 0x0600023C RID: 572 RVA: 0x00010B50 File Offset: 0x0000ED50
		public void OnHubMatchUpdate()
		{
			bool flag = this.isInitialized && this.tournamentHubCallbackHandler != null;
			if (flag)
			{
				this.tournamentHubCallbackHandler.OnHubMatchUpdate();
			}
		}

		// Token: 0x0600023D RID: 573 RVA: 0x00010B84 File Offset: 0x0000ED84
		public void OnTournamentUpdate()
		{
			bool flag = this.isInitialized && this.tournamentHubCallbackHandler != null;
			if (flag)
			{
				this.tournamentHubCallbackHandler.OnTournamentUpdate();
			}
		}

		// Token: 0x0600023E RID: 574 RVA: 0x00010BB8 File Offset: 0x0000EDB8
		public void JoinTournamentMatch(TournamentMatch match, ITournamentMatchCallbackHandler tournamentMatchHandler)
		{
			bool flag = this.IsInitialized && this.IsMatchHandlerInitialized;
			if (flag)
			{
				this.LeaveTournamentMatch();
			}
			bool flag2 = this.IsInitialized && match != null && tournamentMatchHandler != null && !string.IsNullOrEmpty(match.Secret);
			if (flag2)
			{
				this.tournamentMatch = match;
				this.tournamentMatchCallbackHandler = tournamentMatchHandler;
				this.tournamentMatchCallbackHandler.OnJoinTournamentMatch(this.Tournament, match, this);
			}
		}

		// Token: 0x0600023F RID: 575 RVA: 0x00010C2C File Offset: 0x0000EE2C
		public bool IsUserConnectedToMatch(long userId)
		{
			return this.IsMatchHandlerInitialized && this.tournamentMatchCallbackHandler.IsUserConnectedToMatch(userId);
		}

		// Token: 0x06000240 RID: 576 RVA: 0x00010C58 File Offset: 0x0000EE58
		public bool IsUserReadyForMatch(long userId)
		{
			return this.IsMatchHandlerInitialized && this.tournamentMatchCallbackHandler.IsUserReadyForMatch(userId);
		}

		// Token: 0x06000241 RID: 577 RVA: 0x00010C84 File Offset: 0x0000EE84
		public void LeaveTournamentMatch()
		{
			bool isMatchHandlerInitialized = this.IsMatchHandlerInitialized;
			if (isMatchHandlerInitialized)
			{
				this.tournamentMatchCallbackHandler.OnLeaveTournamentMatch();
			}
			this.tournamentMatch = null;
			this.tournamentMatchCallbackHandler = null;
			this.SetHubMatchStatus(TournamentHubMatchStatus.NotInitialized);
		}

		// Token: 0x06000242 RID: 578 RVA: 0x00010CC0 File Offset: 0x0000EEC0
		public void ReportJoinedUser(long userId)
		{
			bool isMatchHandlerInitialized = this.IsMatchHandlerInitialized;
			if (isMatchHandlerInitialized)
			{
				bool flag = this.tournamentMatch.GetMatchUserById(userId) == null;
				if (flag)
				{
					bool flag2 = this.Tournament.UserActiveMatch != null;
					if (flag2)
					{
						this.RefreshActiveMatch();
					}
					else
					{
						this.RefreshJoinedMatch();
					}
				}
				this.OnHubMatchUpdate();
			}
		}

		// Token: 0x06000243 RID: 579 RVA: 0x00010D1C File Offset: 0x0000EF1C
		public void ReportStatusChange()
		{
			bool isMatchHandlerInitialized = this.IsMatchHandlerInitialized;
			if (isMatchHandlerInitialized)
			{
				bool flag = this.tournamentMatch.Users.Any((TournamentMatch.User user) => !user.IsCheckedIn && this.tournamentMatchCallbackHandler.IsUserReadyForMatch(user.UserId)) || this.tournamentMatch.Deadline <= ServerTime.UtcNow;
				if (flag)
				{
					bool flag2 = this.Tournament.UserActiveMatch != null;
					if (flag2)
					{
						this.RefreshActiveMatch();
					}
					else
					{
						this.RefreshJoinedMatch();
					}
				}
				this.OnHubMatchUpdate();
			}
		}

		// Token: 0x06000244 RID: 580 RVA: 0x00010DA0 File Offset: 0x0000EFA0
		public void ReportDisconnectedUser(long userId)
		{
			bool isMatchHandlerInitialized = this.IsMatchHandlerInitialized;
			if (isMatchHandlerInitialized)
			{
				bool flag = this.tournamentMatch.GetMatchUserById(userId) != null;
				if (flag)
				{
					this.OnHubMatchUpdate();
				}
			}
		}

		// Token: 0x04000238 RID: 568
		private WaitForSeconds waitOneSecond = new WaitForSeconds(1f);

		// Token: 0x04000239 RID: 569
		private ITournamentHubCallbackHandler tournamentHubCallbackHandler;

		// Token: 0x0400023A RID: 570
		private BackboneClient backboneClient;

		// Token: 0x0400023B RID: 571
		private Tournament tournament;

		// Token: 0x0400023C RID: 572
		private DateTime nextEventTime;

		// Token: 0x0400023D RID: 573
		private DateTime matchDeadline;

		// Token: 0x0400023E RID: 574
		private DateTime matchStart;

		// Token: 0x0400023F RID: 575
		private TournamentHubStatus hubStatus;

		// Token: 0x04000240 RID: 576
		private bool isInitialized;

		// Token: 0x04000241 RID: 577
		private bool isProcessingUserReadyRequest;

		// Token: 0x04000242 RID: 578
		private bool isProcessingRefreshActiveMatchRequest;

		// Token: 0x04000243 RID: 579
		private bool isProcessingRefreshJoinedMatchRequest;

		// Token: 0x04000244 RID: 580
		private DateTime lastSetUserReadyUpdate;

		// Token: 0x04000245 RID: 581
		private TournamentMatch tournamentMatch;

		// Token: 0x04000246 RID: 582
		private ITournamentMatchCallbackHandler tournamentMatchCallbackHandler;

		// Token: 0x04000247 RID: 583
		private TournamentHubMatchStatus matchStatus;

		// Token: 0x04000248 RID: 584
		private long[] tournamentMatchIds = new long[1];
	}
}
