﻿using System;
using Gimmebreak.Backbone.Core;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200002D RID: 45
	public class InviteResult : BackboneHttpResult
	{
		// Token: 0x1700006B RID: 107
		// (get) Token: 0x0600018B RID: 395 RVA: 0x00003949 File Offset: 0x00001B49
		// (set) Token: 0x0600018C RID: 396 RVA: 0x00003951 File Offset: 0x00001B51
		public TournamentSignUpStatus ProcessStatus { get; private set; }

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x0600018D RID: 397 RVA: 0x0000395A File Offset: 0x00001B5A
		// (set) Token: 0x0600018E RID: 398 RVA: 0x00003962 File Offset: 0x00001B62
		public long InviteId { get; private set; }

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x0600018F RID: 399 RVA: 0x0000396B File Offset: 0x00001B6B
		// (set) Token: 0x06000190 RID: 400 RVA: 0x00003973 File Offset: 0x00001B73
		public TournamentUserStatus InviteStatus { get; set; }

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000191 RID: 401 RVA: 0x0000CDD4 File Offset: 0x0000AFD4
		public bool IsExternalSignupError
		{
			get
			{
				return base.IsHttpError && (base.ErrorCode == 109 || base.ErrorCode == 110 || base.ErrorCode == 111);
			}
		}

		// Token: 0x06000192 RID: 402 RVA: 0x0000CE14 File Offset: 0x0000B014
		public InviteResult(BackboneHttpResult httpResponse) : base(httpResponse.ResponseCode, httpResponse.JsonResult, httpResponse.ErrorCode, httpResponse.ErrorMessage, httpResponse.ErrorReference)
		{
			bool flag = !httpResponse.HasError && httpResponse.JsonResult != null && httpResponse.JsonResult.HasFields(InviteResult.REQUIRED_FIELDS);
			if (flag)
			{
				this.ProcessStatus = httpResponse.JsonResult["status"].ToEnum(TournamentSignUpStatus.NotSigned);
				bool flag2 = !httpResponse.JsonResult["inviteId"].IsNull;
				if (flag2)
				{
					this.InviteId = long.Parse(httpResponse.JsonResult["inviteId"].str);
				}
				this.InviteStatus = httpResponse.JsonResult["inviteStatus"].ToEnum(TournamentUserStatus.Unkown);
			}
		}

		// Token: 0x04000129 RID: 297
		private static readonly string[] REQUIRED_FIELDS = new string[]
		{
			"status",
			"inviteId",
			"inviteStatus"
		};
	}
}
