﻿using System;
using System.Collections.Generic;
using Gimmebreak.Backbone.Notifications;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200002B RID: 43
	public interface ITournamentHubController
	{
		// Token: 0x1700005E RID: 94
		// (get) Token: 0x06000174 RID: 372
		TimeSpan NextEventCountdown { get; }

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x06000175 RID: 373
		TimeSpan ActiveMatchFinishDeadlineCountdown { get; }

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x06000176 RID: 374
		TimeSpan ActiveMatchStartDeadlineCountdown { get; }

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000177 RID: 375
		TournamentHubStatus Status { get; }

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000178 RID: 376
		bool IsTournamentRunning { get; }

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000179 RID: 377
		bool IsUserKnockedOut { get; }

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x0600017A RID: 378
		IEnumerable<TournamentPartyInviteNotification> PartyInvites { get; }

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x0600017B RID: 379
		Tournament Tournament { get; }

		// Token: 0x0600017C RID: 380
		void SetUserReady();

		// Token: 0x0600017D RID: 381
		void RefreshActiveMatch();

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x0600017E RID: 382
		bool IsMatchHandlerInitialized { get; }

		// Token: 0x0600017F RID: 383
		void JoinTournamentMatch(TournamentMatch match, ITournamentMatchCallbackHandler tournamentMatchHandler);

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000180 RID: 384
		bool IsConnectedToGameServerNetwork { get; }

		// Token: 0x06000181 RID: 385
		bool IsUserConnectedToMatch(long userId);

		// Token: 0x06000182 RID: 386
		bool IsUserReadyForMatch(long userId);

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000183 RID: 387
		bool IsGameSessionInProgress { get; }

		// Token: 0x06000184 RID: 388
		void LeaveTournamentMatch();
	}
}
