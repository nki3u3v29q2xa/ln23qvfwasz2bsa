﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200003C RID: 60
	public enum TournamentHubStatus
	{
		// Token: 0x0400021D RID: 541
		RegistrationClosed,
		// Token: 0x0400021E RID: 542
		RegistrationOpening,
		// Token: 0x0400021F RID: 543
		RegistrationOpened,
		// Token: 0x04000220 RID: 544
		RegistrationClosing,
		// Token: 0x04000221 RID: 545
		WaitingForTournamentStart,
		// Token: 0x04000222 RID: 546
		Starting,
		// Token: 0x04000223 RID: 547
		Started,
		// Token: 0x04000224 RID: 548
		ResolvingPartiallyFilledMatch,
		// Token: 0x04000225 RID: 549
		ClosingOverdueMatch,
		// Token: 0x04000226 RID: 550
		MatchInProgress,
		// Token: 0x04000227 RID: 551
		KickedOutByAdmin,
		// Token: 0x04000228 RID: 552
		WaitingForUserReadyConfirmation,
		// Token: 0x04000229 RID: 553
		WaitingForNextPhase,
		// Token: 0x0400022A RID: 554
		WaitingForTournamentToFinish,
		// Token: 0x0400022B RID: 555
		Finishing,
		// Token: 0x0400022C RID: 556
		Finished
	}
}
