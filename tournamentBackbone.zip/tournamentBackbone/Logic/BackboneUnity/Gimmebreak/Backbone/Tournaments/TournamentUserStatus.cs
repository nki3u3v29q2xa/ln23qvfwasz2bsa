﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000030 RID: 48
	public enum TournamentUserStatus
	{
		// Token: 0x0400013B RID: 315
		Unkown = -1,
		// Token: 0x0400013C RID: 316
		Invited,
		// Token: 0x0400013D RID: 317
		Confirmed,
		// Token: 0x0400013E RID: 318
		Declined,
		// Token: 0x0400013F RID: 319
		PartyNotFull,
		// Token: 0x04000140 RID: 320
		ProcessingSignup,
		// Token: 0x04000141 RID: 321
		ProcessingSignupFail,
		// Token: 0x04000142 RID: 322
		ProcessingSignout,
		// Token: 0x04000143 RID: 323
		ProcessingSignoutFail,
		// Token: 0x04000144 RID: 324
		KickedOutByAdmin
	}
}
