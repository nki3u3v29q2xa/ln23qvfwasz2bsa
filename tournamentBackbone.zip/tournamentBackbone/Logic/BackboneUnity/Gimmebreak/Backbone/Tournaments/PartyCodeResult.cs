﻿using System;
using Gimmebreak.Backbone.Core;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000026 RID: 38
	public class PartyCodeResult : BackboneHttpResult
	{
		// Token: 0x1700004A RID: 74
		// (get) Token: 0x0600013E RID: 318 RVA: 0x0000373F File Offset: 0x0000193F
		// (set) Token: 0x0600013F RID: 319 RVA: 0x00003747 File Offset: 0x00001947
		public TournamentCreatePartyCodeStatus Status { get; private set; }

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000140 RID: 320 RVA: 0x00003750 File Offset: 0x00001950
		// (set) Token: 0x06000141 RID: 321 RVA: 0x00003758 File Offset: 0x00001958
		public string PartyCode { get; private set; }

		// Token: 0x06000142 RID: 322 RVA: 0x0000C668 File Offset: 0x0000A868
		public PartyCodeResult(BackboneHttpResult httpResponse) : base(httpResponse.ResponseCode, httpResponse.JsonResult, httpResponse.ErrorCode, httpResponse.ErrorMessage, httpResponse.ErrorReference)
		{
			bool flag = !httpResponse.HasError && httpResponse.JsonResult != null && httpResponse.JsonResult.HasFields(PartyCodeResult.REQUIRED_FIELDS);
			if (flag)
			{
				this.Status = httpResponse.JsonResult["status"].ToEnum(TournamentCreatePartyCodeStatus.NotAttempted);
				bool flag2 = !httpResponse.JsonResult["partyCode"].IsNull;
				if (flag2)
				{
					this.PartyCode = httpResponse.JsonResult["partyCode"].str;
				}
			}
		}

		// Token: 0x040000FB RID: 251
		private static readonly string[] REQUIRED_FIELDS = new string[]
		{
			"status",
			"partyCode"
		};
	}
}
