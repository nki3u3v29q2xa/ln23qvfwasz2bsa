﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000048 RID: 72
	[XmlType(Namespace = "TournamentWinner")]
	[Serializable]
	public class TournamentWinner
	{
		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x060002F6 RID: 758 RVA: 0x00004411 File Offset: 0x00002611
		// (set) Token: 0x060002F7 RID: 759 RVA: 0x00004419 File Offset: 0x00002619
		public List<TournamentWinner.User> Users { get; set; }

		// Token: 0x060002F8 RID: 760 RVA: 0x00004422 File Offset: 0x00002622
		public TournamentWinner()
		{
			this.Users = new List<TournamentWinner.User>();
			this.removeUsers = new HashSet<long>();
		}

		// Token: 0x060002F9 RID: 761 RVA: 0x0001277C File Offset: 0x0001097C
		internal void LoadJSONWinners(JSONObject data)
		{
			bool flag = data == null || !data.HasField(TournamentWinner.FIELD_WINNERDATA) || !data[TournamentWinner.FIELD_WINNERDATA][0].HasField(TournamentWinner.FIELD_WINNERDATA_USER);
			if (!flag)
			{
				List<JSONObject> list = data[TournamentWinner.FIELD_WINNERDATA][0][TournamentWinner.FIELD_WINNERDATA_USER].list;
				this.removeUsers.Clear();
				for (int i = 0; i < this.Users.Count; i++)
				{
					this.removeUsers.Add(this.Users[i].UserId);
				}
				for (int j = 0; j < list.Count; j++)
				{
					JSONObject jsonobject = list[j];
					bool flag2 = jsonobject.HasField(TournamentWinner.FIELD_WINNERDATA_USER_USERID);
					if (flag2)
					{
						long num = long.Parse(jsonobject[TournamentWinner.FIELD_WINNERDATA_USER_USERID].str);
						TournamentWinner.User user = this.GetWinnerById(num);
						bool flag3 = user == null;
						if (flag3)
						{
							user = new TournamentWinner.User();
							user.UserId = num;
							this.Users.Add(user);
						}
						bool flag4 = jsonobject.HasField(TournamentWinner.FIELD_WINNERDATA_USER_USERNICK);
						if (flag4)
						{
							user.Nick = jsonobject[TournamentWinner.FIELD_WINNERDATA_USER_USERNICK].str;
						}
						this.removeUsers.Remove(num);
					}
				}
			}
		}

		// Token: 0x060002FA RID: 762 RVA: 0x000128F8 File Offset: 0x00010AF8
		public TournamentWinner.User GetWinnerById(long userId)
		{
			return this.Users.FirstOrDefault((TournamentWinner.User user) => user.UserId == userId);
		}

		// Token: 0x040002CA RID: 714
		internal static readonly string FIELD_WINNERDATA = "winner-data";

		// Token: 0x040002CB RID: 715
		private static readonly string FIELD_WINNERDATA_USER = "user";

		// Token: 0x040002CC RID: 716
		private static readonly string FIELD_WINNERDATA_USER_USERID = "@user-id";

		// Token: 0x040002CD RID: 717
		private static readonly string FIELD_WINNERDATA_USER_USERNICK = "@nick";

		// Token: 0x040002CE RID: 718
		private HashSet<long> removeUsers;

		// Token: 0x02000097 RID: 151
		[Serializable]
		public class User
		{
			// Token: 0x170001A9 RID: 425
			// (get) Token: 0x06000648 RID: 1608 RVA: 0x00006066 File Offset: 0x00004266
			// (set) Token: 0x06000649 RID: 1609 RVA: 0x0000606E File Offset: 0x0000426E
			public long UserId { get; set; }

			// Token: 0x170001AA RID: 426
			// (get) Token: 0x0600064A RID: 1610 RVA: 0x00006077 File Offset: 0x00004277
			// (set) Token: 0x0600064B RID: 1611 RVA: 0x0000607F File Offset: 0x0000427F
			public string Nick { get; set; }
		}
	}
}
