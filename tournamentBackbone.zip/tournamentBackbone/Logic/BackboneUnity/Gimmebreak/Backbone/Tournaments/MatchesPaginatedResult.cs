﻿using System;
using System.Collections.Generic;
using Gimmebreak.Backbone.Core;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000029 RID: 41
	public class MatchesPaginatedResult : PaginatedHttpResult
	{
		// Token: 0x1700005D RID: 93
		// (get) Token: 0x0600016C RID: 364 RVA: 0x000038E6 File Offset: 0x00001AE6
		// (set) Token: 0x0600016D RID: 365 RVA: 0x000038EE File Offset: 0x00001AEE
		public List<TournamentMatch> Matches { get; private set; }

		// Token: 0x0600016E RID: 366 RVA: 0x000038F7 File Offset: 0x00001AF7
		public MatchesPaginatedResult(List<TournamentMatch> parsedMatches, BackboneHttpResult httpResponse) : base(httpResponse)
		{
			this.Matches = parsedMatches;
		}
	}
}
