﻿using System;
using System.Collections.Generic;
using Gimmebreak.Backbone.Core;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000033 RID: 51
	[Serializable]
	public class TournamentCustomProperties
	{
		// Token: 0x1700009D RID: 157
		// (get) Token: 0x0600020F RID: 527 RVA: 0x00003CAF File Offset: 0x00001EAF
		// (set) Token: 0x06000210 RID: 528 RVA: 0x00003CB7 File Offset: 0x00001EB7
		public SerializableDictionary<string, string> Properties { get; set; }

		// Token: 0x06000211 RID: 529 RVA: 0x00003CC0 File Offset: 0x00001EC0
		public TournamentCustomProperties()
		{
			this.Properties = new SerializableDictionary<string, string>();
		}

		// Token: 0x06000212 RID: 530 RVA: 0x0000F8B4 File Offset: 0x0000DAB4
		internal void LoadJsonCusomProperties(JSONObject data)
		{
			bool flag = data != null && data.HasField(TournamentCustomProperties.FIELD_DATA_PROPERTYSETTING) && data[TournamentCustomProperties.FIELD_DATA_PROPERTYSETTING][0].HasField(TournamentCustomProperties.FIELD_DATA_PROPERTIES) && data[TournamentCustomProperties.FIELD_DATA_PROPERTYSETTING][0][TournamentCustomProperties.FIELD_DATA_PROPERTIES][0].HasField(TournamentCustomProperties.FIELD_DATA_PROPERTY) && data[TournamentCustomProperties.FIELD_DATA_PROPERTYSETTING][0][TournamentCustomProperties.FIELD_DATA_PROPERTIES][0][TournamentCustomProperties.FIELD_DATA_PROPERTY].IsArray;
			if (flag)
			{
				List<JSONObject> list = data[TournamentCustomProperties.FIELD_DATA_PROPERTYSETTING][0][TournamentCustomProperties.FIELD_DATA_PROPERTIES][0][TournamentCustomProperties.FIELD_DATA_PROPERTY].list;
				this.Properties.Clear();
				for (int i = 0; i < list.Count; i++)
				{
					JSONObject jsonobject = list[i];
					this.Properties.Add(jsonobject[TournamentCustomProperties.FIELD_DATA_PROPERTYNAME].str, jsonobject[TournamentCustomProperties.FIELD_DATA_PROPERTYVALUE].str);
				}
			}
		}

		// Token: 0x040001D8 RID: 472
		internal static readonly string FIELD_DATA_PROPERTYSETTING = "property-setting";

		// Token: 0x040001D9 RID: 473
		private static readonly string FIELD_DATA_PROPERTIES = "properties";

		// Token: 0x040001DA RID: 474
		private static readonly string FIELD_DATA_PROPERTY = "property";

		// Token: 0x040001DB RID: 475
		private static readonly string FIELD_DATA_PROPERTYNAME = "@name";

		// Token: 0x040001DC RID: 476
		private static readonly string FIELD_DATA_PROPERTYVALUE = "@value";
	}
}
