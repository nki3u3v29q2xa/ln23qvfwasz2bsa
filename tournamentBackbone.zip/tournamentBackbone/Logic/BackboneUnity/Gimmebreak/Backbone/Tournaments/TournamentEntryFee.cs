﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200003B RID: 59
	[XmlType(Namespace = "TournamentEntryFee")]
	[Serializable]
	public class TournamentEntryFee
	{
		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x0600021E RID: 542 RVA: 0x00003D9A File Offset: 0x00001F9A
		// (set) Token: 0x0600021F RID: 543 RVA: 0x00003DA2 File Offset: 0x00001FA2
		public List<TournamentEntryFee.Item> Items { get; set; }

		// Token: 0x06000220 RID: 544 RVA: 0x00003DAB File Offset: 0x00001FAB
		public TournamentEntryFee()
		{
			this.Items = new List<TournamentEntryFee.Item>();
			this.removeItems = new HashSet<long>();
		}

		// Token: 0x06000221 RID: 545 RVA: 0x0000FDA0 File Offset: 0x0000DFA0
		internal void LoadJSONEntryFee(JSONObject data)
		{
			this.removeItems.Clear();
			for (int i = 0; i < this.Items.Count; i++)
			{
				this.removeItems.Add(this.Items[i].Id);
				this.Items[i].Amount = 0m;
				this.Items[i].PotAmount = 0m;
				this.Items[i].ExternalId = null;
			}
			bool flag = data.HasField(TournamentEntryFee.FIELD_DATA_ITEM);
			if (flag)
			{
				List<JSONObject> list = data[TournamentEntryFee.FIELD_DATA_ITEM].list;
				for (int j = 0; j < list.Count; j++)
				{
					JSONObject jsonobject = list[j];
					long num = long.Parse(jsonobject[TournamentEntryFee.FIELD_DATA_ID].str);
					TournamentEntryFee.Item item2 = this.GetFeeItemById(num);
					bool flag2 = item2 == null;
					if (flag2)
					{
						item2 = new TournamentEntryFee.Item();
						item2.Id = num;
						this.Items.Add(item2);
					}
					bool flag3 = jsonobject.HasField(TournamentEntryFee.FIELD_DATA_EXTERNALID);
					if (flag3)
					{
						item2.ExternalId = jsonobject[TournamentEntryFee.FIELD_DATA_EXTERNALID].str;
					}
					item2.Type = (TournamentItemType)int.Parse(jsonobject[TournamentEntryFee.FIELD_DATA_TYPE].str);
					int value = int.Parse(jsonobject[TournamentEntryFee.FIELD_DATA_AMOUNT].str);
					bool flag4 = jsonobject.HasField(TournamentEntryFee.FIELD_DATA_ADDTOPOT) && jsonobject[TournamentEntryFee.FIELD_DATA_ADDTOPOT].str == "1";
					item2.Amount += value;
					bool flag5 = flag4;
					if (flag5)
					{
						item2.PotAmount += value;
					}
					this.removeItems.Remove(num);
				}
			}
			this.Items.RemoveAll((TournamentEntryFee.Item item) => this.removeItems.Contains(item.Id));
		}

		// Token: 0x06000222 RID: 546 RVA: 0x0000FFCC File Offset: 0x0000E1CC
		public TournamentEntryFee.Item GetFeeItemById(long itemId)
		{
			return this.Items.FirstOrDefault((TournamentEntryFee.Item item) => item.Id == itemId);
		}

		// Token: 0x04000212 RID: 530
		internal static readonly string FIELD_DATA_ENTRYFEE = "entry-fee";

		// Token: 0x04000213 RID: 531
		private static readonly string FIELD_DATA_MINRAKE = "@min-rake";

		// Token: 0x04000214 RID: 532
		private static readonly string FIELD_DATA_ITEM = "item";

		// Token: 0x04000215 RID: 533
		private static readonly string FIELD_DATA_ID = "@id";

		// Token: 0x04000216 RID: 534
		private static readonly string FIELD_DATA_TYPE = "@type";

		// Token: 0x04000217 RID: 535
		private static readonly string FIELD_DATA_AMOUNT = "@amount";

		// Token: 0x04000218 RID: 536
		private static readonly string FIELD_DATA_EXTERNALID = "@external-id";

		// Token: 0x04000219 RID: 537
		private static readonly string FIELD_DATA_ADDTOPOT = "@add-to-pot";

		// Token: 0x0400021A RID: 538
		private HashSet<long> removeItems;

		// Token: 0x02000084 RID: 132
		[Serializable]
		public class Item
		{
			// Token: 0x17000186 RID: 390
			// (get) Token: 0x060005D9 RID: 1497 RVA: 0x00005C55 File Offset: 0x00003E55
			// (set) Token: 0x060005DA RID: 1498 RVA: 0x00005C5D File Offset: 0x00003E5D
			public long Id { get; set; }

			// Token: 0x17000187 RID: 391
			// (get) Token: 0x060005DB RID: 1499 RVA: 0x00005C66 File Offset: 0x00003E66
			// (set) Token: 0x060005DC RID: 1500 RVA: 0x00005C6E File Offset: 0x00003E6E
			public TournamentItemType Type { get; set; }

			// Token: 0x17000188 RID: 392
			// (get) Token: 0x060005DD RID: 1501 RVA: 0x00005C77 File Offset: 0x00003E77
			// (set) Token: 0x060005DE RID: 1502 RVA: 0x00005C7F File Offset: 0x00003E7F
			public decimal Amount { get; set; }

			// Token: 0x17000189 RID: 393
			// (get) Token: 0x060005DF RID: 1503 RVA: 0x00005C88 File Offset: 0x00003E88
			// (set) Token: 0x060005E0 RID: 1504 RVA: 0x00005C90 File Offset: 0x00003E90
			public decimal PotAmount { get; set; }

			// Token: 0x1700018A RID: 394
			// (get) Token: 0x060005E1 RID: 1505 RVA: 0x00005C99 File Offset: 0x00003E99
			// (set) Token: 0x060005E2 RID: 1506 RVA: 0x00005CA1 File Offset: 0x00003EA1
			public string ExternalId { get; set; }
		}
	}
}
