﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000037 RID: 55
	public enum TournamentRemoveUserStatus
	{
		// Token: 0x040001F3 RID: 499
		Unknown = -1,
		// Token: 0x040001F4 RID: 500
		NotAttempted,
		// Token: 0x040001F5 RID: 501
		Ok,
		// Token: 0x040001F6 RID: 502
		UserIsNotPartyLeader,
		// Token: 0x040001F7 RID: 503
		TournamentRegistrationClosed,
		// Token: 0x040001F8 RID: 504
		UserIsNotSignedUp
	}
}
