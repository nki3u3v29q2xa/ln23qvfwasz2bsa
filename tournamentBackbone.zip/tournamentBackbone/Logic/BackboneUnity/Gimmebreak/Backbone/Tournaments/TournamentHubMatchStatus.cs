﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200003D RID: 61
	public enum TournamentHubMatchStatus
	{
		// Token: 0x0400022E RID: 558
		NotInitialized,
		// Token: 0x0400022F RID: 559
		ConnectingToGameServerNetwork,
		// Token: 0x04000230 RID: 560
		ConnectingToMatch,
		// Token: 0x04000231 RID: 561
		ConnectedWaitingForTeamatesToCheckIn,
		// Token: 0x04000232 RID: 562
		ConnectedWaitingForMatchToFill,
		// Token: 0x04000233 RID: 563
		ConnectedWaitingForStart,
		// Token: 0x04000234 RID: 564
		ConnectedStartingMatch,
		// Token: 0x04000235 RID: 565
		ConnectedMatchInProgress,
		// Token: 0x04000236 RID: 566
		ConnectedMatchFinished,
		// Token: 0x04000237 RID: 567
		PartyNotReadyInTime
	}
}
