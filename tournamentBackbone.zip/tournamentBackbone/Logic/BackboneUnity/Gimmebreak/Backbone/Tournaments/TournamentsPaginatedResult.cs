﻿using System;
using System.Collections.Generic;
using Gimmebreak.Backbone.Core;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000028 RID: 40
	public class TournamentsPaginatedResult : PaginatedHttpResult
	{
		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06000169 RID: 361 RVA: 0x000038C2 File Offset: 0x00001AC2
		// (set) Token: 0x0600016A RID: 362 RVA: 0x000038CA File Offset: 0x00001ACA
		public List<Tournament> Tournaments { get; private set; }

		// Token: 0x0600016B RID: 363 RVA: 0x000038D3 File Offset: 0x00001AD3
		public TournamentsPaginatedResult(List<Tournament> parsedTournaments, BackboneHttpResult httpResponse) : base(httpResponse)
		{
			this.Tournaments = parsedTournaments;
		}
	}
}
