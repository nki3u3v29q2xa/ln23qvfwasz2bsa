﻿using System;
using Gimmebreak.Backbone.Core;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x0200002C RID: 44
	public class PartyInviteResult : BackboneHttpResult
	{
		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000185 RID: 389 RVA: 0x0000390A File Offset: 0x00001B0A
		// (set) Token: 0x06000186 RID: 390 RVA: 0x00003912 File Offset: 0x00001B12
		public TournamentCreatePartyInviteStatus Status { get; private set; }

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x06000187 RID: 391 RVA: 0x0000391B File Offset: 0x00001B1B
		// (set) Token: 0x06000188 RID: 392 RVA: 0x00003923 File Offset: 0x00001B23
		public long PartyInviteId { get; private set; }

		// Token: 0x06000189 RID: 393 RVA: 0x0000CD1C File Offset: 0x0000AF1C
		public PartyInviteResult(BackboneHttpResult httpResponse) : base(httpResponse.ResponseCode, httpResponse.JsonResult, httpResponse.ErrorCode, httpResponse.ErrorMessage, httpResponse.ErrorReference)
		{
			bool flag = !httpResponse.HasError && httpResponse.JsonResult != null && httpResponse.JsonResult.HasFields(PartyInviteResult.REQUIRED_FIELDS);
			if (flag)
			{
				this.Status = httpResponse.JsonResult["status"].ToEnum(TournamentCreatePartyInviteStatus.NotAttempted);
				bool flag2 = !httpResponse.JsonResult["partyInviteId"].IsNull;
				if (flag2)
				{
					this.PartyInviteId = long.Parse(httpResponse.JsonResult["partyInviteId"].str);
				}
			}
		}

		// Token: 0x04000126 RID: 294
		private static readonly string[] REQUIRED_FIELDS = new string[]
		{
			"status",
			"partyInviteId"
		};
	}
}
