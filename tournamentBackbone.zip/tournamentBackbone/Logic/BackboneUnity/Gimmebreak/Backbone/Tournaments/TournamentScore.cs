﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000027 RID: 39
	[XmlType(Namespace = "TournamentScore")]
	[Serializable]
	public class TournamentScore
	{
		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000144 RID: 324 RVA: 0x0000377E File Offset: 0x0000197E
		// (set) Token: 0x06000145 RID: 325 RVA: 0x00003786 File Offset: 0x00001986
		public long PartyId { get; set; }

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000146 RID: 326 RVA: 0x0000378F File Offset: 0x0000198F
		// (set) Token: 0x06000147 RID: 327 RVA: 0x00003797 File Offset: 0x00001997
		public int PhaseId { get; set; }

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000148 RID: 328 RVA: 0x000037A0 File Offset: 0x000019A0
		// (set) Token: 0x06000149 RID: 329 RVA: 0x000037A8 File Offset: 0x000019A8
		public int GroupId { get; set; }

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x0600014A RID: 330 RVA: 0x000037B1 File Offset: 0x000019B1
		// (set) Token: 0x0600014B RID: 331 RVA: 0x000037B9 File Offset: 0x000019B9
		public bool IsCheckedIn { get; set; }

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x0600014C RID: 332 RVA: 0x000037C2 File Offset: 0x000019C2
		// (set) Token: 0x0600014D RID: 333 RVA: 0x000037CA File Offset: 0x000019CA
		public int Position { get; set; }

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x0600014E RID: 334 RVA: 0x000037D3 File Offset: 0x000019D3
		// (set) Token: 0x0600014F RID: 335 RVA: 0x000037DB File Offset: 0x000019DB
		public int TotalPoints { get; set; }

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000150 RID: 336 RVA: 0x000037E4 File Offset: 0x000019E4
		// (set) Token: 0x06000151 RID: 337 RVA: 0x000037EC File Offset: 0x000019EC
		public int MatchWins { get; set; }

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000152 RID: 338 RVA: 0x000037F5 File Offset: 0x000019F5
		// (set) Token: 0x06000153 RID: 339 RVA: 0x000037FD File Offset: 0x000019FD
		public int MatchLoses { get; set; }

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x06000154 RID: 340 RVA: 0x00003806 File Offset: 0x00001A06
		// (set) Token: 0x06000155 RID: 341 RVA: 0x0000380E File Offset: 0x00001A0E
		public int GameWins { get; set; }

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000156 RID: 342 RVA: 0x00003817 File Offset: 0x00001A17
		// (set) Token: 0x06000157 RID: 343 RVA: 0x0000381F File Offset: 0x00001A1F
		public int GameLoses { get; set; }

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000158 RID: 344 RVA: 0x00003828 File Offset: 0x00001A28
		// (set) Token: 0x06000159 RID: 345 RVA: 0x00003830 File Offset: 0x00001A30
		public decimal Stat1Summed { get; set; }

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x0600015A RID: 346 RVA: 0x00003839 File Offset: 0x00001A39
		// (set) Token: 0x0600015B RID: 347 RVA: 0x00003841 File Offset: 0x00001A41
		public decimal Stat2Summed { get; set; }

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x0600015C RID: 348 RVA: 0x0000384A File Offset: 0x00001A4A
		// (set) Token: 0x0600015D RID: 349 RVA: 0x00003852 File Offset: 0x00001A52
		public int Seed { get; set; }

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x0600015E RID: 350 RVA: 0x0000385B File Offset: 0x00001A5B
		// (set) Token: 0x0600015F RID: 351 RVA: 0x00003863 File Offset: 0x00001A63
		public int LoseWeight { get; set; }

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000160 RID: 352 RVA: 0x0000386C File Offset: 0x00001A6C
		// (set) Token: 0x06000161 RID: 353 RVA: 0x00003874 File Offset: 0x00001A74
		public int TotalRounds { get; set; }

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06000162 RID: 354 RVA: 0x0000387D File Offset: 0x00001A7D
		// (set) Token: 0x06000163 RID: 355 RVA: 0x00003885 File Offset: 0x00001A85
		public List<TournamentParty.User> Users { get; set; }

		// Token: 0x06000164 RID: 356 RVA: 0x0000388E File Offset: 0x00001A8E
		public TournamentScore()
		{
			this.removeUsers = new HashSet<long>();
			this.Users = new List<TournamentParty.User>();
		}

		// Token: 0x06000165 RID: 357 RVA: 0x0000C71C File Offset: 0x0000A91C
		internal void LoadJSONScore(JSONObject data)
		{
			bool flag = data.HasField(TournamentScore.FIELD_PARTYID) && !data[TournamentScore.FIELD_PARTYID].IsNull;
			if (flag)
			{
				this.PartyId = long.Parse(data[TournamentScore.FIELD_PARTYID].str);
			}
			bool flag2 = data.HasField(TournamentScore.FIELD_PHASEID);
			if (flag2)
			{
				this.PhaseId = (int)data[TournamentScore.FIELD_PHASEID].f;
			}
			bool flag3 = data.HasField(TournamentScore.FIELD_GROUPID);
			if (flag3)
			{
				this.GroupId = (int)data[TournamentScore.FIELD_GROUPID].f;
			}
			bool flag4 = data.HasField(TournamentScore.FIELD_CHECKIN);
			if (flag4)
			{
				this.IsCheckedIn = data[TournamentScore.FIELD_CHECKIN].b;
			}
			bool flag5 = data.HasField(TournamentScore.FIELD_POSITION);
			if (flag5)
			{
				this.Position = (int)data[TournamentScore.FIELD_POSITION].f;
			}
			bool flag6 = data.HasField(TournamentScore.FIELD_TOTALPOINTS);
			if (flag6)
			{
				this.TotalPoints = (int)data[TournamentScore.FIELD_TOTALPOINTS].f;
			}
			bool flag7 = data.HasField(TournamentScore.FIELD_MATCHWINS);
			if (flag7)
			{
				this.MatchWins = (int)data[TournamentScore.FIELD_MATCHWINS].f;
			}
			bool flag8 = data.HasField(TournamentScore.FIELD_MATCHLOSES);
			if (flag8)
			{
				this.MatchLoses = (int)data[TournamentScore.FIELD_MATCHLOSES].f;
			}
			bool flag9 = data.HasField(TournamentScore.FIELD_GAMEWINS);
			if (flag9)
			{
				this.GameWins = (int)data[TournamentScore.FIELD_GAMEWINS].f;
			}
			bool flag10 = data.HasField(TournamentScore.FIELD_GAMELOSES);
			if (flag10)
			{
				this.GameLoses = (int)data[TournamentScore.FIELD_GAMELOSES].f;
			}
			bool flag11 = data.HasField(TournamentScore.FIELD_STAT1SUM);
			if (flag11)
			{
				this.Stat1Summed = (decimal)data[TournamentScore.FIELD_STAT1SUM].f;
			}
			bool flag12 = data.HasField(TournamentScore.FIELD_STAT2SUM);
			if (flag12)
			{
				this.Stat2Summed = (decimal)data[TournamentScore.FIELD_STAT2SUM].f;
			}
			bool flag13 = data.HasField(TournamentScore.FIELD_SEED);
			if (flag13)
			{
				this.Seed = (int)data[TournamentScore.FIELD_SEED].f;
			}
			bool flag14 = data.HasField(TournamentScore.FIELD_LOSEWEIGHT);
			if (flag14)
			{
				this.LoseWeight = (int)data[TournamentScore.FIELD_LOSEWEIGHT].f;
			}
			bool flag15 = data.HasField(TournamentScore.FIELD_TOTALROUNDS);
			if (flag15)
			{
				this.TotalRounds = (int)data[TournamentScore.FIELD_TOTALROUNDS].f;
			}
			this.removeUsers.Clear();
			for (int i = 0; i < this.Users.Count; i++)
			{
				this.removeUsers.Add(this.Users[i].UserId);
			}
			bool flag16 = data.HasField(TournamentScore.FIELD_USERS) && !data[TournamentScore.FIELD_USERS].IsNull;
			if (flag16)
			{
				List<JSONObject> list = data[TournamentScore.FIELD_USERS].list;
				for (int j = 0; j < list.Count; j++)
				{
					JSONObject jsonobject = list[j];
					bool flag17 = jsonobject.HasField(TournamentScore.FIELD_USER_USERID);
					if (flag17)
					{
						long num = long.Parse(jsonobject[TournamentScore.FIELD_USER_USERID].str);
						TournamentParty.User user3 = this.GetPartyUserById(num);
						bool flag18 = user3 == null;
						if (flag18)
						{
							user3 = new TournamentParty.User();
							user3.UserId = num;
							this.Users.Add(user3);
						}
						bool flag19 = jsonobject.HasField(TournamentScore.FIELD_USER_CHECKEDIN);
						if (flag19)
						{
							user3.IsCheckedIn = (jsonobject[TournamentScore.FIELD_USER_CHECKEDIN].str == "1");
						}
						bool flag20 = jsonobject.HasField(TournamentScore.FIELD_USER_ISPARTYLEADER);
						if (flag20)
						{
							user3.IsPartyLeader = (jsonobject[TournamentScore.FIELD_USER_ISPARTYLEADER].str == "1");
						}
						bool flag21 = jsonobject.HasField(TournamentScore.FIELD_USER_STATUS);
						if (flag21)
						{
							user3.Status = jsonobject[TournamentScore.FIELD_USER_STATUS].ToEnum(TournamentUserStatus.Unkown);
						}
						bool flag22 = jsonobject.HasField(TournamentScore.FIELD_USER_NICK);
						if (flag22)
						{
							user3.Nick = jsonobject[TournamentScore.FIELD_USER_NICK].str;
						}
						this.removeUsers.Remove(num);
					}
				}
			}
			this.Users.RemoveAll((TournamentParty.User user) => this.removeUsers.Contains(user.UserId));
			this.Users.Sort(delegate(TournamentParty.User user1, TournamentParty.User user2)
			{
				bool flag23 = user1.IsPartyLeader != user2.IsPartyLeader;
				int result;
				if (flag23)
				{
					result = user1.IsPartyLeader.CompareTo(user2.IsPartyLeader);
				}
				else
				{
					result = user1.UserId.CompareTo(user2.UserId);
				}
				return result;
			});
		}

		// Token: 0x06000166 RID: 358 RVA: 0x0000CC04 File Offset: 0x0000AE04
		public TournamentParty.User GetPartyUserById(long userId)
		{
			return this.Users.FirstOrDefault((TournamentParty.User user) => user.UserId == userId);
		}

		// Token: 0x040000FE RID: 254
		internal static readonly string FIELD_PARTYID = "partyid";

		// Token: 0x040000FF RID: 255
		private static readonly string FIELD_PHASEID = "phaseid";

		// Token: 0x04000100 RID: 256
		private static readonly string FIELD_GROUPID = "groupid";

		// Token: 0x04000101 RID: 257
		private static readonly string FIELD_CHECKIN = "checkin";

		// Token: 0x04000102 RID: 258
		private static readonly string FIELD_POSITION = "position";

		// Token: 0x04000103 RID: 259
		private static readonly string FIELD_TOTALPOINTS = "totalpoints";

		// Token: 0x04000104 RID: 260
		private static readonly string FIELD_MATCHWINS = "matchwins";

		// Token: 0x04000105 RID: 261
		private static readonly string FIELD_MATCHLOSES = "matchloses";

		// Token: 0x04000106 RID: 262
		private static readonly string FIELD_GAMEWINS = "gamewins";

		// Token: 0x04000107 RID: 263
		private static readonly string FIELD_GAMELOSES = "gameloses";

		// Token: 0x04000108 RID: 264
		private static readonly string FIELD_STAT1SUM = "stat1sum";

		// Token: 0x04000109 RID: 265
		private static readonly string FIELD_STAT2SUM = "stat2sum";

		// Token: 0x0400010A RID: 266
		private static readonly string FIELD_LOSEWEIGHT = "loseweight";

		// Token: 0x0400010B RID: 267
		private static readonly string FIELD_TOTALROUNDS = "totalrounds";

		// Token: 0x0400010C RID: 268
		private static readonly string FIELD_SEED = "seed";

		// Token: 0x0400010D RID: 269
		private static readonly string FIELD_USERS = "users";

		// Token: 0x0400010E RID: 270
		private static readonly string FIELD_USER_USERID = "@user-id";

		// Token: 0x0400010F RID: 271
		private static readonly string FIELD_USER_STATUS = "@status";

		// Token: 0x04000110 RID: 272
		private static readonly string FIELD_USER_CHECKEDIN = "@checked-in";

		// Token: 0x04000111 RID: 273
		private static readonly string FIELD_USER_ISPARTYLEADER = "@is-party-leader";

		// Token: 0x04000112 RID: 274
		private static readonly string FIELD_USER_NICK = "@nick";

		// Token: 0x04000113 RID: 275
		private HashSet<long> removeUsers;
	}
}
