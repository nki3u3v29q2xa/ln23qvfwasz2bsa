﻿using System;
using System.Collections.Generic;
using Gimmebreak.Backbone.Core;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000025 RID: 37
	public class ScoresPaginatedResult : PaginatedHttpResult
	{
		// Token: 0x17000049 RID: 73
		// (get) Token: 0x0600013B RID: 315 RVA: 0x0000371B File Offset: 0x0000191B
		// (set) Token: 0x0600013C RID: 316 RVA: 0x00003723 File Offset: 0x00001923
		public List<TournamentScore> Scores { get; private set; }

		// Token: 0x0600013D RID: 317 RVA: 0x0000372C File Offset: 0x0000192C
		public ScoresPaginatedResult(List<TournamentScore> parsedScores, BackboneHttpResult httpResponse) : base(httpResponse)
		{
			this.Scores = parsedScores;
		}
	}
}
