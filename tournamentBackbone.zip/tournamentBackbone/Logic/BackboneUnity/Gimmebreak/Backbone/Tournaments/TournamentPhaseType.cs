﻿using System;

namespace Gimmebreak.Backbone.Tournaments
{
	// Token: 0x02000043 RID: 67
	public enum TournamentPhaseType
	{
		// Token: 0x04000295 RID: 661
		Arena = 1,
		// Token: 0x04000296 RID: 662
		SingleEliminationBracket,
		// Token: 0x04000297 RID: 663
		RoundRobin,
		// Token: 0x04000298 RID: 664
		DoubleEliminationBracket,
		// Token: 0x04000299 RID: 665
		DynamicBrackets
	}
}
