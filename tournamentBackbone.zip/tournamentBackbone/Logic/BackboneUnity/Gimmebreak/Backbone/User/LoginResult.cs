﻿using System;
using Gimmebreak.Backbone.Core;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.User
{
	// Token: 0x0200001F RID: 31
	public class LoginResult : BackboneHttpResult
	{
		// Token: 0x1700002F RID: 47
		// (get) Token: 0x060000EE RID: 238 RVA: 0x000034F3 File Offset: 0x000016F3
		// (set) Token: 0x060000EF RID: 239 RVA: 0x000034FB File Offset: 0x000016FB
		public string AccessToken { get; private set; }

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x00003504 File Offset: 0x00001704
		// (set) Token: 0x060000F1 RID: 241 RVA: 0x0000350C File Offset: 0x0000170C
		public string RefreshToken { get; private set; }

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x060000F2 RID: 242 RVA: 0x00003515 File Offset: 0x00001715
		// (set) Token: 0x060000F3 RID: 243 RVA: 0x0000351D File Offset: 0x0000171D
		public DateTime ExpireAt { get; private set; }

		// Token: 0x060000F4 RID: 244 RVA: 0x0000BF28 File Offset: 0x0000A128
		public LoginResult(BackboneHttpResult httpResponse) : base(httpResponse.ResponseCode, httpResponse.JsonResult, httpResponse.ErrorCode, httpResponse.ErrorMessage, httpResponse.ErrorReference)
		{
			bool flag = !httpResponse.HasError && httpResponse.JsonResult != null && httpResponse.JsonResult.HasFields(LoginResult.REQUIRED_FIELDS);
			if (flag)
			{
				this.AccessToken = httpResponse.JsonResult["accessToken"].str;
				this.RefreshToken = httpResponse.JsonResult["refreshToken"].str;
				this.ExpireAt = httpResponse.JsonResult["expireAt"].ToUniversalTime();
			}
		}

		// Token: 0x040000DA RID: 218
		private static readonly string[] REQUIRED_FIELDS = new string[]
		{
			"accessToken",
			"refreshToken",
			"expireAt"
		};
	}
}
