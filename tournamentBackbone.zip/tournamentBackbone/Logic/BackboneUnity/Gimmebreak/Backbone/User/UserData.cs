﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Serialization;
using Gimmebreak.Backbone.Core;
using Gimmebreak.Backbone.Core.JSON;

namespace Gimmebreak.Backbone.User
{
	// Token: 0x02000022 RID: 34
	[Serializable]
	public class UserData
	{
		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000107 RID: 263 RVA: 0x000035D2 File Offset: 0x000017D2
		// (set) Token: 0x06000108 RID: 264 RVA: 0x000035DA File Offset: 0x000017DA
		public string UserNick { get; set; }

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000109 RID: 265 RVA: 0x000035E3 File Offset: 0x000017E3
		// (set) Token: 0x0600010A RID: 266 RVA: 0x000035EB File Offset: 0x000017EB
		public string UserNickHash { get; set; }

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600010B RID: 267 RVA: 0x000035F4 File Offset: 0x000017F4
		// (set) Token: 0x0600010C RID: 268 RVA: 0x000035FC File Offset: 0x000017FC
		public long UserId { get; set; }

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x0600010D RID: 269 RVA: 0x00003605 File Offset: 0x00001805
		// (set) Token: 0x0600010E RID: 270 RVA: 0x0000360D File Offset: 0x0000180D
		public SerializableDictionary<byte, string> Logins { get; set; }

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x0600010F RID: 271 RVA: 0x00003616 File Offset: 0x00001816
		// (set) Token: 0x06000110 RID: 272 RVA: 0x0000361E File Offset: 0x0000181E
		public SerializableDictionary<long, int> Currencies { get; set; }

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000111 RID: 273 RVA: 0x00003627 File Offset: 0x00001827
		// (set) Token: 0x06000112 RID: 274 RVA: 0x0000362F File Offset: 0x0000182F
		public string UserLanguage { get; set; }

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000113 RID: 275 RVA: 0x00003638 File Offset: 0x00001838
		// (set) Token: 0x06000114 RID: 276 RVA: 0x00003640 File Offset: 0x00001840
		[XmlIgnore]
		internal int UserRankScore { get; set; }

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000115 RID: 277 RVA: 0x00003649 File Offset: 0x00001849
		// (set) Token: 0x06000116 RID: 278 RVA: 0x00003651 File Offset: 0x00001851
		[XmlIgnore]
		internal int WorldRank { get; set; }

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000117 RID: 279 RVA: 0x0000365A File Offset: 0x0000185A
		// (set) Token: 0x06000118 RID: 280 RVA: 0x00003662 File Offset: 0x00001862
		public int RemainingReports { get; set; }

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000119 RID: 281 RVA: 0x0000366B File Offset: 0x0000186B
		// (set) Token: 0x0600011A RID: 282 RVA: 0x00003673 File Offset: 0x00001873
		public DateTime RemainingReportsResetAt { get; set; }

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600011B RID: 283 RVA: 0x0000367C File Offset: 0x0000187C
		// (set) Token: 0x0600011C RID: 284 RVA: 0x00003684 File Offset: 0x00001884
		public List<long> LastReportedUsers { get; set; }

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600011D RID: 285 RVA: 0x0000368D File Offset: 0x0000188D
		// (set) Token: 0x0600011E RID: 286 RVA: 0x00003695 File Offset: 0x00001895
		public SerializableDictionary<string, string> Properties { get; set; }

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x0600011F RID: 287 RVA: 0x0000369E File Offset: 0x0000189E
		// (set) Token: 0x06000120 RID: 288 RVA: 0x000036A6 File Offset: 0x000018A6
		public bool IsSyncDirty { get; set; }

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000121 RID: 289 RVA: 0x000036AF File Offset: 0x000018AF
		// (set) Token: 0x06000122 RID: 290 RVA: 0x000036B7 File Offset: 0x000018B7
		public DateTime LastSync { get; set; }

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000123 RID: 291 RVA: 0x000036C0 File Offset: 0x000018C0
		// (set) Token: 0x06000124 RID: 292 RVA: 0x000036C8 File Offset: 0x000018C8
		public bool IsAnonymUser { get; set; }

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000125 RID: 293 RVA: 0x000036D1 File Offset: 0x000018D1
		// (set) Token: 0x06000126 RID: 294 RVA: 0x000036D9 File Offset: 0x000018D9
		public DateTime DataCreatedAt { get; set; }

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000127 RID: 295 RVA: 0x000036E2 File Offset: 0x000018E2
		// (set) Token: 0x06000128 RID: 296 RVA: 0x000036EA File Offset: 0x000018EA
		public DateTime AccountCreatedAt { get; set; }

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000129 RID: 297 RVA: 0x000036F3 File Offset: 0x000018F3
		// (set) Token: 0x0600012A RID: 298 RVA: 0x000036FB File Offset: 0x000018FB
		[XmlIgnore]
		public DateTime LastUpdate { get; set; }

		// Token: 0x0600012B RID: 299 RVA: 0x0000C0EC File Offset: 0x0000A2EC
		public UserData()
		{
			this.Logins = new SerializableDictionary<byte, string>();
			this.Properties = new SerializableDictionary<string, string>();
			this.Currencies = new SerializableDictionary<long, int>();
			this.DataCreatedAt = DateTime.UtcNow;
			this.LastUpdate = DateTime.MinValue;
			this.LastReportedUsers = new List<long>();
			this.UserLanguage = "en";
		}

		// Token: 0x0600012C RID: 300 RVA: 0x0000C158 File Offset: 0x0000A358
		public string GetLoginId(LoginProvider.Platform platform)
		{
			string result = null;
			this.Logins.TryGetValue((byte)platform, out result);
			return result;
		}

		// Token: 0x0600012D RID: 301 RVA: 0x00003704 File Offset: 0x00001904
		public void SetDataAsDirty()
		{
			this.IsSyncDirty = true;
			this.LastSync = DateTime.UtcNow;
		}

		// Token: 0x0600012E RID: 302 RVA: 0x0000C180 File Offset: 0x0000A380
		internal XElement GetSyncXML()
		{
			XName name = "user-data";
			object[] array = new object[2];
			array[0] = new XAttribute("language", string.IsNullOrEmpty(this.UserLanguage) ? "en" : this.UserLanguage.ToLower());
			array[1] = new XElement("properties", from property in this.Properties
			select new XElement("property", new object[]
			{
				new XElement("name", property.Key),
				new XElement("value", property.Value)
			}));
			return new XElement(name, array);
		}

		// Token: 0x0600012F RID: 303 RVA: 0x0000C218 File Offset: 0x0000A418
		internal void LoadSyncData(JSONObject syncData)
		{
			bool flag = syncData.HasField("user-data");
			if (flag)
			{
				JSONObject jsonobject = syncData["user-data"];
				bool flag2 = jsonobject.HasField("@language");
				if (flag2)
				{
					this.UserLanguage = jsonobject["@language"].str;
				}
				else
				{
					this.UserLanguage = "en";
				}
				bool flag3 = jsonobject.HasField("properties") && jsonobject["properties"][0].HasField("property");
				if (flag3)
				{
					JSONObject jsonobject2 = jsonobject["properties"][0]["property"];
					bool flag4 = !jsonobject2.IsNull && jsonobject2.IsArray && jsonobject2.Count > 0;
					if (flag4)
					{
						List<JSONObject> list = jsonobject2.list;
						this.Properties.Clear();
						for (int i = 0; i < list.Count; i++)
						{
							string str = list[i]["name"][0]["#text"][0]["value"].str;
							bool flag5 = !this.Properties.ContainsKey(str);
							if (flag5)
							{
								string str2 = list[i]["value"][0]["#text"][0]["value"].str;
								this.Properties.Add(str, str2);
							}
						}
					}
				}
			}
		}

		// Token: 0x06000130 RID: 304 RVA: 0x0000C3D0 File Offset: 0x0000A5D0
		internal void LoadJsonUser(JSONObject data, bool updateCurrencies)
		{
			bool b = data["ban"].b;
			if (b)
			{
			}
			bool flag = this.LastUpdate == DateTime.MinValue;
			this.LastUpdate = ServerTime.UtcNow;
			this.AccountCreatedAt = data["createdAt"].ToUniversalTime();
			this.UserNick = data["nick"].str;
			this.UserNickHash = "#" + data["nickhashnumber"].n.ToString();
			this.UserId = long.Parse(data["id"].str);
			List<JSONObject> list = data["logins"].list;
			this.Logins.Clear();
			for (int i = 0; i < list.Count; i++)
			{
				this.Logins.Add((byte)list[i]["platformType"].i, list[i]["platformId"].str);
			}
			bool flag2 = updateCurrencies && data.HasField("currencies");
			if (flag2)
			{
				List<JSONObject> list2 = data["currencies"].list;
				this.Currencies.Clear();
				for (int j = 0; j < list2.Count; j++)
				{
					this.Currencies.Add(long.Parse(list2[j]["currencyid"].str), (int)list2[j]["amount"].i);
				}
			}
			this.UserRankScore = (int)data["rank"].i;
			this.WorldRank = (int)data["worldrank"].i;
			this.LastSync = data["lastsync"].ToUniversalTime();
			bool flag3 = data.HasField("usersettingdata") && !data["usersettingdata"].IsNull;
			if (flag3)
			{
				this.LoadSyncData(data["usersettingdata"]);
			}
			this.RemainingReports = (int)data["remainingReports"].i;
			DateTime dateTime = data["reportsResetAt"].ToUniversalTime();
			bool flag4 = dateTime != this.RemainingReportsResetAt;
			if (flag4)
			{
				this.LastReportedUsers.Clear();
			}
			this.RemainingReportsResetAt = dateTime;
		}
	}
}
