﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Gimmebreak.Backbone.Core;
using UnityEngine;

namespace Gimmebreak.Backbone.User
{
	// Token: 0x0200001E RID: 30
	public class LoginProvider : ILoginProvider
	{
		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060000DD RID: 221 RVA: 0x0000B840 File Offset: 0x00009A40
		bool ILoginProvider.CreateNewUser
		{
			get
			{
				return this.createNewUser;
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060000DE RID: 222 RVA: 0x0000B858 File Offset: 0x00009A58
		string ILoginProvider.DeviceId
		{
			get
			{
				return SystemInfoExtensions.GetBackboneDeviceUniqueId();
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060000DF RID: 223 RVA: 0x0000B870 File Offset: 0x00009A70
		string ILoginProvider.DeviceName
		{
			get
			{
				return SystemInfo.deviceName;
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060000E0 RID: 224 RVA: 0x0000B888 File Offset: 0x00009A88
		int ILoginProvider.DevicePlatform
		{
			get
			{
				return Application.platform;
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060000E1 RID: 225 RVA: 0x0000B8A0 File Offset: 0x00009AA0
		string ILoginProvider.ProviderName
		{
			get
			{
				return this.providerName;
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060000E2 RID: 226 RVA: 0x0000B8B8 File Offset: 0x00009AB8
		KeyValuePair<string, object>[] ILoginProvider.Parameters
		{
			get
			{
				return this.parameters.ToArray();
			}
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x000034CD File Offset: 0x000016CD
		private LoginProvider()
		{
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x0000B8D8 File Offset: 0x00009AD8
		public static LoginProvider Anonym(bool createNewUser, string nickName, string uniqueId = null)
		{
			bool flag = uniqueId != null && (uniqueId.Length < 64 || uniqueId.Length > 450);
			if (flag)
			{
				throw new ArgumentOutOfRangeException("uniqueId", "For anonym login 'uniqueId' must be between 64 and 450 characters.");
			}
			bool flag2 = uniqueId == null;
			if (flag2)
			{
				uniqueId = SystemInfoExtensions.GetBackboneDeviceUniqueId();
				while (uniqueId.Length < 64)
				{
					uniqueId = string.Concat(new string[]
					{
						uniqueId,
						"_",
						SystemInfo.graphicsDeviceID.ToString(),
						"_",
						SystemInfoExtensions.GetBackboneDeviceUniqueId()
					});
				}
				uniqueId = uniqueId.Substring(0, 64);
			}
			return new LoginProvider
			{
				createNewUser = createNewUser,
				providerName = "Anonym",
				parameters = 
				{
					new KeyValuePair<string, object>("nickName", nickName),
					new KeyValuePair<string, object>("anonId", uniqueId)
				}
			};
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x0000B9D4 File Offset: 0x00009BD4
		public static LoginProvider Email(bool createNewUser, string nickName, string email, string password)
		{
			bool flag = string.IsNullOrEmpty(email);
			if (flag)
			{
				throw new ArgumentNullException("email", "Email cannot be null or empty.");
			}
			bool flag2 = string.IsNullOrEmpty(password);
			if (flag2)
			{
				throw new ArgumentNullException("password", "Password cannot be null or empty.");
			}
			bool flag3 = !LoginProvider.emailFormatRegex.IsMatch(email);
			if (flag3)
			{
				throw new ArgumentException("email", "Provided email is not in valid format.");
			}
			bool flag4 = password != null && password.Length < 6;
			if (flag4)
			{
				throw new ArgumentOutOfRangeException("password", "Password must be at least 6 character long.");
			}
			return new LoginProvider
			{
				createNewUser = createNewUser,
				providerName = "Email",
				parameters = 
				{
					new KeyValuePair<string, object>("nickName", nickName),
					new KeyValuePair<string, object>("email", email),
					new KeyValuePair<string, object>("password", password)
				}
			};
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x0000BAC8 File Offset: 0x00009CC8
		public static LoginProvider CustomExternal(bool createNewUser, string nickName, params KeyValuePair<string, object>[] customParameters)
		{
			LoginProvider loginProvider = new LoginProvider();
			loginProvider.createNewUser = createNewUser;
			loginProvider.providerName = "External";
			loginProvider.parameters.Add(new KeyValuePair<string, object>("nickName", nickName));
			string text = "nickName";
			for (int i = 0; i < customParameters.Length; i++)
			{
				text = text + "," + customParameters[i].Key;
				loginProvider.parameters.Add(customParameters[i]);
			}
			loginProvider.parameters.Add(new KeyValuePair<string, object>("clientParameters", text));
			return loginProvider;
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x0000BB68 File Offset: 0x00009D68
		public static LoginProvider GameCenter(bool createNewUser, string nickName, string userGCId, string userGCSignature)
		{
			bool flag = string.IsNullOrEmpty(userGCId);
			if (flag)
			{
				throw new ArgumentNullException("userGCId", "GameCenter id cannot be null or empty.");
			}
			bool flag2 = string.IsNullOrEmpty(userGCSignature);
			if (flag2)
			{
				throw new ArgumentNullException("userGCSignature", "GameCenter signature cannot be null or empty.");
			}
			return new LoginProvider
			{
				createNewUser = createNewUser,
				providerName = "GC",
				parameters = 
				{
					new KeyValuePair<string, object>("userGCNick", nickName),
					new KeyValuePair<string, object>("userGCId", userGCId),
					new KeyValuePair<string, object>("userGCSignature", userGCSignature)
				}
			};
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x0000BC10 File Offset: 0x00009E10
		public static LoginProvider GooglePlayUsingIdToken(bool createNewUser, string nickName, string userGPGSIdToken, string userGPGSId)
		{
			bool flag = string.IsNullOrEmpty(userGPGSIdToken);
			if (flag)
			{
				throw new ArgumentNullException("userGPGSIdToken", "Google play id token cannot be null or empty.");
			}
			bool flag2 = string.IsNullOrEmpty(userGPGSId);
			if (flag2)
			{
				throw new ArgumentNullException("userGPGSId", "Google play user id cannot be null or empty.");
			}
			return new LoginProvider
			{
				createNewUser = createNewUser,
				providerName = "GPGS",
				parameters = 
				{
					new KeyValuePair<string, object>("nickName", nickName),
					new KeyValuePair<string, object>("userGPGSIdToken", userGPGSIdToken),
					new KeyValuePair<string, object>("userGPGSId", userGPGSId)
				}
			};
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x0000BCB8 File Offset: 0x00009EB8
		public static LoginProvider GooglePlayUsingAuthCode(bool createNewUser, string nickName, string userGPGSAuthCode, string userGPGSId)
		{
			bool flag = string.IsNullOrEmpty(userGPGSAuthCode);
			if (flag)
			{
				throw new ArgumentNullException("userGPGSAuthCode", "Google play auth code cannot be null or empty.");
			}
			bool flag2 = string.IsNullOrEmpty(userGPGSId);
			if (flag2)
			{
				throw new ArgumentNullException("userGPGSId", "Google play user id cannot be null or empty.");
			}
			return new LoginProvider
			{
				createNewUser = createNewUser,
				providerName = "GPGS",
				parameters = 
				{
					new KeyValuePair<string, object>("nickName", nickName),
					new KeyValuePair<string, object>("userGPGSAuthCode", userGPGSAuthCode),
					new KeyValuePair<string, object>("userGPGSId", userGPGSId)
				}
			};
		}

		// Token: 0x060000EA RID: 234 RVA: 0x0000BD60 File Offset: 0x00009F60
		public static LoginProvider Steam(bool createNewUser, string nickName, string userSteamAuthCode, string userSteamId)
		{
			bool flag = string.IsNullOrEmpty(userSteamAuthCode);
			if (flag)
			{
				throw new ArgumentNullException("userSteamAuthCode", "Steam auth code cannot be null or empty.");
			}
			bool flag2 = string.IsNullOrEmpty(userSteamId);
			if (flag2)
			{
				throw new ArgumentNullException("userSteamId", "Steam user id cannot be null or empty.");
			}
			return new LoginProvider
			{
				createNewUser = createNewUser,
				providerName = "Steam",
				parameters = 
				{
					new KeyValuePair<string, object>("nickName", nickName),
					new KeyValuePair<string, object>("userSteamAuthCode", userSteamAuthCode),
					new KeyValuePair<string, object>("userSteamId", userSteamId)
				}
			};
		}

		// Token: 0x060000EB RID: 235 RVA: 0x0000BE08 File Offset: 0x0000A008
		public static LoginProvider Steam(bool createNewUser, string nickName, byte[] userSteamAuthCode, string userSteamId)
		{
			bool flag = userSteamAuthCode == null || userSteamAuthCode.Length == 0;
			if (flag)
			{
				throw new ArgumentNullException("userSteamAuthCode", "Steam auth code cannot be null or empty.");
			}
			StringBuilder stringBuilder = new StringBuilder(userSteamAuthCode.Length * 2);
			for (int i = 0; i < userSteamAuthCode.Length; i++)
			{
				stringBuilder.AppendFormat("{0:x2}", userSteamAuthCode[i]);
			}
			return LoginProvider.Steam(createNewUser, nickName, stringBuilder.ToString(), userSteamId);
		}

		// Token: 0x060000EC RID: 236 RVA: 0x0000BE80 File Offset: 0x0000A080
		public static LoginProvider Playfab(bool createNewUser, string nickName, string userSessionTicket, string userPlayfabId)
		{
			bool flag = string.IsNullOrEmpty(userSessionTicket);
			if (flag)
			{
				throw new ArgumentNullException("userSessionTicket", "User session ticket cannot be null or empty.");
			}
			bool flag2 = string.IsNullOrEmpty(userPlayfabId);
			if (flag2)
			{
				throw new ArgumentNullException("userPlayfabId", "Playfab user id cannot be null or empty.");
			}
			return new LoginProvider
			{
				createNewUser = createNewUser,
				providerName = "Playfab",
				parameters = 
				{
					new KeyValuePair<string, object>("nickName", nickName),
					new KeyValuePair<string, object>("sessionTicket", userSessionTicket),
					new KeyValuePair<string, object>("playfabId", userPlayfabId)
				}
			};
		}

		// Token: 0x040000D6 RID: 214
		private static readonly Regex emailFormatRegex = new Regex("^[\\w!#$%&'*+\\-/=?\\^_`{|}~]+(\\.[\\w!#$%&'*+\\-/=?\\^_`{|}~]+)*@((([\\-\\w]+\\.)+[a-zA-Z]{2,4})|(([0-9]{1,3}\\.){3}[0-9]{1,3}))$");

		// Token: 0x040000D7 RID: 215
		private List<KeyValuePair<string, object>> parameters = new List<KeyValuePair<string, object>>();

		// Token: 0x040000D8 RID: 216
		private bool createNewUser;

		// Token: 0x040000D9 RID: 217
		private string providerName;

		// Token: 0x0200007D RID: 125
		public enum Platform
		{
			// Token: 0x0400040A RID: 1034
			GooglePlay,
			// Token: 0x0400040B RID: 1035
			GameCenter,
			// Token: 0x0400040C RID: 1036
			XBox,
			// Token: 0x0400040D RID: 1037
			Reserved3,
			// Token: 0x0400040E RID: 1038
			Steam,
			// Token: 0x0400040F RID: 1039
			Facebook,
			// Token: 0x04000410 RID: 1040
			Anonym,
			// Token: 0x04000411 RID: 1041
			CustomExternal,
			// Token: 0x04000412 RID: 1042
			PlayWin,
			// Token: 0x04000413 RID: 1043
			Email,
			// Token: 0x04000414 RID: 1044
			Twitch,
			// Token: 0x04000415 RID: 1045
			Discord,
			// Token: 0x04000416 RID: 1046
			Playfab
		}
	}
}
