﻿using System;
using Gimmebreak.Backbone.Core;

namespace Gimmebreak.Backbone.User
{
	// Token: 0x02000020 RID: 32
	[Serializable]
	public class LoginSession : IAuthContext
	{
		// Token: 0x17000032 RID: 50
		// (get) Token: 0x060000F6 RID: 246 RVA: 0x0000354B File Offset: 0x0000174B
		// (set) Token: 0x060000F7 RID: 247 RVA: 0x00003553 File Offset: 0x00001753
		public string AccessToken { get; set; }

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x060000F8 RID: 248 RVA: 0x0000355C File Offset: 0x0000175C
		// (set) Token: 0x060000F9 RID: 249 RVA: 0x00003564 File Offset: 0x00001764
		public string RefreshToken { get; set; }

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x060000FA RID: 250 RVA: 0x0000356D File Offset: 0x0000176D
		// (set) Token: 0x060000FB RID: 251 RVA: 0x00003575 File Offset: 0x00001775
		public DateTime ExpireAt { get; set; }

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x060000FC RID: 252 RVA: 0x0000BFD8 File Offset: 0x0000A1D8
		public string DeviceId
		{
			get
			{
				return SystemInfoExtensions.GetBackboneDeviceUniqueId();
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x060000FD RID: 253 RVA: 0x0000357E File Offset: 0x0000177E
		// (set) Token: 0x060000FE RID: 254 RVA: 0x00003586 File Offset: 0x00001786
		public bool IsValid { get; set; }

		// Token: 0x060000FF RID: 255 RVA: 0x0000358F File Offset: 0x0000178F
		public LoginSession()
		{
		}

		// Token: 0x06000100 RID: 256 RVA: 0x00003599 File Offset: 0x00001799
		public LoginSession(LoginResult loginResult)
		{
			this.AccessToken = loginResult.AccessToken;
			this.RefreshToken = loginResult.RefreshToken;
			this.ExpireAt = loginResult.ExpireAt;
			this.IsValid = true;
		}

		// Token: 0x06000101 RID: 257 RVA: 0x0000BFF0 File Offset: 0x0000A1F0
		public AsyncOperation<bool> InvalidateAuthContext()
		{
			this.IsValid = false;
			return this.Delete();
		}

		// Token: 0x06000102 RID: 258 RVA: 0x0000C010 File Offset: 0x0000A210
		public AsyncOperation<bool> UpdateAccessToken(string newAccessToken, DateTime expireAt)
		{
			this.AccessToken = newAccessToken;
			this.ExpireAt = expireAt;
			return this.Save();
		}

		// Token: 0x06000103 RID: 259 RVA: 0x0000C038 File Offset: 0x0000A238
		internal AsyncOperation<bool> Delete()
		{
			return new AsyncOperation<bool>(delegate()
			{
				FileStorage.Delete(FileStorage.SESSION_FILE);
				return true;
			});
		}

		// Token: 0x06000104 RID: 260 RVA: 0x0000C070 File Offset: 0x0000A270
		internal AsyncOperation<bool> Save()
		{
			return new AsyncOperation<bool>(delegate()
			{
				FileStorage.SaveObjectToFile<LoginSession>(FileStorage.SESSION_FILE, this, true);
				return true;
			});
		}

		// Token: 0x06000105 RID: 261 RVA: 0x0000C094 File Offset: 0x0000A294
		internal static AsyncOperation<LoginSession> Load()
		{
			return new AsyncOperation<LoginSession>(() => FileStorage.LoadObjectFromFile<LoginSession>(FileStorage.SESSION_FILE, true));
		}
	}
}
