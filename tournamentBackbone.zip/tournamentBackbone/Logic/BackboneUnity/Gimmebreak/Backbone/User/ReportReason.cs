﻿using System;

namespace Gimmebreak.Backbone.User
{
	// Token: 0x02000021 RID: 33
	public enum ReportReason
	{
		// Token: 0x040000E3 RID: 227
		Undefined,
		// Token: 0x040000E4 RID: 228
		CheatingReportedByUser,
		// Token: 0x040000E5 RID: 229
		CheatingReportedBySystem,
		// Token: 0x040000E6 RID: 230
		TournamentAbuseReportedByUser,
		// Token: 0x040000E7 RID: 231
		Other
	}
}
