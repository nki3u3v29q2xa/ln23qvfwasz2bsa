﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.33970")]
[assembly: AssemblyTitle("BackboneUnity")]
[assembly: AssemblyDescription("Unity plugin for accessing backbone API backend")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Gimmebreak Ltd.")]
[assembly: AssemblyProduct("Backbone")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("df5a7e6d-94c5-4f5d-b59c-8f19f666b048")]
[assembly: AssemblyFileVersion("1.0.0.0")]
