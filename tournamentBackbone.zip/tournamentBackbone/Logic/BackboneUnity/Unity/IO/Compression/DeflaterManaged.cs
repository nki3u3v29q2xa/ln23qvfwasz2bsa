﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000008 RID: 8
	internal class DeflaterManaged : IDeflater, IDisposable
	{
		// Token: 0x06000010 RID: 16 RVA: 0x00002FD8 File Offset: 0x000011D8
		internal DeflaterManaged()
		{
			this.deflateEncoder = new FastEncoder();
			this.copyEncoder = new CopyEncoder();
			this.input = new DeflateInput();
			this.output = new OutputBuffer();
			this.processingState = DeflaterManaged.DeflaterState.NotStarted;
		}

		// Token: 0x06000011 RID: 17 RVA: 0x000075D0 File Offset: 0x000057D0
		private bool NeedsInput()
		{
			return ((IDeflater)this).NeedsInput();
		}

		// Token: 0x06000012 RID: 18 RVA: 0x000075E8 File Offset: 0x000057E8
		bool IDeflater.NeedsInput()
		{
			return this.input.Count == 0 && this.deflateEncoder.BytesInHistory == 0;
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00007618 File Offset: 0x00005818
		void IDeflater.SetInput(byte[] inputBuffer, int startIndex, int count)
		{
			this.input.Buffer = inputBuffer;
			this.input.Count = count;
			this.input.StartIndex = startIndex;
			bool flag = count > 0 && count < 256;
			if (flag)
			{
				DeflaterManaged.DeflaterState deflaterState = this.processingState;
				if (deflaterState != DeflaterManaged.DeflaterState.NotStarted)
				{
					if (deflaterState == DeflaterManaged.DeflaterState.CompressThenCheck)
					{
						this.processingState = DeflaterManaged.DeflaterState.HandlingSmallData;
						goto IL_66;
					}
					if (deflaterState != DeflaterManaged.DeflaterState.CheckingForIncompressible)
					{
						goto IL_66;
					}
				}
				this.processingState = DeflaterManaged.DeflaterState.StartingSmallData;
				IL_66:;
			}
		}

		// Token: 0x06000014 RID: 20 RVA: 0x0000768C File Offset: 0x0000588C
		int IDeflater.GetDeflateOutput(byte[] outputBuffer)
		{
			this.output.UpdateBuffer(outputBuffer);
			switch (this.processingState)
			{
			case DeflaterManaged.DeflaterState.NotStarted:
			{
				DeflateInput.InputState state = this.input.DumpState();
				OutputBuffer.BufferState state2 = this.output.DumpState();
				this.deflateEncoder.GetBlockHeader(this.output);
				this.deflateEncoder.GetCompressedData(this.input, this.output);
				bool flag = !this.UseCompressed(this.deflateEncoder.LastCompressionRatio);
				if (flag)
				{
					this.input.RestoreState(state);
					this.output.RestoreState(state2);
					this.copyEncoder.GetBlock(this.input, this.output, false);
					this.FlushInputWindows();
					this.processingState = DeflaterManaged.DeflaterState.CheckingForIncompressible;
				}
				else
				{
					this.processingState = DeflaterManaged.DeflaterState.CompressThenCheck;
				}
				goto IL_27F;
			}
			case DeflaterManaged.DeflaterState.SlowDownForIncompressible1:
				this.deflateEncoder.GetBlockFooter(this.output);
				this.processingState = DeflaterManaged.DeflaterState.SlowDownForIncompressible2;
				break;
			case DeflaterManaged.DeflaterState.SlowDownForIncompressible2:
				break;
			case DeflaterManaged.DeflaterState.StartingSmallData:
				this.deflateEncoder.GetBlockHeader(this.output);
				this.processingState = DeflaterManaged.DeflaterState.HandlingSmallData;
				goto IL_264;
			case DeflaterManaged.DeflaterState.CompressThenCheck:
			{
				this.deflateEncoder.GetCompressedData(this.input, this.output);
				bool flag2 = !this.UseCompressed(this.deflateEncoder.LastCompressionRatio);
				if (flag2)
				{
					this.processingState = DeflaterManaged.DeflaterState.SlowDownForIncompressible1;
					this.inputFromHistory = this.deflateEncoder.UnprocessedInput;
				}
				goto IL_27F;
			}
			case DeflaterManaged.DeflaterState.CheckingForIncompressible:
			{
				DeflateInput.InputState state3 = this.input.DumpState();
				OutputBuffer.BufferState state4 = this.output.DumpState();
				this.deflateEncoder.GetBlock(this.input, this.output, 8072);
				bool flag3 = !this.UseCompressed(this.deflateEncoder.LastCompressionRatio);
				if (flag3)
				{
					this.input.RestoreState(state3);
					this.output.RestoreState(state4);
					this.copyEncoder.GetBlock(this.input, this.output, false);
					this.FlushInputWindows();
				}
				goto IL_27F;
			}
			case DeflaterManaged.DeflaterState.HandlingSmallData:
				goto IL_264;
			default:
				goto IL_27F;
			}
			bool flag4 = this.inputFromHistory.Count > 0;
			if (flag4)
			{
				this.copyEncoder.GetBlock(this.inputFromHistory, this.output, false);
			}
			bool flag5 = this.inputFromHistory.Count == 0;
			if (flag5)
			{
				this.deflateEncoder.FlushInput();
				this.processingState = DeflaterManaged.DeflaterState.CheckingForIncompressible;
			}
			goto IL_27F;
			IL_264:
			this.deflateEncoder.GetCompressedData(this.input, this.output);
			IL_27F:
			return this.output.BytesWritten;
		}

		// Token: 0x06000015 RID: 21 RVA: 0x0000792C File Offset: 0x00005B2C
		bool IDeflater.Finish(byte[] outputBuffer, out int bytesRead)
		{
			bool flag = this.processingState == DeflaterManaged.DeflaterState.NotStarted;
			bool result;
			if (flag)
			{
				bytesRead = 0;
				result = true;
			}
			else
			{
				this.output.UpdateBuffer(outputBuffer);
				bool flag2 = this.processingState == DeflaterManaged.DeflaterState.CompressThenCheck || this.processingState == DeflaterManaged.DeflaterState.HandlingSmallData || this.processingState == DeflaterManaged.DeflaterState.SlowDownForIncompressible1;
				if (flag2)
				{
					this.deflateEncoder.GetBlockFooter(this.output);
				}
				this.WriteFinal();
				bytesRead = this.output.BytesWritten;
				result = true;
			}
			return result;
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00003015 File Offset: 0x00001215
		void IDisposable.Dispose()
		{
		}

		// Token: 0x06000017 RID: 23 RVA: 0x00003018 File Offset: 0x00001218
		protected void Dispose(bool disposing)
		{
		}

		// Token: 0x06000018 RID: 24 RVA: 0x000079AC File Offset: 0x00005BAC
		private bool UseCompressed(double ratio)
		{
			return ratio <= 1.0;
		}

		// Token: 0x06000019 RID: 25 RVA: 0x0000301B File Offset: 0x0000121B
		private void FlushInputWindows()
		{
			this.deflateEncoder.FlushInput();
		}

		// Token: 0x0600001A RID: 26 RVA: 0x0000302A File Offset: 0x0000122A
		private void WriteFinal()
		{
			this.copyEncoder.GetBlock(null, this.output, true);
		}

		// Token: 0x04000012 RID: 18
		private const int MinBlockSize = 256;

		// Token: 0x04000013 RID: 19
		private const int MaxHeaderFooterGoo = 120;

		// Token: 0x04000014 RID: 20
		private const int CleanCopySize = 8072;

		// Token: 0x04000015 RID: 21
		private const double BadCompressionThreshold = 1.0;

		// Token: 0x04000016 RID: 22
		private FastEncoder deflateEncoder;

		// Token: 0x04000017 RID: 23
		private CopyEncoder copyEncoder;

		// Token: 0x04000018 RID: 24
		private DeflateInput input;

		// Token: 0x04000019 RID: 25
		private OutputBuffer output;

		// Token: 0x0400001A RID: 26
		private DeflaterManaged.DeflaterState processingState;

		// Token: 0x0400001B RID: 27
		private DeflateInput inputFromHistory;

		// Token: 0x02000077 RID: 119
		private enum DeflaterState
		{
			// Token: 0x040003E5 RID: 997
			NotStarted,
			// Token: 0x040003E6 RID: 998
			SlowDownForIncompressible1,
			// Token: 0x040003E7 RID: 999
			SlowDownForIncompressible2,
			// Token: 0x040003E8 RID: 1000
			StartingSmallData,
			// Token: 0x040003E9 RID: 1001
			CompressThenCheck,
			// Token: 0x040003EA RID: 1002
			CheckingForIncompressible,
			// Token: 0x040003EB RID: 1003
			HandlingSmallData
		}
	}
}
