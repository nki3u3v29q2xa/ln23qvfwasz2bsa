﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200001A RID: 26
	internal class Match
	{
		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000BE RID: 190 RVA: 0x0000B244 File Offset: 0x00009444
		// (set) Token: 0x060000BF RID: 191 RVA: 0x0000342C File Offset: 0x0000162C
		internal MatchState State
		{
			get
			{
				return this.state;
			}
			set
			{
				this.state = value;
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000C0 RID: 192 RVA: 0x0000B25C File Offset: 0x0000945C
		// (set) Token: 0x060000C1 RID: 193 RVA: 0x00003436 File Offset: 0x00001636
		internal int Position
		{
			get
			{
				return this.pos;
			}
			set
			{
				this.pos = value;
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000C2 RID: 194 RVA: 0x0000B274 File Offset: 0x00009474
		// (set) Token: 0x060000C3 RID: 195 RVA: 0x00003440 File Offset: 0x00001640
		internal int Length
		{
			get
			{
				return this.len;
			}
			set
			{
				this.len = value;
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000C4 RID: 196 RVA: 0x0000B28C File Offset: 0x0000948C
		// (set) Token: 0x060000C5 RID: 197 RVA: 0x0000344A File Offset: 0x0000164A
		internal byte Symbol
		{
			get
			{
				return this.symbol;
			}
			set
			{
				this.symbol = value;
			}
		}

		// Token: 0x040000B6 RID: 182
		private MatchState state;

		// Token: 0x040000B7 RID: 183
		private int pos;

		// Token: 0x040000B8 RID: 184
		private int len;

		// Token: 0x040000B9 RID: 185
		private byte symbol;
	}
}
