﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000007 RID: 7
	internal class DeflateInput
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000006 RID: 6 RVA: 0x00007558 File Offset: 0x00005758
		// (set) Token: 0x06000007 RID: 7 RVA: 0x00002F77 File Offset: 0x00001177
		internal byte[] Buffer
		{
			get
			{
				return this.buffer;
			}
			set
			{
				this.buffer = value;
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000008 RID: 8 RVA: 0x00007570 File Offset: 0x00005770
		// (set) Token: 0x06000009 RID: 9 RVA: 0x00002F81 File Offset: 0x00001181
		internal int Count
		{
			get
			{
				return this.count;
			}
			set
			{
				this.count = value;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600000A RID: 10 RVA: 0x00007588 File Offset: 0x00005788
		// (set) Token: 0x0600000B RID: 11 RVA: 0x00002F8B File Offset: 0x0000118B
		internal int StartIndex
		{
			get
			{
				return this.startIndex;
			}
			set
			{
				this.startIndex = value;
			}
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002F95 File Offset: 0x00001195
		internal void ConsumeBytes(int n)
		{
			this.startIndex += n;
			this.count -= n;
		}

		// Token: 0x0600000D RID: 13 RVA: 0x000075A0 File Offset: 0x000057A0
		internal DeflateInput.InputState DumpState()
		{
			DeflateInput.InputState result;
			result.count = this.count;
			result.startIndex = this.startIndex;
			return result;
		}

		// Token: 0x0600000E RID: 14 RVA: 0x00002FB4 File Offset: 0x000011B4
		internal void RestoreState(DeflateInput.InputState state)
		{
			this.count = state.count;
			this.startIndex = state.startIndex;
		}

		// Token: 0x0400000F RID: 15
		private byte[] buffer;

		// Token: 0x04000010 RID: 16
		private int count;

		// Token: 0x04000011 RID: 17
		private int startIndex;

		// Token: 0x02000076 RID: 118
		internal struct InputState
		{
			// Token: 0x040003E2 RID: 994
			internal int count;

			// Token: 0x040003E3 RID: 995
			internal int startIndex;
		}
	}
}
