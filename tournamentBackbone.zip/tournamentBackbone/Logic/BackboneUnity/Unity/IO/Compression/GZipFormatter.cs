﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000013 RID: 19
	internal class GZipFormatter : IFileFormatWriter
	{
		// Token: 0x0600008E RID: 142 RVA: 0x000032F7 File Offset: 0x000014F7
		internal GZipFormatter() : this(3)
		{
		}

		// Token: 0x0600008F RID: 143 RVA: 0x00009AD8 File Offset: 0x00007CD8
		internal GZipFormatter(int compressionLevel)
		{
			bool flag = compressionLevel == 10;
			if (flag)
			{
				this.headerBytes[8] = 2;
			}
		}

		// Token: 0x06000090 RID: 144 RVA: 0x00009B1C File Offset: 0x00007D1C
		public byte[] GetHeader()
		{
			return this.headerBytes;
		}

		// Token: 0x06000091 RID: 145 RVA: 0x00009B34 File Offset: 0x00007D34
		public void UpdateWithBytesRead(byte[] buffer, int offset, int bytesToCopy)
		{
			this._crc32 = Crc32Helper.UpdateCrc32(this._crc32, buffer, offset, bytesToCopy);
			long num = this._inputStreamSizeModulo + (long)((ulong)bytesToCopy);
			bool flag = num >= 4294967296L;
			if (flag)
			{
				num %= 4294967296L;
			}
			this._inputStreamSizeModulo = num;
		}

		// Token: 0x06000092 RID: 146 RVA: 0x00009B88 File Offset: 0x00007D88
		public byte[] GetFooter()
		{
			byte[] array = new byte[8];
			this.WriteUInt32(array, this._crc32, 0);
			this.WriteUInt32(array, (uint)this._inputStreamSizeModulo, 4);
			return array;
		}

		// Token: 0x06000093 RID: 147 RVA: 0x00003302 File Offset: 0x00001502
		internal void WriteUInt32(byte[] b, uint value, int startIndex)
		{
			b[startIndex] = (byte)value;
			b[startIndex + 1] = (byte)(value >> 8);
			b[startIndex + 2] = (byte)(value >> 16);
			b[startIndex + 3] = (byte)(value >> 24);
		}

		// Token: 0x0400006E RID: 110
		private byte[] headerBytes = new byte[]
		{
			31,
			139,
			8,
			0,
			0,
			0,
			0,
			0,
			4,
			0
		};

		// Token: 0x0400006F RID: 111
		private uint _crc32;

		// Token: 0x04000070 RID: 112
		private long _inputStreamSizeModulo;
	}
}
