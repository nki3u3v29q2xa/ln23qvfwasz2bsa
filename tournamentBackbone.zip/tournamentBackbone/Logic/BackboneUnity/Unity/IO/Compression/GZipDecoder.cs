﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000010 RID: 16
	internal class GZipDecoder : IFileFormatReader
	{
		// Token: 0x06000074 RID: 116 RVA: 0x0000323F File Offset: 0x0000143F
		public GZipDecoder()
		{
			this.Reset();
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00003250 File Offset: 0x00001450
		public void Reset()
		{
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingID1;
			this.gzipFooterSubstate = GZipDecoder.GzipHeaderState.ReadingCRC;
			this.expectedCrc32 = 0U;
			this.expectedOutputStreamSizeModulo = 0U;
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00009228 File Offset: 0x00007428
		public bool ReadHeader(InputBuffer input)
		{
			int bits;
			switch (this.gzipHeaderSubstate)
			{
			case GZipDecoder.GzipHeaderState.ReadingID1:
			{
				bits = input.GetBits(8);
				bool flag = bits < 0;
				if (flag)
				{
					return false;
				}
				bool flag2 = bits != 31;
				if (flag2)
				{
					throw new InvalidDataException(SR.GetString("Corrupted gzip header"));
				}
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingID2;
				break;
			}
			case GZipDecoder.GzipHeaderState.ReadingID2:
				break;
			case GZipDecoder.GzipHeaderState.ReadingCM:
				goto IL_DA;
			case GZipDecoder.GzipHeaderState.ReadingFLG:
				goto IL_11C;
			case GZipDecoder.GzipHeaderState.ReadingMMTime:
				goto IL_14D;
			case GZipDecoder.GzipHeaderState.ReadingXFL:
				goto IL_19A;
			case GZipDecoder.GzipHeaderState.ReadingOS:
				goto IL_1BD;
			case GZipDecoder.GzipHeaderState.ReadingXLen1:
				goto IL_1E0;
			case GZipDecoder.GzipHeaderState.ReadingXLen2:
				goto IL_221;
			case GZipDecoder.GzipHeaderState.ReadingXLenData:
				goto IL_25C;
			case GZipDecoder.GzipHeaderState.ReadingFileName:
				goto IL_2AF;
			case GZipDecoder.GzipHeaderState.ReadingComment:
				goto IL_303;
			case GZipDecoder.GzipHeaderState.ReadingCRC16Part1:
				goto IL_358;
			case GZipDecoder.GzipHeaderState.ReadingCRC16Part2:
				goto IL_395;
			case GZipDecoder.GzipHeaderState.Done:
				goto IL_3B6;
			default:
				throw new InvalidDataException(SR.GetString("Unknown state"));
			}
			bits = input.GetBits(8);
			bool flag3 = bits < 0;
			if (flag3)
			{
				return false;
			}
			bool flag4 = bits != 139;
			if (flag4)
			{
				throw new InvalidDataException(SR.GetString("Corrupted gzip header"));
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingCM;
			IL_DA:
			bits = input.GetBits(8);
			bool flag5 = bits < 0;
			if (flag5)
			{
				return false;
			}
			bool flag6 = bits != 8;
			if (flag6)
			{
				throw new InvalidDataException(SR.GetString("Unknown compression mode"));
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingFLG;
			IL_11C:
			bits = input.GetBits(8);
			bool flag7 = bits < 0;
			if (flag7)
			{
				return false;
			}
			this.gzip_header_flag = bits;
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingMMTime;
			this.loopCounter = 0;
			IL_14D:
			while (this.loopCounter < 4)
			{
				bits = input.GetBits(8);
				bool flag8 = bits < 0;
				if (flag8)
				{
					return false;
				}
				this.loopCounter++;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingXFL;
			this.loopCounter = 0;
			IL_19A:
			bits = input.GetBits(8);
			bool flag9 = bits < 0;
			if (flag9)
			{
				return false;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingOS;
			IL_1BD:
			bits = input.GetBits(8);
			bool flag10 = bits < 0;
			if (flag10)
			{
				return false;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingXLen1;
			IL_1E0:
			bool flag11 = (this.gzip_header_flag & 4) == 0;
			if (flag11)
			{
				goto IL_2AF;
			}
			bits = input.GetBits(8);
			bool flag12 = bits < 0;
			if (flag12)
			{
				return false;
			}
			this.gzip_header_xlen = bits;
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingXLen2;
			IL_221:
			bits = input.GetBits(8);
			bool flag13 = bits < 0;
			if (flag13)
			{
				return false;
			}
			this.gzip_header_xlen |= bits << 8;
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingXLenData;
			this.loopCounter = 0;
			IL_25C:
			while (this.loopCounter < this.gzip_header_xlen)
			{
				bits = input.GetBits(8);
				bool flag14 = bits < 0;
				if (flag14)
				{
					return false;
				}
				this.loopCounter++;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingFileName;
			this.loopCounter = 0;
			IL_2AF:
			bool flag15 = (this.gzip_header_flag & 8) == 0;
			if (flag15)
			{
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingComment;
			}
			else
			{
				for (;;)
				{
					bits = input.GetBits(8);
					bool flag16 = bits < 0;
					if (flag16)
					{
						break;
					}
					bool flag17 = bits == 0;
					if (flag17)
					{
						goto Block_20;
					}
				}
				return false;
				Block_20:
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingComment;
			}
			IL_303:
			bool flag18 = (this.gzip_header_flag & 16) == 0;
			if (flag18)
			{
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingCRC16Part1;
			}
			else
			{
				for (;;)
				{
					bits = input.GetBits(8);
					bool flag19 = bits < 0;
					if (flag19)
					{
						break;
					}
					bool flag20 = bits == 0;
					if (flag20)
					{
						goto Block_23;
					}
				}
				return false;
				Block_23:
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingCRC16Part1;
			}
			IL_358:
			bool flag21 = (this.gzip_header_flag & 2) == 0;
			if (flag21)
			{
				this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.Done;
				goto IL_3B6;
			}
			bits = input.GetBits(8);
			bool flag22 = bits < 0;
			if (flag22)
			{
				return false;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.ReadingCRC16Part2;
			IL_395:
			bits = input.GetBits(8);
			bool flag23 = bits < 0;
			if (flag23)
			{
				return false;
			}
			this.gzipHeaderSubstate = GZipDecoder.GzipHeaderState.Done;
			IL_3B6:
			return true;
		}

		// Token: 0x06000077 RID: 119 RVA: 0x00009608 File Offset: 0x00007808
		public bool ReadFooter(InputBuffer input)
		{
			input.SkipToByteBoundary();
			bool flag = this.gzipFooterSubstate == GZipDecoder.GzipHeaderState.ReadingCRC;
			if (flag)
			{
				while (this.loopCounter < 4)
				{
					int bits = input.GetBits(8);
					bool flag2 = bits < 0;
					if (flag2)
					{
						return false;
					}
					this.expectedCrc32 |= (uint)((uint)bits << 8 * this.loopCounter);
					this.loopCounter++;
				}
				this.gzipFooterSubstate = GZipDecoder.GzipHeaderState.ReadingFileSize;
				this.loopCounter = 0;
			}
			bool flag3 = this.gzipFooterSubstate == GZipDecoder.GzipHeaderState.ReadingFileSize;
			if (flag3)
			{
				bool flag4 = this.loopCounter == 0;
				if (flag4)
				{
					this.expectedOutputStreamSizeModulo = 0U;
				}
				while (this.loopCounter < 4)
				{
					int bits2 = input.GetBits(8);
					bool flag5 = bits2 < 0;
					if (flag5)
					{
						return false;
					}
					this.expectedOutputStreamSizeModulo |= (uint)((uint)bits2 << 8 * this.loopCounter);
					this.loopCounter++;
				}
			}
			return true;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00009714 File Offset: 0x00007914
		public void UpdateWithBytesRead(byte[] buffer, int offset, int copied)
		{
			this.actualCrc32 = Crc32Helper.UpdateCrc32(this.actualCrc32, buffer, offset, copied);
			long num = this.actualStreamSizeModulo + (long)((ulong)copied);
			bool flag = num >= 4294967296L;
			if (flag)
			{
				num %= 4294967296L;
			}
			this.actualStreamSizeModulo = num;
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00009768 File Offset: 0x00007968
		public void Validate()
		{
			bool flag = this.expectedCrc32 != this.actualCrc32;
			if (flag)
			{
				throw new InvalidDataException(SR.GetString("Invalid CRC"));
			}
			bool flag2 = this.actualStreamSizeModulo != (long)((ulong)this.expectedOutputStreamSizeModulo);
			if (flag2)
			{
				throw new InvalidDataException(SR.GetString("Invalid stream size"));
			}
		}

		// Token: 0x0400005B RID: 91
		private GZipDecoder.GzipHeaderState gzipHeaderSubstate;

		// Token: 0x0400005C RID: 92
		private GZipDecoder.GzipHeaderState gzipFooterSubstate;

		// Token: 0x0400005D RID: 93
		private int gzip_header_flag;

		// Token: 0x0400005E RID: 94
		private int gzip_header_xlen;

		// Token: 0x0400005F RID: 95
		private uint expectedCrc32;

		// Token: 0x04000060 RID: 96
		private uint expectedOutputStreamSizeModulo;

		// Token: 0x04000061 RID: 97
		private int loopCounter;

		// Token: 0x04000062 RID: 98
		private uint actualCrc32;

		// Token: 0x04000063 RID: 99
		private long actualStreamSizeModulo;

		// Token: 0x0200007A RID: 122
		internal enum GzipHeaderState
		{
			// Token: 0x040003F0 RID: 1008
			ReadingID1,
			// Token: 0x040003F1 RID: 1009
			ReadingID2,
			// Token: 0x040003F2 RID: 1010
			ReadingCM,
			// Token: 0x040003F3 RID: 1011
			ReadingFLG,
			// Token: 0x040003F4 RID: 1012
			ReadingMMTime,
			// Token: 0x040003F5 RID: 1013
			ReadingXFL,
			// Token: 0x040003F6 RID: 1014
			ReadingOS,
			// Token: 0x040003F7 RID: 1015
			ReadingXLen1,
			// Token: 0x040003F8 RID: 1016
			ReadingXLen2,
			// Token: 0x040003F9 RID: 1017
			ReadingXLenData,
			// Token: 0x040003FA RID: 1018
			ReadingFileName,
			// Token: 0x040003FB RID: 1019
			ReadingComment,
			// Token: 0x040003FC RID: 1020
			ReadingCRC16Part1,
			// Token: 0x040003FD RID: 1021
			ReadingCRC16Part2,
			// Token: 0x040003FE RID: 1022
			Done,
			// Token: 0x040003FF RID: 1023
			ReadingCRC,
			// Token: 0x04000400 RID: 1024
			ReadingFileSize
		}

		// Token: 0x0200007B RID: 123
		[Flags]
		internal enum GZipOptionalHeaderFlags
		{
			// Token: 0x04000402 RID: 1026
			CRCFlag = 2,
			// Token: 0x04000403 RID: 1027
			ExtraFieldsFlag = 4,
			// Token: 0x04000404 RID: 1028
			FileNameFlag = 8,
			// Token: 0x04000405 RID: 1029
			CommentFlag = 16
		}
	}
}
