﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200001B RID: 27
	internal class OutputBuffer
	{
		// Token: 0x060000C7 RID: 199 RVA: 0x0000345D File Offset: 0x0000165D
		internal void UpdateBuffer(byte[] output)
		{
			this.byteBuffer = output;
			this.pos = 0;
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000C8 RID: 200 RVA: 0x0000B2A4 File Offset: 0x000094A4
		internal int BytesWritten
		{
			get
			{
				return this.pos;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000C9 RID: 201 RVA: 0x0000B2BC File Offset: 0x000094BC
		internal int FreeBytes
		{
			get
			{
				return this.byteBuffer.Length - this.pos;
			}
		}

		// Token: 0x060000CA RID: 202 RVA: 0x0000B2E0 File Offset: 0x000094E0
		internal void WriteUInt16(ushort value)
		{
			byte[] array = this.byteBuffer;
			int num = this.pos;
			this.pos = num + 1;
			array[num] = (byte)value;
			byte[] array2 = this.byteBuffer;
			num = this.pos;
			this.pos = num + 1;
			array2[num] = (byte)(value >> 8);
		}

		// Token: 0x060000CB RID: 203 RVA: 0x0000B324 File Offset: 0x00009524
		internal void WriteBits(int n, uint bits)
		{
			this.bitBuf |= bits << this.bitCount;
			this.bitCount += n;
			bool flag = this.bitCount >= 16;
			if (flag)
			{
				byte[] array = this.byteBuffer;
				int num = this.pos;
				this.pos = num + 1;
				array[num] = (byte)this.bitBuf;
				byte[] array2 = this.byteBuffer;
				num = this.pos;
				this.pos = num + 1;
				array2[num] = (byte)(this.bitBuf >> 8);
				this.bitCount -= 16;
				this.bitBuf >>= 16;
			}
		}

		// Token: 0x060000CC RID: 204 RVA: 0x0000B3CC File Offset: 0x000095CC
		internal void FlushBits()
		{
			while (this.bitCount >= 8)
			{
				byte[] array = this.byteBuffer;
				int num = this.pos;
				this.pos = num + 1;
				array[num] = (byte)this.bitBuf;
				this.bitCount -= 8;
				this.bitBuf >>= 8;
			}
			bool flag = this.bitCount > 0;
			if (flag)
			{
				byte[] array2 = this.byteBuffer;
				int num = this.pos;
				this.pos = num + 1;
				array2[num] = (byte)this.bitBuf;
				this.bitBuf = 0U;
				this.bitCount = 0;
			}
		}

		// Token: 0x060000CD RID: 205 RVA: 0x0000B468 File Offset: 0x00009668
		internal void WriteBytes(byte[] byteArray, int offset, int count)
		{
			bool flag = this.bitCount == 0;
			if (flag)
			{
				Array.Copy(byteArray, offset, this.byteBuffer, this.pos, count);
				this.pos += count;
			}
			else
			{
				this.WriteBytesUnaligned(byteArray, offset, count);
			}
		}

		// Token: 0x060000CE RID: 206 RVA: 0x0000B4B8 File Offset: 0x000096B8
		private void WriteBytesUnaligned(byte[] byteArray, int offset, int count)
		{
			for (int i = 0; i < count; i++)
			{
				byte b = byteArray[offset + i];
				this.WriteByteUnaligned(b);
			}
		}

		// Token: 0x060000CF RID: 207 RVA: 0x0000346E File Offset: 0x0000166E
		private void WriteByteUnaligned(byte b)
		{
			this.WriteBits(8, (uint)b);
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060000D0 RID: 208 RVA: 0x0000B4E8 File Offset: 0x000096E8
		internal int BitsInBuffer
		{
			get
			{
				return this.bitCount / 8 + 1;
			}
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x0000B504 File Offset: 0x00009704
		internal OutputBuffer.BufferState DumpState()
		{
			OutputBuffer.BufferState result;
			result.pos = this.pos;
			result.bitBuf = this.bitBuf;
			result.bitCount = this.bitCount;
			return result;
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x0000347A File Offset: 0x0000167A
		internal void RestoreState(OutputBuffer.BufferState state)
		{
			this.pos = state.pos;
			this.bitBuf = state.bitBuf;
			this.bitCount = state.bitCount;
		}

		// Token: 0x040000BA RID: 186
		private byte[] byteBuffer;

		// Token: 0x040000BB RID: 187
		private int pos;

		// Token: 0x040000BC RID: 188
		private uint bitBuf;

		// Token: 0x040000BD RID: 189
		private int bitCount;

		// Token: 0x0200007C RID: 124
		internal struct BufferState
		{
			// Token: 0x04000406 RID: 1030
			internal int pos;

			// Token: 0x04000407 RID: 1031
			internal uint bitBuf;

			// Token: 0x04000408 RID: 1032
			internal int bitCount;
		}
	}
}
