﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000005 RID: 5
	internal class CopyEncoder
	{
		// Token: 0x06000001 RID: 1 RVA: 0x0000743C File Offset: 0x0000563C
		public void GetBlock(DeflateInput input, OutputBuffer output, bool isFinal)
		{
			int num = 0;
			bool flag = input != null;
			if (flag)
			{
				num = Math.Min(input.Count, output.FreeBytes - 5 - output.BitsInBuffer);
				bool flag2 = num > 65531;
				if (flag2)
				{
					num = 65531;
				}
			}
			if (isFinal)
			{
				output.WriteBits(3, 1U);
			}
			else
			{
				output.WriteBits(3, 0U);
			}
			output.FlushBits();
			this.WriteLenNLen((ushort)num, output);
			bool flag3 = input != null && num > 0;
			if (flag3)
			{
				output.WriteBytes(input.Buffer, input.StartIndex, num);
				input.ConsumeBytes(num);
			}
		}

		// Token: 0x06000002 RID: 2 RVA: 0x000074E4 File Offset: 0x000056E4
		private void WriteLenNLen(ushort len, OutputBuffer output)
		{
			output.WriteUInt16(len);
			ushort value = ~len;
			output.WriteUInt16(value);
		}

		// Token: 0x0400000C RID: 12
		private const int PaddingSize = 5;

		// Token: 0x0400000D RID: 13
		private const int MaxUncompressedBlockSize = 65536;
	}
}
