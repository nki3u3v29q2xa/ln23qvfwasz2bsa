﻿using System;
using System.Runtime.Serialization;

namespace Unity.IO.Compression
{
	// Token: 0x02000019 RID: 25
	[Serializable]
	public sealed class InvalidDataException : SystemException
	{
		// Token: 0x060000BA RID: 186 RVA: 0x000033F5 File Offset: 0x000015F5
		public InvalidDataException() : base(SR.GetString("Invalid data"))
		{
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00003409 File Offset: 0x00001609
		public InvalidDataException(string message) : base(message)
		{
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00003414 File Offset: 0x00001614
		public InvalidDataException(string message, Exception innerException) : base(message, innerException)
		{
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00003420 File Offset: 0x00001620
		internal InvalidDataException(SerializationInfo info, StreamingContext context) : base(info, context)
		{
		}
	}
}
