﻿using System;
using System.Diagnostics;

namespace Unity.IO.Compression
{
	// Token: 0x0200000D RID: 13
	internal class FastEncoderWindow
	{
		// Token: 0x0600005E RID: 94 RVA: 0x000031FE File Offset: 0x000013FE
		public FastEncoderWindow()
		{
			this.ResetWindow();
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x0600005F RID: 95 RVA: 0x00008B64 File Offset: 0x00006D64
		public int BytesAvailable
		{
			get
			{
				return this.bufEnd - this.bufPos;
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000060 RID: 96 RVA: 0x00008B84 File Offset: 0x00006D84
		public DeflateInput UnprocessedInput
		{
			get
			{
				return new DeflateInput
				{
					Buffer = this.window,
					StartIndex = this.bufPos,
					Count = this.bufEnd - this.bufPos
				};
			}
		}

		// Token: 0x06000061 RID: 97 RVA: 0x0000320F File Offset: 0x0000140F
		public void FlushWindow()
		{
			this.ResetWindow();
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00008BCC File Offset: 0x00006DCC
		private void ResetWindow()
		{
			this.window = new byte[16646];
			this.prev = new ushort[8450];
			this.lookup = new ushort[2048];
			this.bufPos = 8192;
			this.bufEnd = this.bufPos;
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000063 RID: 99 RVA: 0x00008C24 File Offset: 0x00006E24
		public int FreeWindowSpace
		{
			get
			{
				return 16384 - this.bufEnd;
			}
		}

		// Token: 0x06000064 RID: 100 RVA: 0x00003219 File Offset: 0x00001419
		public void CopyBytes(byte[] inputBuffer, int startIndex, int count)
		{
			Array.Copy(inputBuffer, startIndex, this.window, this.bufEnd, count);
			this.bufEnd += count;
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00008C44 File Offset: 0x00006E44
		public void MoveWindows()
		{
			Array.Copy(this.window, this.bufPos - 8192, this.window, 0, 8192);
			for (int i = 0; i < 2048; i++)
			{
				int num = (int)(this.lookup[i] - 8192);
				bool flag = num <= 0;
				if (flag)
				{
					this.lookup[i] = 0;
				}
				else
				{
					this.lookup[i] = (ushort)num;
				}
			}
			for (int i = 0; i < 8192; i++)
			{
				long num2 = (long)((ulong)this.prev[i] - 8192UL);
				bool flag2 = num2 <= 0L;
				if (flag2)
				{
					this.prev[i] = 0;
				}
				else
				{
					this.prev[i] = (ushort)num2;
				}
			}
			this.bufPos = 8192;
			this.bufEnd = this.bufPos;
		}

		// Token: 0x06000066 RID: 102 RVA: 0x00008D2C File Offset: 0x00006F2C
		private uint HashValue(uint hash, byte b)
		{
			return hash << 4 ^ (uint)b;
		}

		// Token: 0x06000067 RID: 103 RVA: 0x00008D44 File Offset: 0x00006F44
		private uint InsertString(ref uint hash)
		{
			hash = this.HashValue(hash, this.window[this.bufPos + 2]);
			uint num = (uint)this.lookup[(int)(hash & 2047U)];
			this.lookup[(int)(hash & 2047U)] = (ushort)this.bufPos;
			this.prev[this.bufPos & 8191] = (ushort)num;
			return num;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00008DAC File Offset: 0x00006FAC
		private void InsertStrings(ref uint hash, int matchLen)
		{
			bool flag = this.bufEnd - this.bufPos <= matchLen;
			if (flag)
			{
				this.bufPos += matchLen - 1;
			}
			else
			{
				while (--matchLen > 0)
				{
					this.InsertString(ref hash);
					this.bufPos++;
				}
			}
		}

		// Token: 0x06000069 RID: 105 RVA: 0x00008E10 File Offset: 0x00007010
		internal bool GetNextSymbolOrMatch(Match match)
		{
			uint hash = this.HashValue(0U, this.window[this.bufPos]);
			hash = this.HashValue(hash, this.window[this.bufPos + 1]);
			int position = 0;
			bool flag = this.bufEnd - this.bufPos <= 3;
			int num;
			if (flag)
			{
				num = 0;
			}
			else
			{
				int num2 = (int)this.InsertString(ref hash);
				bool flag2 = num2 != 0;
				if (flag2)
				{
					num = this.FindMatch(num2, out position, 32, 32);
					bool flag3 = this.bufPos + num > this.bufEnd;
					if (flag3)
					{
						num = this.bufEnd - this.bufPos;
					}
				}
				else
				{
					num = 0;
				}
			}
			bool flag4 = num < 3;
			if (flag4)
			{
				match.State = MatchState.HasSymbol;
				match.Symbol = this.window[this.bufPos];
				this.bufPos++;
			}
			else
			{
				this.bufPos++;
				bool flag5 = num <= 6;
				if (flag5)
				{
					int position2 = 0;
					int num3 = (int)this.InsertString(ref hash);
					bool flag6 = num3 != 0;
					int num4;
					if (flag6)
					{
						num4 = this.FindMatch(num3, out position2, (num < 4) ? 32 : 8, 32);
						bool flag7 = this.bufPos + num4 > this.bufEnd;
						if (flag7)
						{
							num4 = this.bufEnd - this.bufPos;
						}
					}
					else
					{
						num4 = 0;
					}
					bool flag8 = num4 > num;
					if (flag8)
					{
						match.State = MatchState.HasSymbolAndMatch;
						match.Symbol = this.window[this.bufPos - 1];
						match.Position = position2;
						match.Length = num4;
						this.bufPos++;
						num = num4;
						this.InsertStrings(ref hash, num);
					}
					else
					{
						match.State = MatchState.HasMatch;
						match.Position = position;
						match.Length = num;
						num--;
						this.bufPos++;
						this.InsertStrings(ref hash, num);
					}
				}
				else
				{
					match.State = MatchState.HasMatch;
					match.Position = position;
					match.Length = num;
					this.InsertStrings(ref hash, num);
				}
			}
			bool flag9 = this.bufPos == 16384;
			if (flag9)
			{
				this.MoveWindows();
			}
			return true;
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00009054 File Offset: 0x00007254
		private int FindMatch(int search, out int matchPos, int searchDepth, int niceLength)
		{
			int num = 0;
			int num2 = 0;
			int num3 = this.bufPos - 8192;
			byte b = this.window[this.bufPos];
			while (search > num3)
			{
				bool flag = this.window[search + num] == b;
				if (flag)
				{
					int i;
					for (i = 0; i < 258; i++)
					{
						bool flag2 = this.window[this.bufPos + i] != this.window[search + i];
						if (flag2)
						{
							break;
						}
					}
					bool flag3 = i > num;
					if (flag3)
					{
						num = i;
						num2 = search;
						bool flag4 = i > 32;
						if (flag4)
						{
							break;
						}
						b = this.window[this.bufPos + i];
					}
				}
				bool flag5 = --searchDepth == 0;
				if (flag5)
				{
					break;
				}
				search = (int)this.prev[search & 8191];
			}
			matchPos = this.bufPos - num2 - 1;
			bool flag6 = num == 3 && matchPos >= 16384;
			int result;
			if (flag6)
			{
				result = 0;
			}
			else
			{
				result = num;
			}
			return result;
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00009174 File Offset: 0x00007374
		[Conditional("DEBUG")]
		private void VerifyHashes()
		{
			for (int i = 0; i < 2048; i++)
			{
				ushort num = this.lookup[i];
				while (num != 0 && this.bufPos - (int)num < 8192)
				{
					ushort num2 = this.prev[(int)(num & 8191)];
					bool flag = this.bufPos - (int)num2 >= 8192;
					if (flag)
					{
						break;
					}
					num = num2;
				}
			}
		}

		// Token: 0x0600006C RID: 108 RVA: 0x000091EC File Offset: 0x000073EC
		private uint RecalculateHash(int position)
		{
			return (uint)(((int)this.window[position] << 8 ^ (int)this.window[position + 1] << 4 ^ (int)this.window[position + 2]) & 2047);
		}

		// Token: 0x0400004A RID: 74
		private byte[] window;

		// Token: 0x0400004B RID: 75
		private int bufPos;

		// Token: 0x0400004C RID: 76
		private int bufEnd;

		// Token: 0x0400004D RID: 77
		private const int FastEncoderHashShift = 4;

		// Token: 0x0400004E RID: 78
		private const int FastEncoderHashtableSize = 2048;

		// Token: 0x0400004F RID: 79
		private const int FastEncoderHashMask = 2047;

		// Token: 0x04000050 RID: 80
		private const int FastEncoderWindowSize = 8192;

		// Token: 0x04000051 RID: 81
		private const int FastEncoderWindowMask = 8191;

		// Token: 0x04000052 RID: 82
		private const int FastEncoderMatch3DistThreshold = 16384;

		// Token: 0x04000053 RID: 83
		internal const int MaxMatch = 258;

		// Token: 0x04000054 RID: 84
		internal const int MinMatch = 3;

		// Token: 0x04000055 RID: 85
		private const int SearchDepth = 32;

		// Token: 0x04000056 RID: 86
		private const int GoodLength = 4;

		// Token: 0x04000057 RID: 87
		private const int NiceLength = 32;

		// Token: 0x04000058 RID: 88
		private const int LazyMatchThreshold = 6;

		// Token: 0x04000059 RID: 89
		private ushort[] prev;

		// Token: 0x0400005A RID: 90
		private ushort[] lookup;
	}
}
