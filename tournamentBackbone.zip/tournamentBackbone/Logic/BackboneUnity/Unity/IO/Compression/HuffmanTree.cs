﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000014 RID: 20
	internal class HuffmanTree
	{
		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000095 RID: 149 RVA: 0x00009BC4 File Offset: 0x00007DC4
		public static HuffmanTree StaticLiteralLengthTree
		{
			get
			{
				return HuffmanTree.staticLiteralLengthTree;
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000096 RID: 150 RVA: 0x00009BDC File Offset: 0x00007DDC
		public static HuffmanTree StaticDistanceTree
		{
			get
			{
				return HuffmanTree.staticDistanceTree;
			}
		}

		// Token: 0x06000097 RID: 151 RVA: 0x00009BF4 File Offset: 0x00007DF4
		public HuffmanTree(byte[] codeLengths)
		{
			this.codeLengthArray = codeLengths;
			bool flag = this.codeLengthArray.Length == 288;
			if (flag)
			{
				this.tableBits = 9;
			}
			else
			{
				this.tableBits = 7;
			}
			this.tableMask = (1 << this.tableBits) - 1;
			this.CreateTable();
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00009C54 File Offset: 0x00007E54
		private static byte[] GetStaticLiteralTreeLength()
		{
			byte[] array = new byte[288];
			for (int i = 0; i <= 143; i++)
			{
				array[i] = 8;
			}
			for (int j = 144; j <= 255; j++)
			{
				array[j] = 9;
			}
			for (int k = 256; k <= 279; k++)
			{
				array[k] = 7;
			}
			for (int l = 280; l <= 287; l++)
			{
				array[l] = 8;
			}
			return array;
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00009D00 File Offset: 0x00007F00
		private static byte[] GetStaticDistanceTreeLength()
		{
			byte[] array = new byte[32];
			for (int i = 0; i < 32; i++)
			{
				array[i] = 5;
			}
			return array;
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00009D34 File Offset: 0x00007F34
		private uint[] CalculateHuffmanCode()
		{
			uint[] array = new uint[17];
			foreach (int num in this.codeLengthArray)
			{
				array[num] += 1U;
			}
			array[0] = 0U;
			uint[] array3 = new uint[17];
			uint num2 = 0U;
			for (int j = 1; j <= 16; j++)
			{
				num2 = num2 + array[j - 1] << 1;
				array3[j] = num2;
			}
			uint[] array4 = new uint[288];
			for (int k = 0; k < this.codeLengthArray.Length; k++)
			{
				int num3 = (int)this.codeLengthArray[k];
				bool flag = num3 > 0;
				if (flag)
				{
					array4[k] = FastEncoderStatics.BitReverse(array3[num3], num3);
					array3[num3] += 1U;
				}
			}
			return array4;
		}

		// Token: 0x0600009B RID: 155 RVA: 0x00009E1C File Offset: 0x0000801C
		private void CreateTable()
		{
			uint[] array = this.CalculateHuffmanCode();
			this.table = new short[1 << this.tableBits];
			this.left = new short[2 * this.codeLengthArray.Length];
			this.right = new short[2 * this.codeLengthArray.Length];
			short num = (short)this.codeLengthArray.Length;
			for (int i = 0; i < this.codeLengthArray.Length; i++)
			{
				int num2 = (int)this.codeLengthArray[i];
				bool flag = num2 > 0;
				if (flag)
				{
					int num3 = (int)array[i];
					bool flag2 = num2 <= this.tableBits;
					if (!flag2)
					{
						int num4 = num2 - this.tableBits;
						int num5 = 1 << this.tableBits;
						int num6 = num3 & (1 << this.tableBits) - 1;
						short[] array2 = this.table;
						do
						{
							short num7 = array2[num6];
							bool flag3 = num7 == 0;
							if (flag3)
							{
								array2[num6] = -num;
								num7 = -num;
								num += 1;
							}
							bool flag4 = num7 > 0;
							if (flag4)
							{
								goto Block_6;
							}
							bool flag5 = (num3 & num5) == 0;
							if (flag5)
							{
								array2 = this.left;
							}
							else
							{
								array2 = this.right;
							}
							num6 = (int)(-(int)num7);
							num5 <<= 1;
							num4--;
						}
						while (num4 != 0);
						array2[num6] = (short)i;
						goto IL_1B2;
						Block_6:
						throw new InvalidDataException(SR.GetString("Invalid Huffman data"));
					}
					int num8 = 1 << num2;
					bool flag6 = num3 >= num8;
					if (flag6)
					{
						throw new InvalidDataException(SR.GetString("Invalid Huffman data"));
					}
					int num9 = 1 << this.tableBits - num2;
					for (int j = 0; j < num9; j++)
					{
						this.table[num3] = (short)i;
						num3 += num8;
					}
					IL_1B2:;
				}
			}
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00009FF8 File Offset: 0x000081F8
		public int GetNextSymbol(InputBuffer input)
		{
			uint num = input.TryLoad16Bits();
			bool flag = input.AvailableBits == 0;
			int result;
			if (flag)
			{
				result = -1;
			}
			else
			{
				int num2 = (int)this.table[(int)(checked((IntPtr)(unchecked((ulong)num & (ulong)((long)this.tableMask)))))];
				bool flag2 = num2 < 0;
				if (flag2)
				{
					uint num3 = 1U << this.tableBits;
					do
					{
						num2 = -num2;
						bool flag3 = (num & num3) == 0U;
						if (flag3)
						{
							num2 = (int)this.left[num2];
						}
						else
						{
							num2 = (int)this.right[num2];
						}
						num3 <<= 1;
					}
					while (num2 < 0);
				}
				int num4 = (int)this.codeLengthArray[num2];
				bool flag4 = num4 <= 0;
				if (flag4)
				{
					throw new InvalidDataException(SR.GetString("Invalid Huffman data"));
				}
				bool flag5 = num4 > input.AvailableBits;
				if (flag5)
				{
					result = -1;
				}
				else
				{
					input.SkipBits(num4);
					result = num2;
				}
			}
			return result;
		}

		// Token: 0x04000071 RID: 113
		internal const int MaxLiteralTreeElements = 288;

		// Token: 0x04000072 RID: 114
		internal const int MaxDistTreeElements = 32;

		// Token: 0x04000073 RID: 115
		internal const int EndOfBlockCode = 256;

		// Token: 0x04000074 RID: 116
		internal const int NumberOfCodeLengthTreeElements = 19;

		// Token: 0x04000075 RID: 117
		private int tableBits;

		// Token: 0x04000076 RID: 118
		private short[] table;

		// Token: 0x04000077 RID: 119
		private short[] left;

		// Token: 0x04000078 RID: 120
		private short[] right;

		// Token: 0x04000079 RID: 121
		private byte[] codeLengthArray;

		// Token: 0x0400007A RID: 122
		private int tableMask;

		// Token: 0x0400007B RID: 123
		private static HuffmanTree staticLiteralLengthTree = new HuffmanTree(HuffmanTree.GetStaticLiteralTreeLength());

		// Token: 0x0400007C RID: 124
		private static HuffmanTree staticDistanceTree = new HuffmanTree(HuffmanTree.GetStaticDistanceTreeLength());
	}
}
