﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200000F RID: 15
	internal interface IFileFormatReader
	{
		// Token: 0x06000070 RID: 112
		bool ReadHeader(InputBuffer input);

		// Token: 0x06000071 RID: 113
		bool ReadFooter(InputBuffer input);

		// Token: 0x06000072 RID: 114
		void UpdateWithBytesRead(byte[] buffer, int offset, int bytesToCopy);

		// Token: 0x06000073 RID: 115
		void Validate();
	}
}
