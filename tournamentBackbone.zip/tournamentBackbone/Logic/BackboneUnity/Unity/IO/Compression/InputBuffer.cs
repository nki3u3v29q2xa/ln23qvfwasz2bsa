﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000018 RID: 24
	internal class InputBuffer
	{
		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000AE RID: 174 RVA: 0x0000AEB4 File Offset: 0x000090B4
		public int AvailableBits
		{
			get
			{
				return this.bitsInBuffer;
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000AF RID: 175 RVA: 0x0000AECC File Offset: 0x000090CC
		public int AvailableBytes
		{
			get
			{
				return this.end - this.start + this.bitsInBuffer / 8;
			}
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x0000AEF4 File Offset: 0x000090F4
		public bool EnsureBitsAvailable(int count)
		{
			bool flag = this.bitsInBuffer < count;
			if (flag)
			{
				bool flag2 = this.NeedsInput();
				if (flag2)
				{
					return false;
				}
				uint num = this.bitBuffer;
				byte[] array = this.buffer;
				int num2 = this.start;
				this.start = num2 + 1;
				this.bitBuffer = (num | array[num2] << (this.bitsInBuffer & 31));
				this.bitsInBuffer += 8;
				bool flag3 = this.bitsInBuffer < count;
				if (flag3)
				{
					bool flag4 = this.NeedsInput();
					if (flag4)
					{
						return false;
					}
					uint num3 = this.bitBuffer;
					byte[] array2 = this.buffer;
					num2 = this.start;
					this.start = num2 + 1;
					this.bitBuffer = (num3 | array2[num2] << (this.bitsInBuffer & 31));
					this.bitsInBuffer += 8;
				}
			}
			return true;
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x0000AFC8 File Offset: 0x000091C8
		public uint TryLoad16Bits()
		{
			bool flag = this.bitsInBuffer < 8;
			if (flag)
			{
				bool flag2 = this.start < this.end;
				if (flag2)
				{
					uint num = this.bitBuffer;
					byte[] array = this.buffer;
					int num2 = this.start;
					this.start = num2 + 1;
					this.bitBuffer = (num | array[num2] << (this.bitsInBuffer & 31));
					this.bitsInBuffer += 8;
				}
				bool flag3 = this.start < this.end;
				if (flag3)
				{
					uint num3 = this.bitBuffer;
					byte[] array2 = this.buffer;
					int num2 = this.start;
					this.start = num2 + 1;
					this.bitBuffer = (num3 | array2[num2] << (this.bitsInBuffer & 31));
					this.bitsInBuffer += 8;
				}
			}
			else
			{
				bool flag4 = this.bitsInBuffer < 16;
				if (flag4)
				{
					bool flag5 = this.start < this.end;
					if (flag5)
					{
						uint num4 = this.bitBuffer;
						byte[] array3 = this.buffer;
						int num2 = this.start;
						this.start = num2 + 1;
						this.bitBuffer = (num4 | array3[num2] << (this.bitsInBuffer & 31));
						this.bitsInBuffer += 8;
					}
				}
			}
			return this.bitBuffer;
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x0000B100 File Offset: 0x00009300
		private uint GetBitMask(int count)
		{
			return (1U << count) - 1U;
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x0000B11C File Offset: 0x0000931C
		public int GetBits(int count)
		{
			bool flag = !this.EnsureBitsAvailable(count);
			int result;
			if (flag)
			{
				result = -1;
			}
			else
			{
				int num = (int)(this.bitBuffer & this.GetBitMask(count));
				this.bitBuffer >>= count;
				this.bitsInBuffer -= count;
				result = num;
			}
			return result;
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x0000B170 File Offset: 0x00009370
		public int CopyTo(byte[] output, int offset, int length)
		{
			int num = 0;
			while (this.bitsInBuffer > 0 && length > 0)
			{
				output[offset++] = (byte)this.bitBuffer;
				this.bitBuffer >>= 8;
				this.bitsInBuffer -= 8;
				length--;
				num++;
			}
			bool flag = length == 0;
			int result;
			if (flag)
			{
				result = num;
			}
			else
			{
				int num2 = this.end - this.start;
				bool flag2 = length > num2;
				if (flag2)
				{
					length = num2;
				}
				Array.Copy(this.buffer, this.start, output, offset, length);
				this.start += length;
				result = num + length;
			}
			return result;
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x0000B224 File Offset: 0x00009424
		public bool NeedsInput()
		{
			return this.start == this.end;
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x00003372 File Offset: 0x00001572
		public void SetInput(byte[] buffer, int offset, int length)
		{
			this.buffer = buffer;
			this.start = offset;
			this.end = offset + length;
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x0000338C File Offset: 0x0000158C
		public void SkipBits(int n)
		{
			this.bitBuffer >>= n;
			this.bitsInBuffer -= n;
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x000033AE File Offset: 0x000015AE
		public void SkipToByteBoundary()
		{
			this.bitBuffer >>= this.bitsInBuffer % 8;
			this.bitsInBuffer -= this.bitsInBuffer % 8;
		}

		// Token: 0x040000B1 RID: 177
		private byte[] buffer;

		// Token: 0x040000B2 RID: 178
		private int start;

		// Token: 0x040000B3 RID: 179
		private int end;

		// Token: 0x040000B4 RID: 180
		private uint bitBuffer = 0U;

		// Token: 0x040000B5 RID: 181
		private int bitsInBuffer = 0;
	}
}
