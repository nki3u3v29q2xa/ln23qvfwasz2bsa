﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000017 RID: 23
	internal enum InflaterState
	{
		// Token: 0x0400009A RID: 154
		ReadingHeader,
		// Token: 0x0400009B RID: 155
		ReadingBFinal = 2,
		// Token: 0x0400009C RID: 156
		ReadingBType,
		// Token: 0x0400009D RID: 157
		ReadingNumLitCodes,
		// Token: 0x0400009E RID: 158
		ReadingNumDistCodes,
		// Token: 0x0400009F RID: 159
		ReadingNumCodeLengthCodes,
		// Token: 0x040000A0 RID: 160
		ReadingCodeLengthCodes,
		// Token: 0x040000A1 RID: 161
		ReadingTreeCodesBefore,
		// Token: 0x040000A2 RID: 162
		ReadingTreeCodesAfter,
		// Token: 0x040000A3 RID: 163
		DecodeTop,
		// Token: 0x040000A4 RID: 164
		HaveInitialLength,
		// Token: 0x040000A5 RID: 165
		HaveFullLength,
		// Token: 0x040000A6 RID: 166
		HaveDistCode,
		// Token: 0x040000A7 RID: 167
		UncompressedAligning = 15,
		// Token: 0x040000A8 RID: 168
		UncompressedByte1,
		// Token: 0x040000A9 RID: 169
		UncompressedByte2,
		// Token: 0x040000AA RID: 170
		UncompressedByte3,
		// Token: 0x040000AB RID: 171
		UncompressedByte4,
		// Token: 0x040000AC RID: 172
		DecodingUncompressed,
		// Token: 0x040000AD RID: 173
		StartReadingFooter,
		// Token: 0x040000AE RID: 174
		ReadingFooter,
		// Token: 0x040000AF RID: 175
		VerifyingFooter,
		// Token: 0x040000B0 RID: 176
		Done
	}
}
