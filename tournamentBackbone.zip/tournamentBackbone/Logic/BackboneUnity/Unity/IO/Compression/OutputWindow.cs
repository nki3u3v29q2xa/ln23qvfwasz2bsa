﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200001C RID: 28
	internal class OutputWindow
	{
		// Token: 0x060000D4 RID: 212 RVA: 0x0000B540 File Offset: 0x00009740
		public void Write(byte b)
		{
			byte[] array = this.window;
			int num = this.end;
			this.end = num + 1;
			array[num] = b;
			this.end &= 32767;
			this.bytesUsed++;
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x0000B588 File Offset: 0x00009788
		public void WriteLengthDistance(int length, int distance)
		{
			this.bytesUsed += length;
			int num = this.end - distance & 32767;
			int num2 = 32768 - length;
			bool flag = num <= num2 && this.end < num2;
			if (flag)
			{
				bool flag2 = length <= distance;
				if (flag2)
				{
					Array.Copy(this.window, num, this.window, this.end, length);
					this.end += length;
				}
				else
				{
					while (length-- > 0)
					{
						byte[] array = this.window;
						int num3 = this.end;
						this.end = num3 + 1;
						array[num3] = this.window[num++];
					}
				}
			}
			else
			{
				while (length-- > 0)
				{
					byte[] array2 = this.window;
					int num3 = this.end;
					this.end = num3 + 1;
					array2[num3] = this.window[num++];
					this.end &= 32767;
					num &= 32767;
				}
			}
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x0000B69C File Offset: 0x0000989C
		public int CopyFrom(InputBuffer input, int length)
		{
			length = Math.Min(Math.Min(length, 32768 - this.bytesUsed), input.AvailableBytes);
			int num = 32768 - this.end;
			bool flag = length > num;
			int num2;
			if (flag)
			{
				num2 = input.CopyTo(this.window, this.end, num);
				bool flag2 = num2 == num;
				if (flag2)
				{
					num2 += input.CopyTo(this.window, 0, length - num);
				}
			}
			else
			{
				num2 = input.CopyTo(this.window, this.end, length);
			}
			this.end = (this.end + num2 & 32767);
			this.bytesUsed += num2;
			return num2;
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060000D7 RID: 215 RVA: 0x0000B754 File Offset: 0x00009954
		public int FreeBytes
		{
			get
			{
				return 32768 - this.bytesUsed;
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060000D8 RID: 216 RVA: 0x0000B774 File Offset: 0x00009974
		public int AvailableBytes
		{
			get
			{
				return this.bytesUsed;
			}
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x0000B78C File Offset: 0x0000998C
		public int CopyTo(byte[] output, int offset, int length)
		{
			bool flag = length > this.bytesUsed;
			int num;
			if (flag)
			{
				num = this.end;
				length = this.bytesUsed;
			}
			else
			{
				num = (this.end - this.bytesUsed + length & 32767);
			}
			int num2 = length;
			int num3 = length - num;
			bool flag2 = num3 > 0;
			if (flag2)
			{
				Array.Copy(this.window, 32768 - num3, output, offset, num3);
				offset += num3;
				length = num;
			}
			Array.Copy(this.window, num - length, output, offset, length);
			this.bytesUsed -= num2;
			return num2;
		}

		// Token: 0x040000BE RID: 190
		private const int WindowSize = 32768;

		// Token: 0x040000BF RID: 191
		private const int WindowMask = 32767;

		// Token: 0x040000C0 RID: 192
		private byte[] window = new byte[32768];

		// Token: 0x040000C1 RID: 193
		private int end;

		// Token: 0x040000C2 RID: 194
		private int bytesUsed;
	}
}
