﻿using System;
using System.Threading;

namespace Unity.IO.Compression
{
	// Token: 0x0200000A RID: 10
	internal class DeflateStreamAsyncResult : IAsyncResult
	{
		// Token: 0x0600003F RID: 63 RVA: 0x00003108 File Offset: 0x00001308
		public DeflateStreamAsyncResult(object asyncObject, object asyncState, AsyncCallback asyncCallback, byte[] buffer, int offset, int count)
		{
			this.buffer = buffer;
			this.offset = offset;
			this.count = count;
			this.m_CompletedSynchronously = true;
			this.m_AsyncObject = asyncObject;
			this.m_AsyncState = asyncState;
			this.m_AsyncCallback = asyncCallback;
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000040 RID: 64 RVA: 0x000084D0 File Offset: 0x000066D0
		public object AsyncState
		{
			get
			{
				return this.m_AsyncState;
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000041 RID: 65 RVA: 0x000084E8 File Offset: 0x000066E8
		public WaitHandle AsyncWaitHandle
		{
			get
			{
				int completed = this.m_Completed;
				bool flag = this.m_Event == null;
				if (flag)
				{
					Interlocked.CompareExchange(ref this.m_Event, new ManualResetEvent(completed != 0), null);
				}
				ManualResetEvent manualResetEvent = (ManualResetEvent)this.m_Event;
				bool flag2 = completed == 0 && this.m_Completed != 0;
				if (flag2)
				{
					manualResetEvent.Set();
				}
				return manualResetEvent;
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000042 RID: 66 RVA: 0x00008554 File Offset: 0x00006754
		public bool CompletedSynchronously
		{
			get
			{
				return this.m_CompletedSynchronously;
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000043 RID: 67 RVA: 0x0000856C File Offset: 0x0000676C
		public bool IsCompleted
		{
			get
			{
				return this.m_Completed != 0;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000044 RID: 68 RVA: 0x00008588 File Offset: 0x00006788
		internal object Result
		{
			get
			{
				return this.m_Result;
			}
		}

		// Token: 0x06000045 RID: 69 RVA: 0x000085A0 File Offset: 0x000067A0
		internal void Close()
		{
			bool flag = this.m_Event != null;
			if (flag)
			{
				((ManualResetEvent)this.m_Event).Close();
			}
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00003146 File Offset: 0x00001346
		internal void InvokeCallback(bool completedSynchronously, object result)
		{
			this.Complete(completedSynchronously, result);
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00003152 File Offset: 0x00001352
		internal void InvokeCallback(object result)
		{
			this.Complete(result);
		}

		// Token: 0x06000048 RID: 72 RVA: 0x0000315D File Offset: 0x0000135D
		private void Complete(bool completedSynchronously, object result)
		{
			this.m_CompletedSynchronously = completedSynchronously;
			this.Complete(result);
		}

		// Token: 0x06000049 RID: 73 RVA: 0x000085D0 File Offset: 0x000067D0
		private void Complete(object result)
		{
			this.m_Result = result;
			Interlocked.Increment(ref this.m_Completed);
			bool flag = this.m_Event != null;
			if (flag)
			{
				((ManualResetEvent)this.m_Event).Set();
			}
			bool flag2 = Interlocked.Increment(ref this.m_InvokedCallback) == 1;
			if (flag2)
			{
				bool flag3 = this.m_AsyncCallback != null;
				if (flag3)
				{
					this.m_AsyncCallback(this);
				}
			}
		}

		// Token: 0x04000029 RID: 41
		public byte[] buffer;

		// Token: 0x0400002A RID: 42
		public int offset;

		// Token: 0x0400002B RID: 43
		public int count;

		// Token: 0x0400002C RID: 44
		public bool isWrite;

		// Token: 0x0400002D RID: 45
		private object m_AsyncObject;

		// Token: 0x0400002E RID: 46
		private object m_AsyncState;

		// Token: 0x0400002F RID: 47
		private AsyncCallback m_AsyncCallback;

		// Token: 0x04000030 RID: 48
		private object m_Result;

		// Token: 0x04000031 RID: 49
		internal bool m_CompletedSynchronously;

		// Token: 0x04000032 RID: 50
		private int m_InvokedCallback;

		// Token: 0x04000033 RID: 51
		private int m_Completed;

		// Token: 0x04000034 RID: 52
		private object m_Event;
	}
}
