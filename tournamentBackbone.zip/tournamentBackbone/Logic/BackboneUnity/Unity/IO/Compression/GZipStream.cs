﻿using System;
using System.IO;

namespace Unity.IO.Compression
{
	// Token: 0x02000011 RID: 17
	public class GZipStream : Stream
	{
		// Token: 0x0600007A RID: 122 RVA: 0x00003270 File Offset: 0x00001470
		public GZipStream(Stream stream, CompressionMode mode) : this(stream, mode, false)
		{
		}

		// Token: 0x0600007B RID: 123 RVA: 0x0000327D File Offset: 0x0000147D
		public GZipStream(Stream stream, CompressionMode mode, bool leaveOpen)
		{
			this.deflateStream = new DeflateStream(stream, mode, leaveOpen);
			this.SetDeflateStreamFileFormatter(mode);
		}

		// Token: 0x0600007C RID: 124 RVA: 0x000097C4 File Offset: 0x000079C4
		private void SetDeflateStreamFileFormatter(CompressionMode mode)
		{
			bool flag = mode == CompressionMode.Compress;
			if (flag)
			{
				IFileFormatWriter fileFormatWriter = new GZipFormatter();
				this.deflateStream.SetFileFormatWriter(fileFormatWriter);
			}
			else
			{
				IFileFormatReader fileFormatReader = new GZipDecoder();
				this.deflateStream.SetFileFormatReader(fileFormatReader);
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x0600007D RID: 125 RVA: 0x00009808 File Offset: 0x00007A08
		public override bool CanRead
		{
			get
			{
				bool flag = this.deflateStream == null;
				return !flag && this.deflateStream.CanRead;
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x0600007E RID: 126 RVA: 0x00009838 File Offset: 0x00007A38
		public override bool CanWrite
		{
			get
			{
				bool flag = this.deflateStream == null;
				return !flag && this.deflateStream.CanWrite;
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x0600007F RID: 127 RVA: 0x00009868 File Offset: 0x00007A68
		public override bool CanSeek
		{
			get
			{
				bool flag = this.deflateStream == null;
				return !flag && this.deflateStream.CanSeek;
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000080 RID: 128 RVA: 0x0000329D File Offset: 0x0000149D
		public override long Length
		{
			get
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000081 RID: 129 RVA: 0x000032AF File Offset: 0x000014AF
		// (set) Token: 0x06000082 RID: 130 RVA: 0x000032C1 File Offset: 0x000014C1
		public override long Position
		{
			get
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
			set
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00009898 File Offset: 0x00007A98
		public override void Flush()
		{
			bool flag = this.deflateStream == null;
			if (flag)
			{
				throw new ObjectDisposedException(null, SR.GetString("Object disposed"));
			}
			this.deflateStream.Flush();
		}

		// Token: 0x06000084 RID: 132 RVA: 0x000032D3 File Offset: 0x000014D3
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotSupportedException(SR.GetString("Not supported"));
		}

		// Token: 0x06000085 RID: 133 RVA: 0x000032E5 File Offset: 0x000014E5
		public override void SetLength(long value)
		{
			throw new NotSupportedException(SR.GetString("Not supported"));
		}

		// Token: 0x06000086 RID: 134 RVA: 0x000098D4 File Offset: 0x00007AD4
		public override IAsyncResult BeginRead(byte[] array, int offset, int count, AsyncCallback asyncCallback, object asyncState)
		{
			bool flag = this.deflateStream == null;
			if (flag)
			{
				throw new InvalidOperationException(SR.GetString("Object disposed"));
			}
			return this.deflateStream.BeginRead(array, offset, count, asyncCallback, asyncState);
		}

		// Token: 0x06000087 RID: 135 RVA: 0x00009918 File Offset: 0x00007B18
		public override int EndRead(IAsyncResult asyncResult)
		{
			bool flag = this.deflateStream == null;
			if (flag)
			{
				throw new InvalidOperationException(SR.GetString("Object disposed"));
			}
			return this.deflateStream.EndRead(asyncResult);
		}

		// Token: 0x06000088 RID: 136 RVA: 0x00009954 File Offset: 0x00007B54
		public override IAsyncResult BeginWrite(byte[] array, int offset, int count, AsyncCallback asyncCallback, object asyncState)
		{
			bool flag = this.deflateStream == null;
			if (flag)
			{
				throw new InvalidOperationException(SR.GetString("Object disposed"));
			}
			return this.deflateStream.BeginWrite(array, offset, count, asyncCallback, asyncState);
		}

		// Token: 0x06000089 RID: 137 RVA: 0x00009998 File Offset: 0x00007B98
		public override void EndWrite(IAsyncResult asyncResult)
		{
			bool flag = this.deflateStream == null;
			if (flag)
			{
				throw new InvalidOperationException(SR.GetString("Object disposed"));
			}
			this.deflateStream.EndWrite(asyncResult);
		}

		// Token: 0x0600008A RID: 138 RVA: 0x000099D4 File Offset: 0x00007BD4
		public override int Read(byte[] array, int offset, int count)
		{
			bool flag = this.deflateStream == null;
			if (flag)
			{
				throw new ObjectDisposedException(null, SR.GetString("Object disposed"));
			}
			return this.deflateStream.Read(array, offset, count);
		}

		// Token: 0x0600008B RID: 139 RVA: 0x00009A14 File Offset: 0x00007C14
		public override void Write(byte[] array, int offset, int count)
		{
			bool flag = this.deflateStream == null;
			if (flag)
			{
				throw new ObjectDisposedException(null, SR.GetString("Object disposed"));
			}
			this.deflateStream.Write(array, offset, count);
		}

		// Token: 0x0600008C RID: 140 RVA: 0x00009A50 File Offset: 0x00007C50
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.deflateStream != null;
				if (flag)
				{
					this.deflateStream.Dispose();
				}
				this.deflateStream = null;
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x0600008D RID: 141 RVA: 0x00009AA8 File Offset: 0x00007CA8
		public Stream BaseStream
		{
			get
			{
				bool flag = this.deflateStream != null;
				Stream result;
				if (flag)
				{
					result = this.deflateStream.BaseStream;
				}
				else
				{
					result = null;
				}
				return result;
			}
		}

		// Token: 0x04000064 RID: 100
		private DeflateStream deflateStream;
	}
}
