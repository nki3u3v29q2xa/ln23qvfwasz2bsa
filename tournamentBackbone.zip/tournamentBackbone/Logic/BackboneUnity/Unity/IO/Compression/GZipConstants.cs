﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000012 RID: 18
	internal static class GZipConstants
	{
		// Token: 0x04000065 RID: 101
		internal const int CompressionLevel_3 = 3;

		// Token: 0x04000066 RID: 102
		internal const int CompressionLevel_10 = 10;

		// Token: 0x04000067 RID: 103
		internal const long FileLengthModulo = 4294967296L;

		// Token: 0x04000068 RID: 104
		internal const byte ID1 = 31;

		// Token: 0x04000069 RID: 105
		internal const byte ID2 = 139;

		// Token: 0x0400006A RID: 106
		internal const byte Deflate = 8;

		// Token: 0x0400006B RID: 107
		internal const int Xfl_HeaderPos = 8;

		// Token: 0x0400006C RID: 108
		internal const byte Xfl_FastestAlgorithm = 4;

		// Token: 0x0400006D RID: 109
		internal const byte Xfl_MaxCompressionSlowestAlgorithm = 2;
	}
}
