﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200000B RID: 11
	internal class FastEncoder
	{
		// Token: 0x0600004A RID: 74 RVA: 0x0000316F File Offset: 0x0000136F
		public FastEncoder()
		{
			this.inputWindow = new FastEncoderWindow();
			this.currentMatch = new Match();
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x0600004B RID: 75 RVA: 0x00008644 File Offset: 0x00006844
		internal int BytesInHistory
		{
			get
			{
				return this.inputWindow.BytesAvailable;
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x0600004C RID: 76 RVA: 0x00008664 File Offset: 0x00006864
		internal DeflateInput UnprocessedInput
		{
			get
			{
				return this.inputWindow.UnprocessedInput;
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x0000318F File Offset: 0x0000138F
		internal void FlushInput()
		{
			this.inputWindow.FlushWindow();
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600004E RID: 78 RVA: 0x00008684 File Offset: 0x00006884
		internal double LastCompressionRatio
		{
			get
			{
				return this.lastCompressionRatio;
			}
		}

		// Token: 0x0600004F RID: 79 RVA: 0x0000319E File Offset: 0x0000139E
		internal void GetBlock(DeflateInput input, OutputBuffer output, int maxBytesToCopy)
		{
			FastEncoder.WriteDeflatePreamble(output);
			this.GetCompressedOutput(input, output, maxBytesToCopy);
			this.WriteEndOfBlock(output);
		}

		// Token: 0x06000050 RID: 80 RVA: 0x000031BA File Offset: 0x000013BA
		internal void GetCompressedData(DeflateInput input, OutputBuffer output)
		{
			this.GetCompressedOutput(input, output, -1);
		}

		// Token: 0x06000051 RID: 81 RVA: 0x000031C7 File Offset: 0x000013C7
		internal void GetBlockHeader(OutputBuffer output)
		{
			FastEncoder.WriteDeflatePreamble(output);
		}

		// Token: 0x06000052 RID: 82 RVA: 0x000031D1 File Offset: 0x000013D1
		internal void GetBlockFooter(OutputBuffer output)
		{
			this.WriteEndOfBlock(output);
		}

		// Token: 0x06000053 RID: 83 RVA: 0x0000869C File Offset: 0x0000689C
		private void GetCompressedOutput(DeflateInput input, OutputBuffer output, int maxBytesToCopy)
		{
			int bytesWritten = output.BytesWritten;
			int num = 0;
			int num2 = this.BytesInHistory + input.Count;
			do
			{
				int num3 = (input.Count < this.inputWindow.FreeWindowSpace) ? input.Count : this.inputWindow.FreeWindowSpace;
				bool flag = maxBytesToCopy >= 1;
				if (flag)
				{
					num3 = Math.Min(num3, maxBytesToCopy - num);
				}
				bool flag2 = num3 > 0;
				if (flag2)
				{
					this.inputWindow.CopyBytes(input.Buffer, input.StartIndex, num3);
					input.ConsumeBytes(num3);
					num += num3;
				}
				this.GetCompressedOutput(output);
			}
			while (this.SafeToWriteTo(output) && this.InputAvailable(input) && (maxBytesToCopy < 1 || num < maxBytesToCopy));
			int bytesWritten2 = output.BytesWritten;
			int num4 = bytesWritten2 - bytesWritten;
			int num5 = this.BytesInHistory + input.Count;
			int num6 = num2 - num5;
			bool flag3 = num4 != 0;
			if (flag3)
			{
				this.lastCompressionRatio = (double)num4 / (double)num6;
			}
		}

		// Token: 0x06000054 RID: 84 RVA: 0x000087A8 File Offset: 0x000069A8
		private void GetCompressedOutput(OutputBuffer output)
		{
			while (this.inputWindow.BytesAvailable > 0 && this.SafeToWriteTo(output))
			{
				this.inputWindow.GetNextSymbolOrMatch(this.currentMatch);
				bool flag = this.currentMatch.State == MatchState.HasSymbol;
				if (flag)
				{
					FastEncoder.WriteChar(this.currentMatch.Symbol, output);
				}
				else
				{
					bool flag2 = this.currentMatch.State == MatchState.HasMatch;
					if (flag2)
					{
						FastEncoder.WriteMatch(this.currentMatch.Length, this.currentMatch.Position, output);
					}
					else
					{
						FastEncoder.WriteChar(this.currentMatch.Symbol, output);
						FastEncoder.WriteMatch(this.currentMatch.Length, this.currentMatch.Position, output);
					}
				}
			}
		}

		// Token: 0x06000055 RID: 85 RVA: 0x0000887C File Offset: 0x00006A7C
		private bool InputAvailable(DeflateInput input)
		{
			return input.Count > 0 || this.BytesInHistory > 0;
		}

		// Token: 0x06000056 RID: 86 RVA: 0x000088A4 File Offset: 0x00006AA4
		private bool SafeToWriteTo(OutputBuffer output)
		{
			return output.FreeBytes > 16;
		}

		// Token: 0x06000057 RID: 87 RVA: 0x000088C0 File Offset: 0x00006AC0
		private void WriteEndOfBlock(OutputBuffer output)
		{
			uint num = FastEncoderStatics.FastEncoderLiteralCodeInfo[256];
			int n = (int)(num & 31U);
			output.WriteBits(n, num >> 5);
		}

		// Token: 0x06000058 RID: 88 RVA: 0x000088EC File Offset: 0x00006AEC
		internal static void WriteMatch(int matchLen, int matchPos, OutputBuffer output)
		{
			uint num = FastEncoderStatics.FastEncoderLiteralCodeInfo[254 + matchLen];
			int num2 = (int)(num & 31U);
			bool flag = num2 <= 16;
			if (flag)
			{
				output.WriteBits(num2, num >> 5);
			}
			else
			{
				output.WriteBits(16, num >> 5 & 65535U);
				output.WriteBits(num2 - 16, num >> 21);
			}
			num = FastEncoderStatics.FastEncoderDistanceCodeInfo[FastEncoderStatics.GetSlot(matchPos)];
			output.WriteBits((int)(num & 15U), num >> 8);
			int num3 = (int)(num >> 4 & 15U);
			bool flag2 = num3 != 0;
			if (flag2)
			{
				output.WriteBits(num3, (uint)(matchPos & (int)FastEncoderStatics.BitMask[num3]));
			}
		}

		// Token: 0x06000059 RID: 89 RVA: 0x0000898C File Offset: 0x00006B8C
		internal static void WriteChar(byte b, OutputBuffer output)
		{
			uint num = FastEncoderStatics.FastEncoderLiteralCodeInfo[(int)b];
			output.WriteBits((int)(num & 31U), num >> 5);
		}

		// Token: 0x0600005A RID: 90 RVA: 0x000031DC File Offset: 0x000013DC
		internal static void WriteDeflatePreamble(OutputBuffer output)
		{
			output.WriteBytes(FastEncoderStatics.FastEncoderTreeStructureData, 0, FastEncoderStatics.FastEncoderTreeStructureData.Length);
			output.WriteBits(9, 34U);
		}

		// Token: 0x04000035 RID: 53
		private FastEncoderWindow inputWindow;

		// Token: 0x04000036 RID: 54
		private Match currentMatch;

		// Token: 0x04000037 RID: 55
		private double lastCompressionRatio;
	}
}
