﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200001D RID: 29
	internal class SR
	{
		// Token: 0x060000DB RID: 219 RVA: 0x000034C3 File Offset: 0x000016C3
		private SR()
		{
		}

		// Token: 0x060000DC RID: 220 RVA: 0x0000B82C File Offset: 0x00009A2C
		internal static string GetString(string p)
		{
			return p;
		}

		// Token: 0x040000C3 RID: 195
		public const string ArgumentOutOfRange_Enum = "Argument out of range";

		// Token: 0x040000C4 RID: 196
		public const string CorruptedGZipHeader = "Corrupted gzip header";

		// Token: 0x040000C5 RID: 197
		public const string CannotReadFromDeflateStream = "Cannot read from deflate stream";

		// Token: 0x040000C6 RID: 198
		public const string CannotWriteToDeflateStream = "Cannot write to deflate stream";

		// Token: 0x040000C7 RID: 199
		public const string GenericInvalidData = "Invalid data";

		// Token: 0x040000C8 RID: 200
		public const string InvalidCRC = "Invalid CRC";

		// Token: 0x040000C9 RID: 201
		public const string InvalidStreamSize = "Invalid stream size";

		// Token: 0x040000CA RID: 202
		public const string InvalidHuffmanData = "Invalid Huffman data";

		// Token: 0x040000CB RID: 203
		public const string InvalidBeginCall = "Invalid begin call";

		// Token: 0x040000CC RID: 204
		public const string InvalidEndCall = "Invalid end call";

		// Token: 0x040000CD RID: 205
		public const string InvalidBlockLength = "Invalid block length";

		// Token: 0x040000CE RID: 206
		public const string InvalidArgumentOffsetCount = "Invalid argument offset count";

		// Token: 0x040000CF RID: 207
		public const string NotSupported = "Not supported";

		// Token: 0x040000D0 RID: 208
		public const string NotWriteableStream = "Not a writeable stream";

		// Token: 0x040000D1 RID: 209
		public const string NotReadableStream = "Not a readable stream";

		// Token: 0x040000D2 RID: 210
		public const string ObjectDisposed_StreamClosed = "Object disposed";

		// Token: 0x040000D3 RID: 211
		public const string UnknownState = "Unknown state";

		// Token: 0x040000D4 RID: 212
		public const string UnknownCompressionMode = "Unknown compression mode";

		// Token: 0x040000D5 RID: 213
		public const string UnknownBlockType = "Unknown block type";
	}
}
