﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000016 RID: 22
	internal class Inflater
	{
		// Token: 0x060000A1 RID: 161 RVA: 0x0000A0D0 File Offset: 0x000082D0
		public Inflater()
		{
			this.output = new OutputWindow();
			this.input = new InputBuffer();
			this.codeList = new byte[320];
			this.codeLengthTreeCodeLength = new byte[19];
			this.Reset();
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00003348 File Offset: 0x00001548
		internal void SetFileFormatReader(IFileFormatReader reader)
		{
			this.formatReader = reader;
			this.hasFormatReader = true;
			this.Reset();
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x0000A12C File Offset: 0x0000832C
		private void Reset()
		{
			bool flag = this.hasFormatReader;
			if (flag)
			{
				this.state = InflaterState.ReadingHeader;
			}
			else
			{
				this.state = InflaterState.ReadingBFinal;
			}
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00003360 File Offset: 0x00001560
		public void SetInput(byte[] inputBytes, int offset, int length)
		{
			this.input.SetInput(inputBytes, offset, length);
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x0000A158 File Offset: 0x00008358
		public bool Finished()
		{
			return this.state == InflaterState.Done || this.state == InflaterState.VerifyingFooter;
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000A6 RID: 166 RVA: 0x0000A184 File Offset: 0x00008384
		public int AvailableOutput
		{
			get
			{
				return this.output.AvailableBytes;
			}
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x0000A1A4 File Offset: 0x000083A4
		public bool NeedsInput()
		{
			return this.input.NeedsInput();
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x0000A1C4 File Offset: 0x000083C4
		public int Inflate(byte[] bytes, int offset, int length)
		{
			int num = 0;
			do
			{
				int num2 = this.output.CopyTo(bytes, offset, length);
				bool flag = num2 > 0;
				if (flag)
				{
					bool flag2 = this.hasFormatReader;
					if (flag2)
					{
						this.formatReader.UpdateWithBytesRead(bytes, offset, num2);
					}
					offset += num2;
					num += num2;
					length -= num2;
				}
				bool flag3 = length == 0;
				if (flag3)
				{
					break;
				}
			}
			while (!this.Finished() && this.Decode());
			bool flag4 = this.state == InflaterState.VerifyingFooter;
			if (flag4)
			{
				bool flag5 = this.output.AvailableBytes == 0;
				if (flag5)
				{
					this.formatReader.Validate();
				}
			}
			return num;
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x0000A278 File Offset: 0x00008478
		private bool Decode()
		{
			bool flag = false;
			bool flag2 = this.Finished();
			bool result;
			if (flag2)
			{
				result = true;
			}
			else
			{
				bool flag3 = this.hasFormatReader;
				if (flag3)
				{
					bool flag4 = this.state == InflaterState.ReadingHeader;
					if (flag4)
					{
						bool flag5 = !this.formatReader.ReadHeader(this.input);
						if (flag5)
						{
							return false;
						}
						this.state = InflaterState.ReadingBFinal;
					}
					else
					{
						bool flag6 = this.state == InflaterState.StartReadingFooter || this.state == InflaterState.ReadingFooter;
						if (flag6)
						{
							bool flag7 = !this.formatReader.ReadFooter(this.input);
							if (flag7)
							{
								return false;
							}
							this.state = InflaterState.VerifyingFooter;
							return true;
						}
					}
				}
				bool flag8 = this.state == InflaterState.ReadingBFinal;
				if (flag8)
				{
					bool flag9 = !this.input.EnsureBitsAvailable(1);
					if (flag9)
					{
						return false;
					}
					this.bfinal = this.input.GetBits(1);
					this.state = InflaterState.ReadingBType;
				}
				bool flag10 = this.state == InflaterState.ReadingBType;
				if (flag10)
				{
					bool flag11 = !this.input.EnsureBitsAvailable(2);
					if (flag11)
					{
						this.state = InflaterState.ReadingBType;
						return false;
					}
					this.blockType = (BlockType)this.input.GetBits(2);
					bool flag12 = this.blockType == BlockType.Dynamic;
					if (flag12)
					{
						this.state = InflaterState.ReadingNumLitCodes;
					}
					else
					{
						bool flag13 = this.blockType == BlockType.Static;
						if (flag13)
						{
							this.literalLengthTree = HuffmanTree.StaticLiteralLengthTree;
							this.distanceTree = HuffmanTree.StaticDistanceTree;
							this.state = InflaterState.DecodeTop;
						}
						else
						{
							bool flag14 = this.blockType == BlockType.Uncompressed;
							if (!flag14)
							{
								throw new InvalidDataException(SR.GetString("Unknown block type"));
							}
							this.state = InflaterState.UncompressedAligning;
						}
					}
				}
				bool flag15 = this.blockType == BlockType.Dynamic;
				bool flag17;
				if (flag15)
				{
					bool flag16 = this.state < InflaterState.DecodeTop;
					if (flag16)
					{
						flag17 = this.DecodeDynamicBlockHeader();
					}
					else
					{
						flag17 = this.DecodeBlock(out flag);
					}
				}
				else
				{
					bool flag18 = this.blockType == BlockType.Static;
					if (flag18)
					{
						flag17 = this.DecodeBlock(out flag);
					}
					else
					{
						bool flag19 = this.blockType == BlockType.Uncompressed;
						if (!flag19)
						{
							throw new InvalidDataException(SR.GetString("Unknown block type"));
						}
						flag17 = this.DecodeUncompressedBlock(out flag);
					}
				}
				bool flag20 = flag && this.bfinal != 0;
				if (flag20)
				{
					bool flag21 = this.hasFormatReader;
					if (flag21)
					{
						this.state = InflaterState.StartReadingFooter;
					}
					else
					{
						this.state = InflaterState.Done;
					}
				}
				result = flag17;
			}
			return result;
		}

		// Token: 0x060000AA RID: 170 RVA: 0x0000A4FC File Offset: 0x000086FC
		private bool DecodeUncompressedBlock(out bool end_of_block)
		{
			end_of_block = false;
			for (;;)
			{
				switch (this.state)
				{
				case InflaterState.UncompressedAligning:
					this.input.SkipToByteBoundary();
					this.state = InflaterState.UncompressedByte1;
					goto IL_4D;
				case InflaterState.UncompressedByte1:
				case InflaterState.UncompressedByte2:
				case InflaterState.UncompressedByte3:
				case InflaterState.UncompressedByte4:
					goto IL_4D;
				case InflaterState.DecodingUncompressed:
					goto IL_FC;
				}
				break;
				IL_4D:
				int bits = this.input.GetBits(8);
				bool flag = bits < 0;
				if (flag)
				{
					goto Block_2;
				}
				this.blockLengthBuffer[this.state - InflaterState.UncompressedByte1] = (byte)bits;
				bool flag2 = this.state == InflaterState.UncompressedByte4;
				if (flag2)
				{
					this.blockLength = (int)this.blockLengthBuffer[0] + (int)this.blockLengthBuffer[1] * 256;
					int num = (int)this.blockLengthBuffer[2] + (int)this.blockLengthBuffer[3] * 256;
					bool flag3 = (ushort)this.blockLength != (ushort)(~(ushort)num);
					if (flag3)
					{
						goto Block_4;
					}
				}
				this.state++;
			}
			throw new InvalidDataException(SR.GetString("Unknown state"));
			Block_2:
			return false;
			Block_4:
			throw new InvalidDataException(SR.GetString("Invalid block length"));
			IL_FC:
			int num2 = this.output.CopyFrom(this.input, this.blockLength);
			this.blockLength -= num2;
			bool flag4 = this.blockLength == 0;
			bool result;
			if (flag4)
			{
				this.state = InflaterState.ReadingBFinal;
				end_of_block = true;
				result = true;
			}
			else
			{
				bool flag5 = this.output.FreeBytes == 0;
				result = flag5;
			}
			return result;
		}

		// Token: 0x060000AB RID: 171 RVA: 0x0000A684 File Offset: 0x00008884
		private bool DecodeBlock(out bool end_of_block_code_seen)
		{
			end_of_block_code_seen = false;
			int i = this.output.FreeBytes;
			while (i > 258)
			{
				switch (this.state)
				{
				case InflaterState.DecodeTop:
				{
					int num = this.literalLengthTree.GetNextSymbol(this.input);
					bool flag = num < 0;
					if (flag)
					{
						return false;
					}
					bool flag2 = num < 256;
					if (flag2)
					{
						this.output.Write((byte)num);
						i--;
					}
					else
					{
						bool flag3 = num == 256;
						if (flag3)
						{
							end_of_block_code_seen = true;
							this.state = InflaterState.ReadingBFinal;
							return true;
						}
						num -= 257;
						bool flag4 = num < 8;
						if (flag4)
						{
							num += 3;
							this.extraBits = 0;
						}
						else
						{
							bool flag5 = num == 28;
							if (flag5)
							{
								num = 258;
								this.extraBits = 0;
							}
							else
							{
								bool flag6 = num < 0 || num >= Inflater.extraLengthBits.Length;
								if (flag6)
								{
									throw new InvalidDataException(SR.GetString("Invalid data"));
								}
								this.extraBits = (int)Inflater.extraLengthBits[num];
							}
						}
						this.length = num;
						goto IL_12E;
					}
					break;
				}
				case InflaterState.HaveInitialLength:
					goto IL_12E;
				case InflaterState.HaveFullLength:
					goto IL_1C2;
				case InflaterState.HaveDistCode:
					goto IL_248;
				default:
					throw new InvalidDataException(SR.GetString("Unknown state"));
				}
				continue;
				IL_248:
				bool flag7 = this.distanceCode > 3;
				int distance;
				if (flag7)
				{
					this.extraBits = this.distanceCode - 2 >> 1;
					int bits = this.input.GetBits(this.extraBits);
					bool flag8 = bits < 0;
					if (flag8)
					{
						return false;
					}
					distance = Inflater.distanceBasePosition[this.distanceCode] + bits;
				}
				else
				{
					distance = this.distanceCode + 1;
				}
				this.output.WriteLengthDistance(this.length, distance);
				i -= this.length;
				this.state = InflaterState.DecodeTop;
				continue;
				IL_1C2:
				bool flag9 = this.blockType == BlockType.Dynamic;
				if (flag9)
				{
					this.distanceCode = this.distanceTree.GetNextSymbol(this.input);
				}
				else
				{
					this.distanceCode = this.input.GetBits(5);
					bool flag10 = this.distanceCode >= 0;
					if (flag10)
					{
						this.distanceCode = (int)Inflater.staticDistanceTreeTable[this.distanceCode];
					}
				}
				bool flag11 = this.distanceCode < 0;
				if (flag11)
				{
					return false;
				}
				this.state = InflaterState.HaveDistCode;
				goto IL_248;
				IL_12E:
				bool flag12 = this.extraBits > 0;
				if (flag12)
				{
					this.state = InflaterState.HaveInitialLength;
					int bits2 = this.input.GetBits(this.extraBits);
					bool flag13 = bits2 < 0;
					if (flag13)
					{
						return false;
					}
					bool flag14 = this.length < 0 || this.length >= Inflater.lengthBase.Length;
					if (flag14)
					{
						throw new InvalidDataException(SR.GetString("Invalid data"));
					}
					this.length = Inflater.lengthBase[this.length] + bits2;
				}
				this.state = InflaterState.HaveFullLength;
				goto IL_1C2;
			}
			return true;
		}

		// Token: 0x060000AC RID: 172 RVA: 0x0000A98C File Offset: 0x00008B8C
		private bool DecodeDynamicBlockHeader()
		{
			switch (this.state)
			{
			case InflaterState.ReadingNumLitCodes:
			{
				this.literalLengthCodeCount = this.input.GetBits(5);
				bool flag = this.literalLengthCodeCount < 0;
				if (flag)
				{
					return false;
				}
				this.literalLengthCodeCount += 257;
				this.state = InflaterState.ReadingNumDistCodes;
				break;
			}
			case InflaterState.ReadingNumDistCodes:
				break;
			case InflaterState.ReadingNumCodeLengthCodes:
				goto IL_B1;
			case InflaterState.ReadingCodeLengthCodes:
				goto IL_F9;
			case InflaterState.ReadingTreeCodesBefore:
			case InflaterState.ReadingTreeCodesAfter:
				goto IL_1BE;
			default:
				throw new InvalidDataException(SR.GetString("Unknown state"));
			}
			this.distanceCodeCount = this.input.GetBits(5);
			bool flag2 = this.distanceCodeCount < 0;
			if (flag2)
			{
				return false;
			}
			this.distanceCodeCount++;
			this.state = InflaterState.ReadingNumCodeLengthCodes;
			IL_B1:
			this.codeLengthCodeCount = this.input.GetBits(4);
			bool flag3 = this.codeLengthCodeCount < 0;
			if (flag3)
			{
				return false;
			}
			this.codeLengthCodeCount += 4;
			this.loopCounter = 0;
			this.state = InflaterState.ReadingCodeLengthCodes;
			IL_F9:
			while (this.loopCounter < this.codeLengthCodeCount)
			{
				int bits = this.input.GetBits(3);
				bool flag4 = bits < 0;
				if (flag4)
				{
					return false;
				}
				this.codeLengthTreeCodeLength[(int)Inflater.codeOrder[this.loopCounter]] = (byte)bits;
				this.loopCounter++;
			}
			for (int i = this.codeLengthCodeCount; i < Inflater.codeOrder.Length; i++)
			{
				this.codeLengthTreeCodeLength[(int)Inflater.codeOrder[i]] = 0;
			}
			this.codeLengthTree = new HuffmanTree(this.codeLengthTreeCodeLength);
			this.codeArraySize = this.literalLengthCodeCount + this.distanceCodeCount;
			this.loopCounter = 0;
			this.state = InflaterState.ReadingTreeCodesBefore;
			IL_1BE:
			while (this.loopCounter < this.codeArraySize)
			{
				bool flag5 = this.state == InflaterState.ReadingTreeCodesBefore;
				if (flag5)
				{
					bool flag6 = (this.lengthCode = this.codeLengthTree.GetNextSymbol(this.input)) < 0;
					if (flag6)
					{
						return false;
					}
				}
				bool flag7 = this.lengthCode <= 15;
				if (flag7)
				{
					byte[] array = this.codeList;
					int num = this.loopCounter;
					this.loopCounter = num + 1;
					array[num] = (byte)this.lengthCode;
				}
				else
				{
					bool flag8 = !this.input.EnsureBitsAvailable(7);
					if (flag8)
					{
						this.state = InflaterState.ReadingTreeCodesAfter;
						return false;
					}
					bool flag9 = this.lengthCode == 16;
					if (flag9)
					{
						bool flag10 = this.loopCounter == 0;
						if (flag10)
						{
							throw new InvalidDataException();
						}
						byte b = this.codeList[this.loopCounter - 1];
						int num2 = this.input.GetBits(2) + 3;
						bool flag11 = this.loopCounter + num2 > this.codeArraySize;
						if (flag11)
						{
							throw new InvalidDataException();
						}
						for (int j = 0; j < num2; j++)
						{
							byte[] array2 = this.codeList;
							int num = this.loopCounter;
							this.loopCounter = num + 1;
							array2[num] = b;
						}
					}
					else
					{
						bool flag12 = this.lengthCode == 17;
						if (flag12)
						{
							int num2 = this.input.GetBits(3) + 3;
							bool flag13 = this.loopCounter + num2 > this.codeArraySize;
							if (flag13)
							{
								throw new InvalidDataException();
							}
							for (int k = 0; k < num2; k++)
							{
								byte[] array3 = this.codeList;
								int num = this.loopCounter;
								this.loopCounter = num + 1;
								array3[num] = 0;
							}
						}
						else
						{
							int num2 = this.input.GetBits(7) + 11;
							bool flag14 = this.loopCounter + num2 > this.codeArraySize;
							if (flag14)
							{
								throw new InvalidDataException();
							}
							for (int l = 0; l < num2; l++)
							{
								byte[] array4 = this.codeList;
								int num = this.loopCounter;
								this.loopCounter = num + 1;
								array4[num] = 0;
							}
						}
					}
				}
				this.state = InflaterState.ReadingTreeCodesBefore;
			}
			byte[] array5 = new byte[288];
			byte[] array6 = new byte[32];
			Array.Copy(this.codeList, array5, this.literalLengthCodeCount);
			Array.Copy(this.codeList, this.literalLengthCodeCount, array6, 0, this.distanceCodeCount);
			bool flag15 = array5[256] == 0;
			if (flag15)
			{
				throw new InvalidDataException();
			}
			this.literalLengthTree = new HuffmanTree(array5);
			this.distanceTree = new HuffmanTree(array6);
			this.state = InflaterState.DecodeTop;
			return true;
		}

		// Token: 0x0400007D RID: 125
		private static readonly byte[] extraLengthBits = new byte[]
		{
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			1,
			1,
			1,
			1,
			2,
			2,
			2,
			2,
			3,
			3,
			3,
			3,
			4,
			4,
			4,
			4,
			5,
			5,
			5,
			5,
			0
		};

		// Token: 0x0400007E RID: 126
		private static readonly int[] lengthBase = new int[]
		{
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			13,
			15,
			17,
			19,
			23,
			27,
			31,
			35,
			43,
			51,
			59,
			67,
			83,
			99,
			115,
			131,
			163,
			195,
			227,
			258
		};

		// Token: 0x0400007F RID: 127
		private static readonly int[] distanceBasePosition = new int[]
		{
			1,
			2,
			3,
			4,
			5,
			7,
			9,
			13,
			17,
			25,
			33,
			49,
			65,
			97,
			129,
			193,
			257,
			385,
			513,
			769,
			1025,
			1537,
			2049,
			3073,
			4097,
			6145,
			8193,
			12289,
			16385,
			24577,
			0,
			0
		};

		// Token: 0x04000080 RID: 128
		private static readonly byte[] codeOrder = new byte[]
		{
			16,
			17,
			18,
			0,
			8,
			7,
			9,
			6,
			10,
			5,
			11,
			4,
			12,
			3,
			13,
			2,
			14,
			1,
			15
		};

		// Token: 0x04000081 RID: 129
		private static readonly byte[] staticDistanceTreeTable = new byte[]
		{
			0,
			16,
			8,
			24,
			4,
			20,
			12,
			28,
			2,
			18,
			10,
			26,
			6,
			22,
			14,
			30,
			1,
			17,
			9,
			25,
			5,
			21,
			13,
			29,
			3,
			19,
			11,
			27,
			7,
			23,
			15,
			31
		};

		// Token: 0x04000082 RID: 130
		private OutputWindow output;

		// Token: 0x04000083 RID: 131
		private InputBuffer input;

		// Token: 0x04000084 RID: 132
		private HuffmanTree literalLengthTree;

		// Token: 0x04000085 RID: 133
		private HuffmanTree distanceTree;

		// Token: 0x04000086 RID: 134
		private InflaterState state;

		// Token: 0x04000087 RID: 135
		private bool hasFormatReader;

		// Token: 0x04000088 RID: 136
		private int bfinal;

		// Token: 0x04000089 RID: 137
		private BlockType blockType;

		// Token: 0x0400008A RID: 138
		private byte[] blockLengthBuffer = new byte[4];

		// Token: 0x0400008B RID: 139
		private int blockLength;

		// Token: 0x0400008C RID: 140
		private int length;

		// Token: 0x0400008D RID: 141
		private int distanceCode;

		// Token: 0x0400008E RID: 142
		private int extraBits;

		// Token: 0x0400008F RID: 143
		private int loopCounter;

		// Token: 0x04000090 RID: 144
		private int literalLengthCodeCount;

		// Token: 0x04000091 RID: 145
		private int distanceCodeCount;

		// Token: 0x04000092 RID: 146
		private int codeLengthCodeCount;

		// Token: 0x04000093 RID: 147
		private int codeArraySize;

		// Token: 0x04000094 RID: 148
		private int lengthCode;

		// Token: 0x04000095 RID: 149
		private byte[] codeList;

		// Token: 0x04000096 RID: 150
		private byte[] codeLengthTreeCodeLength;

		// Token: 0x04000097 RID: 151
		private HuffmanTree codeLengthTree;

		// Token: 0x04000098 RID: 152
		private IFileFormatReader formatReader;
	}
}
