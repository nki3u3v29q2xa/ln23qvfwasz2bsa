﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000004 RID: 4
	public enum CompressionMode
	{
		// Token: 0x0400000A RID: 10
		Decompress,
		// Token: 0x0400000B RID: 11
		Compress
	}
}
