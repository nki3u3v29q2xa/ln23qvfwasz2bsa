﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000015 RID: 21
	internal interface IDeflater : IDisposable
	{
		// Token: 0x0600009D RID: 157
		bool NeedsInput();

		// Token: 0x0600009E RID: 158
		void SetInput(byte[] inputBuffer, int startIndex, int count);

		// Token: 0x0600009F RID: 159
		int GetDeflateOutput(byte[] outputBuffer);

		// Token: 0x060000A0 RID: 160
		bool Finish(byte[] outputBuffer, out int bytesRead);
	}
}
