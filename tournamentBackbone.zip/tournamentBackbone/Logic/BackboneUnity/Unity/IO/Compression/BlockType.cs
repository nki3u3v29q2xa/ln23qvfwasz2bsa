﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x02000003 RID: 3
	internal enum BlockType
	{
		// Token: 0x04000006 RID: 6
		Uncompressed,
		// Token: 0x04000007 RID: 7
		Static,
		// Token: 0x04000008 RID: 8
		Dynamic
	}
}
