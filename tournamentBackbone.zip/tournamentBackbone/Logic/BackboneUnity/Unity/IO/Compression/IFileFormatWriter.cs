﻿using System;

namespace Unity.IO.Compression
{
	// Token: 0x0200000E RID: 14
	internal interface IFileFormatWriter
	{
		// Token: 0x0600006D RID: 109
		byte[] GetHeader();

		// Token: 0x0600006E RID: 110
		void UpdateWithBytesRead(byte[] buffer, int offset, int bytesToCopy);

		// Token: 0x0600006F RID: 111
		byte[] GetFooter();
	}
}
