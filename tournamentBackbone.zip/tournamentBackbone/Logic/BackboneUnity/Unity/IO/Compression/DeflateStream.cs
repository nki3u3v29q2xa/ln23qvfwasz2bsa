﻿using System;
using System.IO;
using System.Security;
using System.Threading;

namespace Unity.IO.Compression
{
	// Token: 0x02000009 RID: 9
	public class DeflateStream : Stream
	{
		// Token: 0x0600001B RID: 27 RVA: 0x00003041 File Offset: 0x00001241
		public DeflateStream(Stream stream, CompressionMode mode) : this(stream, mode, false)
		{
		}

		// Token: 0x0600001C RID: 28 RVA: 0x000079D0 File Offset: 0x00005BD0
		public DeflateStream(Stream stream, CompressionMode mode, bool leaveOpen)
		{
			bool flag = stream == null;
			if (flag)
			{
				throw new ArgumentNullException("stream");
			}
			bool flag2 = CompressionMode.Compress != mode && mode > CompressionMode.Decompress;
			if (flag2)
			{
				throw new ArgumentException(SR.GetString("Argument out of range"), "mode");
			}
			this._stream = stream;
			this._mode = mode;
			this._leaveOpen = leaveOpen;
			CompressionMode mode2 = this._mode;
			if (mode2 != CompressionMode.Decompress)
			{
				if (mode2 == CompressionMode.Compress)
				{
					bool flag3 = !this._stream.CanWrite;
					if (flag3)
					{
						throw new ArgumentException(SR.GetString("Not a writeable stream"), "stream");
					}
					this.deflater = DeflateStream.CreateDeflater();
					this.m_AsyncWriterDelegate = new DeflateStream.AsyncWriteDelegate(this.InternalWrite);
					this.m_CallBack = new AsyncCallback(this.WriteCallback);
				}
			}
			else
			{
				bool flag4 = !this._stream.CanRead;
				if (flag4)
				{
					throw new ArgumentException(SR.GetString("Not a readable stream"), "stream");
				}
				this.inflater = new Inflater();
				this.m_CallBack = new AsyncCallback(this.ReadCallback);
			}
			this.buffer = new byte[8192];
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00007AF8 File Offset: 0x00005CF8
		private static IDeflater CreateDeflater()
		{
			DeflateStream.WorkerType deflaterType = DeflateStream.GetDeflaterType();
			if (deflaterType != DeflateStream.WorkerType.Managed)
			{
				throw new SystemException("Program entered an unexpected state.");
			}
			return new DeflaterManaged();
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00007B28 File Offset: 0x00005D28
		[SecuritySafeCritical]
		private static DeflateStream.WorkerType GetDeflaterType()
		{
			return DeflateStream.WorkerType.Managed;
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00007B3C File Offset: 0x00005D3C
		internal void SetFileFormatReader(IFileFormatReader reader)
		{
			bool flag = reader != null;
			if (flag)
			{
				this.inflater.SetFileFormatReader(reader);
			}
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00007B64 File Offset: 0x00005D64
		internal void SetFileFormatWriter(IFileFormatWriter writer)
		{
			bool flag = writer != null;
			if (flag)
			{
				this.formatWriter = writer;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000021 RID: 33 RVA: 0x00007B84 File Offset: 0x00005D84
		public Stream BaseStream
		{
			get
			{
				return this._stream;
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000022 RID: 34 RVA: 0x00007B9C File Offset: 0x00005D9C
		public override bool CanRead
		{
			get
			{
				bool flag = this._stream == null;
				return !flag && this._mode == CompressionMode.Decompress && this._stream.CanRead;
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000023 RID: 35 RVA: 0x00007BD8 File Offset: 0x00005DD8
		public override bool CanWrite
		{
			get
			{
				bool flag = this._stream == null;
				return !flag && this._mode == CompressionMode.Compress && this._stream.CanWrite;
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000024 RID: 36 RVA: 0x00007C14 File Offset: 0x00005E14
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000025 RID: 37 RVA: 0x0000304E File Offset: 0x0000124E
		public override long Length
		{
			get
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000026 RID: 38 RVA: 0x00003060 File Offset: 0x00001260
		// (set) Token: 0x06000027 RID: 39 RVA: 0x00003072 File Offset: 0x00001272
		public override long Position
		{
			get
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
			set
			{
				throw new NotSupportedException(SR.GetString("Not supported"));
			}
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00003084 File Offset: 0x00001284
		public override void Flush()
		{
			this.EnsureNotDisposed();
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00003090 File Offset: 0x00001290
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotSupportedException(SR.GetString("Not supported"));
		}

		// Token: 0x0600002A RID: 42 RVA: 0x000030A2 File Offset: 0x000012A2
		public override void SetLength(long value)
		{
			throw new NotSupportedException(SR.GetString("Not supported"));
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00007C28 File Offset: 0x00005E28
		public override int Read(byte[] array, int offset, int count)
		{
			this.EnsureDecompressionMode();
			this.ValidateParameters(array, offset, count);
			this.EnsureNotDisposed();
			int num = offset;
			int num2 = count;
			for (;;)
			{
				int num3 = this.inflater.Inflate(array, num, num2);
				num += num3;
				num2 -= num3;
				bool flag = num2 == 0;
				if (flag)
				{
					break;
				}
				bool flag2 = this.inflater.Finished();
				if (flag2)
				{
					break;
				}
				int num4 = this._stream.Read(this.buffer, 0, this.buffer.Length);
				bool flag3 = num4 == 0;
				if (flag3)
				{
					break;
				}
				this.inflater.SetInput(this.buffer, 0, num4);
			}
			return count - num2;
		}

		// Token: 0x0600002C RID: 44 RVA: 0x00007CD8 File Offset: 0x00005ED8
		private void ValidateParameters(byte[] array, int offset, int count)
		{
			bool flag = array == null;
			if (flag)
			{
				throw new ArgumentNullException("array");
			}
			bool flag2 = offset < 0;
			if (flag2)
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			bool flag3 = count < 0;
			if (flag3)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			bool flag4 = array.Length - offset < count;
			if (flag4)
			{
				throw new ArgumentException(SR.GetString("Invalid argument offset count"));
			}
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00007D3C File Offset: 0x00005F3C
		private void EnsureNotDisposed()
		{
			bool flag = this._stream == null;
			if (flag)
			{
				throw new ObjectDisposedException(null, SR.GetString("Object disposed"));
			}
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00007D68 File Offset: 0x00005F68
		private void EnsureDecompressionMode()
		{
			bool flag = this._mode > CompressionMode.Decompress;
			if (flag)
			{
				throw new InvalidOperationException(SR.GetString("Cannot read from deflate stream"));
			}
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00007D94 File Offset: 0x00005F94
		private void EnsureCompressionMode()
		{
			bool flag = this._mode != CompressionMode.Compress;
			if (flag)
			{
				throw new InvalidOperationException(SR.GetString("Cannot write to deflate stream"));
			}
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00007DC4 File Offset: 0x00005FC4
		public override IAsyncResult BeginRead(byte[] array, int offset, int count, AsyncCallback asyncCallback, object asyncState)
		{
			this.EnsureDecompressionMode();
			bool flag = this.asyncOperations != 0;
			if (flag)
			{
				throw new InvalidOperationException(SR.GetString("Invalid begin call"));
			}
			this.ValidateParameters(array, offset, count);
			this.EnsureNotDisposed();
			Interlocked.Increment(ref this.asyncOperations);
			IAsyncResult result;
			try
			{
				DeflateStreamAsyncResult deflateStreamAsyncResult = new DeflateStreamAsyncResult(this, asyncState, asyncCallback, array, offset, count);
				deflateStreamAsyncResult.isWrite = false;
				int num = this.inflater.Inflate(array, offset, count);
				bool flag2 = num != 0;
				if (flag2)
				{
					deflateStreamAsyncResult.InvokeCallback(true, num);
					result = deflateStreamAsyncResult;
				}
				else
				{
					bool flag3 = this.inflater.Finished();
					if (flag3)
					{
						deflateStreamAsyncResult.InvokeCallback(true, 0);
						result = deflateStreamAsyncResult;
					}
					else
					{
						this._stream.BeginRead(this.buffer, 0, this.buffer.Length, this.m_CallBack, deflateStreamAsyncResult);
						deflateStreamAsyncResult.m_CompletedSynchronously &= deflateStreamAsyncResult.IsCompleted;
						result = deflateStreamAsyncResult;
					}
				}
			}
			catch
			{
				Interlocked.Decrement(ref this.asyncOperations);
				throw;
			}
			return result;
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00007ED8 File Offset: 0x000060D8
		private void ReadCallback(IAsyncResult baseStreamResult)
		{
			DeflateStreamAsyncResult deflateStreamAsyncResult = (DeflateStreamAsyncResult)baseStreamResult.AsyncState;
			deflateStreamAsyncResult.m_CompletedSynchronously &= baseStreamResult.CompletedSynchronously;
			try
			{
				this.EnsureNotDisposed();
				int num = this._stream.EndRead(baseStreamResult);
				bool flag = num <= 0;
				if (flag)
				{
					deflateStreamAsyncResult.InvokeCallback(0);
				}
				else
				{
					this.inflater.SetInput(this.buffer, 0, num);
					num = this.inflater.Inflate(deflateStreamAsyncResult.buffer, deflateStreamAsyncResult.offset, deflateStreamAsyncResult.count);
					bool flag2 = num == 0 && !this.inflater.Finished();
					if (flag2)
					{
						this._stream.BeginRead(this.buffer, 0, this.buffer.Length, this.m_CallBack, deflateStreamAsyncResult);
					}
					else
					{
						deflateStreamAsyncResult.InvokeCallback(num);
					}
				}
			}
			catch (Exception result)
			{
				deflateStreamAsyncResult.InvokeCallback(result);
			}
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00007FDC File Offset: 0x000061DC
		public override int EndRead(IAsyncResult asyncResult)
		{
			this.EnsureDecompressionMode();
			this.CheckEndXxxxLegalStateAndParams(asyncResult);
			DeflateStreamAsyncResult deflateStreamAsyncResult = (DeflateStreamAsyncResult)asyncResult;
			this.AwaitAsyncResultCompletion(deflateStreamAsyncResult);
			Exception ex = deflateStreamAsyncResult.Result as Exception;
			bool flag = ex != null;
			if (flag)
			{
				throw ex;
			}
			return (int)deflateStreamAsyncResult.Result;
		}

		// Token: 0x06000033 RID: 51 RVA: 0x000030B4 File Offset: 0x000012B4
		public override void Write(byte[] array, int offset, int count)
		{
			this.EnsureCompressionMode();
			this.ValidateParameters(array, offset, count);
			this.EnsureNotDisposed();
			this.InternalWrite(array, offset, count, false);
		}

		// Token: 0x06000034 RID: 52 RVA: 0x000030DA File Offset: 0x000012DA
		internal void InternalWrite(byte[] array, int offset, int count, bool isAsync)
		{
			this.DoMaintenance(array, offset, count);
			this.WriteDeflaterOutput(isAsync);
			this.deflater.SetInput(array, offset, count);
			this.WriteDeflaterOutput(isAsync);
		}

		// Token: 0x06000035 RID: 53 RVA: 0x00008030 File Offset: 0x00006230
		private void WriteDeflaterOutput(bool isAsync)
		{
			while (!this.deflater.NeedsInput())
			{
				int deflateOutput = this.deflater.GetDeflateOutput(this.buffer);
				bool flag = deflateOutput > 0;
				if (flag)
				{
					this.DoWrite(this.buffer, 0, deflateOutput, isAsync);
				}
			}
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00008080 File Offset: 0x00006280
		private void DoWrite(byte[] array, int offset, int count, bool isAsync)
		{
			if (isAsync)
			{
				IAsyncResult asyncResult = this._stream.BeginWrite(array, offset, count, null, null);
				this._stream.EndWrite(asyncResult);
			}
			else
			{
				this._stream.Write(array, offset, count);
			}
		}

		// Token: 0x06000037 RID: 55 RVA: 0x000080C8 File Offset: 0x000062C8
		private void DoMaintenance(byte[] array, int offset, int count)
		{
			bool flag = count <= 0;
			if (!flag)
			{
				this.wroteBytes = true;
				bool flag2 = this.formatWriter == null;
				if (!flag2)
				{
					bool flag3 = !this.wroteHeader;
					if (flag3)
					{
						byte[] header = this.formatWriter.GetHeader();
						this._stream.Write(header, 0, header.Length);
						this.wroteHeader = true;
					}
					this.formatWriter.UpdateWithBytesRead(array, offset, count);
				}
			}
		}

		// Token: 0x06000038 RID: 56 RVA: 0x0000813C File Offset: 0x0000633C
		private void PurgeBuffers(bool disposing)
		{
			bool flag = !disposing;
			if (!flag)
			{
				bool flag2 = this._stream == null;
				if (!flag2)
				{
					this.Flush();
					bool flag3 = this._mode != CompressionMode.Compress;
					if (!flag3)
					{
						bool flag4 = this.wroteBytes;
						if (flag4)
						{
							this.WriteDeflaterOutput(false);
							bool flag5;
							do
							{
								int num;
								flag5 = this.deflater.Finish(this.buffer, out num);
								bool flag6 = num > 0;
								if (flag6)
								{
									this.DoWrite(this.buffer, 0, num, false);
								}
							}
							while (!flag5);
						}
						bool flag7 = this.formatWriter != null && this.wroteHeader;
						if (flag7)
						{
							byte[] footer = this.formatWriter.GetFooter();
							this._stream.Write(footer, 0, footer.Length);
						}
					}
				}
			}
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00008210 File Offset: 0x00006410
		protected override void Dispose(bool disposing)
		{
			try
			{
				this.PurgeBuffers(disposing);
			}
			finally
			{
				try
				{
					bool flag = disposing && !this._leaveOpen && this._stream != null;
					if (flag)
					{
						this._stream.Dispose();
					}
				}
				finally
				{
					this._stream = null;
					try
					{
						bool flag2 = this.deflater != null;
						if (flag2)
						{
							this.deflater.Dispose();
						}
					}
					finally
					{
						this.deflater = null;
						base.Dispose(disposing);
					}
				}
			}
		}

		// Token: 0x0600003A RID: 58 RVA: 0x000082BC File Offset: 0x000064BC
		public override IAsyncResult BeginWrite(byte[] array, int offset, int count, AsyncCallback asyncCallback, object asyncState)
		{
			this.EnsureCompressionMode();
			bool flag = this.asyncOperations != 0;
			if (flag)
			{
				throw new InvalidOperationException(SR.GetString("Invalid begin call"));
			}
			this.ValidateParameters(array, offset, count);
			this.EnsureNotDisposed();
			Interlocked.Increment(ref this.asyncOperations);
			IAsyncResult result;
			try
			{
				DeflateStreamAsyncResult deflateStreamAsyncResult = new DeflateStreamAsyncResult(this, asyncState, asyncCallback, array, offset, count);
				deflateStreamAsyncResult.isWrite = true;
				this.m_AsyncWriterDelegate.BeginInvoke(array, offset, count, true, this.m_CallBack, deflateStreamAsyncResult);
				deflateStreamAsyncResult.m_CompletedSynchronously &= deflateStreamAsyncResult.IsCompleted;
				result = deflateStreamAsyncResult;
			}
			catch
			{
				Interlocked.Decrement(ref this.asyncOperations);
				throw;
			}
			return result;
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00008370 File Offset: 0x00006570
		private void WriteCallback(IAsyncResult asyncResult)
		{
			DeflateStreamAsyncResult deflateStreamAsyncResult = (DeflateStreamAsyncResult)asyncResult.AsyncState;
			deflateStreamAsyncResult.m_CompletedSynchronously &= asyncResult.CompletedSynchronously;
			try
			{
				this.m_AsyncWriterDelegate.EndInvoke(asyncResult);
			}
			catch (Exception result)
			{
				deflateStreamAsyncResult.InvokeCallback(result);
				return;
			}
			deflateStreamAsyncResult.InvokeCallback(null);
		}

		// Token: 0x0600003C RID: 60 RVA: 0x000083D4 File Offset: 0x000065D4
		public override void EndWrite(IAsyncResult asyncResult)
		{
			this.EnsureCompressionMode();
			this.CheckEndXxxxLegalStateAndParams(asyncResult);
			DeflateStreamAsyncResult deflateStreamAsyncResult = (DeflateStreamAsyncResult)asyncResult;
			this.AwaitAsyncResultCompletion(deflateStreamAsyncResult);
			Exception ex = deflateStreamAsyncResult.Result as Exception;
			bool flag = ex != null;
			if (flag)
			{
				throw ex;
			}
		}

		// Token: 0x0600003D RID: 61 RVA: 0x00008418 File Offset: 0x00006618
		private void CheckEndXxxxLegalStateAndParams(IAsyncResult asyncResult)
		{
			bool flag = this.asyncOperations != 1;
			if (flag)
			{
				throw new InvalidOperationException(SR.GetString("Invalid end call"));
			}
			bool flag2 = asyncResult == null;
			if (flag2)
			{
				throw new ArgumentNullException("asyncResult");
			}
			this.EnsureNotDisposed();
			DeflateStreamAsyncResult deflateStreamAsyncResult = asyncResult as DeflateStreamAsyncResult;
			bool flag3 = deflateStreamAsyncResult == null;
			if (flag3)
			{
				throw new ArgumentNullException("asyncResult");
			}
		}

		// Token: 0x0600003E RID: 62 RVA: 0x0000847C File Offset: 0x0000667C
		private void AwaitAsyncResultCompletion(DeflateStreamAsyncResult asyncResult)
		{
			try
			{
				bool flag = !asyncResult.IsCompleted;
				if (flag)
				{
					asyncResult.AsyncWaitHandle.WaitOne();
				}
			}
			finally
			{
				Interlocked.Decrement(ref this.asyncOperations);
				asyncResult.Close();
			}
		}

		// Token: 0x0400001C RID: 28
		internal const int DefaultBufferSize = 8192;

		// Token: 0x0400001D RID: 29
		private Stream _stream;

		// Token: 0x0400001E RID: 30
		private CompressionMode _mode;

		// Token: 0x0400001F RID: 31
		private bool _leaveOpen;

		// Token: 0x04000020 RID: 32
		private Inflater inflater;

		// Token: 0x04000021 RID: 33
		private IDeflater deflater;

		// Token: 0x04000022 RID: 34
		private byte[] buffer;

		// Token: 0x04000023 RID: 35
		private int asyncOperations;

		// Token: 0x04000024 RID: 36
		private readonly AsyncCallback m_CallBack;

		// Token: 0x04000025 RID: 37
		private readonly DeflateStream.AsyncWriteDelegate m_AsyncWriterDelegate;

		// Token: 0x04000026 RID: 38
		private IFileFormatWriter formatWriter;

		// Token: 0x04000027 RID: 39
		private bool wroteHeader;

		// Token: 0x04000028 RID: 40
		private bool wroteBytes;

		// Token: 0x02000078 RID: 120
		// (Invoke) Token: 0x060005C2 RID: 1474
		internal delegate void AsyncWriteDelegate(byte[] array, int offset, int count, bool isAsync);

		// Token: 0x02000079 RID: 121
		private enum WorkerType : byte
		{
			// Token: 0x040003ED RID: 1005
			Managed,
			// Token: 0x040003EE RID: 1006
			Unknown
		}
	}
}
