﻿using System;

// Token: 0x02000002 RID: 2
internal enum MatchState
{
	// Token: 0x04000002 RID: 2
	HasSymbol = 1,
	// Token: 0x04000003 RID: 3
	HasMatch,
	// Token: 0x04000004 RID: 4
	HasSymbolAndMatch
}
